var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
  __accessCheck(obj, member, "write to private field");
  setter ? setter.call(obj, value) : member.set(obj, value);
  return value;
};
(function() {
  var _data, _listeners, _log_level, _try_interval, _try_limit, _sidemenu_backdrop, _consumer_window, _root, _on;
  "use strict";
  function _mergeNamespaces(n2, m2) {
    for (var i = 0; i < m2.length; i++) {
      const e2 = m2[i];
      if (typeof e2 !== "string" && !Array.isArray(e2)) {
        for (const k2 in e2) {
          if (k2 !== "default" && !(k2 in n2)) {
            const d2 = Object.getOwnPropertyDescriptor(e2, k2);
            if (d2) {
              Object.defineProperty(n2, k2, d2.get ? d2 : {
                enumerable: true,
                get: () => e2[k2]
              });
            }
          }
        }
      }
    }
    return Object.freeze(Object.defineProperty(n2, Symbol.toStringTag, { value: "Module" }));
  }
  const _Preferences = class {
    static notify(fy) {
      const before = new Preference(__privateGet(this, _data).toJSON());
      fy(__privateGet(this, _data));
      for (const l2 of __privateGet(this, _listeners))
        l2(before, __privateGet(this, _data));
    }
    static get log_level() {
      return __privateGet(this, _data).log_level;
    }
    static set log_level(v2) {
      if (__privateGet(this, _data).log_level !== v2)
        this.notify((p2) => p2.log_level = v2);
    }
    static get try_interval() {
      return __privateGet(this, _data).try_interval;
    }
    static set try_interval(v2) {
      if (__privateGet(this, _data).try_interval !== v2)
        this.notify((p2) => p2.try_interval = v2);
    }
    static get try_limit() {
      return __privateGet(this, _data).try_limit;
    }
    static set try_limit(v2) {
      if (__privateGet(this, _data).try_limit !== v2)
        this.notify((p2) => p2.try_limit = v2);
    }
    static get sidemenu_backdrop() {
      return __privateGet(this, _data).sidemenu_backdrop;
    }
    static set sidemenu_backdrop(v2) {
      if (__privateGet(this, _data).sidemenu_backdrop !== v2)
        this.notify((p2) => p2.sidemenu_backdrop = v2);
    }
    static get consumer_window() {
      return __privateGet(this, _data).consumer_window;
    }
    static set consumer_window(v2) {
      if (__privateGet(this, _data).consumer_window !== v2)
        this.notify((p2) => p2.consumer_window = v2);
    }
  };
  let Preferences = _Preferences;
  _data = new WeakMap();
  _listeners = new WeakMap();
  __privateAdd(Preferences, _data, void 0);
  __privateAdd(Preferences, _listeners, []);
  __publicField(Preferences, "init", async () => {
    if (__privateGet(_Preferences, _data))
      return;
    __privateSet(_Preferences, _data, new Preference(await chrome.storage.local.get(null)));
    await _Preferences.save();
  });
  __publicField(Preferences, "save", async () => {
    await chrome.storage.local.clear();
    await chrome.storage.local.set(__privateGet(_Preferences, _data).toJSON());
  });
  __publicField(Preferences, "str", () => {
    return JSON.stringify(__privateGet(_Preferences, _data));
  });
  __publicField(Preferences, "addListener", (l2) => {
    if (!__privateGet(_Preferences, _listeners).includes(l2))
      __privateGet(_Preferences, _listeners).push(l2);
  });
  __publicField(Preferences, "removeListener", (l2) => {
    __privateSet(_Preferences, _listeners, __privateGet(_Preferences, _listeners).filter((ll2) => ll2 !== l2));
  });
  class Preference {
    constructor(json) {
      __privateAdd(this, _log_level, void 0);
      __privateAdd(this, _try_interval, void 0);
      __privateAdd(this, _try_limit, void 0);
      __privateAdd(this, _sidemenu_backdrop, void 0);
      __privateAdd(this, _consumer_window, void 0);
      const d2 = (key, val, def) => {
        try {
          this[key] = val || def;
        } catch {
          this[key] = def;
        }
      };
      d2("log_level", json.log_level, "INFO");
      d2("try_interval", json.try_interval, 250);
      d2("try_limit", json.try_limit, 40);
      d2("sidemenu_backdrop", json.sidemenu_backdrop, false);
      d2("consumer_window", json.consumer_window, false);
    }
    get toJSON() {
      return () => ({
        log_level: __privateGet(this, _log_level),
        try_interval: __privateGet(this, _try_interval),
        try_limit: __privateGet(this, _try_limit),
        sidemenu_backdrop: __privateGet(this, _sidemenu_backdrop),
        consumer_window: __privateGet(this, _consumer_window)
      });
    }
    get log_level() {
      return __privateGet(this, _log_level);
    }
    set log_level(v2) {
      if (typeof v2 !== "string" || !Logger.level.is(v2)) {
        throw new TypeError(`Preference.log_level accepts only ${Logger.level.summary}: ${v2}`);
      }
      __privateSet(this, _log_level, v2);
    }
    get try_interval() {
      return __privateGet(this, _try_interval);
    }
    set try_interval(v2) {
      const e2 = `Preference.try_interval accepts only positive integers: ${v2}`;
      if (!Number.isSafeInteger(v2)) {
        throw new TypeError(e2);
      } else if (v2 < 1) {
        throw new RangeError(e2);
      }
      __privateSet(this, _try_interval, v2);
    }
    get try_limit() {
      return __privateGet(this, _try_limit);
    }
    set try_limit(v2) {
      const e2 = `Preference.try_limit accepts only positive integers: ${v2}`;
      if (!Number.isSafeInteger(v2)) {
        throw new TypeError(e2);
      } else if (v2 < 1) {
        throw new RangeError(e2);
      }
      __privateSet(this, _try_limit, v2);
    }
    get sidemenu_backdrop() {
      return __privateGet(this, _sidemenu_backdrop);
    }
    set sidemenu_backdrop(v2) {
      if (typeof v2 !== "boolean") {
        throw new TypeError(`Preference.sidemenu_backdrop accepts only boolean: ${v2}`);
      }
      __privateSet(this, _sidemenu_backdrop, v2);
    }
    get consumer_window() {
      return __privateGet(this, _consumer_window);
    }
    set consumer_window(v2) {
      if (typeof v2 !== "boolean") {
        throw new TypeError(`Preference.consumer_window accepts only boolean: ${v2}`);
      }
      __privateSet(this, _consumer_window, v2);
    }
  }
  _log_level = new WeakMap();
  _try_interval = new WeakMap();
  _try_limit = new WeakMap();
  _sidemenu_backdrop = new WeakMap();
  _consumer_window = new WeakMap();
  const _Logger = class {
    static log(level) {
      const fulfilled = this.table[Preferences.log_level] <= this.table[level];
      return fulfilled ? console.log.bind(console, "\u{1F44F}", `[${level}]`) : () => void 0;
    }
    static get debug() {
      return this.log("DEBUG");
    }
    static get info() {
      return this.log("INFO");
    }
    static get warn() {
      return this.log("WARN");
    }
    static get error() {
      return this.log("ERROR");
    }
    static get fatal() {
      return this.log("FATAL");
    }
  };
  let Logger = _Logger;
  __publicField(Logger, "levels", ["DEBUG", "INFO", "WARN", "ERROR", "FATAL"]);
  __publicField(Logger, "table", { DEBUG: 1, INFO: 2, WARN: 3, ERROR: 4, FATAL: 5 });
  __publicField(Logger, "level", {
    is: (str) => {
      return str in _Logger.table;
    },
    summary: _Logger.levels.join(", ")
  });
  class JSONRPC {
  }
  __publicField(JSONRPC, "call", async (url, method, id2, params, headers) => {
    const request = new Request(url, {
      method: "POST",
      headers: {
        ...headers,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method,
        id: id2,
        params
      })
    });
    const res = await fetch(request).then((res2) => res2.json());
    res.status = res.error ? "failed" : "success";
    return res;
  });
  const _UniposAPI = class {
    static get accessToken() {
      const token2 = window.localStorage.getItem("authnToken");
      if (!token2)
        throw new ReferenceError("Access token not found.");
      return token2;
    }
    static set accessToken(v2) {
      window.localStorage.setItem("authnToken", v2);
    }
    static get refreshToken() {
      const token2 = window.localStorage.getItem("refreshToken");
      if (!token2)
        throw new ReferenceError("Refresh token not found.");
      return token2;
    }
    static set refreshToken(v2) {
      window.localStorage.setItem("refreshToken", v2);
    }
    static get ready() {
      try {
        return this.accessToken !== this.refreshToken;
      } catch (error) {
        return false;
      }
    }
    static tokens() {
      return this.call("Unipos.RefreshToken", null, { authn_token: this.accessToken, refresh_token: this.refreshToken }, false);
    }
    static async call(method, id2, params, refresh = true) {
      const url = "https://unipos.me/jsonrpc?method=" + method;
      const call = (token2) => JSONRPC.call(url, method, id2 || method, params, { "x-unipos-token": token2 });
      const res1 = await call(this.accessToken);
      if (res1.status === "success")
        return res1;
      else if (res1.error.code !== -4e4 || !refresh)
        throw new Error(JSON.stringify(res1.error));
      const tokens = await this.tokens();
      this.accessToken = tokens.result.authn_token;
      this.refreshToken = tokens.result.refresh_token;
      const res2 = await call(tokens.result.authn_token);
      if (res2.status === "success")
        return res2;
      else
        throw new Error(JSON.stringify(res2.error));
    }
  };
  let UniposAPI = _UniposAPI;
  __publicField(UniposAPI, "MAX_PRAISE_COUNT", 60);
  (() => {
    window.UniposAPI = _UniposAPI;
  })();
  __publicField(UniposAPI, "getProfile", () => {
    return _UniposAPI.call("Unipos.GetProfile", null, {});
  });
  __publicField(UniposAPI, "getMembersByNameWithFuzzySearch", (name, limit = 20) => {
    return _UniposAPI.call("Unipos.GetMembersByNameWithFuzzySearch", null, { name, limit });
  });
  __publicField(UniposAPI, "getCard", (card_id) => {
    return _UniposAPI.call("Unipos.GetCard2", null, { id: card_id });
  });
  __publicField(UniposAPI, "getCards", (count, offset_card_id, options) => {
    return _UniposAPI.call("Unipos.GetCards2", null, {
      ...options,
      count,
      offset_card_id: offset_card_id || ""
    });
  });
  __publicField(UniposAPI, "praise", (card_id, count) => {
    const method = "Unipos.Praise";
    const id2 = [method, card_id, count].join("_");
    return _UniposAPI.call(method, id2, { card_id, count });
  });
  __publicField(UniposAPI, "extractCardIdFromCardLink", (url) => {
    const match2 = url.match(_UniposAPI.CARD_LINK_REGEX);
    return match2 && match2.length > 1 ? match2[1] : void 0;
  });
  __publicField(UniposAPI, "CARD_LINK_REGEX", new RegExp(
    "^https://unipos.me/cards/([a-zA-Z0-9]{8}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{12})($|\\?.*$)"
  ));
  function getDefaultExportFromCjs(x2) {
    return x2 && x2.__esModule && Object.prototype.hasOwnProperty.call(x2, "default") ? x2["default"] : x2;
  }
  function getAugmentedNamespace(n2) {
    var f2 = n2.default;
    if (typeof f2 == "function") {
      var a = function() {
        return f2.apply(this, arguments);
      };
      a.prototype = f2.prototype;
    } else
      a = {};
    Object.defineProperty(a, "__esModule", { value: true });
    Object.keys(n2).forEach(function(k2) {
      var d2 = Object.getOwnPropertyDescriptor(n2, k2);
      Object.defineProperty(a, k2, d2.get ? d2 : {
        enumerable: true,
        get: function() {
          return n2[k2];
        }
      });
    });
    return a;
  }
  var react = { exports: {} };
  var react_production_min = {};
  /**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var l$3 = Symbol.for("react.element"), n$3 = Symbol.for("react.portal"), p$4 = Symbol.for("react.fragment"), q$3 = Symbol.for("react.strict_mode"), r$2 = Symbol.for("react.profiler"), t$2 = Symbol.for("react.provider"), u$1 = Symbol.for("react.context"), v$3 = Symbol.for("react.forward_ref"), w$1 = Symbol.for("react.suspense"), x$1 = Symbol.for("react.memo"), y$1 = Symbol.for("react.lazy"), z$2 = Symbol.iterator;
  function A$2(a) {
    if (null === a || "object" !== typeof a)
      return null;
    a = z$2 && a[z$2] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var B$1 = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, C$1 = Object.assign, D$1 = {};
  function E$1(a, b2, e2) {
    this.props = a;
    this.context = b2;
    this.refs = D$1;
    this.updater = e2 || B$1;
  }
  E$1.prototype.isReactComponent = {};
  E$1.prototype.setState = function(a, b2) {
    if ("object" !== typeof a && "function" !== typeof a && null != a)
      throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, a, b2, "setState");
  };
  E$1.prototype.forceUpdate = function(a) {
    this.updater.enqueueForceUpdate(this, a, "forceUpdate");
  };
  function F() {
  }
  F.prototype = E$1.prototype;
  function G$1(a, b2, e2) {
    this.props = a;
    this.context = b2;
    this.refs = D$1;
    this.updater = e2 || B$1;
  }
  var H$1 = G$1.prototype = new F();
  H$1.constructor = G$1;
  C$1(H$1, E$1.prototype);
  H$1.isPureReactComponent = true;
  var I$1 = Array.isArray, J = Object.prototype.hasOwnProperty, K$1 = { current: null }, L$1 = { key: true, ref: true, __self: true, __source: true };
  function M$1(a, b2, e2) {
    var d2, c2 = {}, k2 = null, h2 = null;
    if (null != b2)
      for (d2 in void 0 !== b2.ref && (h2 = b2.ref), void 0 !== b2.key && (k2 = "" + b2.key), b2)
        J.call(b2, d2) && !L$1.hasOwnProperty(d2) && (c2[d2] = b2[d2]);
    var g2 = arguments.length - 2;
    if (1 === g2)
      c2.children = e2;
    else if (1 < g2) {
      for (var f2 = Array(g2), m2 = 0; m2 < g2; m2++)
        f2[m2] = arguments[m2 + 2];
      c2.children = f2;
    }
    if (a && a.defaultProps)
      for (d2 in g2 = a.defaultProps, g2)
        void 0 === c2[d2] && (c2[d2] = g2[d2]);
    return { $$typeof: l$3, type: a, key: k2, ref: h2, props: c2, _owner: K$1.current };
  }
  function N$1(a, b2) {
    return { $$typeof: l$3, type: a.type, key: b2, ref: a.ref, props: a.props, _owner: a._owner };
  }
  function O$1(a) {
    return "object" === typeof a && null !== a && a.$$typeof === l$3;
  }
  function escape(a) {
    var b2 = { "=": "=0", ":": "=2" };
    return "$" + a.replace(/[=:]/g, function(a2) {
      return b2[a2];
    });
  }
  var P$1 = /\/+/g;
  function Q$1(a, b2) {
    return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b2.toString(36);
  }
  function R$1(a, b2, e2, d2, c2) {
    var k2 = typeof a;
    if ("undefined" === k2 || "boolean" === k2)
      a = null;
    var h2 = false;
    if (null === a)
      h2 = true;
    else
      switch (k2) {
        case "string":
        case "number":
          h2 = true;
          break;
        case "object":
          switch (a.$$typeof) {
            case l$3:
            case n$3:
              h2 = true;
          }
      }
    if (h2)
      return h2 = a, c2 = c2(h2), a = "" === d2 ? "." + Q$1(h2, 0) : d2, I$1(c2) ? (e2 = "", null != a && (e2 = a.replace(P$1, "$&/") + "/"), R$1(c2, b2, e2, "", function(a2) {
        return a2;
      })) : null != c2 && (O$1(c2) && (c2 = N$1(c2, e2 + (!c2.key || h2 && h2.key === c2.key ? "" : ("" + c2.key).replace(P$1, "$&/") + "/") + a)), b2.push(c2)), 1;
    h2 = 0;
    d2 = "" === d2 ? "." : d2 + ":";
    if (I$1(a))
      for (var g2 = 0; g2 < a.length; g2++) {
        k2 = a[g2];
        var f2 = d2 + Q$1(k2, g2);
        h2 += R$1(k2, b2, e2, f2, c2);
      }
    else if (f2 = A$2(a), "function" === typeof f2)
      for (a = f2.call(a), g2 = 0; !(k2 = a.next()).done; )
        k2 = k2.value, f2 = d2 + Q$1(k2, g2++), h2 += R$1(k2, b2, e2, f2, c2);
    else if ("object" === k2)
      throw b2 = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b2 ? "object with keys {" + Object.keys(a).join(", ") + "}" : b2) + "). If you meant to render a collection of children, use an array instead.");
    return h2;
  }
  function S$1(a, b2, e2) {
    if (null == a)
      return a;
    var d2 = [], c2 = 0;
    R$1(a, d2, "", "", function(a2) {
      return b2.call(e2, a2, c2++);
    });
    return d2;
  }
  function T$1(a) {
    if (-1 === a._status) {
      var b2 = a._result;
      b2 = b2();
      b2.then(function(b3) {
        if (0 === a._status || -1 === a._status)
          a._status = 1, a._result = b3;
      }, function(b3) {
        if (0 === a._status || -1 === a._status)
          a._status = 2, a._result = b3;
      });
      -1 === a._status && (a._status = 0, a._result = b2);
    }
    if (1 === a._status)
      return a._result.default;
    throw a._result;
  }
  var U$1 = { current: null }, V$1 = { transition: null }, W$1 = { ReactCurrentDispatcher: U$1, ReactCurrentBatchConfig: V$1, ReactCurrentOwner: K$1 };
  react_production_min.Children = { map: S$1, forEach: function(a, b2, e2) {
    S$1(a, function() {
      b2.apply(this, arguments);
    }, e2);
  }, count: function(a) {
    var b2 = 0;
    S$1(a, function() {
      b2++;
    });
    return b2;
  }, toArray: function(a) {
    return S$1(a, function(a2) {
      return a2;
    }) || [];
  }, only: function(a) {
    if (!O$1(a))
      throw Error("React.Children.only expected to receive a single React element child.");
    return a;
  } };
  react_production_min.Component = E$1;
  react_production_min.Fragment = p$4;
  react_production_min.Profiler = r$2;
  react_production_min.PureComponent = G$1;
  react_production_min.StrictMode = q$3;
  react_production_min.Suspense = w$1;
  react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W$1;
  react_production_min.cloneElement = function(a, b2, e2) {
    if (null === a || void 0 === a)
      throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
    var d2 = C$1({}, a.props), c2 = a.key, k2 = a.ref, h2 = a._owner;
    if (null != b2) {
      void 0 !== b2.ref && (k2 = b2.ref, h2 = K$1.current);
      void 0 !== b2.key && (c2 = "" + b2.key);
      if (a.type && a.type.defaultProps)
        var g2 = a.type.defaultProps;
      for (f2 in b2)
        J.call(b2, f2) && !L$1.hasOwnProperty(f2) && (d2[f2] = void 0 === b2[f2] && void 0 !== g2 ? g2[f2] : b2[f2]);
    }
    var f2 = arguments.length - 2;
    if (1 === f2)
      d2.children = e2;
    else if (1 < f2) {
      g2 = Array(f2);
      for (var m2 = 0; m2 < f2; m2++)
        g2[m2] = arguments[m2 + 2];
      d2.children = g2;
    }
    return { $$typeof: l$3, type: a.type, key: c2, ref: k2, props: d2, _owner: h2 };
  };
  react_production_min.createContext = function(a) {
    a = { $$typeof: u$1, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
    a.Provider = { $$typeof: t$2, _context: a };
    return a.Consumer = a;
  };
  react_production_min.createElement = M$1;
  react_production_min.createFactory = function(a) {
    var b2 = M$1.bind(null, a);
    b2.type = a;
    return b2;
  };
  react_production_min.createRef = function() {
    return { current: null };
  };
  react_production_min.forwardRef = function(a) {
    return { $$typeof: v$3, render: a };
  };
  react_production_min.isValidElement = O$1;
  react_production_min.lazy = function(a) {
    return { $$typeof: y$1, _payload: { _status: -1, _result: a }, _init: T$1 };
  };
  react_production_min.memo = function(a, b2) {
    return { $$typeof: x$1, type: a, compare: void 0 === b2 ? null : b2 };
  };
  react_production_min.startTransition = function(a) {
    var b2 = V$1.transition;
    V$1.transition = {};
    try {
      a();
    } finally {
      V$1.transition = b2;
    }
  };
  react_production_min.unstable_act = function() {
    throw Error("act(...) is not supported in production builds of React.");
  };
  react_production_min.useCallback = function(a, b2) {
    return U$1.current.useCallback(a, b2);
  };
  react_production_min.useContext = function(a) {
    return U$1.current.useContext(a);
  };
  react_production_min.useDebugValue = function() {
  };
  react_production_min.useDeferredValue = function(a) {
    return U$1.current.useDeferredValue(a);
  };
  react_production_min.useEffect = function(a, b2) {
    return U$1.current.useEffect(a, b2);
  };
  react_production_min.useId = function() {
    return U$1.current.useId();
  };
  react_production_min.useImperativeHandle = function(a, b2, e2) {
    return U$1.current.useImperativeHandle(a, b2, e2);
  };
  react_production_min.useInsertionEffect = function(a, b2) {
    return U$1.current.useInsertionEffect(a, b2);
  };
  react_production_min.useLayoutEffect = function(a, b2) {
    return U$1.current.useLayoutEffect(a, b2);
  };
  react_production_min.useMemo = function(a, b2) {
    return U$1.current.useMemo(a, b2);
  };
  react_production_min.useReducer = function(a, b2, e2) {
    return U$1.current.useReducer(a, b2, e2);
  };
  react_production_min.useRef = function(a) {
    return U$1.current.useRef(a);
  };
  react_production_min.useState = function(a) {
    return U$1.current.useState(a);
  };
  react_production_min.useSyncExternalStore = function(a, b2, e2) {
    return U$1.current.useSyncExternalStore(a, b2, e2);
  };
  react_production_min.useTransition = function() {
    return U$1.current.useTransition();
  };
  react_production_min.version = "18.2.0";
  (function(module) {
    {
      module.exports = react_production_min;
    }
  })(react);
  const React$1 = /* @__PURE__ */ getDefaultExportFromCjs(react.exports);
  const React$2 = /* @__PURE__ */ _mergeNamespaces({
    __proto__: null,
    default: React$1
  }, [react.exports]);
  var reactDom = { exports: {} };
  var reactDom_production_min = {};
  var scheduler = { exports: {} };
  var scheduler_production_min = {};
  /**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  (function(exports) {
    function f2(a, b2) {
      var c2 = a.length;
      a.push(b2);
      a:
        for (; 0 < c2; ) {
          var d2 = c2 - 1 >>> 1, e2 = a[d2];
          if (0 < g2(e2, b2))
            a[d2] = b2, a[c2] = e2, c2 = d2;
          else
            break a;
        }
    }
    function h2(a) {
      return 0 === a.length ? null : a[0];
    }
    function k2(a) {
      if (0 === a.length)
        return null;
      var b2 = a[0], c2 = a.pop();
      if (c2 !== b2) {
        a[0] = c2;
        a:
          for (var d2 = 0, e2 = a.length, w2 = e2 >>> 1; d2 < w2; ) {
            var m2 = 2 * (d2 + 1) - 1, C2 = a[m2], n2 = m2 + 1, x2 = a[n2];
            if (0 > g2(C2, c2))
              n2 < e2 && 0 > g2(x2, C2) ? (a[d2] = x2, a[n2] = c2, d2 = n2) : (a[d2] = C2, a[m2] = c2, d2 = m2);
            else if (n2 < e2 && 0 > g2(x2, c2))
              a[d2] = x2, a[n2] = c2, d2 = n2;
            else
              break a;
          }
      }
      return b2;
    }
    function g2(a, b2) {
      var c2 = a.sortIndex - b2.sortIndex;
      return 0 !== c2 ? c2 : a.id - b2.id;
    }
    if ("object" === typeof performance && "function" === typeof performance.now) {
      var l2 = performance;
      exports.unstable_now = function() {
        return l2.now();
      };
    } else {
      var p2 = Date, q2 = p2.now();
      exports.unstable_now = function() {
        return p2.now() - q2;
      };
    }
    var r2 = [], t2 = [], u2 = 1, v2 = null, y2 = 3, z2 = false, A2 = false, B2 = false, D2 = "function" === typeof setTimeout ? setTimeout : null, E2 = "function" === typeof clearTimeout ? clearTimeout : null, F2 = "undefined" !== typeof setImmediate ? setImmediate : null;
    "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function G2(a) {
      for (var b2 = h2(t2); null !== b2; ) {
        if (null === b2.callback)
          k2(t2);
        else if (b2.startTime <= a)
          k2(t2), b2.sortIndex = b2.expirationTime, f2(r2, b2);
        else
          break;
        b2 = h2(t2);
      }
    }
    function H2(a) {
      B2 = false;
      G2(a);
      if (!A2)
        if (null !== h2(r2))
          A2 = true, I2(J2);
        else {
          var b2 = h2(t2);
          null !== b2 && K2(H2, b2.startTime - a);
        }
    }
    function J2(a, b2) {
      A2 = false;
      B2 && (B2 = false, E2(L2), L2 = -1);
      z2 = true;
      var c2 = y2;
      try {
        G2(b2);
        for (v2 = h2(r2); null !== v2 && (!(v2.expirationTime > b2) || a && !M2()); ) {
          var d2 = v2.callback;
          if ("function" === typeof d2) {
            v2.callback = null;
            y2 = v2.priorityLevel;
            var e2 = d2(v2.expirationTime <= b2);
            b2 = exports.unstable_now();
            "function" === typeof e2 ? v2.callback = e2 : v2 === h2(r2) && k2(r2);
            G2(b2);
          } else
            k2(r2);
          v2 = h2(r2);
        }
        if (null !== v2)
          var w2 = true;
        else {
          var m2 = h2(t2);
          null !== m2 && K2(H2, m2.startTime - b2);
          w2 = false;
        }
        return w2;
      } finally {
        v2 = null, y2 = c2, z2 = false;
      }
    }
    var N2 = false, O2 = null, L2 = -1, P2 = 5, Q2 = -1;
    function M2() {
      return exports.unstable_now() - Q2 < P2 ? false : true;
    }
    function R2() {
      if (null !== O2) {
        var a = exports.unstable_now();
        Q2 = a;
        var b2 = true;
        try {
          b2 = O2(true, a);
        } finally {
          b2 ? S2() : (N2 = false, O2 = null);
        }
      } else
        N2 = false;
    }
    var S2;
    if ("function" === typeof F2)
      S2 = function() {
        F2(R2);
      };
    else if ("undefined" !== typeof MessageChannel) {
      var T2 = new MessageChannel(), U2 = T2.port2;
      T2.port1.onmessage = R2;
      S2 = function() {
        U2.postMessage(null);
      };
    } else
      S2 = function() {
        D2(R2, 0);
      };
    function I2(a) {
      O2 = a;
      N2 || (N2 = true, S2());
    }
    function K2(a, b2) {
      L2 = D2(function() {
        a(exports.unstable_now());
      }, b2);
    }
    exports.unstable_IdlePriority = 5;
    exports.unstable_ImmediatePriority = 1;
    exports.unstable_LowPriority = 4;
    exports.unstable_NormalPriority = 3;
    exports.unstable_Profiling = null;
    exports.unstable_UserBlockingPriority = 2;
    exports.unstable_cancelCallback = function(a) {
      a.callback = null;
    };
    exports.unstable_continueExecution = function() {
      A2 || z2 || (A2 = true, I2(J2));
    };
    exports.unstable_forceFrameRate = function(a) {
      0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P2 = 0 < a ? Math.floor(1e3 / a) : 5;
    };
    exports.unstable_getCurrentPriorityLevel = function() {
      return y2;
    };
    exports.unstable_getFirstCallbackNode = function() {
      return h2(r2);
    };
    exports.unstable_next = function(a) {
      switch (y2) {
        case 1:
        case 2:
        case 3:
          var b2 = 3;
          break;
        default:
          b2 = y2;
      }
      var c2 = y2;
      y2 = b2;
      try {
        return a();
      } finally {
        y2 = c2;
      }
    };
    exports.unstable_pauseExecution = function() {
    };
    exports.unstable_requestPaint = function() {
    };
    exports.unstable_runWithPriority = function(a, b2) {
      switch (a) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          a = 3;
      }
      var c2 = y2;
      y2 = a;
      try {
        return b2();
      } finally {
        y2 = c2;
      }
    };
    exports.unstable_scheduleCallback = function(a, b2, c2) {
      var d2 = exports.unstable_now();
      "object" === typeof c2 && null !== c2 ? (c2 = c2.delay, c2 = "number" === typeof c2 && 0 < c2 ? d2 + c2 : d2) : c2 = d2;
      switch (a) {
        case 1:
          var e2 = -1;
          break;
        case 2:
          e2 = 250;
          break;
        case 5:
          e2 = 1073741823;
          break;
        case 4:
          e2 = 1e4;
          break;
        default:
          e2 = 5e3;
      }
      e2 = c2 + e2;
      a = { id: u2++, callback: b2, priorityLevel: a, startTime: c2, expirationTime: e2, sortIndex: -1 };
      c2 > d2 ? (a.sortIndex = c2, f2(t2, a), null === h2(r2) && a === h2(t2) && (B2 ? (E2(L2), L2 = -1) : B2 = true, K2(H2, c2 - d2))) : (a.sortIndex = e2, f2(r2, a), A2 || z2 || (A2 = true, I2(J2)));
      return a;
    };
    exports.unstable_shouldYield = M2;
    exports.unstable_wrapCallback = function(a) {
      var b2 = y2;
      return function() {
        var c2 = y2;
        y2 = b2;
        try {
          return a.apply(this, arguments);
        } finally {
          y2 = c2;
        }
      };
    };
  })(scheduler_production_min);
  (function(module) {
    {
      module.exports = scheduler_production_min;
    }
  })(scheduler);
  /**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var aa = react.exports, ca = scheduler.exports;
  function p$3(a) {
    for (var b2 = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c2 = 1; c2 < arguments.length; c2++)
      b2 += "&args[]=" + encodeURIComponent(arguments[c2]);
    return "Minified React error #" + a + "; visit " + b2 + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  var da = /* @__PURE__ */ new Set(), ea = {};
  function fa(a, b2) {
    ha(a, b2);
    ha(a + "Capture", b2);
  }
  function ha(a, b2) {
    ea[a] = b2;
    for (a = 0; a < b2.length; a++)
      da.add(b2[a]);
  }
  var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement), ja = Object.prototype.hasOwnProperty, ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, la = {}, ma = {};
  function oa(a) {
    if (ja.call(ma, a))
      return true;
    if (ja.call(la, a))
      return false;
    if (ka.test(a))
      return ma[a] = true;
    la[a] = true;
    return false;
  }
  function pa(a, b2, c2, d2) {
    if (null !== c2 && 0 === c2.type)
      return false;
    switch (typeof b2) {
      case "function":
      case "symbol":
        return true;
      case "boolean":
        if (d2)
          return false;
        if (null !== c2)
          return !c2.acceptsBooleans;
        a = a.toLowerCase().slice(0, 5);
        return "data-" !== a && "aria-" !== a;
      default:
        return false;
    }
  }
  function qa(a, b2, c2, d2) {
    if (null === b2 || "undefined" === typeof b2 || pa(a, b2, c2, d2))
      return true;
    if (d2)
      return false;
    if (null !== c2)
      switch (c2.type) {
        case 3:
          return !b2;
        case 4:
          return false === b2;
        case 5:
          return isNaN(b2);
        case 6:
          return isNaN(b2) || 1 > b2;
      }
    return false;
  }
  function v$2(a, b2, c2, d2, e2, f2, g2) {
    this.acceptsBooleans = 2 === b2 || 3 === b2 || 4 === b2;
    this.attributeName = d2;
    this.attributeNamespace = e2;
    this.mustUseProperty = c2;
    this.propertyName = a;
    this.type = b2;
    this.sanitizeURL = f2;
    this.removeEmptyString = g2;
  }
  var z$1 = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
    z$1[a] = new v$2(a, 0, false, a, null, false, false);
  });
  [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
    var b2 = a[0];
    z$1[b2] = new v$2(b2, 1, false, a[1], null, false, false);
  });
  ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
    z$1[a] = new v$2(a, 2, false, a.toLowerCase(), null, false, false);
  });
  ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
    z$1[a] = new v$2(a, 2, false, a, null, false, false);
  });
  "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
    z$1[a] = new v$2(a, 3, false, a.toLowerCase(), null, false, false);
  });
  ["checked", "multiple", "muted", "selected"].forEach(function(a) {
    z$1[a] = new v$2(a, 3, true, a, null, false, false);
  });
  ["capture", "download"].forEach(function(a) {
    z$1[a] = new v$2(a, 4, false, a, null, false, false);
  });
  ["cols", "rows", "size", "span"].forEach(function(a) {
    z$1[a] = new v$2(a, 6, false, a, null, false, false);
  });
  ["rowSpan", "start"].forEach(function(a) {
    z$1[a] = new v$2(a, 5, false, a.toLowerCase(), null, false, false);
  });
  var ra = /[\-:]([a-z])/g;
  function sa(a) {
    return a[1].toUpperCase();
  }
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
    var b2 = a.replace(
      ra,
      sa
    );
    z$1[b2] = new v$2(b2, 1, false, a, null, false, false);
  });
  "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
    var b2 = a.replace(ra, sa);
    z$1[b2] = new v$2(b2, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
  });
  ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
    var b2 = a.replace(ra, sa);
    z$1[b2] = new v$2(b2, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
  });
  ["tabIndex", "crossOrigin"].forEach(function(a) {
    z$1[a] = new v$2(a, 1, false, a.toLowerCase(), null, false, false);
  });
  z$1.xlinkHref = new v$2("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
  ["src", "href", "action", "formAction"].forEach(function(a) {
    z$1[a] = new v$2(a, 1, false, a.toLowerCase(), null, true, true);
  });
  function ta(a, b2, c2, d2) {
    var e2 = z$1.hasOwnProperty(b2) ? z$1[b2] : null;
    if (null !== e2 ? 0 !== e2.type : d2 || !(2 < b2.length) || "o" !== b2[0] && "O" !== b2[0] || "n" !== b2[1] && "N" !== b2[1])
      qa(b2, c2, e2, d2) && (c2 = null), d2 || null === e2 ? oa(b2) && (null === c2 ? a.removeAttribute(b2) : a.setAttribute(b2, "" + c2)) : e2.mustUseProperty ? a[e2.propertyName] = null === c2 ? 3 === e2.type ? false : "" : c2 : (b2 = e2.attributeName, d2 = e2.attributeNamespace, null === c2 ? a.removeAttribute(b2) : (e2 = e2.type, c2 = 3 === e2 || 4 === e2 && true === c2 ? "" : "" + c2, d2 ? a.setAttributeNS(d2, b2, c2) : a.setAttribute(b2, c2)));
  }
  var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, va = Symbol.for("react.element"), wa = Symbol.for("react.portal"), ya = Symbol.for("react.fragment"), za = Symbol.for("react.strict_mode"), Aa = Symbol.for("react.profiler"), Ba = Symbol.for("react.provider"), Ca = Symbol.for("react.context"), Da = Symbol.for("react.forward_ref"), Ea = Symbol.for("react.suspense"), Fa = Symbol.for("react.suspense_list"), Ga = Symbol.for("react.memo"), Ha = Symbol.for("react.lazy");
  var Ia = Symbol.for("react.offscreen");
  var Ja = Symbol.iterator;
  function Ka(a) {
    if (null === a || "object" !== typeof a)
      return null;
    a = Ja && a[Ja] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var A$1 = Object.assign, La;
  function Ma(a) {
    if (void 0 === La)
      try {
        throw Error();
      } catch (c2) {
        var b2 = c2.stack.trim().match(/\n( *(at )?)/);
        La = b2 && b2[1] || "";
      }
    return "\n" + La + a;
  }
  var Na = false;
  function Oa(a, b2) {
    if (!a || Na)
      return "";
    Na = true;
    var c2 = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (b2)
        if (b2 = function() {
          throw Error();
        }, Object.defineProperty(b2.prototype, "props", { set: function() {
          throw Error();
        } }), "object" === typeof Reflect && Reflect.construct) {
          try {
            Reflect.construct(b2, []);
          } catch (l2) {
            var d2 = l2;
          }
          Reflect.construct(a, [], b2);
        } else {
          try {
            b2.call();
          } catch (l2) {
            d2 = l2;
          }
          a.call(b2.prototype);
        }
      else {
        try {
          throw Error();
        } catch (l2) {
          d2 = l2;
        }
        a();
      }
    } catch (l2) {
      if (l2 && d2 && "string" === typeof l2.stack) {
        for (var e2 = l2.stack.split("\n"), f2 = d2.stack.split("\n"), g2 = e2.length - 1, h2 = f2.length - 1; 1 <= g2 && 0 <= h2 && e2[g2] !== f2[h2]; )
          h2--;
        for (; 1 <= g2 && 0 <= h2; g2--, h2--)
          if (e2[g2] !== f2[h2]) {
            if (1 !== g2 || 1 !== h2) {
              do
                if (g2--, h2--, 0 > h2 || e2[g2] !== f2[h2]) {
                  var k2 = "\n" + e2[g2].replace(" at new ", " at ");
                  a.displayName && k2.includes("<anonymous>") && (k2 = k2.replace("<anonymous>", a.displayName));
                  return k2;
                }
              while (1 <= g2 && 0 <= h2);
            }
            break;
          }
      }
    } finally {
      Na = false, Error.prepareStackTrace = c2;
    }
    return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
  }
  function Pa(a) {
    switch (a.tag) {
      case 5:
        return Ma(a.type);
      case 16:
        return Ma("Lazy");
      case 13:
        return Ma("Suspense");
      case 19:
        return Ma("SuspenseList");
      case 0:
      case 2:
      case 15:
        return a = Oa(a.type, false), a;
      case 11:
        return a = Oa(a.type.render, false), a;
      case 1:
        return a = Oa(a.type, true), a;
      default:
        return "";
    }
  }
  function Qa(a) {
    if (null == a)
      return null;
    if ("function" === typeof a)
      return a.displayName || a.name || null;
    if ("string" === typeof a)
      return a;
    switch (a) {
      case ya:
        return "Fragment";
      case wa:
        return "Portal";
      case Aa:
        return "Profiler";
      case za:
        return "StrictMode";
      case Ea:
        return "Suspense";
      case Fa:
        return "SuspenseList";
    }
    if ("object" === typeof a)
      switch (a.$$typeof) {
        case Ca:
          return (a.displayName || "Context") + ".Consumer";
        case Ba:
          return (a._context.displayName || "Context") + ".Provider";
        case Da:
          var b2 = a.render;
          a = a.displayName;
          a || (a = b2.displayName || b2.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
          return a;
        case Ga:
          return b2 = a.displayName || null, null !== b2 ? b2 : Qa(a.type) || "Memo";
        case Ha:
          b2 = a._payload;
          a = a._init;
          try {
            return Qa(a(b2));
          } catch (c2) {
          }
      }
    return null;
  }
  function Ra(a) {
    var b2 = a.type;
    switch (a.tag) {
      case 24:
        return "Cache";
      case 9:
        return (b2.displayName || "Context") + ".Consumer";
      case 10:
        return (b2._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return a = b2.render, a = a.displayName || a.name || "", b2.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
      case 7:
        return "Fragment";
      case 5:
        return b2;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return Qa(b2);
      case 8:
        return b2 === za ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if ("function" === typeof b2)
          return b2.displayName || b2.name || null;
        if ("string" === typeof b2)
          return b2;
    }
    return null;
  }
  function Sa(a) {
    switch (typeof a) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return a;
      case "object":
        return a;
      default:
        return "";
    }
  }
  function Ta(a) {
    var b2 = a.type;
    return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b2 || "radio" === b2);
  }
  function Ua(a) {
    var b2 = Ta(a) ? "checked" : "value", c2 = Object.getOwnPropertyDescriptor(a.constructor.prototype, b2), d2 = "" + a[b2];
    if (!a.hasOwnProperty(b2) && "undefined" !== typeof c2 && "function" === typeof c2.get && "function" === typeof c2.set) {
      var e2 = c2.get, f2 = c2.set;
      Object.defineProperty(a, b2, { configurable: true, get: function() {
        return e2.call(this);
      }, set: function(a2) {
        d2 = "" + a2;
        f2.call(this, a2);
      } });
      Object.defineProperty(a, b2, { enumerable: c2.enumerable });
      return { getValue: function() {
        return d2;
      }, setValue: function(a2) {
        d2 = "" + a2;
      }, stopTracking: function() {
        a._valueTracker = null;
        delete a[b2];
      } };
    }
  }
  function Va(a) {
    a._valueTracker || (a._valueTracker = Ua(a));
  }
  function Wa(a) {
    if (!a)
      return false;
    var b2 = a._valueTracker;
    if (!b2)
      return true;
    var c2 = b2.getValue();
    var d2 = "";
    a && (d2 = Ta(a) ? a.checked ? "true" : "false" : a.value);
    a = d2;
    return a !== c2 ? (b2.setValue(a), true) : false;
  }
  function Xa(a) {
    a = a || ("undefined" !== typeof document ? document : void 0);
    if ("undefined" === typeof a)
      return null;
    try {
      return a.activeElement || a.body;
    } catch (b2) {
      return a.body;
    }
  }
  function Ya(a, b2) {
    var c2 = b2.checked;
    return A$1({}, b2, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c2 ? c2 : a._wrapperState.initialChecked });
  }
  function Za(a, b2) {
    var c2 = null == b2.defaultValue ? "" : b2.defaultValue, d2 = null != b2.checked ? b2.checked : b2.defaultChecked;
    c2 = Sa(null != b2.value ? b2.value : c2);
    a._wrapperState = { initialChecked: d2, initialValue: c2, controlled: "checkbox" === b2.type || "radio" === b2.type ? null != b2.checked : null != b2.value };
  }
  function ab(a, b2) {
    b2 = b2.checked;
    null != b2 && ta(a, "checked", b2, false);
  }
  function bb(a, b2) {
    ab(a, b2);
    var c2 = Sa(b2.value), d2 = b2.type;
    if (null != c2)
      if ("number" === d2) {
        if (0 === c2 && "" === a.value || a.value != c2)
          a.value = "" + c2;
      } else
        a.value !== "" + c2 && (a.value = "" + c2);
    else if ("submit" === d2 || "reset" === d2) {
      a.removeAttribute("value");
      return;
    }
    b2.hasOwnProperty("value") ? cb(a, b2.type, c2) : b2.hasOwnProperty("defaultValue") && cb(a, b2.type, Sa(b2.defaultValue));
    null == b2.checked && null != b2.defaultChecked && (a.defaultChecked = !!b2.defaultChecked);
  }
  function db(a, b2, c2) {
    if (b2.hasOwnProperty("value") || b2.hasOwnProperty("defaultValue")) {
      var d2 = b2.type;
      if (!("submit" !== d2 && "reset" !== d2 || void 0 !== b2.value && null !== b2.value))
        return;
      b2 = "" + a._wrapperState.initialValue;
      c2 || b2 === a.value || (a.value = b2);
      a.defaultValue = b2;
    }
    c2 = a.name;
    "" !== c2 && (a.name = "");
    a.defaultChecked = !!a._wrapperState.initialChecked;
    "" !== c2 && (a.name = c2);
  }
  function cb(a, b2, c2) {
    if ("number" !== b2 || Xa(a.ownerDocument) !== a)
      null == c2 ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c2 && (a.defaultValue = "" + c2);
  }
  var eb = Array.isArray;
  function fb(a, b2, c2, d2) {
    a = a.options;
    if (b2) {
      b2 = {};
      for (var e2 = 0; e2 < c2.length; e2++)
        b2["$" + c2[e2]] = true;
      for (c2 = 0; c2 < a.length; c2++)
        e2 = b2.hasOwnProperty("$" + a[c2].value), a[c2].selected !== e2 && (a[c2].selected = e2), e2 && d2 && (a[c2].defaultSelected = true);
    } else {
      c2 = "" + Sa(c2);
      b2 = null;
      for (e2 = 0; e2 < a.length; e2++) {
        if (a[e2].value === c2) {
          a[e2].selected = true;
          d2 && (a[e2].defaultSelected = true);
          return;
        }
        null !== b2 || a[e2].disabled || (b2 = a[e2]);
      }
      null !== b2 && (b2.selected = true);
    }
  }
  function gb(a, b2) {
    if (null != b2.dangerouslySetInnerHTML)
      throw Error(p$3(91));
    return A$1({}, b2, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
  }
  function hb(a, b2) {
    var c2 = b2.value;
    if (null == c2) {
      c2 = b2.children;
      b2 = b2.defaultValue;
      if (null != c2) {
        if (null != b2)
          throw Error(p$3(92));
        if (eb(c2)) {
          if (1 < c2.length)
            throw Error(p$3(93));
          c2 = c2[0];
        }
        b2 = c2;
      }
      null == b2 && (b2 = "");
      c2 = b2;
    }
    a._wrapperState = { initialValue: Sa(c2) };
  }
  function ib(a, b2) {
    var c2 = Sa(b2.value), d2 = Sa(b2.defaultValue);
    null != c2 && (c2 = "" + c2, c2 !== a.value && (a.value = c2), null == b2.defaultValue && a.defaultValue !== c2 && (a.defaultValue = c2));
    null != d2 && (a.defaultValue = "" + d2);
  }
  function jb(a) {
    var b2 = a.textContent;
    b2 === a._wrapperState.initialValue && "" !== b2 && null !== b2 && (a.value = b2);
  }
  function kb(a) {
    switch (a) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function lb(a, b2) {
    return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b2) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b2 ? "http://www.w3.org/1999/xhtml" : a;
  }
  var mb, nb = function(a) {
    return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b2, c2, d2, e2) {
      MSApp.execUnsafeLocalFunction(function() {
        return a(b2, c2, d2, e2);
      });
    } : a;
  }(function(a, b2) {
    if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a)
      a.innerHTML = b2;
    else {
      mb = mb || document.createElement("div");
      mb.innerHTML = "<svg>" + b2.valueOf().toString() + "</svg>";
      for (b2 = mb.firstChild; a.firstChild; )
        a.removeChild(a.firstChild);
      for (; b2.firstChild; )
        a.appendChild(b2.firstChild);
    }
  });
  function ob(a, b2) {
    if (b2) {
      var c2 = a.firstChild;
      if (c2 && c2 === a.lastChild && 3 === c2.nodeType) {
        c2.nodeValue = b2;
        return;
      }
    }
    a.textContent = b2;
  }
  var pb = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridArea: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowSpan: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnSpan: true,
    gridColumnStart: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  }, qb = ["Webkit", "ms", "Moz", "O"];
  Object.keys(pb).forEach(function(a) {
    qb.forEach(function(b2) {
      b2 = b2 + a.charAt(0).toUpperCase() + a.substring(1);
      pb[b2] = pb[a];
    });
  });
  function rb(a, b2, c2) {
    return null == b2 || "boolean" === typeof b2 || "" === b2 ? "" : c2 || "number" !== typeof b2 || 0 === b2 || pb.hasOwnProperty(a) && pb[a] ? ("" + b2).trim() : b2 + "px";
  }
  function sb(a, b2) {
    a = a.style;
    for (var c2 in b2)
      if (b2.hasOwnProperty(c2)) {
        var d2 = 0 === c2.indexOf("--"), e2 = rb(c2, b2[c2], d2);
        "float" === c2 && (c2 = "cssFloat");
        d2 ? a.setProperty(c2, e2) : a[c2] = e2;
      }
  }
  var tb = A$1({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
  function ub(a, b2) {
    if (b2) {
      if (tb[a] && (null != b2.children || null != b2.dangerouslySetInnerHTML))
        throw Error(p$3(137, a));
      if (null != b2.dangerouslySetInnerHTML) {
        if (null != b2.children)
          throw Error(p$3(60));
        if ("object" !== typeof b2.dangerouslySetInnerHTML || !("__html" in b2.dangerouslySetInnerHTML))
          throw Error(p$3(61));
      }
      if (null != b2.style && "object" !== typeof b2.style)
        throw Error(p$3(62));
    }
  }
  function vb(a, b2) {
    if (-1 === a.indexOf("-"))
      return "string" === typeof b2.is;
    switch (a) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return false;
      default:
        return true;
    }
  }
  var wb = null;
  function xb(a) {
    a = a.target || a.srcElement || window;
    a.correspondingUseElement && (a = a.correspondingUseElement);
    return 3 === a.nodeType ? a.parentNode : a;
  }
  var yb = null, zb = null, Ab = null;
  function Bb(a) {
    if (a = Cb(a)) {
      if ("function" !== typeof yb)
        throw Error(p$3(280));
      var b2 = a.stateNode;
      b2 && (b2 = Db(b2), yb(a.stateNode, a.type, b2));
    }
  }
  function Eb(a) {
    zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
  }
  function Fb() {
    if (zb) {
      var a = zb, b2 = Ab;
      Ab = zb = null;
      Bb(a);
      if (b2)
        for (a = 0; a < b2.length; a++)
          Bb(b2[a]);
    }
  }
  function Gb(a, b2) {
    return a(b2);
  }
  function Hb() {
  }
  var Ib = false;
  function Jb(a, b2, c2) {
    if (Ib)
      return a(b2, c2);
    Ib = true;
    try {
      return Gb(a, b2, c2);
    } finally {
      if (Ib = false, null !== zb || null !== Ab)
        Hb(), Fb();
    }
  }
  function Kb(a, b2) {
    var c2 = a.stateNode;
    if (null === c2)
      return null;
    var d2 = Db(c2);
    if (null === d2)
      return null;
    c2 = d2[b2];
    a:
      switch (b2) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (d2 = !d2.disabled) || (a = a.type, d2 = !("button" === a || "input" === a || "select" === a || "textarea" === a));
          a = !d2;
          break a;
        default:
          a = false;
      }
    if (a)
      return null;
    if (c2 && "function" !== typeof c2)
      throw Error(p$3(231, b2, typeof c2));
    return c2;
  }
  var Lb = false;
  if (ia)
    try {
      var Mb = {};
      Object.defineProperty(Mb, "passive", { get: function() {
        Lb = true;
      } });
      window.addEventListener("test", Mb, Mb);
      window.removeEventListener("test", Mb, Mb);
    } catch (a) {
      Lb = false;
    }
  function Nb(a, b2, c2, d2, e2, f2, g2, h2, k2) {
    var l2 = Array.prototype.slice.call(arguments, 3);
    try {
      b2.apply(c2, l2);
    } catch (m2) {
      this.onError(m2);
    }
  }
  var Ob = false, Pb = null, Qb = false, Rb = null, Sb = { onError: function(a) {
    Ob = true;
    Pb = a;
  } };
  function Tb(a, b2, c2, d2, e2, f2, g2, h2, k2) {
    Ob = false;
    Pb = null;
    Nb.apply(Sb, arguments);
  }
  function Ub(a, b2, c2, d2, e2, f2, g2, h2, k2) {
    Tb.apply(this, arguments);
    if (Ob) {
      if (Ob) {
        var l2 = Pb;
        Ob = false;
        Pb = null;
      } else
        throw Error(p$3(198));
      Qb || (Qb = true, Rb = l2);
    }
  }
  function Vb(a) {
    var b2 = a, c2 = a;
    if (a.alternate)
      for (; b2.return; )
        b2 = b2.return;
    else {
      a = b2;
      do
        b2 = a, 0 !== (b2.flags & 4098) && (c2 = b2.return), a = b2.return;
      while (a);
    }
    return 3 === b2.tag ? c2 : null;
  }
  function Wb(a) {
    if (13 === a.tag) {
      var b2 = a.memoizedState;
      null === b2 && (a = a.alternate, null !== a && (b2 = a.memoizedState));
      if (null !== b2)
        return b2.dehydrated;
    }
    return null;
  }
  function Xb(a) {
    if (Vb(a) !== a)
      throw Error(p$3(188));
  }
  function Yb(a) {
    var b2 = a.alternate;
    if (!b2) {
      b2 = Vb(a);
      if (null === b2)
        throw Error(p$3(188));
      return b2 !== a ? null : a;
    }
    for (var c2 = a, d2 = b2; ; ) {
      var e2 = c2.return;
      if (null === e2)
        break;
      var f2 = e2.alternate;
      if (null === f2) {
        d2 = e2.return;
        if (null !== d2) {
          c2 = d2;
          continue;
        }
        break;
      }
      if (e2.child === f2.child) {
        for (f2 = e2.child; f2; ) {
          if (f2 === c2)
            return Xb(e2), a;
          if (f2 === d2)
            return Xb(e2), b2;
          f2 = f2.sibling;
        }
        throw Error(p$3(188));
      }
      if (c2.return !== d2.return)
        c2 = e2, d2 = f2;
      else {
        for (var g2 = false, h2 = e2.child; h2; ) {
          if (h2 === c2) {
            g2 = true;
            c2 = e2;
            d2 = f2;
            break;
          }
          if (h2 === d2) {
            g2 = true;
            d2 = e2;
            c2 = f2;
            break;
          }
          h2 = h2.sibling;
        }
        if (!g2) {
          for (h2 = f2.child; h2; ) {
            if (h2 === c2) {
              g2 = true;
              c2 = f2;
              d2 = e2;
              break;
            }
            if (h2 === d2) {
              g2 = true;
              d2 = f2;
              c2 = e2;
              break;
            }
            h2 = h2.sibling;
          }
          if (!g2)
            throw Error(p$3(189));
        }
      }
      if (c2.alternate !== d2)
        throw Error(p$3(190));
    }
    if (3 !== c2.tag)
      throw Error(p$3(188));
    return c2.stateNode.current === c2 ? a : b2;
  }
  function Zb(a) {
    a = Yb(a);
    return null !== a ? $b(a) : null;
  }
  function $b(a) {
    if (5 === a.tag || 6 === a.tag)
      return a;
    for (a = a.child; null !== a; ) {
      var b2 = $b(a);
      if (null !== b2)
        return b2;
      a = a.sibling;
    }
    return null;
  }
  var ac = ca.unstable_scheduleCallback, bc = ca.unstable_cancelCallback, cc = ca.unstable_shouldYield, dc = ca.unstable_requestPaint, B = ca.unstable_now, ec = ca.unstable_getCurrentPriorityLevel, fc = ca.unstable_ImmediatePriority, gc = ca.unstable_UserBlockingPriority, hc = ca.unstable_NormalPriority, ic = ca.unstable_LowPriority, jc = ca.unstable_IdlePriority, kc = null, lc = null;
  function mc(a) {
    if (lc && "function" === typeof lc.onCommitFiberRoot)
      try {
        lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
      } catch (b2) {
      }
  }
  var oc = Math.clz32 ? Math.clz32 : nc, pc = Math.log, qc = Math.LN2;
  function nc(a) {
    a >>>= 0;
    return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
  }
  var rc = 64, sc = 4194304;
  function tc(a) {
    switch (a & -a) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return a & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return a & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return a;
    }
  }
  function uc(a, b2) {
    var c2 = a.pendingLanes;
    if (0 === c2)
      return 0;
    var d2 = 0, e2 = a.suspendedLanes, f2 = a.pingedLanes, g2 = c2 & 268435455;
    if (0 !== g2) {
      var h2 = g2 & ~e2;
      0 !== h2 ? d2 = tc(h2) : (f2 &= g2, 0 !== f2 && (d2 = tc(f2)));
    } else
      g2 = c2 & ~e2, 0 !== g2 ? d2 = tc(g2) : 0 !== f2 && (d2 = tc(f2));
    if (0 === d2)
      return 0;
    if (0 !== b2 && b2 !== d2 && 0 === (b2 & e2) && (e2 = d2 & -d2, f2 = b2 & -b2, e2 >= f2 || 16 === e2 && 0 !== (f2 & 4194240)))
      return b2;
    0 !== (d2 & 4) && (d2 |= c2 & 16);
    b2 = a.entangledLanes;
    if (0 !== b2)
      for (a = a.entanglements, b2 &= d2; 0 < b2; )
        c2 = 31 - oc(b2), e2 = 1 << c2, d2 |= a[c2], b2 &= ~e2;
    return d2;
  }
  function vc(a, b2) {
    switch (a) {
      case 1:
      case 2:
      case 4:
        return b2 + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return b2 + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function wc(a, b2) {
    for (var c2 = a.suspendedLanes, d2 = a.pingedLanes, e2 = a.expirationTimes, f2 = a.pendingLanes; 0 < f2; ) {
      var g2 = 31 - oc(f2), h2 = 1 << g2, k2 = e2[g2];
      if (-1 === k2) {
        if (0 === (h2 & c2) || 0 !== (h2 & d2))
          e2[g2] = vc(h2, b2);
      } else
        k2 <= b2 && (a.expiredLanes |= h2);
      f2 &= ~h2;
    }
  }
  function xc(a) {
    a = a.pendingLanes & -1073741825;
    return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
  }
  function yc() {
    var a = rc;
    rc <<= 1;
    0 === (rc & 4194240) && (rc = 64);
    return a;
  }
  function zc(a) {
    for (var b2 = [], c2 = 0; 31 > c2; c2++)
      b2.push(a);
    return b2;
  }
  function Ac(a, b2, c2) {
    a.pendingLanes |= b2;
    536870912 !== b2 && (a.suspendedLanes = 0, a.pingedLanes = 0);
    a = a.eventTimes;
    b2 = 31 - oc(b2);
    a[b2] = c2;
  }
  function Bc(a, b2) {
    var c2 = a.pendingLanes & ~b2;
    a.pendingLanes = b2;
    a.suspendedLanes = 0;
    a.pingedLanes = 0;
    a.expiredLanes &= b2;
    a.mutableReadLanes &= b2;
    a.entangledLanes &= b2;
    b2 = a.entanglements;
    var d2 = a.eventTimes;
    for (a = a.expirationTimes; 0 < c2; ) {
      var e2 = 31 - oc(c2), f2 = 1 << e2;
      b2[e2] = 0;
      d2[e2] = -1;
      a[e2] = -1;
      c2 &= ~f2;
    }
  }
  function Cc(a, b2) {
    var c2 = a.entangledLanes |= b2;
    for (a = a.entanglements; c2; ) {
      var d2 = 31 - oc(c2), e2 = 1 << d2;
      e2 & b2 | a[d2] & b2 && (a[d2] |= b2);
      c2 &= ~e2;
    }
  }
  var C = 0;
  function Dc(a) {
    a &= -a;
    return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
  }
  var Ec, Fc, Gc, Hc, Ic, Jc = false, Kc = [], Lc = null, Mc = null, Nc = null, Oc = /* @__PURE__ */ new Map(), Pc = /* @__PURE__ */ new Map(), Qc = [], Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  function Sc(a, b2) {
    switch (a) {
      case "focusin":
      case "focusout":
        Lc = null;
        break;
      case "dragenter":
      case "dragleave":
        Mc = null;
        break;
      case "mouseover":
      case "mouseout":
        Nc = null;
        break;
      case "pointerover":
      case "pointerout":
        Oc.delete(b2.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Pc.delete(b2.pointerId);
    }
  }
  function Tc(a, b2, c2, d2, e2, f2) {
    if (null === a || a.nativeEvent !== f2)
      return a = { blockedOn: b2, domEventName: c2, eventSystemFlags: d2, nativeEvent: f2, targetContainers: [e2] }, null !== b2 && (b2 = Cb(b2), null !== b2 && Fc(b2)), a;
    a.eventSystemFlags |= d2;
    b2 = a.targetContainers;
    null !== e2 && -1 === b2.indexOf(e2) && b2.push(e2);
    return a;
  }
  function Uc(a, b2, c2, d2, e2) {
    switch (b2) {
      case "focusin":
        return Lc = Tc(Lc, a, b2, c2, d2, e2), true;
      case "dragenter":
        return Mc = Tc(Mc, a, b2, c2, d2, e2), true;
      case "mouseover":
        return Nc = Tc(Nc, a, b2, c2, d2, e2), true;
      case "pointerover":
        var f2 = e2.pointerId;
        Oc.set(f2, Tc(Oc.get(f2) || null, a, b2, c2, d2, e2));
        return true;
      case "gotpointercapture":
        return f2 = e2.pointerId, Pc.set(f2, Tc(Pc.get(f2) || null, a, b2, c2, d2, e2)), true;
    }
    return false;
  }
  function Vc(a) {
    var b2 = Wc(a.target);
    if (null !== b2) {
      var c2 = Vb(b2);
      if (null !== c2) {
        if (b2 = c2.tag, 13 === b2) {
          if (b2 = Wb(c2), null !== b2) {
            a.blockedOn = b2;
            Ic(a.priority, function() {
              Gc(c2);
            });
            return;
          }
        } else if (3 === b2 && c2.stateNode.current.memoizedState.isDehydrated) {
          a.blockedOn = 3 === c2.tag ? c2.stateNode.containerInfo : null;
          return;
        }
      }
    }
    a.blockedOn = null;
  }
  function Xc(a) {
    if (null !== a.blockedOn)
      return false;
    for (var b2 = a.targetContainers; 0 < b2.length; ) {
      var c2 = Yc(a.domEventName, a.eventSystemFlags, b2[0], a.nativeEvent);
      if (null === c2) {
        c2 = a.nativeEvent;
        var d2 = new c2.constructor(c2.type, c2);
        wb = d2;
        c2.target.dispatchEvent(d2);
        wb = null;
      } else
        return b2 = Cb(c2), null !== b2 && Fc(b2), a.blockedOn = c2, false;
      b2.shift();
    }
    return true;
  }
  function Zc(a, b2, c2) {
    Xc(a) && c2.delete(b2);
  }
  function $c() {
    Jc = false;
    null !== Lc && Xc(Lc) && (Lc = null);
    null !== Mc && Xc(Mc) && (Mc = null);
    null !== Nc && Xc(Nc) && (Nc = null);
    Oc.forEach(Zc);
    Pc.forEach(Zc);
  }
  function ad(a, b2) {
    a.blockedOn === b2 && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
  }
  function bd(a) {
    function b2(b3) {
      return ad(b3, a);
    }
    if (0 < Kc.length) {
      ad(Kc[0], a);
      for (var c2 = 1; c2 < Kc.length; c2++) {
        var d2 = Kc[c2];
        d2.blockedOn === a && (d2.blockedOn = null);
      }
    }
    null !== Lc && ad(Lc, a);
    null !== Mc && ad(Mc, a);
    null !== Nc && ad(Nc, a);
    Oc.forEach(b2);
    Pc.forEach(b2);
    for (c2 = 0; c2 < Qc.length; c2++)
      d2 = Qc[c2], d2.blockedOn === a && (d2.blockedOn = null);
    for (; 0 < Qc.length && (c2 = Qc[0], null === c2.blockedOn); )
      Vc(c2), null === c2.blockedOn && Qc.shift();
  }
  var cd = ua.ReactCurrentBatchConfig, dd = true;
  function ed(a, b2, c2, d2) {
    var e2 = C, f2 = cd.transition;
    cd.transition = null;
    try {
      C = 1, fd(a, b2, c2, d2);
    } finally {
      C = e2, cd.transition = f2;
    }
  }
  function gd(a, b2, c2, d2) {
    var e2 = C, f2 = cd.transition;
    cd.transition = null;
    try {
      C = 4, fd(a, b2, c2, d2);
    } finally {
      C = e2, cd.transition = f2;
    }
  }
  function fd(a, b2, c2, d2) {
    if (dd) {
      var e2 = Yc(a, b2, c2, d2);
      if (null === e2)
        hd(a, b2, d2, id, c2), Sc(a, d2);
      else if (Uc(e2, a, b2, c2, d2))
        d2.stopPropagation();
      else if (Sc(a, d2), b2 & 4 && -1 < Rc.indexOf(a)) {
        for (; null !== e2; ) {
          var f2 = Cb(e2);
          null !== f2 && Ec(f2);
          f2 = Yc(a, b2, c2, d2);
          null === f2 && hd(a, b2, d2, id, c2);
          if (f2 === e2)
            break;
          e2 = f2;
        }
        null !== e2 && d2.stopPropagation();
      } else
        hd(a, b2, d2, null, c2);
    }
  }
  var id = null;
  function Yc(a, b2, c2, d2) {
    id = null;
    a = xb(d2);
    a = Wc(a);
    if (null !== a)
      if (b2 = Vb(a), null === b2)
        a = null;
      else if (c2 = b2.tag, 13 === c2) {
        a = Wb(b2);
        if (null !== a)
          return a;
        a = null;
      } else if (3 === c2) {
        if (b2.stateNode.current.memoizedState.isDehydrated)
          return 3 === b2.tag ? b2.stateNode.containerInfo : null;
        a = null;
      } else
        b2 !== a && (a = null);
    id = a;
    return null;
  }
  function jd(a) {
    switch (a) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (ec()) {
          case fc:
            return 1;
          case gc:
            return 4;
          case hc:
          case ic:
            return 16;
          case jc:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var kd = null, ld = null, md = null;
  function nd() {
    if (md)
      return md;
    var a, b2 = ld, c2 = b2.length, d2, e2 = "value" in kd ? kd.value : kd.textContent, f2 = e2.length;
    for (a = 0; a < c2 && b2[a] === e2[a]; a++)
      ;
    var g2 = c2 - a;
    for (d2 = 1; d2 <= g2 && b2[c2 - d2] === e2[f2 - d2]; d2++)
      ;
    return md = e2.slice(a, 1 < d2 ? 1 - d2 : void 0);
  }
  function od(a) {
    var b2 = a.keyCode;
    "charCode" in a ? (a = a.charCode, 0 === a && 13 === b2 && (a = 13)) : a = b2;
    10 === a && (a = 13);
    return 32 <= a || 13 === a ? a : 0;
  }
  function pd() {
    return true;
  }
  function qd() {
    return false;
  }
  function rd(a) {
    function b2(b3, d2, e2, f2, g2) {
      this._reactName = b3;
      this._targetInst = e2;
      this.type = d2;
      this.nativeEvent = f2;
      this.target = g2;
      this.currentTarget = null;
      for (var c2 in a)
        a.hasOwnProperty(c2) && (b3 = a[c2], this[c2] = b3 ? b3(f2) : f2[c2]);
      this.isDefaultPrevented = (null != f2.defaultPrevented ? f2.defaultPrevented : false === f2.returnValue) ? pd : qd;
      this.isPropagationStopped = qd;
      return this;
    }
    A$1(b2.prototype, { preventDefault: function() {
      this.defaultPrevented = true;
      var a2 = this.nativeEvent;
      a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
    }, stopPropagation: function() {
      var a2 = this.nativeEvent;
      a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
    }, persist: function() {
    }, isPersistent: pd });
    return b2;
  }
  var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
    return a.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, td = rd(sd), ud = A$1({}, sd, { view: 0, detail: 0 }), vd = rd(ud), wd, xd, yd, Ad = A$1({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
    return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
  }, movementX: function(a) {
    if ("movementX" in a)
      return a.movementX;
    a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
    return wd;
  }, movementY: function(a) {
    return "movementY" in a ? a.movementY : xd;
  } }), Bd = rd(Ad), Cd = A$1({}, Ad, { dataTransfer: 0 }), Dd = rd(Cd), Ed = A$1({}, ud, { relatedTarget: 0 }), Fd = rd(Ed), Gd = A$1({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), Hd = rd(Gd), Id = A$1({}, sd, { clipboardData: function(a) {
    return "clipboardData" in a ? a.clipboardData : window.clipboardData;
  } }), Jd = rd(Id), Kd = A$1({}, sd, { data: 0 }), Ld = rd(Kd), Md = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Nd = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
  function Pd(a) {
    var b2 = this.nativeEvent;
    return b2.getModifierState ? b2.getModifierState(a) : (a = Od[a]) ? !!b2[a] : false;
  }
  function zd() {
    return Pd;
  }
  var Qd = A$1({}, ud, { key: function(a) {
    if (a.key) {
      var b2 = Md[a.key] || a.key;
      if ("Unidentified" !== b2)
        return b2;
    }
    return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
    return "keypress" === a.type ? od(a) : 0;
  }, keyCode: function(a) {
    return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  }, which: function(a) {
    return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  } }), Rd = rd(Qd), Sd = A$1({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Td = rd(Sd), Ud = A$1({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd }), Vd = rd(Ud), Wd = A$1({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Xd = rd(Wd), Yd = A$1({}, Ad, {
    deltaX: function(a) {
      return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
    },
    deltaY: function(a) {
      return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Zd = rd(Yd), $d = [9, 13, 27, 32], ae = ia && "CompositionEvent" in window, be = null;
  ia && "documentMode" in document && (be = document.documentMode);
  var ce = ia && "TextEvent" in window && !be, de = ia && (!ae || be && 8 < be && 11 >= be), ee = String.fromCharCode(32), fe = false;
  function ge(a, b2) {
    switch (a) {
      case "keyup":
        return -1 !== $d.indexOf(b2.keyCode);
      case "keydown":
        return 229 !== b2.keyCode;
      case "keypress":
      case "mousedown":
      case "focusout":
        return true;
      default:
        return false;
    }
  }
  function he(a) {
    a = a.detail;
    return "object" === typeof a && "data" in a ? a.data : null;
  }
  var ie = false;
  function je(a, b2) {
    switch (a) {
      case "compositionend":
        return he(b2);
      case "keypress":
        if (32 !== b2.which)
          return null;
        fe = true;
        return ee;
      case "textInput":
        return a = b2.data, a === ee && fe ? null : a;
      default:
        return null;
    }
  }
  function ke(a, b2) {
    if (ie)
      return "compositionend" === a || !ae && ge(a, b2) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
    switch (a) {
      case "paste":
        return null;
      case "keypress":
        if (!(b2.ctrlKey || b2.altKey || b2.metaKey) || b2.ctrlKey && b2.altKey) {
          if (b2.char && 1 < b2.char.length)
            return b2.char;
          if (b2.which)
            return String.fromCharCode(b2.which);
        }
        return null;
      case "compositionend":
        return de && "ko" !== b2.locale ? null : b2.data;
      default:
        return null;
    }
  }
  var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  function me(a) {
    var b2 = a && a.nodeName && a.nodeName.toLowerCase();
    return "input" === b2 ? !!le[a.type] : "textarea" === b2 ? true : false;
  }
  function ne(a, b2, c2, d2) {
    Eb(d2);
    b2 = oe(b2, "onChange");
    0 < b2.length && (c2 = new td("onChange", "change", null, c2, d2), a.push({ event: c2, listeners: b2 }));
  }
  var pe = null, qe = null;
  function re(a) {
    se(a, 0);
  }
  function te(a) {
    var b2 = ue(a);
    if (Wa(b2))
      return a;
  }
  function ve(a, b2) {
    if ("change" === a)
      return b2;
  }
  var we = false;
  if (ia) {
    var xe;
    if (ia) {
      var ye = "oninput" in document;
      if (!ye) {
        var ze = document.createElement("div");
        ze.setAttribute("oninput", "return;");
        ye = "function" === typeof ze.oninput;
      }
      xe = ye;
    } else
      xe = false;
    we = xe && (!document.documentMode || 9 < document.documentMode);
  }
  function Ae() {
    pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
  }
  function Be(a) {
    if ("value" === a.propertyName && te(qe)) {
      var b2 = [];
      ne(b2, qe, a, xb(a));
      Jb(re, b2);
    }
  }
  function Ce(a, b2, c2) {
    "focusin" === a ? (Ae(), pe = b2, qe = c2, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
  }
  function De(a) {
    if ("selectionchange" === a || "keyup" === a || "keydown" === a)
      return te(qe);
  }
  function Ee(a, b2) {
    if ("click" === a)
      return te(b2);
  }
  function Fe(a, b2) {
    if ("input" === a || "change" === a)
      return te(b2);
  }
  function Ge(a, b2) {
    return a === b2 && (0 !== a || 1 / a === 1 / b2) || a !== a && b2 !== b2;
  }
  var He = "function" === typeof Object.is ? Object.is : Ge;
  function Ie(a, b2) {
    if (He(a, b2))
      return true;
    if ("object" !== typeof a || null === a || "object" !== typeof b2 || null === b2)
      return false;
    var c2 = Object.keys(a), d2 = Object.keys(b2);
    if (c2.length !== d2.length)
      return false;
    for (d2 = 0; d2 < c2.length; d2++) {
      var e2 = c2[d2];
      if (!ja.call(b2, e2) || !He(a[e2], b2[e2]))
        return false;
    }
    return true;
  }
  function Je(a) {
    for (; a && a.firstChild; )
      a = a.firstChild;
    return a;
  }
  function Ke(a, b2) {
    var c2 = Je(a);
    a = 0;
    for (var d2; c2; ) {
      if (3 === c2.nodeType) {
        d2 = a + c2.textContent.length;
        if (a <= b2 && d2 >= b2)
          return { node: c2, offset: b2 - a };
        a = d2;
      }
      a: {
        for (; c2; ) {
          if (c2.nextSibling) {
            c2 = c2.nextSibling;
            break a;
          }
          c2 = c2.parentNode;
        }
        c2 = void 0;
      }
      c2 = Je(c2);
    }
  }
  function Le(a, b2) {
    return a && b2 ? a === b2 ? true : a && 3 === a.nodeType ? false : b2 && 3 === b2.nodeType ? Le(a, b2.parentNode) : "contains" in a ? a.contains(b2) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b2) & 16) : false : false;
  }
  function Me() {
    for (var a = window, b2 = Xa(); b2 instanceof a.HTMLIFrameElement; ) {
      try {
        var c2 = "string" === typeof b2.contentWindow.location.href;
      } catch (d2) {
        c2 = false;
      }
      if (c2)
        a = b2.contentWindow;
      else
        break;
      b2 = Xa(a.document);
    }
    return b2;
  }
  function Ne(a) {
    var b2 = a && a.nodeName && a.nodeName.toLowerCase();
    return b2 && ("input" === b2 && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b2 || "true" === a.contentEditable);
  }
  function Oe(a) {
    var b2 = Me(), c2 = a.focusedElem, d2 = a.selectionRange;
    if (b2 !== c2 && c2 && c2.ownerDocument && Le(c2.ownerDocument.documentElement, c2)) {
      if (null !== d2 && Ne(c2)) {
        if (b2 = d2.start, a = d2.end, void 0 === a && (a = b2), "selectionStart" in c2)
          c2.selectionStart = b2, c2.selectionEnd = Math.min(a, c2.value.length);
        else if (a = (b2 = c2.ownerDocument || document) && b2.defaultView || window, a.getSelection) {
          a = a.getSelection();
          var e2 = c2.textContent.length, f2 = Math.min(d2.start, e2);
          d2 = void 0 === d2.end ? f2 : Math.min(d2.end, e2);
          !a.extend && f2 > d2 && (e2 = d2, d2 = f2, f2 = e2);
          e2 = Ke(c2, f2);
          var g2 = Ke(
            c2,
            d2
          );
          e2 && g2 && (1 !== a.rangeCount || a.anchorNode !== e2.node || a.anchorOffset !== e2.offset || a.focusNode !== g2.node || a.focusOffset !== g2.offset) && (b2 = b2.createRange(), b2.setStart(e2.node, e2.offset), a.removeAllRanges(), f2 > d2 ? (a.addRange(b2), a.extend(g2.node, g2.offset)) : (b2.setEnd(g2.node, g2.offset), a.addRange(b2)));
        }
      }
      b2 = [];
      for (a = c2; a = a.parentNode; )
        1 === a.nodeType && b2.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
      "function" === typeof c2.focus && c2.focus();
      for (c2 = 0; c2 < b2.length; c2++)
        a = b2[c2], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
    }
  }
  var Pe = ia && "documentMode" in document && 11 >= document.documentMode, Qe = null, Re = null, Se = null, Te = false;
  function Ue(a, b2, c2) {
    var d2 = c2.window === c2 ? c2.document : 9 === c2.nodeType ? c2 : c2.ownerDocument;
    Te || null == Qe || Qe !== Xa(d2) || (d2 = Qe, "selectionStart" in d2 && Ne(d2) ? d2 = { start: d2.selectionStart, end: d2.selectionEnd } : (d2 = (d2.ownerDocument && d2.ownerDocument.defaultView || window).getSelection(), d2 = { anchorNode: d2.anchorNode, anchorOffset: d2.anchorOffset, focusNode: d2.focusNode, focusOffset: d2.focusOffset }), Se && Ie(Se, d2) || (Se = d2, d2 = oe(Re, "onSelect"), 0 < d2.length && (b2 = new td("onSelect", "select", null, b2, c2), a.push({ event: b2, listeners: d2 }), b2.target = Qe)));
  }
  function Ve(a, b2) {
    var c2 = {};
    c2[a.toLowerCase()] = b2.toLowerCase();
    c2["Webkit" + a] = "webkit" + b2;
    c2["Moz" + a] = "moz" + b2;
    return c2;
  }
  var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") }, Xe = {}, Ye = {};
  ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
  function Ze(a) {
    if (Xe[a])
      return Xe[a];
    if (!We[a])
      return a;
    var b2 = We[a], c2;
    for (c2 in b2)
      if (b2.hasOwnProperty(c2) && c2 in Ye)
        return Xe[a] = b2[c2];
    return a;
  }
  var $e = Ze("animationend"), af = Ze("animationiteration"), bf = Ze("animationstart"), cf = Ze("transitionend"), df = /* @__PURE__ */ new Map(), ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  function ff(a, b2) {
    df.set(a, b2);
    fa(b2, [a]);
  }
  for (var gf = 0; gf < ef.length; gf++) {
    var hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
    ff(jf, "on" + kf);
  }
  ff($e, "onAnimationEnd");
  ff(af, "onAnimationIteration");
  ff(bf, "onAnimationStart");
  ff("dblclick", "onDoubleClick");
  ff("focusin", "onFocus");
  ff("focusout", "onBlur");
  ff(cf, "onTransitionEnd");
  ha("onMouseEnter", ["mouseout", "mouseover"]);
  ha("onMouseLeave", ["mouseout", "mouseover"]);
  ha("onPointerEnter", ["pointerout", "pointerover"]);
  ha("onPointerLeave", ["pointerout", "pointerover"]);
  fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
  fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
  fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
  fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
  function nf(a, b2, c2) {
    var d2 = a.type || "unknown-event";
    a.currentTarget = c2;
    Ub(d2, b2, void 0, a);
    a.currentTarget = null;
  }
  function se(a, b2) {
    b2 = 0 !== (b2 & 4);
    for (var c2 = 0; c2 < a.length; c2++) {
      var d2 = a[c2], e2 = d2.event;
      d2 = d2.listeners;
      a: {
        var f2 = void 0;
        if (b2)
          for (var g2 = d2.length - 1; 0 <= g2; g2--) {
            var h2 = d2[g2], k2 = h2.instance, l2 = h2.currentTarget;
            h2 = h2.listener;
            if (k2 !== f2 && e2.isPropagationStopped())
              break a;
            nf(e2, h2, l2);
            f2 = k2;
          }
        else
          for (g2 = 0; g2 < d2.length; g2++) {
            h2 = d2[g2];
            k2 = h2.instance;
            l2 = h2.currentTarget;
            h2 = h2.listener;
            if (k2 !== f2 && e2.isPropagationStopped())
              break a;
            nf(e2, h2, l2);
            f2 = k2;
          }
      }
    }
    if (Qb)
      throw a = Rb, Qb = false, Rb = null, a;
  }
  function D(a, b2) {
    var c2 = b2[of];
    void 0 === c2 && (c2 = b2[of] = /* @__PURE__ */ new Set());
    var d2 = a + "__bubble";
    c2.has(d2) || (pf(b2, a, 2, false), c2.add(d2));
  }
  function qf(a, b2, c2) {
    var d2 = 0;
    b2 && (d2 |= 4);
    pf(c2, a, d2, b2);
  }
  var rf = "_reactListening" + Math.random().toString(36).slice(2);
  function sf(a) {
    if (!a[rf]) {
      a[rf] = true;
      da.forEach(function(b3) {
        "selectionchange" !== b3 && (mf.has(b3) || qf(b3, false, a), qf(b3, true, a));
      });
      var b2 = 9 === a.nodeType ? a : a.ownerDocument;
      null === b2 || b2[rf] || (b2[rf] = true, qf("selectionchange", false, b2));
    }
  }
  function pf(a, b2, c2, d2) {
    switch (jd(b2)) {
      case 1:
        var e2 = ed;
        break;
      case 4:
        e2 = gd;
        break;
      default:
        e2 = fd;
    }
    c2 = e2.bind(null, b2, c2, a);
    e2 = void 0;
    !Lb || "touchstart" !== b2 && "touchmove" !== b2 && "wheel" !== b2 || (e2 = true);
    d2 ? void 0 !== e2 ? a.addEventListener(b2, c2, { capture: true, passive: e2 }) : a.addEventListener(b2, c2, true) : void 0 !== e2 ? a.addEventListener(b2, c2, { passive: e2 }) : a.addEventListener(b2, c2, false);
  }
  function hd(a, b2, c2, d2, e2) {
    var f2 = d2;
    if (0 === (b2 & 1) && 0 === (b2 & 2) && null !== d2)
      a:
        for (; ; ) {
          if (null === d2)
            return;
          var g2 = d2.tag;
          if (3 === g2 || 4 === g2) {
            var h2 = d2.stateNode.containerInfo;
            if (h2 === e2 || 8 === h2.nodeType && h2.parentNode === e2)
              break;
            if (4 === g2)
              for (g2 = d2.return; null !== g2; ) {
                var k2 = g2.tag;
                if (3 === k2 || 4 === k2) {
                  if (k2 = g2.stateNode.containerInfo, k2 === e2 || 8 === k2.nodeType && k2.parentNode === e2)
                    return;
                }
                g2 = g2.return;
              }
            for (; null !== h2; ) {
              g2 = Wc(h2);
              if (null === g2)
                return;
              k2 = g2.tag;
              if (5 === k2 || 6 === k2) {
                d2 = f2 = g2;
                continue a;
              }
              h2 = h2.parentNode;
            }
          }
          d2 = d2.return;
        }
    Jb(function() {
      var d3 = f2, e3 = xb(c2), g3 = [];
      a: {
        var h3 = df.get(a);
        if (void 0 !== h3) {
          var k3 = td, n2 = a;
          switch (a) {
            case "keypress":
              if (0 === od(c2))
                break a;
            case "keydown":
            case "keyup":
              k3 = Rd;
              break;
            case "focusin":
              n2 = "focus";
              k3 = Fd;
              break;
            case "focusout":
              n2 = "blur";
              k3 = Fd;
              break;
            case "beforeblur":
            case "afterblur":
              k3 = Fd;
              break;
            case "click":
              if (2 === c2.button)
                break a;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              k3 = Bd;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              k3 = Dd;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              k3 = Vd;
              break;
            case $e:
            case af:
            case bf:
              k3 = Hd;
              break;
            case cf:
              k3 = Xd;
              break;
            case "scroll":
              k3 = vd;
              break;
            case "wheel":
              k3 = Zd;
              break;
            case "copy":
            case "cut":
            case "paste":
              k3 = Jd;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              k3 = Td;
          }
          var t2 = 0 !== (b2 & 4), J2 = !t2 && "scroll" === a, x2 = t2 ? null !== h3 ? h3 + "Capture" : null : h3;
          t2 = [];
          for (var w2 = d3, u2; null !== w2; ) {
            u2 = w2;
            var F2 = u2.stateNode;
            5 === u2.tag && null !== F2 && (u2 = F2, null !== x2 && (F2 = Kb(w2, x2), null != F2 && t2.push(tf(w2, F2, u2))));
            if (J2)
              break;
            w2 = w2.return;
          }
          0 < t2.length && (h3 = new k3(h3, n2, null, c2, e3), g3.push({ event: h3, listeners: t2 }));
        }
      }
      if (0 === (b2 & 7)) {
        a: {
          h3 = "mouseover" === a || "pointerover" === a;
          k3 = "mouseout" === a || "pointerout" === a;
          if (h3 && c2 !== wb && (n2 = c2.relatedTarget || c2.fromElement) && (Wc(n2) || n2[uf]))
            break a;
          if (k3 || h3) {
            h3 = e3.window === e3 ? e3 : (h3 = e3.ownerDocument) ? h3.defaultView || h3.parentWindow : window;
            if (k3) {
              if (n2 = c2.relatedTarget || c2.toElement, k3 = d3, n2 = n2 ? Wc(n2) : null, null !== n2 && (J2 = Vb(n2), n2 !== J2 || 5 !== n2.tag && 6 !== n2.tag))
                n2 = null;
            } else
              k3 = null, n2 = d3;
            if (k3 !== n2) {
              t2 = Bd;
              F2 = "onMouseLeave";
              x2 = "onMouseEnter";
              w2 = "mouse";
              if ("pointerout" === a || "pointerover" === a)
                t2 = Td, F2 = "onPointerLeave", x2 = "onPointerEnter", w2 = "pointer";
              J2 = null == k3 ? h3 : ue(k3);
              u2 = null == n2 ? h3 : ue(n2);
              h3 = new t2(F2, w2 + "leave", k3, c2, e3);
              h3.target = J2;
              h3.relatedTarget = u2;
              F2 = null;
              Wc(e3) === d3 && (t2 = new t2(x2, w2 + "enter", n2, c2, e3), t2.target = u2, t2.relatedTarget = J2, F2 = t2);
              J2 = F2;
              if (k3 && n2)
                b: {
                  t2 = k3;
                  x2 = n2;
                  w2 = 0;
                  for (u2 = t2; u2; u2 = vf(u2))
                    w2++;
                  u2 = 0;
                  for (F2 = x2; F2; F2 = vf(F2))
                    u2++;
                  for (; 0 < w2 - u2; )
                    t2 = vf(t2), w2--;
                  for (; 0 < u2 - w2; )
                    x2 = vf(x2), u2--;
                  for (; w2--; ) {
                    if (t2 === x2 || null !== x2 && t2 === x2.alternate)
                      break b;
                    t2 = vf(t2);
                    x2 = vf(x2);
                  }
                  t2 = null;
                }
              else
                t2 = null;
              null !== k3 && wf(g3, h3, k3, t2, false);
              null !== n2 && null !== J2 && wf(g3, J2, n2, t2, true);
            }
          }
        }
        a: {
          h3 = d3 ? ue(d3) : window;
          k3 = h3.nodeName && h3.nodeName.toLowerCase();
          if ("select" === k3 || "input" === k3 && "file" === h3.type)
            var na = ve;
          else if (me(h3))
            if (we)
              na = Fe;
            else {
              na = De;
              var xa = Ce;
            }
          else
            (k3 = h3.nodeName) && "input" === k3.toLowerCase() && ("checkbox" === h3.type || "radio" === h3.type) && (na = Ee);
          if (na && (na = na(a, d3))) {
            ne(g3, na, c2, e3);
            break a;
          }
          xa && xa(a, h3, d3);
          "focusout" === a && (xa = h3._wrapperState) && xa.controlled && "number" === h3.type && cb(h3, "number", h3.value);
        }
        xa = d3 ? ue(d3) : window;
        switch (a) {
          case "focusin":
            if (me(xa) || "true" === xa.contentEditable)
              Qe = xa, Re = d3, Se = null;
            break;
          case "focusout":
            Se = Re = Qe = null;
            break;
          case "mousedown":
            Te = true;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Te = false;
            Ue(g3, c2, e3);
            break;
          case "selectionchange":
            if (Pe)
              break;
          case "keydown":
          case "keyup":
            Ue(g3, c2, e3);
        }
        var $a;
        if (ae)
          b: {
            switch (a) {
              case "compositionstart":
                var ba = "onCompositionStart";
                break b;
              case "compositionend":
                ba = "onCompositionEnd";
                break b;
              case "compositionupdate":
                ba = "onCompositionUpdate";
                break b;
            }
            ba = void 0;
          }
        else
          ie ? ge(a, c2) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c2.keyCode && (ba = "onCompositionStart");
        ba && (de && "ko" !== c2.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e3, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d3, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c2, e3), g3.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c2), null !== $a && (ba.data = $a))));
        if ($a = ce ? je(a, c2) : ke(a, c2))
          d3 = oe(d3, "onBeforeInput"), 0 < d3.length && (e3 = new Ld("onBeforeInput", "beforeinput", null, c2, e3), g3.push({ event: e3, listeners: d3 }), e3.data = $a);
      }
      se(g3, b2);
    });
  }
  function tf(a, b2, c2) {
    return { instance: a, listener: b2, currentTarget: c2 };
  }
  function oe(a, b2) {
    for (var c2 = b2 + "Capture", d2 = []; null !== a; ) {
      var e2 = a, f2 = e2.stateNode;
      5 === e2.tag && null !== f2 && (e2 = f2, f2 = Kb(a, c2), null != f2 && d2.unshift(tf(a, f2, e2)), f2 = Kb(a, b2), null != f2 && d2.push(tf(a, f2, e2)));
      a = a.return;
    }
    return d2;
  }
  function vf(a) {
    if (null === a)
      return null;
    do
      a = a.return;
    while (a && 5 !== a.tag);
    return a ? a : null;
  }
  function wf(a, b2, c2, d2, e2) {
    for (var f2 = b2._reactName, g2 = []; null !== c2 && c2 !== d2; ) {
      var h2 = c2, k2 = h2.alternate, l2 = h2.stateNode;
      if (null !== k2 && k2 === d2)
        break;
      5 === h2.tag && null !== l2 && (h2 = l2, e2 ? (k2 = Kb(c2, f2), null != k2 && g2.unshift(tf(c2, k2, h2))) : e2 || (k2 = Kb(c2, f2), null != k2 && g2.push(tf(c2, k2, h2))));
      c2 = c2.return;
    }
    0 !== g2.length && a.push({ event: b2, listeners: g2 });
  }
  var xf = /\r\n?/g, yf = /\u0000|\uFFFD/g;
  function zf(a) {
    return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
  }
  function Af(a, b2, c2) {
    b2 = zf(b2);
    if (zf(a) !== b2 && c2)
      throw Error(p$3(425));
  }
  function Bf() {
  }
  var Cf = null, Df = null;
  function Ef(a, b2) {
    return "textarea" === a || "noscript" === a || "string" === typeof b2.children || "number" === typeof b2.children || "object" === typeof b2.dangerouslySetInnerHTML && null !== b2.dangerouslySetInnerHTML && null != b2.dangerouslySetInnerHTML.__html;
  }
  var Ff = "function" === typeof setTimeout ? setTimeout : void 0, Gf = "function" === typeof clearTimeout ? clearTimeout : void 0, Hf = "function" === typeof Promise ? Promise : void 0, Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
    return Hf.resolve(null).then(a).catch(If);
  } : Ff;
  function If(a) {
    setTimeout(function() {
      throw a;
    });
  }
  function Kf(a, b2) {
    var c2 = b2, d2 = 0;
    do {
      var e2 = c2.nextSibling;
      a.removeChild(c2);
      if (e2 && 8 === e2.nodeType)
        if (c2 = e2.data, "/$" === c2) {
          if (0 === d2) {
            a.removeChild(e2);
            bd(b2);
            return;
          }
          d2--;
        } else
          "$" !== c2 && "$?" !== c2 && "$!" !== c2 || d2++;
      c2 = e2;
    } while (c2);
    bd(b2);
  }
  function Lf(a) {
    for (; null != a; a = a.nextSibling) {
      var b2 = a.nodeType;
      if (1 === b2 || 3 === b2)
        break;
      if (8 === b2) {
        b2 = a.data;
        if ("$" === b2 || "$!" === b2 || "$?" === b2)
          break;
        if ("/$" === b2)
          return null;
      }
    }
    return a;
  }
  function Mf(a) {
    a = a.previousSibling;
    for (var b2 = 0; a; ) {
      if (8 === a.nodeType) {
        var c2 = a.data;
        if ("$" === c2 || "$!" === c2 || "$?" === c2) {
          if (0 === b2)
            return a;
          b2--;
        } else
          "/$" === c2 && b2++;
      }
      a = a.previousSibling;
    }
    return null;
  }
  var Nf = Math.random().toString(36).slice(2), Of = "__reactFiber$" + Nf, Pf = "__reactProps$" + Nf, uf = "__reactContainer$" + Nf, of = "__reactEvents$" + Nf, Qf = "__reactListeners$" + Nf, Rf = "__reactHandles$" + Nf;
  function Wc(a) {
    var b2 = a[Of];
    if (b2)
      return b2;
    for (var c2 = a.parentNode; c2; ) {
      if (b2 = c2[uf] || c2[Of]) {
        c2 = b2.alternate;
        if (null !== b2.child || null !== c2 && null !== c2.child)
          for (a = Mf(a); null !== a; ) {
            if (c2 = a[Of])
              return c2;
            a = Mf(a);
          }
        return b2;
      }
      a = c2;
      c2 = a.parentNode;
    }
    return null;
  }
  function Cb(a) {
    a = a[Of] || a[uf];
    return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
  }
  function ue(a) {
    if (5 === a.tag || 6 === a.tag)
      return a.stateNode;
    throw Error(p$3(33));
  }
  function Db(a) {
    return a[Pf] || null;
  }
  var Sf = [], Tf = -1;
  function Uf(a) {
    return { current: a };
  }
  function E(a) {
    0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
  }
  function G(a, b2) {
    Tf++;
    Sf[Tf] = a.current;
    a.current = b2;
  }
  var Vf = {}, H = Uf(Vf), Wf = Uf(false), Xf = Vf;
  function Yf(a, b2) {
    var c2 = a.type.contextTypes;
    if (!c2)
      return Vf;
    var d2 = a.stateNode;
    if (d2 && d2.__reactInternalMemoizedUnmaskedChildContext === b2)
      return d2.__reactInternalMemoizedMaskedChildContext;
    var e2 = {}, f2;
    for (f2 in c2)
      e2[f2] = b2[f2];
    d2 && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b2, a.__reactInternalMemoizedMaskedChildContext = e2);
    return e2;
  }
  function Zf(a) {
    a = a.childContextTypes;
    return null !== a && void 0 !== a;
  }
  function $f() {
    E(Wf);
    E(H);
  }
  function ag(a, b2, c2) {
    if (H.current !== Vf)
      throw Error(p$3(168));
    G(H, b2);
    G(Wf, c2);
  }
  function bg(a, b2, c2) {
    var d2 = a.stateNode;
    b2 = b2.childContextTypes;
    if ("function" !== typeof d2.getChildContext)
      return c2;
    d2 = d2.getChildContext();
    for (var e2 in d2)
      if (!(e2 in b2))
        throw Error(p$3(108, Ra(a) || "Unknown", e2));
    return A$1({}, c2, d2);
  }
  function cg(a) {
    a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
    Xf = H.current;
    G(H, a);
    G(Wf, Wf.current);
    return true;
  }
  function dg(a, b2, c2) {
    var d2 = a.stateNode;
    if (!d2)
      throw Error(p$3(169));
    c2 ? (a = bg(a, b2, Xf), d2.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
    G(Wf, c2);
  }
  var eg = null, fg = false, gg = false;
  function hg(a) {
    null === eg ? eg = [a] : eg.push(a);
  }
  function ig(a) {
    fg = true;
    hg(a);
  }
  function jg() {
    if (!gg && null !== eg) {
      gg = true;
      var a = 0, b2 = C;
      try {
        var c2 = eg;
        for (C = 1; a < c2.length; a++) {
          var d2 = c2[a];
          do
            d2 = d2(true);
          while (null !== d2);
        }
        eg = null;
        fg = false;
      } catch (e2) {
        throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e2;
      } finally {
        C = b2, gg = false;
      }
    }
    return null;
  }
  var kg = [], lg = 0, mg = null, ng = 0, og = [], pg = 0, qg = null, rg = 1, sg = "";
  function tg(a, b2) {
    kg[lg++] = ng;
    kg[lg++] = mg;
    mg = a;
    ng = b2;
  }
  function ug(a, b2, c2) {
    og[pg++] = rg;
    og[pg++] = sg;
    og[pg++] = qg;
    qg = a;
    var d2 = rg;
    a = sg;
    var e2 = 32 - oc(d2) - 1;
    d2 &= ~(1 << e2);
    c2 += 1;
    var f2 = 32 - oc(b2) + e2;
    if (30 < f2) {
      var g2 = e2 - e2 % 5;
      f2 = (d2 & (1 << g2) - 1).toString(32);
      d2 >>= g2;
      e2 -= g2;
      rg = 1 << 32 - oc(b2) + e2 | c2 << e2 | d2;
      sg = f2 + a;
    } else
      rg = 1 << f2 | c2 << e2 | d2, sg = a;
  }
  function vg(a) {
    null !== a.return && (tg(a, 1), ug(a, 1, 0));
  }
  function wg(a) {
    for (; a === mg; )
      mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
    for (; a === qg; )
      qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
  }
  var xg = null, yg = null, I = false, zg = null;
  function Ag(a, b2) {
    var c2 = Bg(5, null, null, 0);
    c2.elementType = "DELETED";
    c2.stateNode = b2;
    c2.return = a;
    b2 = a.deletions;
    null === b2 ? (a.deletions = [c2], a.flags |= 16) : b2.push(c2);
  }
  function Cg(a, b2) {
    switch (a.tag) {
      case 5:
        var c2 = a.type;
        b2 = 1 !== b2.nodeType || c2.toLowerCase() !== b2.nodeName.toLowerCase() ? null : b2;
        return null !== b2 ? (a.stateNode = b2, xg = a, yg = Lf(b2.firstChild), true) : false;
      case 6:
        return b2 = "" === a.pendingProps || 3 !== b2.nodeType ? null : b2, null !== b2 ? (a.stateNode = b2, xg = a, yg = null, true) : false;
      case 13:
        return b2 = 8 !== b2.nodeType ? null : b2, null !== b2 ? (c2 = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b2, treeContext: c2, retryLane: 1073741824 }, c2 = Bg(18, null, null, 0), c2.stateNode = b2, c2.return = a, a.child = c2, xg = a, yg = null, true) : false;
      default:
        return false;
    }
  }
  function Dg(a) {
    return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
  }
  function Eg(a) {
    if (I) {
      var b2 = yg;
      if (b2) {
        var c2 = b2;
        if (!Cg(a, b2)) {
          if (Dg(a))
            throw Error(p$3(418));
          b2 = Lf(c2.nextSibling);
          var d2 = xg;
          b2 && Cg(a, b2) ? Ag(d2, c2) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
        }
      } else {
        if (Dg(a))
          throw Error(p$3(418));
        a.flags = a.flags & -4097 | 2;
        I = false;
        xg = a;
      }
    }
  }
  function Fg(a) {
    for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; )
      a = a.return;
    xg = a;
  }
  function Gg(a) {
    if (a !== xg)
      return false;
    if (!I)
      return Fg(a), I = true, false;
    var b2;
    (b2 = 3 !== a.tag) && !(b2 = 5 !== a.tag) && (b2 = a.type, b2 = "head" !== b2 && "body" !== b2 && !Ef(a.type, a.memoizedProps));
    if (b2 && (b2 = yg)) {
      if (Dg(a))
        throw Hg(), Error(p$3(418));
      for (; b2; )
        Ag(a, b2), b2 = Lf(b2.nextSibling);
    }
    Fg(a);
    if (13 === a.tag) {
      a = a.memoizedState;
      a = null !== a ? a.dehydrated : null;
      if (!a)
        throw Error(p$3(317));
      a: {
        a = a.nextSibling;
        for (b2 = 0; a; ) {
          if (8 === a.nodeType) {
            var c2 = a.data;
            if ("/$" === c2) {
              if (0 === b2) {
                yg = Lf(a.nextSibling);
                break a;
              }
              b2--;
            } else
              "$" !== c2 && "$!" !== c2 && "$?" !== c2 || b2++;
          }
          a = a.nextSibling;
        }
        yg = null;
      }
    } else
      yg = xg ? Lf(a.stateNode.nextSibling) : null;
    return true;
  }
  function Hg() {
    for (var a = yg; a; )
      a = Lf(a.nextSibling);
  }
  function Ig() {
    yg = xg = null;
    I = false;
  }
  function Jg(a) {
    null === zg ? zg = [a] : zg.push(a);
  }
  var Kg = ua.ReactCurrentBatchConfig;
  function Lg(a, b2) {
    if (a && a.defaultProps) {
      b2 = A$1({}, b2);
      a = a.defaultProps;
      for (var c2 in a)
        void 0 === b2[c2] && (b2[c2] = a[c2]);
      return b2;
    }
    return b2;
  }
  var Mg = Uf(null), Ng = null, Og = null, Pg = null;
  function Qg() {
    Pg = Og = Ng = null;
  }
  function Rg(a) {
    var b2 = Mg.current;
    E(Mg);
    a._currentValue = b2;
  }
  function Sg(a, b2, c2) {
    for (; null !== a; ) {
      var d2 = a.alternate;
      (a.childLanes & b2) !== b2 ? (a.childLanes |= b2, null !== d2 && (d2.childLanes |= b2)) : null !== d2 && (d2.childLanes & b2) !== b2 && (d2.childLanes |= b2);
      if (a === c2)
        break;
      a = a.return;
    }
  }
  function Tg(a, b2) {
    Ng = a;
    Pg = Og = null;
    a = a.dependencies;
    null !== a && null !== a.firstContext && (0 !== (a.lanes & b2) && (Ug = true), a.firstContext = null);
  }
  function Vg(a) {
    var b2 = a._currentValue;
    if (Pg !== a)
      if (a = { context: a, memoizedValue: b2, next: null }, null === Og) {
        if (null === Ng)
          throw Error(p$3(308));
        Og = a;
        Ng.dependencies = { lanes: 0, firstContext: a };
      } else
        Og = Og.next = a;
    return b2;
  }
  var Wg = null;
  function Xg(a) {
    null === Wg ? Wg = [a] : Wg.push(a);
  }
  function Yg(a, b2, c2, d2) {
    var e2 = b2.interleaved;
    null === e2 ? (c2.next = c2, Xg(b2)) : (c2.next = e2.next, e2.next = c2);
    b2.interleaved = c2;
    return Zg(a, d2);
  }
  function Zg(a, b2) {
    a.lanes |= b2;
    var c2 = a.alternate;
    null !== c2 && (c2.lanes |= b2);
    c2 = a;
    for (a = a.return; null !== a; )
      a.childLanes |= b2, c2 = a.alternate, null !== c2 && (c2.childLanes |= b2), c2 = a, a = a.return;
    return 3 === c2.tag ? c2.stateNode : null;
  }
  var $g = false;
  function ah(a) {
    a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
  }
  function bh(a, b2) {
    a = a.updateQueue;
    b2.updateQueue === a && (b2.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
  }
  function ch(a, b2) {
    return { eventTime: a, lane: b2, tag: 0, payload: null, callback: null, next: null };
  }
  function dh(a, b2, c2) {
    var d2 = a.updateQueue;
    if (null === d2)
      return null;
    d2 = d2.shared;
    if (0 !== (K & 2)) {
      var e2 = d2.pending;
      null === e2 ? b2.next = b2 : (b2.next = e2.next, e2.next = b2);
      d2.pending = b2;
      return Zg(a, c2);
    }
    e2 = d2.interleaved;
    null === e2 ? (b2.next = b2, Xg(d2)) : (b2.next = e2.next, e2.next = b2);
    d2.interleaved = b2;
    return Zg(a, c2);
  }
  function eh(a, b2, c2) {
    b2 = b2.updateQueue;
    if (null !== b2 && (b2 = b2.shared, 0 !== (c2 & 4194240))) {
      var d2 = b2.lanes;
      d2 &= a.pendingLanes;
      c2 |= d2;
      b2.lanes = c2;
      Cc(a, c2);
    }
  }
  function fh(a, b2) {
    var c2 = a.updateQueue, d2 = a.alternate;
    if (null !== d2 && (d2 = d2.updateQueue, c2 === d2)) {
      var e2 = null, f2 = null;
      c2 = c2.firstBaseUpdate;
      if (null !== c2) {
        do {
          var g2 = { eventTime: c2.eventTime, lane: c2.lane, tag: c2.tag, payload: c2.payload, callback: c2.callback, next: null };
          null === f2 ? e2 = f2 = g2 : f2 = f2.next = g2;
          c2 = c2.next;
        } while (null !== c2);
        null === f2 ? e2 = f2 = b2 : f2 = f2.next = b2;
      } else
        e2 = f2 = b2;
      c2 = { baseState: d2.baseState, firstBaseUpdate: e2, lastBaseUpdate: f2, shared: d2.shared, effects: d2.effects };
      a.updateQueue = c2;
      return;
    }
    a = c2.lastBaseUpdate;
    null === a ? c2.firstBaseUpdate = b2 : a.next = b2;
    c2.lastBaseUpdate = b2;
  }
  function gh(a, b2, c2, d2) {
    var e2 = a.updateQueue;
    $g = false;
    var f2 = e2.firstBaseUpdate, g2 = e2.lastBaseUpdate, h2 = e2.shared.pending;
    if (null !== h2) {
      e2.shared.pending = null;
      var k2 = h2, l2 = k2.next;
      k2.next = null;
      null === g2 ? f2 = l2 : g2.next = l2;
      g2 = k2;
      var m2 = a.alternate;
      null !== m2 && (m2 = m2.updateQueue, h2 = m2.lastBaseUpdate, h2 !== g2 && (null === h2 ? m2.firstBaseUpdate = l2 : h2.next = l2, m2.lastBaseUpdate = k2));
    }
    if (null !== f2) {
      var q2 = e2.baseState;
      g2 = 0;
      m2 = l2 = k2 = null;
      h2 = f2;
      do {
        var r2 = h2.lane, y2 = h2.eventTime;
        if ((d2 & r2) === r2) {
          null !== m2 && (m2 = m2.next = {
            eventTime: y2,
            lane: 0,
            tag: h2.tag,
            payload: h2.payload,
            callback: h2.callback,
            next: null
          });
          a: {
            var n2 = a, t2 = h2;
            r2 = b2;
            y2 = c2;
            switch (t2.tag) {
              case 1:
                n2 = t2.payload;
                if ("function" === typeof n2) {
                  q2 = n2.call(y2, q2, r2);
                  break a;
                }
                q2 = n2;
                break a;
              case 3:
                n2.flags = n2.flags & -65537 | 128;
              case 0:
                n2 = t2.payload;
                r2 = "function" === typeof n2 ? n2.call(y2, q2, r2) : n2;
                if (null === r2 || void 0 === r2)
                  break a;
                q2 = A$1({}, q2, r2);
                break a;
              case 2:
                $g = true;
            }
          }
          null !== h2.callback && 0 !== h2.lane && (a.flags |= 64, r2 = e2.effects, null === r2 ? e2.effects = [h2] : r2.push(h2));
        } else
          y2 = { eventTime: y2, lane: r2, tag: h2.tag, payload: h2.payload, callback: h2.callback, next: null }, null === m2 ? (l2 = m2 = y2, k2 = q2) : m2 = m2.next = y2, g2 |= r2;
        h2 = h2.next;
        if (null === h2)
          if (h2 = e2.shared.pending, null === h2)
            break;
          else
            r2 = h2, h2 = r2.next, r2.next = null, e2.lastBaseUpdate = r2, e2.shared.pending = null;
      } while (1);
      null === m2 && (k2 = q2);
      e2.baseState = k2;
      e2.firstBaseUpdate = l2;
      e2.lastBaseUpdate = m2;
      b2 = e2.shared.interleaved;
      if (null !== b2) {
        e2 = b2;
        do
          g2 |= e2.lane, e2 = e2.next;
        while (e2 !== b2);
      } else
        null === f2 && (e2.shared.lanes = 0);
      hh |= g2;
      a.lanes = g2;
      a.memoizedState = q2;
    }
  }
  function ih(a, b2, c2) {
    a = b2.effects;
    b2.effects = null;
    if (null !== a)
      for (b2 = 0; b2 < a.length; b2++) {
        var d2 = a[b2], e2 = d2.callback;
        if (null !== e2) {
          d2.callback = null;
          d2 = c2;
          if ("function" !== typeof e2)
            throw Error(p$3(191, e2));
          e2.call(d2);
        }
      }
  }
  var jh = new aa.Component().refs;
  function kh(a, b2, c2, d2) {
    b2 = a.memoizedState;
    c2 = c2(d2, b2);
    c2 = null === c2 || void 0 === c2 ? b2 : A$1({}, b2, c2);
    a.memoizedState = c2;
    0 === a.lanes && (a.updateQueue.baseState = c2);
  }
  var nh = { isMounted: function(a) {
    return (a = a._reactInternals) ? Vb(a) === a : false;
  }, enqueueSetState: function(a, b2, c2) {
    a = a._reactInternals;
    var d2 = L(), e2 = lh(a), f2 = ch(d2, e2);
    f2.payload = b2;
    void 0 !== c2 && null !== c2 && (f2.callback = c2);
    b2 = dh(a, f2, e2);
    null !== b2 && (mh(b2, a, e2, d2), eh(b2, a, e2));
  }, enqueueReplaceState: function(a, b2, c2) {
    a = a._reactInternals;
    var d2 = L(), e2 = lh(a), f2 = ch(d2, e2);
    f2.tag = 1;
    f2.payload = b2;
    void 0 !== c2 && null !== c2 && (f2.callback = c2);
    b2 = dh(a, f2, e2);
    null !== b2 && (mh(b2, a, e2, d2), eh(b2, a, e2));
  }, enqueueForceUpdate: function(a, b2) {
    a = a._reactInternals;
    var c2 = L(), d2 = lh(a), e2 = ch(c2, d2);
    e2.tag = 2;
    void 0 !== b2 && null !== b2 && (e2.callback = b2);
    b2 = dh(a, e2, d2);
    null !== b2 && (mh(b2, a, d2, c2), eh(b2, a, d2));
  } };
  function oh(a, b2, c2, d2, e2, f2, g2) {
    a = a.stateNode;
    return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d2, f2, g2) : b2.prototype && b2.prototype.isPureReactComponent ? !Ie(c2, d2) || !Ie(e2, f2) : true;
  }
  function ph(a, b2, c2) {
    var d2 = false, e2 = Vf;
    var f2 = b2.contextType;
    "object" === typeof f2 && null !== f2 ? f2 = Vg(f2) : (e2 = Zf(b2) ? Xf : H.current, d2 = b2.contextTypes, f2 = (d2 = null !== d2 && void 0 !== d2) ? Yf(a, e2) : Vf);
    b2 = new b2(c2, f2);
    a.memoizedState = null !== b2.state && void 0 !== b2.state ? b2.state : null;
    b2.updater = nh;
    a.stateNode = b2;
    b2._reactInternals = a;
    d2 && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e2, a.__reactInternalMemoizedMaskedChildContext = f2);
    return b2;
  }
  function qh(a, b2, c2, d2) {
    a = b2.state;
    "function" === typeof b2.componentWillReceiveProps && b2.componentWillReceiveProps(c2, d2);
    "function" === typeof b2.UNSAFE_componentWillReceiveProps && b2.UNSAFE_componentWillReceiveProps(c2, d2);
    b2.state !== a && nh.enqueueReplaceState(b2, b2.state, null);
  }
  function rh(a, b2, c2, d2) {
    var e2 = a.stateNode;
    e2.props = c2;
    e2.state = a.memoizedState;
    e2.refs = jh;
    ah(a);
    var f2 = b2.contextType;
    "object" === typeof f2 && null !== f2 ? e2.context = Vg(f2) : (f2 = Zf(b2) ? Xf : H.current, e2.context = Yf(a, f2));
    e2.state = a.memoizedState;
    f2 = b2.getDerivedStateFromProps;
    "function" === typeof f2 && (kh(a, b2, f2, c2), e2.state = a.memoizedState);
    "function" === typeof b2.getDerivedStateFromProps || "function" === typeof e2.getSnapshotBeforeUpdate || "function" !== typeof e2.UNSAFE_componentWillMount && "function" !== typeof e2.componentWillMount || (b2 = e2.state, "function" === typeof e2.componentWillMount && e2.componentWillMount(), "function" === typeof e2.UNSAFE_componentWillMount && e2.UNSAFE_componentWillMount(), b2 !== e2.state && nh.enqueueReplaceState(e2, e2.state, null), gh(a, c2, e2, d2), e2.state = a.memoizedState);
    "function" === typeof e2.componentDidMount && (a.flags |= 4194308);
  }
  function sh(a, b2, c2) {
    a = c2.ref;
    if (null !== a && "function" !== typeof a && "object" !== typeof a) {
      if (c2._owner) {
        c2 = c2._owner;
        if (c2) {
          if (1 !== c2.tag)
            throw Error(p$3(309));
          var d2 = c2.stateNode;
        }
        if (!d2)
          throw Error(p$3(147, a));
        var e2 = d2, f2 = "" + a;
        if (null !== b2 && null !== b2.ref && "function" === typeof b2.ref && b2.ref._stringRef === f2)
          return b2.ref;
        b2 = function(a2) {
          var b3 = e2.refs;
          b3 === jh && (b3 = e2.refs = {});
          null === a2 ? delete b3[f2] : b3[f2] = a2;
        };
        b2._stringRef = f2;
        return b2;
      }
      if ("string" !== typeof a)
        throw Error(p$3(284));
      if (!c2._owner)
        throw Error(p$3(290, a));
    }
    return a;
  }
  function th(a, b2) {
    a = Object.prototype.toString.call(b2);
    throw Error(p$3(31, "[object Object]" === a ? "object with keys {" + Object.keys(b2).join(", ") + "}" : a));
  }
  function uh(a) {
    var b2 = a._init;
    return b2(a._payload);
  }
  function vh(a) {
    function b2(b3, c3) {
      if (a) {
        var d3 = b3.deletions;
        null === d3 ? (b3.deletions = [c3], b3.flags |= 16) : d3.push(c3);
      }
    }
    function c2(c3, d3) {
      if (!a)
        return null;
      for (; null !== d3; )
        b2(c3, d3), d3 = d3.sibling;
      return null;
    }
    function d2(a2, b3) {
      for (a2 = /* @__PURE__ */ new Map(); null !== b3; )
        null !== b3.key ? a2.set(b3.key, b3) : a2.set(b3.index, b3), b3 = b3.sibling;
      return a2;
    }
    function e2(a2, b3) {
      a2 = wh(a2, b3);
      a2.index = 0;
      a2.sibling = null;
      return a2;
    }
    function f2(b3, c3, d3) {
      b3.index = d3;
      if (!a)
        return b3.flags |= 1048576, c3;
      d3 = b3.alternate;
      if (null !== d3)
        return d3 = d3.index, d3 < c3 ? (b3.flags |= 2, c3) : d3;
      b3.flags |= 2;
      return c3;
    }
    function g2(b3) {
      a && null === b3.alternate && (b3.flags |= 2);
      return b3;
    }
    function h2(a2, b3, c3, d3) {
      if (null === b3 || 6 !== b3.tag)
        return b3 = xh(c3, a2.mode, d3), b3.return = a2, b3;
      b3 = e2(b3, c3);
      b3.return = a2;
      return b3;
    }
    function k2(a2, b3, c3, d3) {
      var f3 = c3.type;
      if (f3 === ya)
        return m2(a2, b3, c3.props.children, d3, c3.key);
      if (null !== b3 && (b3.elementType === f3 || "object" === typeof f3 && null !== f3 && f3.$$typeof === Ha && uh(f3) === b3.type))
        return d3 = e2(b3, c3.props), d3.ref = sh(a2, b3, c3), d3.return = a2, d3;
      d3 = yh(c3.type, c3.key, c3.props, null, a2.mode, d3);
      d3.ref = sh(a2, b3, c3);
      d3.return = a2;
      return d3;
    }
    function l2(a2, b3, c3, d3) {
      if (null === b3 || 4 !== b3.tag || b3.stateNode.containerInfo !== c3.containerInfo || b3.stateNode.implementation !== c3.implementation)
        return b3 = zh(c3, a2.mode, d3), b3.return = a2, b3;
      b3 = e2(b3, c3.children || []);
      b3.return = a2;
      return b3;
    }
    function m2(a2, b3, c3, d3, f3) {
      if (null === b3 || 7 !== b3.tag)
        return b3 = Ah(c3, a2.mode, d3, f3), b3.return = a2, b3;
      b3 = e2(b3, c3);
      b3.return = a2;
      return b3;
    }
    function q2(a2, b3, c3) {
      if ("string" === typeof b3 && "" !== b3 || "number" === typeof b3)
        return b3 = xh("" + b3, a2.mode, c3), b3.return = a2, b3;
      if ("object" === typeof b3 && null !== b3) {
        switch (b3.$$typeof) {
          case va:
            return c3 = yh(b3.type, b3.key, b3.props, null, a2.mode, c3), c3.ref = sh(a2, null, b3), c3.return = a2, c3;
          case wa:
            return b3 = zh(b3, a2.mode, c3), b3.return = a2, b3;
          case Ha:
            var d3 = b3._init;
            return q2(a2, d3(b3._payload), c3);
        }
        if (eb(b3) || Ka(b3))
          return b3 = Ah(b3, a2.mode, c3, null), b3.return = a2, b3;
        th(a2, b3);
      }
      return null;
    }
    function r2(a2, b3, c3, d3) {
      var e3 = null !== b3 ? b3.key : null;
      if ("string" === typeof c3 && "" !== c3 || "number" === typeof c3)
        return null !== e3 ? null : h2(a2, b3, "" + c3, d3);
      if ("object" === typeof c3 && null !== c3) {
        switch (c3.$$typeof) {
          case va:
            return c3.key === e3 ? k2(a2, b3, c3, d3) : null;
          case wa:
            return c3.key === e3 ? l2(a2, b3, c3, d3) : null;
          case Ha:
            return e3 = c3._init, r2(
              a2,
              b3,
              e3(c3._payload),
              d3
            );
        }
        if (eb(c3) || Ka(c3))
          return null !== e3 ? null : m2(a2, b3, c3, d3, null);
        th(a2, c3);
      }
      return null;
    }
    function y2(a2, b3, c3, d3, e3) {
      if ("string" === typeof d3 && "" !== d3 || "number" === typeof d3)
        return a2 = a2.get(c3) || null, h2(b3, a2, "" + d3, e3);
      if ("object" === typeof d3 && null !== d3) {
        switch (d3.$$typeof) {
          case va:
            return a2 = a2.get(null === d3.key ? c3 : d3.key) || null, k2(b3, a2, d3, e3);
          case wa:
            return a2 = a2.get(null === d3.key ? c3 : d3.key) || null, l2(b3, a2, d3, e3);
          case Ha:
            var f3 = d3._init;
            return y2(a2, b3, c3, f3(d3._payload), e3);
        }
        if (eb(d3) || Ka(d3))
          return a2 = a2.get(c3) || null, m2(b3, a2, d3, e3, null);
        th(b3, d3);
      }
      return null;
    }
    function n2(e3, g3, h3, k3) {
      for (var l3 = null, m3 = null, u2 = g3, w2 = g3 = 0, x2 = null; null !== u2 && w2 < h3.length; w2++) {
        u2.index > w2 ? (x2 = u2, u2 = null) : x2 = u2.sibling;
        var n3 = r2(e3, u2, h3[w2], k3);
        if (null === n3) {
          null === u2 && (u2 = x2);
          break;
        }
        a && u2 && null === n3.alternate && b2(e3, u2);
        g3 = f2(n3, g3, w2);
        null === m3 ? l3 = n3 : m3.sibling = n3;
        m3 = n3;
        u2 = x2;
      }
      if (w2 === h3.length)
        return c2(e3, u2), I && tg(e3, w2), l3;
      if (null === u2) {
        for (; w2 < h3.length; w2++)
          u2 = q2(e3, h3[w2], k3), null !== u2 && (g3 = f2(u2, g3, w2), null === m3 ? l3 = u2 : m3.sibling = u2, m3 = u2);
        I && tg(e3, w2);
        return l3;
      }
      for (u2 = d2(e3, u2); w2 < h3.length; w2++)
        x2 = y2(u2, e3, w2, h3[w2], k3), null !== x2 && (a && null !== x2.alternate && u2.delete(null === x2.key ? w2 : x2.key), g3 = f2(x2, g3, w2), null === m3 ? l3 = x2 : m3.sibling = x2, m3 = x2);
      a && u2.forEach(function(a2) {
        return b2(e3, a2);
      });
      I && tg(e3, w2);
      return l3;
    }
    function t2(e3, g3, h3, k3) {
      var l3 = Ka(h3);
      if ("function" !== typeof l3)
        throw Error(p$3(150));
      h3 = l3.call(h3);
      if (null == h3)
        throw Error(p$3(151));
      for (var u2 = l3 = null, m3 = g3, w2 = g3 = 0, x2 = null, n3 = h3.next(); null !== m3 && !n3.done; w2++, n3 = h3.next()) {
        m3.index > w2 ? (x2 = m3, m3 = null) : x2 = m3.sibling;
        var t3 = r2(e3, m3, n3.value, k3);
        if (null === t3) {
          null === m3 && (m3 = x2);
          break;
        }
        a && m3 && null === t3.alternate && b2(e3, m3);
        g3 = f2(t3, g3, w2);
        null === u2 ? l3 = t3 : u2.sibling = t3;
        u2 = t3;
        m3 = x2;
      }
      if (n3.done)
        return c2(
          e3,
          m3
        ), I && tg(e3, w2), l3;
      if (null === m3) {
        for (; !n3.done; w2++, n3 = h3.next())
          n3 = q2(e3, n3.value, k3), null !== n3 && (g3 = f2(n3, g3, w2), null === u2 ? l3 = n3 : u2.sibling = n3, u2 = n3);
        I && tg(e3, w2);
        return l3;
      }
      for (m3 = d2(e3, m3); !n3.done; w2++, n3 = h3.next())
        n3 = y2(m3, e3, w2, n3.value, k3), null !== n3 && (a && null !== n3.alternate && m3.delete(null === n3.key ? w2 : n3.key), g3 = f2(n3, g3, w2), null === u2 ? l3 = n3 : u2.sibling = n3, u2 = n3);
      a && m3.forEach(function(a2) {
        return b2(e3, a2);
      });
      I && tg(e3, w2);
      return l3;
    }
    function J2(a2, d3, f3, h3) {
      "object" === typeof f3 && null !== f3 && f3.type === ya && null === f3.key && (f3 = f3.props.children);
      if ("object" === typeof f3 && null !== f3) {
        switch (f3.$$typeof) {
          case va:
            a: {
              for (var k3 = f3.key, l3 = d3; null !== l3; ) {
                if (l3.key === k3) {
                  k3 = f3.type;
                  if (k3 === ya) {
                    if (7 === l3.tag) {
                      c2(a2, l3.sibling);
                      d3 = e2(l3, f3.props.children);
                      d3.return = a2;
                      a2 = d3;
                      break a;
                    }
                  } else if (l3.elementType === k3 || "object" === typeof k3 && null !== k3 && k3.$$typeof === Ha && uh(k3) === l3.type) {
                    c2(a2, l3.sibling);
                    d3 = e2(l3, f3.props);
                    d3.ref = sh(a2, l3, f3);
                    d3.return = a2;
                    a2 = d3;
                    break a;
                  }
                  c2(a2, l3);
                  break;
                } else
                  b2(a2, l3);
                l3 = l3.sibling;
              }
              f3.type === ya ? (d3 = Ah(f3.props.children, a2.mode, h3, f3.key), d3.return = a2, a2 = d3) : (h3 = yh(f3.type, f3.key, f3.props, null, a2.mode, h3), h3.ref = sh(a2, d3, f3), h3.return = a2, a2 = h3);
            }
            return g2(a2);
          case wa:
            a: {
              for (l3 = f3.key; null !== d3; ) {
                if (d3.key === l3)
                  if (4 === d3.tag && d3.stateNode.containerInfo === f3.containerInfo && d3.stateNode.implementation === f3.implementation) {
                    c2(a2, d3.sibling);
                    d3 = e2(d3, f3.children || []);
                    d3.return = a2;
                    a2 = d3;
                    break a;
                  } else {
                    c2(a2, d3);
                    break;
                  }
                else
                  b2(a2, d3);
                d3 = d3.sibling;
              }
              d3 = zh(f3, a2.mode, h3);
              d3.return = a2;
              a2 = d3;
            }
            return g2(a2);
          case Ha:
            return l3 = f3._init, J2(a2, d3, l3(f3._payload), h3);
        }
        if (eb(f3))
          return n2(a2, d3, f3, h3);
        if (Ka(f3))
          return t2(a2, d3, f3, h3);
        th(a2, f3);
      }
      return "string" === typeof f3 && "" !== f3 || "number" === typeof f3 ? (f3 = "" + f3, null !== d3 && 6 === d3.tag ? (c2(a2, d3.sibling), d3 = e2(d3, f3), d3.return = a2, a2 = d3) : (c2(a2, d3), d3 = xh(f3, a2.mode, h3), d3.return = a2, a2 = d3), g2(a2)) : c2(a2, d3);
    }
    return J2;
  }
  var Bh = vh(true), Ch = vh(false), Dh = {}, Eh = Uf(Dh), Fh = Uf(Dh), Gh = Uf(Dh);
  function Hh(a) {
    if (a === Dh)
      throw Error(p$3(174));
    return a;
  }
  function Ih(a, b2) {
    G(Gh, b2);
    G(Fh, a);
    G(Eh, Dh);
    a = b2.nodeType;
    switch (a) {
      case 9:
      case 11:
        b2 = (b2 = b2.documentElement) ? b2.namespaceURI : lb(null, "");
        break;
      default:
        a = 8 === a ? b2.parentNode : b2, b2 = a.namespaceURI || null, a = a.tagName, b2 = lb(b2, a);
    }
    E(Eh);
    G(Eh, b2);
  }
  function Jh() {
    E(Eh);
    E(Fh);
    E(Gh);
  }
  function Kh(a) {
    Hh(Gh.current);
    var b2 = Hh(Eh.current);
    var c2 = lb(b2, a.type);
    b2 !== c2 && (G(Fh, a), G(Eh, c2));
  }
  function Lh(a) {
    Fh.current === a && (E(Eh), E(Fh));
  }
  var M = Uf(0);
  function Mh(a) {
    for (var b2 = a; null !== b2; ) {
      if (13 === b2.tag) {
        var c2 = b2.memoizedState;
        if (null !== c2 && (c2 = c2.dehydrated, null === c2 || "$?" === c2.data || "$!" === c2.data))
          return b2;
      } else if (19 === b2.tag && void 0 !== b2.memoizedProps.revealOrder) {
        if (0 !== (b2.flags & 128))
          return b2;
      } else if (null !== b2.child) {
        b2.child.return = b2;
        b2 = b2.child;
        continue;
      }
      if (b2 === a)
        break;
      for (; null === b2.sibling; ) {
        if (null === b2.return || b2.return === a)
          return null;
        b2 = b2.return;
      }
      b2.sibling.return = b2.return;
      b2 = b2.sibling;
    }
    return null;
  }
  var Nh = [];
  function Oh() {
    for (var a = 0; a < Nh.length; a++)
      Nh[a]._workInProgressVersionPrimary = null;
    Nh.length = 0;
  }
  var Ph = ua.ReactCurrentDispatcher, Qh = ua.ReactCurrentBatchConfig, Rh = 0, N = null, O = null, P = null, Sh = false, Th = false, Uh = 0, Vh = 0;
  function Q() {
    throw Error(p$3(321));
  }
  function Wh(a, b2) {
    if (null === b2)
      return false;
    for (var c2 = 0; c2 < b2.length && c2 < a.length; c2++)
      if (!He(a[c2], b2[c2]))
        return false;
    return true;
  }
  function Xh(a, b2, c2, d2, e2, f2) {
    Rh = f2;
    N = b2;
    b2.memoizedState = null;
    b2.updateQueue = null;
    b2.lanes = 0;
    Ph.current = null === a || null === a.memoizedState ? Yh : Zh;
    a = c2(d2, e2);
    if (Th) {
      f2 = 0;
      do {
        Th = false;
        Uh = 0;
        if (25 <= f2)
          throw Error(p$3(301));
        f2 += 1;
        P = O = null;
        b2.updateQueue = null;
        Ph.current = $h;
        a = c2(d2, e2);
      } while (Th);
    }
    Ph.current = ai;
    b2 = null !== O && null !== O.next;
    Rh = 0;
    P = O = N = null;
    Sh = false;
    if (b2)
      throw Error(p$3(300));
    return a;
  }
  function bi() {
    var a = 0 !== Uh;
    Uh = 0;
    return a;
  }
  function ci() {
    var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    null === P ? N.memoizedState = P = a : P = P.next = a;
    return P;
  }
  function di() {
    if (null === O) {
      var a = N.alternate;
      a = null !== a ? a.memoizedState : null;
    } else
      a = O.next;
    var b2 = null === P ? N.memoizedState : P.next;
    if (null !== b2)
      P = b2, O = a;
    else {
      if (null === a)
        throw Error(p$3(310));
      O = a;
      a = { memoizedState: O.memoizedState, baseState: O.baseState, baseQueue: O.baseQueue, queue: O.queue, next: null };
      null === P ? N.memoizedState = P = a : P = P.next = a;
    }
    return P;
  }
  function ei(a, b2) {
    return "function" === typeof b2 ? b2(a) : b2;
  }
  function fi(a) {
    var b2 = di(), c2 = b2.queue;
    if (null === c2)
      throw Error(p$3(311));
    c2.lastRenderedReducer = a;
    var d2 = O, e2 = d2.baseQueue, f2 = c2.pending;
    if (null !== f2) {
      if (null !== e2) {
        var g2 = e2.next;
        e2.next = f2.next;
        f2.next = g2;
      }
      d2.baseQueue = e2 = f2;
      c2.pending = null;
    }
    if (null !== e2) {
      f2 = e2.next;
      d2 = d2.baseState;
      var h2 = g2 = null, k2 = null, l2 = f2;
      do {
        var m2 = l2.lane;
        if ((Rh & m2) === m2)
          null !== k2 && (k2 = k2.next = { lane: 0, action: l2.action, hasEagerState: l2.hasEagerState, eagerState: l2.eagerState, next: null }), d2 = l2.hasEagerState ? l2.eagerState : a(d2, l2.action);
        else {
          var q2 = {
            lane: m2,
            action: l2.action,
            hasEagerState: l2.hasEagerState,
            eagerState: l2.eagerState,
            next: null
          };
          null === k2 ? (h2 = k2 = q2, g2 = d2) : k2 = k2.next = q2;
          N.lanes |= m2;
          hh |= m2;
        }
        l2 = l2.next;
      } while (null !== l2 && l2 !== f2);
      null === k2 ? g2 = d2 : k2.next = h2;
      He(d2, b2.memoizedState) || (Ug = true);
      b2.memoizedState = d2;
      b2.baseState = g2;
      b2.baseQueue = k2;
      c2.lastRenderedState = d2;
    }
    a = c2.interleaved;
    if (null !== a) {
      e2 = a;
      do
        f2 = e2.lane, N.lanes |= f2, hh |= f2, e2 = e2.next;
      while (e2 !== a);
    } else
      null === e2 && (c2.lanes = 0);
    return [b2.memoizedState, c2.dispatch];
  }
  function gi(a) {
    var b2 = di(), c2 = b2.queue;
    if (null === c2)
      throw Error(p$3(311));
    c2.lastRenderedReducer = a;
    var d2 = c2.dispatch, e2 = c2.pending, f2 = b2.memoizedState;
    if (null !== e2) {
      c2.pending = null;
      var g2 = e2 = e2.next;
      do
        f2 = a(f2, g2.action), g2 = g2.next;
      while (g2 !== e2);
      He(f2, b2.memoizedState) || (Ug = true);
      b2.memoizedState = f2;
      null === b2.baseQueue && (b2.baseState = f2);
      c2.lastRenderedState = f2;
    }
    return [f2, d2];
  }
  function hi() {
  }
  function ii(a, b2) {
    var c2 = N, d2 = di(), e2 = b2(), f2 = !He(d2.memoizedState, e2);
    f2 && (d2.memoizedState = e2, Ug = true);
    d2 = d2.queue;
    ji(ki.bind(null, c2, d2, a), [a]);
    if (d2.getSnapshot !== b2 || f2 || null !== P && P.memoizedState.tag & 1) {
      c2.flags |= 2048;
      li(9, mi.bind(null, c2, d2, e2, b2), void 0, null);
      if (null === R)
        throw Error(p$3(349));
      0 !== (Rh & 30) || ni(c2, b2, e2);
    }
    return e2;
  }
  function ni(a, b2, c2) {
    a.flags |= 16384;
    a = { getSnapshot: b2, value: c2 };
    b2 = N.updateQueue;
    null === b2 ? (b2 = { lastEffect: null, stores: null }, N.updateQueue = b2, b2.stores = [a]) : (c2 = b2.stores, null === c2 ? b2.stores = [a] : c2.push(a));
  }
  function mi(a, b2, c2, d2) {
    b2.value = c2;
    b2.getSnapshot = d2;
    oi(b2) && pi(a);
  }
  function ki(a, b2, c2) {
    return c2(function() {
      oi(b2) && pi(a);
    });
  }
  function oi(a) {
    var b2 = a.getSnapshot;
    a = a.value;
    try {
      var c2 = b2();
      return !He(a, c2);
    } catch (d2) {
      return true;
    }
  }
  function pi(a) {
    var b2 = Zg(a, 1);
    null !== b2 && mh(b2, a, 1, -1);
  }
  function qi(a) {
    var b2 = ci();
    "function" === typeof a && (a = a());
    b2.memoizedState = b2.baseState = a;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: ei, lastRenderedState: a };
    b2.queue = a;
    a = a.dispatch = ri.bind(null, N, a);
    return [b2.memoizedState, a];
  }
  function li(a, b2, c2, d2) {
    a = { tag: a, create: b2, destroy: c2, deps: d2, next: null };
    b2 = N.updateQueue;
    null === b2 ? (b2 = { lastEffect: null, stores: null }, N.updateQueue = b2, b2.lastEffect = a.next = a) : (c2 = b2.lastEffect, null === c2 ? b2.lastEffect = a.next = a : (d2 = c2.next, c2.next = a, a.next = d2, b2.lastEffect = a));
    return a;
  }
  function si() {
    return di().memoizedState;
  }
  function ti(a, b2, c2, d2) {
    var e2 = ci();
    N.flags |= a;
    e2.memoizedState = li(1 | b2, c2, void 0, void 0 === d2 ? null : d2);
  }
  function ui(a, b2, c2, d2) {
    var e2 = di();
    d2 = void 0 === d2 ? null : d2;
    var f2 = void 0;
    if (null !== O) {
      var g2 = O.memoizedState;
      f2 = g2.destroy;
      if (null !== d2 && Wh(d2, g2.deps)) {
        e2.memoizedState = li(b2, c2, f2, d2);
        return;
      }
    }
    N.flags |= a;
    e2.memoizedState = li(1 | b2, c2, f2, d2);
  }
  function vi(a, b2) {
    return ti(8390656, 8, a, b2);
  }
  function ji(a, b2) {
    return ui(2048, 8, a, b2);
  }
  function wi(a, b2) {
    return ui(4, 2, a, b2);
  }
  function xi(a, b2) {
    return ui(4, 4, a, b2);
  }
  function yi(a, b2) {
    if ("function" === typeof b2)
      return a = a(), b2(a), function() {
        b2(null);
      };
    if (null !== b2 && void 0 !== b2)
      return a = a(), b2.current = a, function() {
        b2.current = null;
      };
  }
  function zi(a, b2, c2) {
    c2 = null !== c2 && void 0 !== c2 ? c2.concat([a]) : null;
    return ui(4, 4, yi.bind(null, b2, a), c2);
  }
  function Ai() {
  }
  function Bi(a, b2) {
    var c2 = di();
    b2 = void 0 === b2 ? null : b2;
    var d2 = c2.memoizedState;
    if (null !== d2 && null !== b2 && Wh(b2, d2[1]))
      return d2[0];
    c2.memoizedState = [a, b2];
    return a;
  }
  function Ci(a, b2) {
    var c2 = di();
    b2 = void 0 === b2 ? null : b2;
    var d2 = c2.memoizedState;
    if (null !== d2 && null !== b2 && Wh(b2, d2[1]))
      return d2[0];
    a = a();
    c2.memoizedState = [a, b2];
    return a;
  }
  function Di(a, b2, c2) {
    if (0 === (Rh & 21))
      return a.baseState && (a.baseState = false, Ug = true), a.memoizedState = c2;
    He(c2, b2) || (c2 = yc(), N.lanes |= c2, hh |= c2, a.baseState = true);
    return b2;
  }
  function Ei(a, b2) {
    var c2 = C;
    C = 0 !== c2 && 4 > c2 ? c2 : 4;
    a(true);
    var d2 = Qh.transition;
    Qh.transition = {};
    try {
      a(false), b2();
    } finally {
      C = c2, Qh.transition = d2;
    }
  }
  function Fi() {
    return di().memoizedState;
  }
  function Gi(a, b2, c2) {
    var d2 = lh(a);
    c2 = { lane: d2, action: c2, hasEagerState: false, eagerState: null, next: null };
    if (Hi(a))
      Ii(b2, c2);
    else if (c2 = Yg(a, b2, c2, d2), null !== c2) {
      var e2 = L();
      mh(c2, a, d2, e2);
      Ji(c2, b2, d2);
    }
  }
  function ri(a, b2, c2) {
    var d2 = lh(a), e2 = { lane: d2, action: c2, hasEagerState: false, eagerState: null, next: null };
    if (Hi(a))
      Ii(b2, e2);
    else {
      var f2 = a.alternate;
      if (0 === a.lanes && (null === f2 || 0 === f2.lanes) && (f2 = b2.lastRenderedReducer, null !== f2))
        try {
          var g2 = b2.lastRenderedState, h2 = f2(g2, c2);
          e2.hasEagerState = true;
          e2.eagerState = h2;
          if (He(h2, g2)) {
            var k2 = b2.interleaved;
            null === k2 ? (e2.next = e2, Xg(b2)) : (e2.next = k2.next, k2.next = e2);
            b2.interleaved = e2;
            return;
          }
        } catch (l2) {
        } finally {
        }
      c2 = Yg(a, b2, e2, d2);
      null !== c2 && (e2 = L(), mh(c2, a, d2, e2), Ji(c2, b2, d2));
    }
  }
  function Hi(a) {
    var b2 = a.alternate;
    return a === N || null !== b2 && b2 === N;
  }
  function Ii(a, b2) {
    Th = Sh = true;
    var c2 = a.pending;
    null === c2 ? b2.next = b2 : (b2.next = c2.next, c2.next = b2);
    a.pending = b2;
  }
  function Ji(a, b2, c2) {
    if (0 !== (c2 & 4194240)) {
      var d2 = b2.lanes;
      d2 &= a.pendingLanes;
      c2 |= d2;
      b2.lanes = c2;
      Cc(a, c2);
    }
  }
  var ai = { readContext: Vg, useCallback: Q, useContext: Q, useEffect: Q, useImperativeHandle: Q, useInsertionEffect: Q, useLayoutEffect: Q, useMemo: Q, useReducer: Q, useRef: Q, useState: Q, useDebugValue: Q, useDeferredValue: Q, useTransition: Q, useMutableSource: Q, useSyncExternalStore: Q, useId: Q, unstable_isNewReconciler: false }, Yh = { readContext: Vg, useCallback: function(a, b2) {
    ci().memoizedState = [a, void 0 === b2 ? null : b2];
    return a;
  }, useContext: Vg, useEffect: vi, useImperativeHandle: function(a, b2, c2) {
    c2 = null !== c2 && void 0 !== c2 ? c2.concat([a]) : null;
    return ti(
      4194308,
      4,
      yi.bind(null, b2, a),
      c2
    );
  }, useLayoutEffect: function(a, b2) {
    return ti(4194308, 4, a, b2);
  }, useInsertionEffect: function(a, b2) {
    return ti(4, 2, a, b2);
  }, useMemo: function(a, b2) {
    var c2 = ci();
    b2 = void 0 === b2 ? null : b2;
    a = a();
    c2.memoizedState = [a, b2];
    return a;
  }, useReducer: function(a, b2, c2) {
    var d2 = ci();
    b2 = void 0 !== c2 ? c2(b2) : b2;
    d2.memoizedState = d2.baseState = b2;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b2 };
    d2.queue = a;
    a = a.dispatch = Gi.bind(null, N, a);
    return [d2.memoizedState, a];
  }, useRef: function(a) {
    var b2 = ci();
    a = { current: a };
    return b2.memoizedState = a;
  }, useState: qi, useDebugValue: Ai, useDeferredValue: function(a) {
    return ci().memoizedState = a;
  }, useTransition: function() {
    var a = qi(false), b2 = a[0];
    a = Ei.bind(null, a[1]);
    ci().memoizedState = a;
    return [b2, a];
  }, useMutableSource: function() {
  }, useSyncExternalStore: function(a, b2, c2) {
    var d2 = N, e2 = ci();
    if (I) {
      if (void 0 === c2)
        throw Error(p$3(407));
      c2 = c2();
    } else {
      c2 = b2();
      if (null === R)
        throw Error(p$3(349));
      0 !== (Rh & 30) || ni(d2, b2, c2);
    }
    e2.memoizedState = c2;
    var f2 = { value: c2, getSnapshot: b2 };
    e2.queue = f2;
    vi(ki.bind(
      null,
      d2,
      f2,
      a
    ), [a]);
    d2.flags |= 2048;
    li(9, mi.bind(null, d2, f2, c2, b2), void 0, null);
    return c2;
  }, useId: function() {
    var a = ci(), b2 = R.identifierPrefix;
    if (I) {
      var c2 = sg;
      var d2 = rg;
      c2 = (d2 & ~(1 << 32 - oc(d2) - 1)).toString(32) + c2;
      b2 = ":" + b2 + "R" + c2;
      c2 = Uh++;
      0 < c2 && (b2 += "H" + c2.toString(32));
      b2 += ":";
    } else
      c2 = Vh++, b2 = ":" + b2 + "r" + c2.toString(32) + ":";
    return a.memoizedState = b2;
  }, unstable_isNewReconciler: false }, Zh = {
    readContext: Vg,
    useCallback: Bi,
    useContext: Vg,
    useEffect: ji,
    useImperativeHandle: zi,
    useInsertionEffect: wi,
    useLayoutEffect: xi,
    useMemo: Ci,
    useReducer: fi,
    useRef: si,
    useState: function() {
      return fi(ei);
    },
    useDebugValue: Ai,
    useDeferredValue: function(a) {
      var b2 = di();
      return Di(b2, O.memoizedState, a);
    },
    useTransition: function() {
      var a = fi(ei)[0], b2 = di().memoizedState;
      return [a, b2];
    },
    useMutableSource: hi,
    useSyncExternalStore: ii,
    useId: Fi,
    unstable_isNewReconciler: false
  }, $h = { readContext: Vg, useCallback: Bi, useContext: Vg, useEffect: ji, useImperativeHandle: zi, useInsertionEffect: wi, useLayoutEffect: xi, useMemo: Ci, useReducer: gi, useRef: si, useState: function() {
    return gi(ei);
  }, useDebugValue: Ai, useDeferredValue: function(a) {
    var b2 = di();
    return null === O ? b2.memoizedState = a : Di(b2, O.memoizedState, a);
  }, useTransition: function() {
    var a = gi(ei)[0], b2 = di().memoizedState;
    return [a, b2];
  }, useMutableSource: hi, useSyncExternalStore: ii, useId: Fi, unstable_isNewReconciler: false };
  function Ki(a, b2) {
    try {
      var c2 = "", d2 = b2;
      do
        c2 += Pa(d2), d2 = d2.return;
      while (d2);
      var e2 = c2;
    } catch (f2) {
      e2 = "\nError generating stack: " + f2.message + "\n" + f2.stack;
    }
    return { value: a, source: b2, stack: e2, digest: null };
  }
  function Li(a, b2, c2) {
    return { value: a, source: null, stack: null != c2 ? c2 : null, digest: null != b2 ? b2 : null };
  }
  function Mi(a, b2) {
    try {
      console.error(b2.value);
    } catch (c2) {
      setTimeout(function() {
        throw c2;
      });
    }
  }
  var Ni = "function" === typeof WeakMap ? WeakMap : Map;
  function Oi(a, b2, c2) {
    c2 = ch(-1, c2);
    c2.tag = 3;
    c2.payload = { element: null };
    var d2 = b2.value;
    c2.callback = function() {
      Pi || (Pi = true, Qi = d2);
      Mi(a, b2);
    };
    return c2;
  }
  function Ri(a, b2, c2) {
    c2 = ch(-1, c2);
    c2.tag = 3;
    var d2 = a.type.getDerivedStateFromError;
    if ("function" === typeof d2) {
      var e2 = b2.value;
      c2.payload = function() {
        return d2(e2);
      };
      c2.callback = function() {
        Mi(a, b2);
      };
    }
    var f2 = a.stateNode;
    null !== f2 && "function" === typeof f2.componentDidCatch && (c2.callback = function() {
      Mi(a, b2);
      "function" !== typeof d2 && (null === Si ? Si = /* @__PURE__ */ new Set([this]) : Si.add(this));
      var c3 = b2.stack;
      this.componentDidCatch(b2.value, { componentStack: null !== c3 ? c3 : "" });
    });
    return c2;
  }
  function Ti(a, b2, c2) {
    var d2 = a.pingCache;
    if (null === d2) {
      d2 = a.pingCache = new Ni();
      var e2 = /* @__PURE__ */ new Set();
      d2.set(b2, e2);
    } else
      e2 = d2.get(b2), void 0 === e2 && (e2 = /* @__PURE__ */ new Set(), d2.set(b2, e2));
    e2.has(c2) || (e2.add(c2), a = Ui.bind(null, a, b2, c2), b2.then(a, a));
  }
  function Vi(a) {
    do {
      var b2;
      if (b2 = 13 === a.tag)
        b2 = a.memoizedState, b2 = null !== b2 ? null !== b2.dehydrated ? true : false : true;
      if (b2)
        return a;
      a = a.return;
    } while (null !== a);
    return null;
  }
  function Wi(a, b2, c2, d2, e2) {
    if (0 === (a.mode & 1))
      return a === b2 ? a.flags |= 65536 : (a.flags |= 128, c2.flags |= 131072, c2.flags &= -52805, 1 === c2.tag && (null === c2.alternate ? c2.tag = 17 : (b2 = ch(-1, 1), b2.tag = 2, dh(c2, b2, 1))), c2.lanes |= 1), a;
    a.flags |= 65536;
    a.lanes = e2;
    return a;
  }
  var Xi = ua.ReactCurrentOwner, Ug = false;
  function Yi(a, b2, c2, d2) {
    b2.child = null === a ? Ch(b2, null, c2, d2) : Bh(b2, a.child, c2, d2);
  }
  function Zi(a, b2, c2, d2, e2) {
    c2 = c2.render;
    var f2 = b2.ref;
    Tg(b2, e2);
    d2 = Xh(a, b2, c2, d2, f2, e2);
    c2 = bi();
    if (null !== a && !Ug)
      return b2.updateQueue = a.updateQueue, b2.flags &= -2053, a.lanes &= ~e2, $i(a, b2, e2);
    I && c2 && vg(b2);
    b2.flags |= 1;
    Yi(a, b2, d2, e2);
    return b2.child;
  }
  function aj(a, b2, c2, d2, e2) {
    if (null === a) {
      var f2 = c2.type;
      if ("function" === typeof f2 && !bj(f2) && void 0 === f2.defaultProps && null === c2.compare && void 0 === c2.defaultProps)
        return b2.tag = 15, b2.type = f2, cj(a, b2, f2, d2, e2);
      a = yh(c2.type, null, d2, b2, b2.mode, e2);
      a.ref = b2.ref;
      a.return = b2;
      return b2.child = a;
    }
    f2 = a.child;
    if (0 === (a.lanes & e2)) {
      var g2 = f2.memoizedProps;
      c2 = c2.compare;
      c2 = null !== c2 ? c2 : Ie;
      if (c2(g2, d2) && a.ref === b2.ref)
        return $i(a, b2, e2);
    }
    b2.flags |= 1;
    a = wh(f2, d2);
    a.ref = b2.ref;
    a.return = b2;
    return b2.child = a;
  }
  function cj(a, b2, c2, d2, e2) {
    if (null !== a) {
      var f2 = a.memoizedProps;
      if (Ie(f2, d2) && a.ref === b2.ref)
        if (Ug = false, b2.pendingProps = d2 = f2, 0 !== (a.lanes & e2))
          0 !== (a.flags & 131072) && (Ug = true);
        else
          return b2.lanes = a.lanes, $i(a, b2, e2);
    }
    return dj(a, b2, c2, d2, e2);
  }
  function ej(a, b2, c2) {
    var d2 = b2.pendingProps, e2 = d2.children, f2 = null !== a ? a.memoizedState : null;
    if ("hidden" === d2.mode)
      if (0 === (b2.mode & 1))
        b2.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(fj, gj), gj |= c2;
      else {
        if (0 === (c2 & 1073741824))
          return a = null !== f2 ? f2.baseLanes | c2 : c2, b2.lanes = b2.childLanes = 1073741824, b2.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b2.updateQueue = null, G(fj, gj), gj |= a, null;
        b2.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
        d2 = null !== f2 ? f2.baseLanes : c2;
        G(fj, gj);
        gj |= d2;
      }
    else
      null !== f2 ? (d2 = f2.baseLanes | c2, b2.memoizedState = null) : d2 = c2, G(fj, gj), gj |= d2;
    Yi(a, b2, e2, c2);
    return b2.child;
  }
  function hj(a, b2) {
    var c2 = b2.ref;
    if (null === a && null !== c2 || null !== a && a.ref !== c2)
      b2.flags |= 512, b2.flags |= 2097152;
  }
  function dj(a, b2, c2, d2, e2) {
    var f2 = Zf(c2) ? Xf : H.current;
    f2 = Yf(b2, f2);
    Tg(b2, e2);
    c2 = Xh(a, b2, c2, d2, f2, e2);
    d2 = bi();
    if (null !== a && !Ug)
      return b2.updateQueue = a.updateQueue, b2.flags &= -2053, a.lanes &= ~e2, $i(a, b2, e2);
    I && d2 && vg(b2);
    b2.flags |= 1;
    Yi(a, b2, c2, e2);
    return b2.child;
  }
  function ij(a, b2, c2, d2, e2) {
    if (Zf(c2)) {
      var f2 = true;
      cg(b2);
    } else
      f2 = false;
    Tg(b2, e2);
    if (null === b2.stateNode)
      jj(a, b2), ph(b2, c2, d2), rh(b2, c2, d2, e2), d2 = true;
    else if (null === a) {
      var g2 = b2.stateNode, h2 = b2.memoizedProps;
      g2.props = h2;
      var k2 = g2.context, l2 = c2.contextType;
      "object" === typeof l2 && null !== l2 ? l2 = Vg(l2) : (l2 = Zf(c2) ? Xf : H.current, l2 = Yf(b2, l2));
      var m2 = c2.getDerivedStateFromProps, q2 = "function" === typeof m2 || "function" === typeof g2.getSnapshotBeforeUpdate;
      q2 || "function" !== typeof g2.UNSAFE_componentWillReceiveProps && "function" !== typeof g2.componentWillReceiveProps || (h2 !== d2 || k2 !== l2) && qh(b2, g2, d2, l2);
      $g = false;
      var r2 = b2.memoizedState;
      g2.state = r2;
      gh(b2, d2, g2, e2);
      k2 = b2.memoizedState;
      h2 !== d2 || r2 !== k2 || Wf.current || $g ? ("function" === typeof m2 && (kh(b2, c2, m2, d2), k2 = b2.memoizedState), (h2 = $g || oh(b2, c2, h2, d2, r2, k2, l2)) ? (q2 || "function" !== typeof g2.UNSAFE_componentWillMount && "function" !== typeof g2.componentWillMount || ("function" === typeof g2.componentWillMount && g2.componentWillMount(), "function" === typeof g2.UNSAFE_componentWillMount && g2.UNSAFE_componentWillMount()), "function" === typeof g2.componentDidMount && (b2.flags |= 4194308)) : ("function" === typeof g2.componentDidMount && (b2.flags |= 4194308), b2.memoizedProps = d2, b2.memoizedState = k2), g2.props = d2, g2.state = k2, g2.context = l2, d2 = h2) : ("function" === typeof g2.componentDidMount && (b2.flags |= 4194308), d2 = false);
    } else {
      g2 = b2.stateNode;
      bh(a, b2);
      h2 = b2.memoizedProps;
      l2 = b2.type === b2.elementType ? h2 : Lg(b2.type, h2);
      g2.props = l2;
      q2 = b2.pendingProps;
      r2 = g2.context;
      k2 = c2.contextType;
      "object" === typeof k2 && null !== k2 ? k2 = Vg(k2) : (k2 = Zf(c2) ? Xf : H.current, k2 = Yf(b2, k2));
      var y2 = c2.getDerivedStateFromProps;
      (m2 = "function" === typeof y2 || "function" === typeof g2.getSnapshotBeforeUpdate) || "function" !== typeof g2.UNSAFE_componentWillReceiveProps && "function" !== typeof g2.componentWillReceiveProps || (h2 !== q2 || r2 !== k2) && qh(b2, g2, d2, k2);
      $g = false;
      r2 = b2.memoizedState;
      g2.state = r2;
      gh(b2, d2, g2, e2);
      var n2 = b2.memoizedState;
      h2 !== q2 || r2 !== n2 || Wf.current || $g ? ("function" === typeof y2 && (kh(b2, c2, y2, d2), n2 = b2.memoizedState), (l2 = $g || oh(b2, c2, l2, d2, r2, n2, k2) || false) ? (m2 || "function" !== typeof g2.UNSAFE_componentWillUpdate && "function" !== typeof g2.componentWillUpdate || ("function" === typeof g2.componentWillUpdate && g2.componentWillUpdate(d2, n2, k2), "function" === typeof g2.UNSAFE_componentWillUpdate && g2.UNSAFE_componentWillUpdate(d2, n2, k2)), "function" === typeof g2.componentDidUpdate && (b2.flags |= 4), "function" === typeof g2.getSnapshotBeforeUpdate && (b2.flags |= 1024)) : ("function" !== typeof g2.componentDidUpdate || h2 === a.memoizedProps && r2 === a.memoizedState || (b2.flags |= 4), "function" !== typeof g2.getSnapshotBeforeUpdate || h2 === a.memoizedProps && r2 === a.memoizedState || (b2.flags |= 1024), b2.memoizedProps = d2, b2.memoizedState = n2), g2.props = d2, g2.state = n2, g2.context = k2, d2 = l2) : ("function" !== typeof g2.componentDidUpdate || h2 === a.memoizedProps && r2 === a.memoizedState || (b2.flags |= 4), "function" !== typeof g2.getSnapshotBeforeUpdate || h2 === a.memoizedProps && r2 === a.memoizedState || (b2.flags |= 1024), d2 = false);
    }
    return kj(a, b2, c2, d2, f2, e2);
  }
  function kj(a, b2, c2, d2, e2, f2) {
    hj(a, b2);
    var g2 = 0 !== (b2.flags & 128);
    if (!d2 && !g2)
      return e2 && dg(b2, c2, false), $i(a, b2, f2);
    d2 = b2.stateNode;
    Xi.current = b2;
    var h2 = g2 && "function" !== typeof c2.getDerivedStateFromError ? null : d2.render();
    b2.flags |= 1;
    null !== a && g2 ? (b2.child = Bh(b2, a.child, null, f2), b2.child = Bh(b2, null, h2, f2)) : Yi(a, b2, h2, f2);
    b2.memoizedState = d2.state;
    e2 && dg(b2, c2, true);
    return b2.child;
  }
  function lj(a) {
    var b2 = a.stateNode;
    b2.pendingContext ? ag(a, b2.pendingContext, b2.pendingContext !== b2.context) : b2.context && ag(a, b2.context, false);
    Ih(a, b2.containerInfo);
  }
  function mj(a, b2, c2, d2, e2) {
    Ig();
    Jg(e2);
    b2.flags |= 256;
    Yi(a, b2, c2, d2);
    return b2.child;
  }
  var nj = { dehydrated: null, treeContext: null, retryLane: 0 };
  function oj(a) {
    return { baseLanes: a, cachePool: null, transitions: null };
  }
  function pj(a, b2, c2) {
    var d2 = b2.pendingProps, e2 = M.current, f2 = false, g2 = 0 !== (b2.flags & 128), h2;
    (h2 = g2) || (h2 = null !== a && null === a.memoizedState ? false : 0 !== (e2 & 2));
    if (h2)
      f2 = true, b2.flags &= -129;
    else if (null === a || null !== a.memoizedState)
      e2 |= 1;
    G(M, e2 & 1);
    if (null === a) {
      Eg(b2);
      a = b2.memoizedState;
      if (null !== a && (a = a.dehydrated, null !== a))
        return 0 === (b2.mode & 1) ? b2.lanes = 1 : "$!" === a.data ? b2.lanes = 8 : b2.lanes = 1073741824, null;
      g2 = d2.children;
      a = d2.fallback;
      return f2 ? (d2 = b2.mode, f2 = b2.child, g2 = { mode: "hidden", children: g2 }, 0 === (d2 & 1) && null !== f2 ? (f2.childLanes = 0, f2.pendingProps = g2) : f2 = qj(g2, d2, 0, null), a = Ah(a, d2, c2, null), f2.return = b2, a.return = b2, f2.sibling = a, b2.child = f2, b2.child.memoizedState = oj(c2), b2.memoizedState = nj, a) : rj(b2, g2);
    }
    e2 = a.memoizedState;
    if (null !== e2 && (h2 = e2.dehydrated, null !== h2))
      return sj(a, b2, g2, d2, h2, e2, c2);
    if (f2) {
      f2 = d2.fallback;
      g2 = b2.mode;
      e2 = a.child;
      h2 = e2.sibling;
      var k2 = { mode: "hidden", children: d2.children };
      0 === (g2 & 1) && b2.child !== e2 ? (d2 = b2.child, d2.childLanes = 0, d2.pendingProps = k2, b2.deletions = null) : (d2 = wh(e2, k2), d2.subtreeFlags = e2.subtreeFlags & 14680064);
      null !== h2 ? f2 = wh(h2, f2) : (f2 = Ah(f2, g2, c2, null), f2.flags |= 2);
      f2.return = b2;
      d2.return = b2;
      d2.sibling = f2;
      b2.child = d2;
      d2 = f2;
      f2 = b2.child;
      g2 = a.child.memoizedState;
      g2 = null === g2 ? oj(c2) : { baseLanes: g2.baseLanes | c2, cachePool: null, transitions: g2.transitions };
      f2.memoizedState = g2;
      f2.childLanes = a.childLanes & ~c2;
      b2.memoizedState = nj;
      return d2;
    }
    f2 = a.child;
    a = f2.sibling;
    d2 = wh(f2, { mode: "visible", children: d2.children });
    0 === (b2.mode & 1) && (d2.lanes = c2);
    d2.return = b2;
    d2.sibling = null;
    null !== a && (c2 = b2.deletions, null === c2 ? (b2.deletions = [a], b2.flags |= 16) : c2.push(a));
    b2.child = d2;
    b2.memoizedState = null;
    return d2;
  }
  function rj(a, b2) {
    b2 = qj({ mode: "visible", children: b2 }, a.mode, 0, null);
    b2.return = a;
    return a.child = b2;
  }
  function tj(a, b2, c2, d2) {
    null !== d2 && Jg(d2);
    Bh(b2, a.child, null, c2);
    a = rj(b2, b2.pendingProps.children);
    a.flags |= 2;
    b2.memoizedState = null;
    return a;
  }
  function sj(a, b2, c2, d2, e2, f2, g2) {
    if (c2) {
      if (b2.flags & 256)
        return b2.flags &= -257, d2 = Li(Error(p$3(422))), tj(a, b2, g2, d2);
      if (null !== b2.memoizedState)
        return b2.child = a.child, b2.flags |= 128, null;
      f2 = d2.fallback;
      e2 = b2.mode;
      d2 = qj({ mode: "visible", children: d2.children }, e2, 0, null);
      f2 = Ah(f2, e2, g2, null);
      f2.flags |= 2;
      d2.return = b2;
      f2.return = b2;
      d2.sibling = f2;
      b2.child = d2;
      0 !== (b2.mode & 1) && Bh(b2, a.child, null, g2);
      b2.child.memoizedState = oj(g2);
      b2.memoizedState = nj;
      return f2;
    }
    if (0 === (b2.mode & 1))
      return tj(a, b2, g2, null);
    if ("$!" === e2.data) {
      d2 = e2.nextSibling && e2.nextSibling.dataset;
      if (d2)
        var h2 = d2.dgst;
      d2 = h2;
      f2 = Error(p$3(419));
      d2 = Li(f2, d2, void 0);
      return tj(a, b2, g2, d2);
    }
    h2 = 0 !== (g2 & a.childLanes);
    if (Ug || h2) {
      d2 = R;
      if (null !== d2) {
        switch (g2 & -g2) {
          case 4:
            e2 = 2;
            break;
          case 16:
            e2 = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            e2 = 32;
            break;
          case 536870912:
            e2 = 268435456;
            break;
          default:
            e2 = 0;
        }
        e2 = 0 !== (e2 & (d2.suspendedLanes | g2)) ? 0 : e2;
        0 !== e2 && e2 !== f2.retryLane && (f2.retryLane = e2, Zg(a, e2), mh(d2, a, e2, -1));
      }
      uj();
      d2 = Li(Error(p$3(421)));
      return tj(a, b2, g2, d2);
    }
    if ("$?" === e2.data)
      return b2.flags |= 128, b2.child = a.child, b2 = vj.bind(null, a), e2._reactRetry = b2, null;
    a = f2.treeContext;
    yg = Lf(e2.nextSibling);
    xg = b2;
    I = true;
    zg = null;
    null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b2);
    b2 = rj(b2, d2.children);
    b2.flags |= 4096;
    return b2;
  }
  function wj(a, b2, c2) {
    a.lanes |= b2;
    var d2 = a.alternate;
    null !== d2 && (d2.lanes |= b2);
    Sg(a.return, b2, c2);
  }
  function xj(a, b2, c2, d2, e2) {
    var f2 = a.memoizedState;
    null === f2 ? a.memoizedState = { isBackwards: b2, rendering: null, renderingStartTime: 0, last: d2, tail: c2, tailMode: e2 } : (f2.isBackwards = b2, f2.rendering = null, f2.renderingStartTime = 0, f2.last = d2, f2.tail = c2, f2.tailMode = e2);
  }
  function yj(a, b2, c2) {
    var d2 = b2.pendingProps, e2 = d2.revealOrder, f2 = d2.tail;
    Yi(a, b2, d2.children, c2);
    d2 = M.current;
    if (0 !== (d2 & 2))
      d2 = d2 & 1 | 2, b2.flags |= 128;
    else {
      if (null !== a && 0 !== (a.flags & 128))
        a:
          for (a = b2.child; null !== a; ) {
            if (13 === a.tag)
              null !== a.memoizedState && wj(a, c2, b2);
            else if (19 === a.tag)
              wj(a, c2, b2);
            else if (null !== a.child) {
              a.child.return = a;
              a = a.child;
              continue;
            }
            if (a === b2)
              break a;
            for (; null === a.sibling; ) {
              if (null === a.return || a.return === b2)
                break a;
              a = a.return;
            }
            a.sibling.return = a.return;
            a = a.sibling;
          }
      d2 &= 1;
    }
    G(M, d2);
    if (0 === (b2.mode & 1))
      b2.memoizedState = null;
    else
      switch (e2) {
        case "forwards":
          c2 = b2.child;
          for (e2 = null; null !== c2; )
            a = c2.alternate, null !== a && null === Mh(a) && (e2 = c2), c2 = c2.sibling;
          c2 = e2;
          null === c2 ? (e2 = b2.child, b2.child = null) : (e2 = c2.sibling, c2.sibling = null);
          xj(b2, false, e2, c2, f2);
          break;
        case "backwards":
          c2 = null;
          e2 = b2.child;
          for (b2.child = null; null !== e2; ) {
            a = e2.alternate;
            if (null !== a && null === Mh(a)) {
              b2.child = e2;
              break;
            }
            a = e2.sibling;
            e2.sibling = c2;
            c2 = e2;
            e2 = a;
          }
          xj(b2, true, c2, null, f2);
          break;
        case "together":
          xj(b2, false, null, null, void 0);
          break;
        default:
          b2.memoizedState = null;
      }
    return b2.child;
  }
  function jj(a, b2) {
    0 === (b2.mode & 1) && null !== a && (a.alternate = null, b2.alternate = null, b2.flags |= 2);
  }
  function $i(a, b2, c2) {
    null !== a && (b2.dependencies = a.dependencies);
    hh |= b2.lanes;
    if (0 === (c2 & b2.childLanes))
      return null;
    if (null !== a && b2.child !== a.child)
      throw Error(p$3(153));
    if (null !== b2.child) {
      a = b2.child;
      c2 = wh(a, a.pendingProps);
      b2.child = c2;
      for (c2.return = b2; null !== a.sibling; )
        a = a.sibling, c2 = c2.sibling = wh(a, a.pendingProps), c2.return = b2;
      c2.sibling = null;
    }
    return b2.child;
  }
  function zj(a, b2, c2) {
    switch (b2.tag) {
      case 3:
        lj(b2);
        Ig();
        break;
      case 5:
        Kh(b2);
        break;
      case 1:
        Zf(b2.type) && cg(b2);
        break;
      case 4:
        Ih(b2, b2.stateNode.containerInfo);
        break;
      case 10:
        var d2 = b2.type._context, e2 = b2.memoizedProps.value;
        G(Mg, d2._currentValue);
        d2._currentValue = e2;
        break;
      case 13:
        d2 = b2.memoizedState;
        if (null !== d2) {
          if (null !== d2.dehydrated)
            return G(M, M.current & 1), b2.flags |= 128, null;
          if (0 !== (c2 & b2.child.childLanes))
            return pj(a, b2, c2);
          G(M, M.current & 1);
          a = $i(a, b2, c2);
          return null !== a ? a.sibling : null;
        }
        G(M, M.current & 1);
        break;
      case 19:
        d2 = 0 !== (c2 & b2.childLanes);
        if (0 !== (a.flags & 128)) {
          if (d2)
            return yj(a, b2, c2);
          b2.flags |= 128;
        }
        e2 = b2.memoizedState;
        null !== e2 && (e2.rendering = null, e2.tail = null, e2.lastEffect = null);
        G(M, M.current);
        if (d2)
          break;
        else
          return null;
      case 22:
      case 23:
        return b2.lanes = 0, ej(a, b2, c2);
    }
    return $i(a, b2, c2);
  }
  var Aj, Bj, Cj, Dj;
  Aj = function(a, b2) {
    for (var c2 = b2.child; null !== c2; ) {
      if (5 === c2.tag || 6 === c2.tag)
        a.appendChild(c2.stateNode);
      else if (4 !== c2.tag && null !== c2.child) {
        c2.child.return = c2;
        c2 = c2.child;
        continue;
      }
      if (c2 === b2)
        break;
      for (; null === c2.sibling; ) {
        if (null === c2.return || c2.return === b2)
          return;
        c2 = c2.return;
      }
      c2.sibling.return = c2.return;
      c2 = c2.sibling;
    }
  };
  Bj = function() {
  };
  Cj = function(a, b2, c2, d2) {
    var e2 = a.memoizedProps;
    if (e2 !== d2) {
      a = b2.stateNode;
      Hh(Eh.current);
      var f2 = null;
      switch (c2) {
        case "input":
          e2 = Ya(a, e2);
          d2 = Ya(a, d2);
          f2 = [];
          break;
        case "select":
          e2 = A$1({}, e2, { value: void 0 });
          d2 = A$1({}, d2, { value: void 0 });
          f2 = [];
          break;
        case "textarea":
          e2 = gb(a, e2);
          d2 = gb(a, d2);
          f2 = [];
          break;
        default:
          "function" !== typeof e2.onClick && "function" === typeof d2.onClick && (a.onclick = Bf);
      }
      ub(c2, d2);
      var g2;
      c2 = null;
      for (l2 in e2)
        if (!d2.hasOwnProperty(l2) && e2.hasOwnProperty(l2) && null != e2[l2])
          if ("style" === l2) {
            var h2 = e2[l2];
            for (g2 in h2)
              h2.hasOwnProperty(g2) && (c2 || (c2 = {}), c2[g2] = "");
          } else
            "dangerouslySetInnerHTML" !== l2 && "children" !== l2 && "suppressContentEditableWarning" !== l2 && "suppressHydrationWarning" !== l2 && "autoFocus" !== l2 && (ea.hasOwnProperty(l2) ? f2 || (f2 = []) : (f2 = f2 || []).push(l2, null));
      for (l2 in d2) {
        var k2 = d2[l2];
        h2 = null != e2 ? e2[l2] : void 0;
        if (d2.hasOwnProperty(l2) && k2 !== h2 && (null != k2 || null != h2))
          if ("style" === l2)
            if (h2) {
              for (g2 in h2)
                !h2.hasOwnProperty(g2) || k2 && k2.hasOwnProperty(g2) || (c2 || (c2 = {}), c2[g2] = "");
              for (g2 in k2)
                k2.hasOwnProperty(g2) && h2[g2] !== k2[g2] && (c2 || (c2 = {}), c2[g2] = k2[g2]);
            } else
              c2 || (f2 || (f2 = []), f2.push(
                l2,
                c2
              )), c2 = k2;
          else
            "dangerouslySetInnerHTML" === l2 ? (k2 = k2 ? k2.__html : void 0, h2 = h2 ? h2.__html : void 0, null != k2 && h2 !== k2 && (f2 = f2 || []).push(l2, k2)) : "children" === l2 ? "string" !== typeof k2 && "number" !== typeof k2 || (f2 = f2 || []).push(l2, "" + k2) : "suppressContentEditableWarning" !== l2 && "suppressHydrationWarning" !== l2 && (ea.hasOwnProperty(l2) ? (null != k2 && "onScroll" === l2 && D("scroll", a), f2 || h2 === k2 || (f2 = [])) : (f2 = f2 || []).push(l2, k2));
      }
      c2 && (f2 = f2 || []).push("style", c2);
      var l2 = f2;
      if (b2.updateQueue = l2)
        b2.flags |= 4;
    }
  };
  Dj = function(a, b2, c2, d2) {
    c2 !== d2 && (b2.flags |= 4);
  };
  function Ej(a, b2) {
    if (!I)
      switch (a.tailMode) {
        case "hidden":
          b2 = a.tail;
          for (var c2 = null; null !== b2; )
            null !== b2.alternate && (c2 = b2), b2 = b2.sibling;
          null === c2 ? a.tail = null : c2.sibling = null;
          break;
        case "collapsed":
          c2 = a.tail;
          for (var d2 = null; null !== c2; )
            null !== c2.alternate && (d2 = c2), c2 = c2.sibling;
          null === d2 ? b2 || null === a.tail ? a.tail = null : a.tail.sibling = null : d2.sibling = null;
      }
  }
  function S(a) {
    var b2 = null !== a.alternate && a.alternate.child === a.child, c2 = 0, d2 = 0;
    if (b2)
      for (var e2 = a.child; null !== e2; )
        c2 |= e2.lanes | e2.childLanes, d2 |= e2.subtreeFlags & 14680064, d2 |= e2.flags & 14680064, e2.return = a, e2 = e2.sibling;
    else
      for (e2 = a.child; null !== e2; )
        c2 |= e2.lanes | e2.childLanes, d2 |= e2.subtreeFlags, d2 |= e2.flags, e2.return = a, e2 = e2.sibling;
    a.subtreeFlags |= d2;
    a.childLanes = c2;
    return b2;
  }
  function Fj(a, b2, c2) {
    var d2 = b2.pendingProps;
    wg(b2);
    switch (b2.tag) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return S(b2), null;
      case 1:
        return Zf(b2.type) && $f(), S(b2), null;
      case 3:
        d2 = b2.stateNode;
        Jh();
        E(Wf);
        E(H);
        Oh();
        d2.pendingContext && (d2.context = d2.pendingContext, d2.pendingContext = null);
        if (null === a || null === a.child)
          Gg(b2) ? b2.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b2.flags & 256) || (b2.flags |= 1024, null !== zg && (Gj(zg), zg = null));
        Bj(a, b2);
        S(b2);
        return null;
      case 5:
        Lh(b2);
        var e2 = Hh(Gh.current);
        c2 = b2.type;
        if (null !== a && null != b2.stateNode)
          Cj(a, b2, c2, d2, e2), a.ref !== b2.ref && (b2.flags |= 512, b2.flags |= 2097152);
        else {
          if (!d2) {
            if (null === b2.stateNode)
              throw Error(p$3(166));
            S(b2);
            return null;
          }
          a = Hh(Eh.current);
          if (Gg(b2)) {
            d2 = b2.stateNode;
            c2 = b2.type;
            var f2 = b2.memoizedProps;
            d2[Of] = b2;
            d2[Pf] = f2;
            a = 0 !== (b2.mode & 1);
            switch (c2) {
              case "dialog":
                D("cancel", d2);
                D("close", d2);
                break;
              case "iframe":
              case "object":
              case "embed":
                D("load", d2);
                break;
              case "video":
              case "audio":
                for (e2 = 0; e2 < lf.length; e2++)
                  D(lf[e2], d2);
                break;
              case "source":
                D("error", d2);
                break;
              case "img":
              case "image":
              case "link":
                D(
                  "error",
                  d2
                );
                D("load", d2);
                break;
              case "details":
                D("toggle", d2);
                break;
              case "input":
                Za(d2, f2);
                D("invalid", d2);
                break;
              case "select":
                d2._wrapperState = { wasMultiple: !!f2.multiple };
                D("invalid", d2);
                break;
              case "textarea":
                hb(d2, f2), D("invalid", d2);
            }
            ub(c2, f2);
            e2 = null;
            for (var g2 in f2)
              if (f2.hasOwnProperty(g2)) {
                var h2 = f2[g2];
                "children" === g2 ? "string" === typeof h2 ? d2.textContent !== h2 && (true !== f2.suppressHydrationWarning && Af(d2.textContent, h2, a), e2 = ["children", h2]) : "number" === typeof h2 && d2.textContent !== "" + h2 && (true !== f2.suppressHydrationWarning && Af(
                  d2.textContent,
                  h2,
                  a
                ), e2 = ["children", "" + h2]) : ea.hasOwnProperty(g2) && null != h2 && "onScroll" === g2 && D("scroll", d2);
              }
            switch (c2) {
              case "input":
                Va(d2);
                db(d2, f2, true);
                break;
              case "textarea":
                Va(d2);
                jb(d2);
                break;
              case "select":
              case "option":
                break;
              default:
                "function" === typeof f2.onClick && (d2.onclick = Bf);
            }
            d2 = e2;
            b2.updateQueue = d2;
            null !== d2 && (b2.flags |= 4);
          } else {
            g2 = 9 === e2.nodeType ? e2 : e2.ownerDocument;
            "http://www.w3.org/1999/xhtml" === a && (a = kb(c2));
            "http://www.w3.org/1999/xhtml" === a ? "script" === c2 ? (a = g2.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d2.is ? a = g2.createElement(c2, { is: d2.is }) : (a = g2.createElement(c2), "select" === c2 && (g2 = a, d2.multiple ? g2.multiple = true : d2.size && (g2.size = d2.size))) : a = g2.createElementNS(a, c2);
            a[Of] = b2;
            a[Pf] = d2;
            Aj(a, b2, false, false);
            b2.stateNode = a;
            a: {
              g2 = vb(c2, d2);
              switch (c2) {
                case "dialog":
                  D("cancel", a);
                  D("close", a);
                  e2 = d2;
                  break;
                case "iframe":
                case "object":
                case "embed":
                  D("load", a);
                  e2 = d2;
                  break;
                case "video":
                case "audio":
                  for (e2 = 0; e2 < lf.length; e2++)
                    D(lf[e2], a);
                  e2 = d2;
                  break;
                case "source":
                  D("error", a);
                  e2 = d2;
                  break;
                case "img":
                case "image":
                case "link":
                  D(
                    "error",
                    a
                  );
                  D("load", a);
                  e2 = d2;
                  break;
                case "details":
                  D("toggle", a);
                  e2 = d2;
                  break;
                case "input":
                  Za(a, d2);
                  e2 = Ya(a, d2);
                  D("invalid", a);
                  break;
                case "option":
                  e2 = d2;
                  break;
                case "select":
                  a._wrapperState = { wasMultiple: !!d2.multiple };
                  e2 = A$1({}, d2, { value: void 0 });
                  D("invalid", a);
                  break;
                case "textarea":
                  hb(a, d2);
                  e2 = gb(a, d2);
                  D("invalid", a);
                  break;
                default:
                  e2 = d2;
              }
              ub(c2, e2);
              h2 = e2;
              for (f2 in h2)
                if (h2.hasOwnProperty(f2)) {
                  var k2 = h2[f2];
                  "style" === f2 ? sb(a, k2) : "dangerouslySetInnerHTML" === f2 ? (k2 = k2 ? k2.__html : void 0, null != k2 && nb(a, k2)) : "children" === f2 ? "string" === typeof k2 ? ("textarea" !== c2 || "" !== k2) && ob(a, k2) : "number" === typeof k2 && ob(a, "" + k2) : "suppressContentEditableWarning" !== f2 && "suppressHydrationWarning" !== f2 && "autoFocus" !== f2 && (ea.hasOwnProperty(f2) ? null != k2 && "onScroll" === f2 && D("scroll", a) : null != k2 && ta(a, f2, k2, g2));
                }
              switch (c2) {
                case "input":
                  Va(a);
                  db(a, d2, false);
                  break;
                case "textarea":
                  Va(a);
                  jb(a);
                  break;
                case "option":
                  null != d2.value && a.setAttribute("value", "" + Sa(d2.value));
                  break;
                case "select":
                  a.multiple = !!d2.multiple;
                  f2 = d2.value;
                  null != f2 ? fb(a, !!d2.multiple, f2, false) : null != d2.defaultValue && fb(
                    a,
                    !!d2.multiple,
                    d2.defaultValue,
                    true
                  );
                  break;
                default:
                  "function" === typeof e2.onClick && (a.onclick = Bf);
              }
              switch (c2) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  d2 = !!d2.autoFocus;
                  break a;
                case "img":
                  d2 = true;
                  break a;
                default:
                  d2 = false;
              }
            }
            d2 && (b2.flags |= 4);
          }
          null !== b2.ref && (b2.flags |= 512, b2.flags |= 2097152);
        }
        S(b2);
        return null;
      case 6:
        if (a && null != b2.stateNode)
          Dj(a, b2, a.memoizedProps, d2);
        else {
          if ("string" !== typeof d2 && null === b2.stateNode)
            throw Error(p$3(166));
          c2 = Hh(Gh.current);
          Hh(Eh.current);
          if (Gg(b2)) {
            d2 = b2.stateNode;
            c2 = b2.memoizedProps;
            d2[Of] = b2;
            if (f2 = d2.nodeValue !== c2) {
              if (a = xg, null !== a)
                switch (a.tag) {
                  case 3:
                    Af(d2.nodeValue, c2, 0 !== (a.mode & 1));
                    break;
                  case 5:
                    true !== a.memoizedProps.suppressHydrationWarning && Af(d2.nodeValue, c2, 0 !== (a.mode & 1));
                }
            }
            f2 && (b2.flags |= 4);
          } else
            d2 = (9 === c2.nodeType ? c2 : c2.ownerDocument).createTextNode(d2), d2[Of] = b2, b2.stateNode = d2;
        }
        S(b2);
        return null;
      case 13:
        E(M);
        d2 = b2.memoizedState;
        if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
          if (I && null !== yg && 0 !== (b2.mode & 1) && 0 === (b2.flags & 128))
            Hg(), Ig(), b2.flags |= 98560, f2 = false;
          else if (f2 = Gg(b2), null !== d2 && null !== d2.dehydrated) {
            if (null === a) {
              if (!f2)
                throw Error(p$3(318));
              f2 = b2.memoizedState;
              f2 = null !== f2 ? f2.dehydrated : null;
              if (!f2)
                throw Error(p$3(317));
              f2[Of] = b2;
            } else
              Ig(), 0 === (b2.flags & 128) && (b2.memoizedState = null), b2.flags |= 4;
            S(b2);
            f2 = false;
          } else
            null !== zg && (Gj(zg), zg = null), f2 = true;
          if (!f2)
            return b2.flags & 65536 ? b2 : null;
        }
        if (0 !== (b2.flags & 128))
          return b2.lanes = c2, b2;
        d2 = null !== d2;
        d2 !== (null !== a && null !== a.memoizedState) && d2 && (b2.child.flags |= 8192, 0 !== (b2.mode & 1) && (null === a || 0 !== (M.current & 1) ? 0 === T && (T = 3) : uj()));
        null !== b2.updateQueue && (b2.flags |= 4);
        S(b2);
        return null;
      case 4:
        return Jh(), Bj(a, b2), null === a && sf(b2.stateNode.containerInfo), S(b2), null;
      case 10:
        return Rg(b2.type._context), S(b2), null;
      case 17:
        return Zf(b2.type) && $f(), S(b2), null;
      case 19:
        E(M);
        f2 = b2.memoizedState;
        if (null === f2)
          return S(b2), null;
        d2 = 0 !== (b2.flags & 128);
        g2 = f2.rendering;
        if (null === g2)
          if (d2)
            Ej(f2, false);
          else {
            if (0 !== T || null !== a && 0 !== (a.flags & 128))
              for (a = b2.child; null !== a; ) {
                g2 = Mh(a);
                if (null !== g2) {
                  b2.flags |= 128;
                  Ej(f2, false);
                  d2 = g2.updateQueue;
                  null !== d2 && (b2.updateQueue = d2, b2.flags |= 4);
                  b2.subtreeFlags = 0;
                  d2 = c2;
                  for (c2 = b2.child; null !== c2; )
                    f2 = c2, a = d2, f2.flags &= 14680066, g2 = f2.alternate, null === g2 ? (f2.childLanes = 0, f2.lanes = a, f2.child = null, f2.subtreeFlags = 0, f2.memoizedProps = null, f2.memoizedState = null, f2.updateQueue = null, f2.dependencies = null, f2.stateNode = null) : (f2.childLanes = g2.childLanes, f2.lanes = g2.lanes, f2.child = g2.child, f2.subtreeFlags = 0, f2.deletions = null, f2.memoizedProps = g2.memoizedProps, f2.memoizedState = g2.memoizedState, f2.updateQueue = g2.updateQueue, f2.type = g2.type, a = g2.dependencies, f2.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c2 = c2.sibling;
                  G(M, M.current & 1 | 2);
                  return b2.child;
                }
                a = a.sibling;
              }
            null !== f2.tail && B() > Hj && (b2.flags |= 128, d2 = true, Ej(f2, false), b2.lanes = 4194304);
          }
        else {
          if (!d2)
            if (a = Mh(g2), null !== a) {
              if (b2.flags |= 128, d2 = true, c2 = a.updateQueue, null !== c2 && (b2.updateQueue = c2, b2.flags |= 4), Ej(f2, true), null === f2.tail && "hidden" === f2.tailMode && !g2.alternate && !I)
                return S(b2), null;
            } else
              2 * B() - f2.renderingStartTime > Hj && 1073741824 !== c2 && (b2.flags |= 128, d2 = true, Ej(f2, false), b2.lanes = 4194304);
          f2.isBackwards ? (g2.sibling = b2.child, b2.child = g2) : (c2 = f2.last, null !== c2 ? c2.sibling = g2 : b2.child = g2, f2.last = g2);
        }
        if (null !== f2.tail)
          return b2 = f2.tail, f2.rendering = b2, f2.tail = b2.sibling, f2.renderingStartTime = B(), b2.sibling = null, c2 = M.current, G(M, d2 ? c2 & 1 | 2 : c2 & 1), b2;
        S(b2);
        return null;
      case 22:
      case 23:
        return Ij(), d2 = null !== b2.memoizedState, null !== a && null !== a.memoizedState !== d2 && (b2.flags |= 8192), d2 && 0 !== (b2.mode & 1) ? 0 !== (gj & 1073741824) && (S(b2), b2.subtreeFlags & 6 && (b2.flags |= 8192)) : S(b2), null;
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(p$3(156, b2.tag));
  }
  function Jj(a, b2) {
    wg(b2);
    switch (b2.tag) {
      case 1:
        return Zf(b2.type) && $f(), a = b2.flags, a & 65536 ? (b2.flags = a & -65537 | 128, b2) : null;
      case 3:
        return Jh(), E(Wf), E(H), Oh(), a = b2.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b2.flags = a & -65537 | 128, b2) : null;
      case 5:
        return Lh(b2), null;
      case 13:
        E(M);
        a = b2.memoizedState;
        if (null !== a && null !== a.dehydrated) {
          if (null === b2.alternate)
            throw Error(p$3(340));
          Ig();
        }
        a = b2.flags;
        return a & 65536 ? (b2.flags = a & -65537 | 128, b2) : null;
      case 19:
        return E(M), null;
      case 4:
        return Jh(), null;
      case 10:
        return Rg(b2.type._context), null;
      case 22:
      case 23:
        return Ij(), null;
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Kj = false, U = false, Lj = "function" === typeof WeakSet ? WeakSet : Set, V = null;
  function Mj(a, b2) {
    var c2 = a.ref;
    if (null !== c2)
      if ("function" === typeof c2)
        try {
          c2(null);
        } catch (d2) {
          W(a, b2, d2);
        }
      else
        c2.current = null;
  }
  function Nj(a, b2, c2) {
    try {
      c2();
    } catch (d2) {
      W(a, b2, d2);
    }
  }
  var Oj = false;
  function Pj(a, b2) {
    Cf = dd;
    a = Me();
    if (Ne(a)) {
      if ("selectionStart" in a)
        var c2 = { start: a.selectionStart, end: a.selectionEnd };
      else
        a: {
          c2 = (c2 = a.ownerDocument) && c2.defaultView || window;
          var d2 = c2.getSelection && c2.getSelection();
          if (d2 && 0 !== d2.rangeCount) {
            c2 = d2.anchorNode;
            var e2 = d2.anchorOffset, f2 = d2.focusNode;
            d2 = d2.focusOffset;
            try {
              c2.nodeType, f2.nodeType;
            } catch (F2) {
              c2 = null;
              break a;
            }
            var g2 = 0, h2 = -1, k2 = -1, l2 = 0, m2 = 0, q2 = a, r2 = null;
            b:
              for (; ; ) {
                for (var y2; ; ) {
                  q2 !== c2 || 0 !== e2 && 3 !== q2.nodeType || (h2 = g2 + e2);
                  q2 !== f2 || 0 !== d2 && 3 !== q2.nodeType || (k2 = g2 + d2);
                  3 === q2.nodeType && (g2 += q2.nodeValue.length);
                  if (null === (y2 = q2.firstChild))
                    break;
                  r2 = q2;
                  q2 = y2;
                }
                for (; ; ) {
                  if (q2 === a)
                    break b;
                  r2 === c2 && ++l2 === e2 && (h2 = g2);
                  r2 === f2 && ++m2 === d2 && (k2 = g2);
                  if (null !== (y2 = q2.nextSibling))
                    break;
                  q2 = r2;
                  r2 = q2.parentNode;
                }
                q2 = y2;
              }
            c2 = -1 === h2 || -1 === k2 ? null : { start: h2, end: k2 };
          } else
            c2 = null;
        }
      c2 = c2 || { start: 0, end: 0 };
    } else
      c2 = null;
    Df = { focusedElem: a, selectionRange: c2 };
    dd = false;
    for (V = b2; null !== V; )
      if (b2 = V, a = b2.child, 0 !== (b2.subtreeFlags & 1028) && null !== a)
        a.return = b2, V = a;
      else
        for (; null !== V; ) {
          b2 = V;
          try {
            var n2 = b2.alternate;
            if (0 !== (b2.flags & 1024))
              switch (b2.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (null !== n2) {
                    var t2 = n2.memoizedProps, J2 = n2.memoizedState, x2 = b2.stateNode, w2 = x2.getSnapshotBeforeUpdate(b2.elementType === b2.type ? t2 : Lg(b2.type, t2), J2);
                    x2.__reactInternalSnapshotBeforeUpdate = w2;
                  }
                  break;
                case 3:
                  var u2 = b2.stateNode.containerInfo;
                  1 === u2.nodeType ? u2.textContent = "" : 9 === u2.nodeType && u2.documentElement && u2.removeChild(u2.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(p$3(163));
              }
          } catch (F2) {
            W(b2, b2.return, F2);
          }
          a = b2.sibling;
          if (null !== a) {
            a.return = b2.return;
            V = a;
            break;
          }
          V = b2.return;
        }
    n2 = Oj;
    Oj = false;
    return n2;
  }
  function Qj(a, b2, c2) {
    var d2 = b2.updateQueue;
    d2 = null !== d2 ? d2.lastEffect : null;
    if (null !== d2) {
      var e2 = d2 = d2.next;
      do {
        if ((e2.tag & a) === a) {
          var f2 = e2.destroy;
          e2.destroy = void 0;
          void 0 !== f2 && Nj(b2, c2, f2);
        }
        e2 = e2.next;
      } while (e2 !== d2);
    }
  }
  function Rj(a, b2) {
    b2 = b2.updateQueue;
    b2 = null !== b2 ? b2.lastEffect : null;
    if (null !== b2) {
      var c2 = b2 = b2.next;
      do {
        if ((c2.tag & a) === a) {
          var d2 = c2.create;
          c2.destroy = d2();
        }
        c2 = c2.next;
      } while (c2 !== b2);
    }
  }
  function Sj(a) {
    var b2 = a.ref;
    if (null !== b2) {
      var c2 = a.stateNode;
      switch (a.tag) {
        case 5:
          a = c2;
          break;
        default:
          a = c2;
      }
      "function" === typeof b2 ? b2(a) : b2.current = a;
    }
  }
  function Tj(a) {
    var b2 = a.alternate;
    null !== b2 && (a.alternate = null, Tj(b2));
    a.child = null;
    a.deletions = null;
    a.sibling = null;
    5 === a.tag && (b2 = a.stateNode, null !== b2 && (delete b2[Of], delete b2[Pf], delete b2[of], delete b2[Qf], delete b2[Rf]));
    a.stateNode = null;
    a.return = null;
    a.dependencies = null;
    a.memoizedProps = null;
    a.memoizedState = null;
    a.pendingProps = null;
    a.stateNode = null;
    a.updateQueue = null;
  }
  function Uj(a) {
    return 5 === a.tag || 3 === a.tag || 4 === a.tag;
  }
  function Vj(a) {
    a:
      for (; ; ) {
        for (; null === a.sibling; ) {
          if (null === a.return || Uj(a.return))
            return null;
          a = a.return;
        }
        a.sibling.return = a.return;
        for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
          if (a.flags & 2)
            continue a;
          if (null === a.child || 4 === a.tag)
            continue a;
          else
            a.child.return = a, a = a.child;
        }
        if (!(a.flags & 2))
          return a.stateNode;
      }
  }
  function Wj(a, b2, c2) {
    var d2 = a.tag;
    if (5 === d2 || 6 === d2)
      a = a.stateNode, b2 ? 8 === c2.nodeType ? c2.parentNode.insertBefore(a, b2) : c2.insertBefore(a, b2) : (8 === c2.nodeType ? (b2 = c2.parentNode, b2.insertBefore(a, c2)) : (b2 = c2, b2.appendChild(a)), c2 = c2._reactRootContainer, null !== c2 && void 0 !== c2 || null !== b2.onclick || (b2.onclick = Bf));
    else if (4 !== d2 && (a = a.child, null !== a))
      for (Wj(a, b2, c2), a = a.sibling; null !== a; )
        Wj(a, b2, c2), a = a.sibling;
  }
  function Xj(a, b2, c2) {
    var d2 = a.tag;
    if (5 === d2 || 6 === d2)
      a = a.stateNode, b2 ? c2.insertBefore(a, b2) : c2.appendChild(a);
    else if (4 !== d2 && (a = a.child, null !== a))
      for (Xj(a, b2, c2), a = a.sibling; null !== a; )
        Xj(a, b2, c2), a = a.sibling;
  }
  var X = null, Yj = false;
  function Zj(a, b2, c2) {
    for (c2 = c2.child; null !== c2; )
      ak(a, b2, c2), c2 = c2.sibling;
  }
  function ak(a, b2, c2) {
    if (lc && "function" === typeof lc.onCommitFiberUnmount)
      try {
        lc.onCommitFiberUnmount(kc, c2);
      } catch (h2) {
      }
    switch (c2.tag) {
      case 5:
        U || Mj(c2, b2);
      case 6:
        var d2 = X, e2 = Yj;
        X = null;
        Zj(a, b2, c2);
        X = d2;
        Yj = e2;
        null !== X && (Yj ? (a = X, c2 = c2.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c2) : a.removeChild(c2)) : X.removeChild(c2.stateNode));
        break;
      case 18:
        null !== X && (Yj ? (a = X, c2 = c2.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c2) : 1 === a.nodeType && Kf(a, c2), bd(a)) : Kf(X, c2.stateNode));
        break;
      case 4:
        d2 = X;
        e2 = Yj;
        X = c2.stateNode.containerInfo;
        Yj = true;
        Zj(a, b2, c2);
        X = d2;
        Yj = e2;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (!U && (d2 = c2.updateQueue, null !== d2 && (d2 = d2.lastEffect, null !== d2))) {
          e2 = d2 = d2.next;
          do {
            var f2 = e2, g2 = f2.destroy;
            f2 = f2.tag;
            void 0 !== g2 && (0 !== (f2 & 2) ? Nj(c2, b2, g2) : 0 !== (f2 & 4) && Nj(c2, b2, g2));
            e2 = e2.next;
          } while (e2 !== d2);
        }
        Zj(a, b2, c2);
        break;
      case 1:
        if (!U && (Mj(c2, b2), d2 = c2.stateNode, "function" === typeof d2.componentWillUnmount))
          try {
            d2.props = c2.memoizedProps, d2.state = c2.memoizedState, d2.componentWillUnmount();
          } catch (h2) {
            W(c2, b2, h2);
          }
        Zj(a, b2, c2);
        break;
      case 21:
        Zj(a, b2, c2);
        break;
      case 22:
        c2.mode & 1 ? (U = (d2 = U) || null !== c2.memoizedState, Zj(a, b2, c2), U = d2) : Zj(a, b2, c2);
        break;
      default:
        Zj(a, b2, c2);
    }
  }
  function bk(a) {
    var b2 = a.updateQueue;
    if (null !== b2) {
      a.updateQueue = null;
      var c2 = a.stateNode;
      null === c2 && (c2 = a.stateNode = new Lj());
      b2.forEach(function(b3) {
        var d2 = ck.bind(null, a, b3);
        c2.has(b3) || (c2.add(b3), b3.then(d2, d2));
      });
    }
  }
  function dk(a, b2) {
    var c2 = b2.deletions;
    if (null !== c2)
      for (var d2 = 0; d2 < c2.length; d2++) {
        var e2 = c2[d2];
        try {
          var f2 = a, g2 = b2, h2 = g2;
          a:
            for (; null !== h2; ) {
              switch (h2.tag) {
                case 5:
                  X = h2.stateNode;
                  Yj = false;
                  break a;
                case 3:
                  X = h2.stateNode.containerInfo;
                  Yj = true;
                  break a;
                case 4:
                  X = h2.stateNode.containerInfo;
                  Yj = true;
                  break a;
              }
              h2 = h2.return;
            }
          if (null === X)
            throw Error(p$3(160));
          ak(f2, g2, e2);
          X = null;
          Yj = false;
          var k2 = e2.alternate;
          null !== k2 && (k2.return = null);
          e2.return = null;
        } catch (l2) {
          W(e2, b2, l2);
        }
      }
    if (b2.subtreeFlags & 12854)
      for (b2 = b2.child; null !== b2; )
        ek(b2, a), b2 = b2.sibling;
  }
  function ek(a, b2) {
    var c2 = a.alternate, d2 = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        dk(b2, a);
        fk(a);
        if (d2 & 4) {
          try {
            Qj(3, a, a.return), Rj(3, a);
          } catch (t2) {
            W(a, a.return, t2);
          }
          try {
            Qj(5, a, a.return);
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        break;
      case 1:
        dk(b2, a);
        fk(a);
        d2 & 512 && null !== c2 && Mj(c2, c2.return);
        break;
      case 5:
        dk(b2, a);
        fk(a);
        d2 & 512 && null !== c2 && Mj(c2, c2.return);
        if (a.flags & 32) {
          var e2 = a.stateNode;
          try {
            ob(e2, "");
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        if (d2 & 4 && (e2 = a.stateNode, null != e2)) {
          var f2 = a.memoizedProps, g2 = null !== c2 ? c2.memoizedProps : f2, h2 = a.type, k2 = a.updateQueue;
          a.updateQueue = null;
          if (null !== k2)
            try {
              "input" === h2 && "radio" === f2.type && null != f2.name && ab(e2, f2);
              vb(h2, g2);
              var l2 = vb(h2, f2);
              for (g2 = 0; g2 < k2.length; g2 += 2) {
                var m2 = k2[g2], q2 = k2[g2 + 1];
                "style" === m2 ? sb(e2, q2) : "dangerouslySetInnerHTML" === m2 ? nb(e2, q2) : "children" === m2 ? ob(e2, q2) : ta(e2, m2, q2, l2);
              }
              switch (h2) {
                case "input":
                  bb(e2, f2);
                  break;
                case "textarea":
                  ib(e2, f2);
                  break;
                case "select":
                  var r2 = e2._wrapperState.wasMultiple;
                  e2._wrapperState.wasMultiple = !!f2.multiple;
                  var y2 = f2.value;
                  null != y2 ? fb(e2, !!f2.multiple, y2, false) : r2 !== !!f2.multiple && (null != f2.defaultValue ? fb(
                    e2,
                    !!f2.multiple,
                    f2.defaultValue,
                    true
                  ) : fb(e2, !!f2.multiple, f2.multiple ? [] : "", false));
              }
              e2[Pf] = f2;
            } catch (t2) {
              W(a, a.return, t2);
            }
        }
        break;
      case 6:
        dk(b2, a);
        fk(a);
        if (d2 & 4) {
          if (null === a.stateNode)
            throw Error(p$3(162));
          e2 = a.stateNode;
          f2 = a.memoizedProps;
          try {
            e2.nodeValue = f2;
          } catch (t2) {
            W(a, a.return, t2);
          }
        }
        break;
      case 3:
        dk(b2, a);
        fk(a);
        if (d2 & 4 && null !== c2 && c2.memoizedState.isDehydrated)
          try {
            bd(b2.containerInfo);
          } catch (t2) {
            W(a, a.return, t2);
          }
        break;
      case 4:
        dk(b2, a);
        fk(a);
        break;
      case 13:
        dk(b2, a);
        fk(a);
        e2 = a.child;
        e2.flags & 8192 && (f2 = null !== e2.memoizedState, e2.stateNode.isHidden = f2, !f2 || null !== e2.alternate && null !== e2.alternate.memoizedState || (gk = B()));
        d2 & 4 && bk(a);
        break;
      case 22:
        m2 = null !== c2 && null !== c2.memoizedState;
        a.mode & 1 ? (U = (l2 = U) || m2, dk(b2, a), U = l2) : dk(b2, a);
        fk(a);
        if (d2 & 8192) {
          l2 = null !== a.memoizedState;
          if ((a.stateNode.isHidden = l2) && !m2 && 0 !== (a.mode & 1))
            for (V = a, m2 = a.child; null !== m2; ) {
              for (q2 = V = m2; null !== V; ) {
                r2 = V;
                y2 = r2.child;
                switch (r2.tag) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Qj(4, r2, r2.return);
                    break;
                  case 1:
                    Mj(r2, r2.return);
                    var n2 = r2.stateNode;
                    if ("function" === typeof n2.componentWillUnmount) {
                      d2 = r2;
                      c2 = r2.return;
                      try {
                        b2 = d2, n2.props = b2.memoizedProps, n2.state = b2.memoizedState, n2.componentWillUnmount();
                      } catch (t2) {
                        W(d2, c2, t2);
                      }
                    }
                    break;
                  case 5:
                    Mj(r2, r2.return);
                    break;
                  case 22:
                    if (null !== r2.memoizedState) {
                      hk(q2);
                      continue;
                    }
                }
                null !== y2 ? (y2.return = r2, V = y2) : hk(q2);
              }
              m2 = m2.sibling;
            }
          a:
            for (m2 = null, q2 = a; ; ) {
              if (5 === q2.tag) {
                if (null === m2) {
                  m2 = q2;
                  try {
                    e2 = q2.stateNode, l2 ? (f2 = e2.style, "function" === typeof f2.setProperty ? f2.setProperty("display", "none", "important") : f2.display = "none") : (h2 = q2.stateNode, k2 = q2.memoizedProps.style, g2 = void 0 !== k2 && null !== k2 && k2.hasOwnProperty("display") ? k2.display : null, h2.style.display = rb("display", g2));
                  } catch (t2) {
                    W(a, a.return, t2);
                  }
                }
              } else if (6 === q2.tag) {
                if (null === m2)
                  try {
                    q2.stateNode.nodeValue = l2 ? "" : q2.memoizedProps;
                  } catch (t2) {
                    W(a, a.return, t2);
                  }
              } else if ((22 !== q2.tag && 23 !== q2.tag || null === q2.memoizedState || q2 === a) && null !== q2.child) {
                q2.child.return = q2;
                q2 = q2.child;
                continue;
              }
              if (q2 === a)
                break a;
              for (; null === q2.sibling; ) {
                if (null === q2.return || q2.return === a)
                  break a;
                m2 === q2 && (m2 = null);
                q2 = q2.return;
              }
              m2 === q2 && (m2 = null);
              q2.sibling.return = q2.return;
              q2 = q2.sibling;
            }
        }
        break;
      case 19:
        dk(b2, a);
        fk(a);
        d2 & 4 && bk(a);
        break;
      case 21:
        break;
      default:
        dk(
          b2,
          a
        ), fk(a);
    }
  }
  function fk(a) {
    var b2 = a.flags;
    if (b2 & 2) {
      try {
        a: {
          for (var c2 = a.return; null !== c2; ) {
            if (Uj(c2)) {
              var d2 = c2;
              break a;
            }
            c2 = c2.return;
          }
          throw Error(p$3(160));
        }
        switch (d2.tag) {
          case 5:
            var e2 = d2.stateNode;
            d2.flags & 32 && (ob(e2, ""), d2.flags &= -33);
            var f2 = Vj(a);
            Xj(a, f2, e2);
            break;
          case 3:
          case 4:
            var g2 = d2.stateNode.containerInfo, h2 = Vj(a);
            Wj(a, h2, g2);
            break;
          default:
            throw Error(p$3(161));
        }
      } catch (k2) {
        W(a, a.return, k2);
      }
      a.flags &= -3;
    }
    b2 & 4096 && (a.flags &= -4097);
  }
  function ik(a, b2, c2) {
    V = a;
    jk(a);
  }
  function jk(a, b2, c2) {
    for (var d2 = 0 !== (a.mode & 1); null !== V; ) {
      var e2 = V, f2 = e2.child;
      if (22 === e2.tag && d2) {
        var g2 = null !== e2.memoizedState || Kj;
        if (!g2) {
          var h2 = e2.alternate, k2 = null !== h2 && null !== h2.memoizedState || U;
          h2 = Kj;
          var l2 = U;
          Kj = g2;
          if ((U = k2) && !l2)
            for (V = e2; null !== V; )
              g2 = V, k2 = g2.child, 22 === g2.tag && null !== g2.memoizedState ? kk(e2) : null !== k2 ? (k2.return = g2, V = k2) : kk(e2);
          for (; null !== f2; )
            V = f2, jk(f2), f2 = f2.sibling;
          V = e2;
          Kj = h2;
          U = l2;
        }
        lk(a);
      } else
        0 !== (e2.subtreeFlags & 8772) && null !== f2 ? (f2.return = e2, V = f2) : lk(a);
    }
  }
  function lk(a) {
    for (; null !== V; ) {
      var b2 = V;
      if (0 !== (b2.flags & 8772)) {
        var c2 = b2.alternate;
        try {
          if (0 !== (b2.flags & 8772))
            switch (b2.tag) {
              case 0:
              case 11:
              case 15:
                U || Rj(5, b2);
                break;
              case 1:
                var d2 = b2.stateNode;
                if (b2.flags & 4 && !U)
                  if (null === c2)
                    d2.componentDidMount();
                  else {
                    var e2 = b2.elementType === b2.type ? c2.memoizedProps : Lg(b2.type, c2.memoizedProps);
                    d2.componentDidUpdate(e2, c2.memoizedState, d2.__reactInternalSnapshotBeforeUpdate);
                  }
                var f2 = b2.updateQueue;
                null !== f2 && ih(b2, f2, d2);
                break;
              case 3:
                var g2 = b2.updateQueue;
                if (null !== g2) {
                  c2 = null;
                  if (null !== b2.child)
                    switch (b2.child.tag) {
                      case 5:
                        c2 = b2.child.stateNode;
                        break;
                      case 1:
                        c2 = b2.child.stateNode;
                    }
                  ih(b2, g2, c2);
                }
                break;
              case 5:
                var h2 = b2.stateNode;
                if (null === c2 && b2.flags & 4) {
                  c2 = h2;
                  var k2 = b2.memoizedProps;
                  switch (b2.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      k2.autoFocus && c2.focus();
                      break;
                    case "img":
                      k2.src && (c2.src = k2.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (null === b2.memoizedState) {
                  var l2 = b2.alternate;
                  if (null !== l2) {
                    var m2 = l2.memoizedState;
                    if (null !== m2) {
                      var q2 = m2.dehydrated;
                      null !== q2 && bd(q2);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(p$3(163));
            }
          U || b2.flags & 512 && Sj(b2);
        } catch (r2) {
          W(b2, b2.return, r2);
        }
      }
      if (b2 === a) {
        V = null;
        break;
      }
      c2 = b2.sibling;
      if (null !== c2) {
        c2.return = b2.return;
        V = c2;
        break;
      }
      V = b2.return;
    }
  }
  function hk(a) {
    for (; null !== V; ) {
      var b2 = V;
      if (b2 === a) {
        V = null;
        break;
      }
      var c2 = b2.sibling;
      if (null !== c2) {
        c2.return = b2.return;
        V = c2;
        break;
      }
      V = b2.return;
    }
  }
  function kk(a) {
    for (; null !== V; ) {
      var b2 = V;
      try {
        switch (b2.tag) {
          case 0:
          case 11:
          case 15:
            var c2 = b2.return;
            try {
              Rj(4, b2);
            } catch (k2) {
              W(b2, c2, k2);
            }
            break;
          case 1:
            var d2 = b2.stateNode;
            if ("function" === typeof d2.componentDidMount) {
              var e2 = b2.return;
              try {
                d2.componentDidMount();
              } catch (k2) {
                W(b2, e2, k2);
              }
            }
            var f2 = b2.return;
            try {
              Sj(b2);
            } catch (k2) {
              W(b2, f2, k2);
            }
            break;
          case 5:
            var g2 = b2.return;
            try {
              Sj(b2);
            } catch (k2) {
              W(b2, g2, k2);
            }
        }
      } catch (k2) {
        W(b2, b2.return, k2);
      }
      if (b2 === a) {
        V = null;
        break;
      }
      var h2 = b2.sibling;
      if (null !== h2) {
        h2.return = b2.return;
        V = h2;
        break;
      }
      V = b2.return;
    }
  }
  var mk = Math.ceil, nk = ua.ReactCurrentDispatcher, ok = ua.ReactCurrentOwner, pk = ua.ReactCurrentBatchConfig, K = 0, R = null, Y = null, Z = 0, gj = 0, fj = Uf(0), T = 0, qk = null, hh = 0, rk = 0, sk = 0, tk = null, uk = null, gk = 0, Hj = Infinity, vk = null, Pi = false, Qi = null, Si = null, wk = false, xk = null, yk = 0, zk = 0, Ak = null, Bk = -1, Ck = 0;
  function L() {
    return 0 !== (K & 6) ? B() : -1 !== Bk ? Bk : Bk = B();
  }
  function lh(a) {
    if (0 === (a.mode & 1))
      return 1;
    if (0 !== (K & 2) && 0 !== Z)
      return Z & -Z;
    if (null !== Kg.transition)
      return 0 === Ck && (Ck = yc()), Ck;
    a = C;
    if (0 !== a)
      return a;
    a = window.event;
    a = void 0 === a ? 16 : jd(a.type);
    return a;
  }
  function mh(a, b2, c2, d2) {
    if (50 < zk)
      throw zk = 0, Ak = null, Error(p$3(185));
    Ac(a, c2, d2);
    if (0 === (K & 2) || a !== R)
      a === R && (0 === (K & 2) && (rk |= c2), 4 === T && Dk(a, Z)), Ek(a, d2), 1 === c2 && 0 === K && 0 === (b2.mode & 1) && (Hj = B() + 500, fg && jg());
  }
  function Ek(a, b2) {
    var c2 = a.callbackNode;
    wc(a, b2);
    var d2 = uc(a, a === R ? Z : 0);
    if (0 === d2)
      null !== c2 && bc(c2), a.callbackNode = null, a.callbackPriority = 0;
    else if (b2 = d2 & -d2, a.callbackPriority !== b2) {
      null != c2 && bc(c2);
      if (1 === b2)
        0 === a.tag ? ig(Fk.bind(null, a)) : hg(Fk.bind(null, a)), Jf(function() {
          0 === (K & 6) && jg();
        }), c2 = null;
      else {
        switch (Dc(d2)) {
          case 1:
            c2 = fc;
            break;
          case 4:
            c2 = gc;
            break;
          case 16:
            c2 = hc;
            break;
          case 536870912:
            c2 = jc;
            break;
          default:
            c2 = hc;
        }
        c2 = Gk(c2, Hk.bind(null, a));
      }
      a.callbackPriority = b2;
      a.callbackNode = c2;
    }
  }
  function Hk(a, b2) {
    Bk = -1;
    Ck = 0;
    if (0 !== (K & 6))
      throw Error(p$3(327));
    var c2 = a.callbackNode;
    if (Ik() && a.callbackNode !== c2)
      return null;
    var d2 = uc(a, a === R ? Z : 0);
    if (0 === d2)
      return null;
    if (0 !== (d2 & 30) || 0 !== (d2 & a.expiredLanes) || b2)
      b2 = Jk(a, d2);
    else {
      b2 = d2;
      var e2 = K;
      K |= 2;
      var f2 = Kk();
      if (R !== a || Z !== b2)
        vk = null, Hj = B() + 500, Lk(a, b2);
      do
        try {
          Mk();
          break;
        } catch (h2) {
          Nk(a, h2);
        }
      while (1);
      Qg();
      nk.current = f2;
      K = e2;
      null !== Y ? b2 = 0 : (R = null, Z = 0, b2 = T);
    }
    if (0 !== b2) {
      2 === b2 && (e2 = xc(a), 0 !== e2 && (d2 = e2, b2 = Ok(a, e2)));
      if (1 === b2)
        throw c2 = qk, Lk(a, 0), Dk(a, d2), Ek(a, B()), c2;
      if (6 === b2)
        Dk(a, d2);
      else {
        e2 = a.current.alternate;
        if (0 === (d2 & 30) && !Pk(e2) && (b2 = Jk(a, d2), 2 === b2 && (f2 = xc(a), 0 !== f2 && (d2 = f2, b2 = Ok(a, f2))), 1 === b2))
          throw c2 = qk, Lk(a, 0), Dk(a, d2), Ek(a, B()), c2;
        a.finishedWork = e2;
        a.finishedLanes = d2;
        switch (b2) {
          case 0:
          case 1:
            throw Error(p$3(345));
          case 2:
            Qk(a, uk, vk);
            break;
          case 3:
            Dk(a, d2);
            if ((d2 & 130023424) === d2 && (b2 = gk + 500 - B(), 10 < b2)) {
              if (0 !== uc(a, 0))
                break;
              e2 = a.suspendedLanes;
              if ((e2 & d2) !== d2) {
                L();
                a.pingedLanes |= a.suspendedLanes & e2;
                break;
              }
              a.timeoutHandle = Ff(Qk.bind(null, a, uk, vk), b2);
              break;
            }
            Qk(a, uk, vk);
            break;
          case 4:
            Dk(a, d2);
            if ((d2 & 4194240) === d2)
              break;
            b2 = a.eventTimes;
            for (e2 = -1; 0 < d2; ) {
              var g2 = 31 - oc(d2);
              f2 = 1 << g2;
              g2 = b2[g2];
              g2 > e2 && (e2 = g2);
              d2 &= ~f2;
            }
            d2 = e2;
            d2 = B() - d2;
            d2 = (120 > d2 ? 120 : 480 > d2 ? 480 : 1080 > d2 ? 1080 : 1920 > d2 ? 1920 : 3e3 > d2 ? 3e3 : 4320 > d2 ? 4320 : 1960 * mk(d2 / 1960)) - d2;
            if (10 < d2) {
              a.timeoutHandle = Ff(Qk.bind(null, a, uk, vk), d2);
              break;
            }
            Qk(a, uk, vk);
            break;
          case 5:
            Qk(a, uk, vk);
            break;
          default:
            throw Error(p$3(329));
        }
      }
    }
    Ek(a, B());
    return a.callbackNode === c2 ? Hk.bind(null, a) : null;
  }
  function Ok(a, b2) {
    var c2 = tk;
    a.current.memoizedState.isDehydrated && (Lk(a, b2).flags |= 256);
    a = Jk(a, b2);
    2 !== a && (b2 = uk, uk = c2, null !== b2 && Gj(b2));
    return a;
  }
  function Gj(a) {
    null === uk ? uk = a : uk.push.apply(uk, a);
  }
  function Pk(a) {
    for (var b2 = a; ; ) {
      if (b2.flags & 16384) {
        var c2 = b2.updateQueue;
        if (null !== c2 && (c2 = c2.stores, null !== c2))
          for (var d2 = 0; d2 < c2.length; d2++) {
            var e2 = c2[d2], f2 = e2.getSnapshot;
            e2 = e2.value;
            try {
              if (!He(f2(), e2))
                return false;
            } catch (g2) {
              return false;
            }
          }
      }
      c2 = b2.child;
      if (b2.subtreeFlags & 16384 && null !== c2)
        c2.return = b2, b2 = c2;
      else {
        if (b2 === a)
          break;
        for (; null === b2.sibling; ) {
          if (null === b2.return || b2.return === a)
            return true;
          b2 = b2.return;
        }
        b2.sibling.return = b2.return;
        b2 = b2.sibling;
      }
    }
    return true;
  }
  function Dk(a, b2) {
    b2 &= ~sk;
    b2 &= ~rk;
    a.suspendedLanes |= b2;
    a.pingedLanes &= ~b2;
    for (a = a.expirationTimes; 0 < b2; ) {
      var c2 = 31 - oc(b2), d2 = 1 << c2;
      a[c2] = -1;
      b2 &= ~d2;
    }
  }
  function Fk(a) {
    if (0 !== (K & 6))
      throw Error(p$3(327));
    Ik();
    var b2 = uc(a, 0);
    if (0 === (b2 & 1))
      return Ek(a, B()), null;
    var c2 = Jk(a, b2);
    if (0 !== a.tag && 2 === c2) {
      var d2 = xc(a);
      0 !== d2 && (b2 = d2, c2 = Ok(a, d2));
    }
    if (1 === c2)
      throw c2 = qk, Lk(a, 0), Dk(a, b2), Ek(a, B()), c2;
    if (6 === c2)
      throw Error(p$3(345));
    a.finishedWork = a.current.alternate;
    a.finishedLanes = b2;
    Qk(a, uk, vk);
    Ek(a, B());
    return null;
  }
  function Rk(a, b2) {
    var c2 = K;
    K |= 1;
    try {
      return a(b2);
    } finally {
      K = c2, 0 === K && (Hj = B() + 500, fg && jg());
    }
  }
  function Sk(a) {
    null !== xk && 0 === xk.tag && 0 === (K & 6) && Ik();
    var b2 = K;
    K |= 1;
    var c2 = pk.transition, d2 = C;
    try {
      if (pk.transition = null, C = 1, a)
        return a();
    } finally {
      C = d2, pk.transition = c2, K = b2, 0 === (K & 6) && jg();
    }
  }
  function Ij() {
    gj = fj.current;
    E(fj);
  }
  function Lk(a, b2) {
    a.finishedWork = null;
    a.finishedLanes = 0;
    var c2 = a.timeoutHandle;
    -1 !== c2 && (a.timeoutHandle = -1, Gf(c2));
    if (null !== Y)
      for (c2 = Y.return; null !== c2; ) {
        var d2 = c2;
        wg(d2);
        switch (d2.tag) {
          case 1:
            d2 = d2.type.childContextTypes;
            null !== d2 && void 0 !== d2 && $f();
            break;
          case 3:
            Jh();
            E(Wf);
            E(H);
            Oh();
            break;
          case 5:
            Lh(d2);
            break;
          case 4:
            Jh();
            break;
          case 13:
            E(M);
            break;
          case 19:
            E(M);
            break;
          case 10:
            Rg(d2.type._context);
            break;
          case 22:
          case 23:
            Ij();
        }
        c2 = c2.return;
      }
    R = a;
    Y = a = wh(a.current, null);
    Z = gj = b2;
    T = 0;
    qk = null;
    sk = rk = hh = 0;
    uk = tk = null;
    if (null !== Wg) {
      for (b2 = 0; b2 < Wg.length; b2++)
        if (c2 = Wg[b2], d2 = c2.interleaved, null !== d2) {
          c2.interleaved = null;
          var e2 = d2.next, f2 = c2.pending;
          if (null !== f2) {
            var g2 = f2.next;
            f2.next = e2;
            d2.next = g2;
          }
          c2.pending = d2;
        }
      Wg = null;
    }
    return a;
  }
  function Nk(a, b2) {
    do {
      var c2 = Y;
      try {
        Qg();
        Ph.current = ai;
        if (Sh) {
          for (var d2 = N.memoizedState; null !== d2; ) {
            var e2 = d2.queue;
            null !== e2 && (e2.pending = null);
            d2 = d2.next;
          }
          Sh = false;
        }
        Rh = 0;
        P = O = N = null;
        Th = false;
        Uh = 0;
        ok.current = null;
        if (null === c2 || null === c2.return) {
          T = 1;
          qk = b2;
          Y = null;
          break;
        }
        a: {
          var f2 = a, g2 = c2.return, h2 = c2, k2 = b2;
          b2 = Z;
          h2.flags |= 32768;
          if (null !== k2 && "object" === typeof k2 && "function" === typeof k2.then) {
            var l2 = k2, m2 = h2, q2 = m2.tag;
            if (0 === (m2.mode & 1) && (0 === q2 || 11 === q2 || 15 === q2)) {
              var r2 = m2.alternate;
              r2 ? (m2.updateQueue = r2.updateQueue, m2.memoizedState = r2.memoizedState, m2.lanes = r2.lanes) : (m2.updateQueue = null, m2.memoizedState = null);
            }
            var y2 = Vi(g2);
            if (null !== y2) {
              y2.flags &= -257;
              Wi(y2, g2, h2, f2, b2);
              y2.mode & 1 && Ti(f2, l2, b2);
              b2 = y2;
              k2 = l2;
              var n2 = b2.updateQueue;
              if (null === n2) {
                var t2 = /* @__PURE__ */ new Set();
                t2.add(k2);
                b2.updateQueue = t2;
              } else
                n2.add(k2);
              break a;
            } else {
              if (0 === (b2 & 1)) {
                Ti(f2, l2, b2);
                uj();
                break a;
              }
              k2 = Error(p$3(426));
            }
          } else if (I && h2.mode & 1) {
            var J2 = Vi(g2);
            if (null !== J2) {
              0 === (J2.flags & 65536) && (J2.flags |= 256);
              Wi(J2, g2, h2, f2, b2);
              Jg(Ki(k2, h2));
              break a;
            }
          }
          f2 = k2 = Ki(k2, h2);
          4 !== T && (T = 2);
          null === tk ? tk = [f2] : tk.push(f2);
          f2 = g2;
          do {
            switch (f2.tag) {
              case 3:
                f2.flags |= 65536;
                b2 &= -b2;
                f2.lanes |= b2;
                var x2 = Oi(f2, k2, b2);
                fh(f2, x2);
                break a;
              case 1:
                h2 = k2;
                var w2 = f2.type, u2 = f2.stateNode;
                if (0 === (f2.flags & 128) && ("function" === typeof w2.getDerivedStateFromError || null !== u2 && "function" === typeof u2.componentDidCatch && (null === Si || !Si.has(u2)))) {
                  f2.flags |= 65536;
                  b2 &= -b2;
                  f2.lanes |= b2;
                  var F2 = Ri(f2, h2, b2);
                  fh(f2, F2);
                  break a;
                }
            }
            f2 = f2.return;
          } while (null !== f2);
        }
        Tk(c2);
      } catch (na) {
        b2 = na;
        Y === c2 && null !== c2 && (Y = c2 = c2.return);
        continue;
      }
      break;
    } while (1);
  }
  function Kk() {
    var a = nk.current;
    nk.current = ai;
    return null === a ? ai : a;
  }
  function uj() {
    if (0 === T || 3 === T || 2 === T)
      T = 4;
    null === R || 0 === (hh & 268435455) && 0 === (rk & 268435455) || Dk(R, Z);
  }
  function Jk(a, b2) {
    var c2 = K;
    K |= 2;
    var d2 = Kk();
    if (R !== a || Z !== b2)
      vk = null, Lk(a, b2);
    do
      try {
        Uk();
        break;
      } catch (e2) {
        Nk(a, e2);
      }
    while (1);
    Qg();
    K = c2;
    nk.current = d2;
    if (null !== Y)
      throw Error(p$3(261));
    R = null;
    Z = 0;
    return T;
  }
  function Uk() {
    for (; null !== Y; )
      Vk(Y);
  }
  function Mk() {
    for (; null !== Y && !cc(); )
      Vk(Y);
  }
  function Vk(a) {
    var b2 = Wk(a.alternate, a, gj);
    a.memoizedProps = a.pendingProps;
    null === b2 ? Tk(a) : Y = b2;
    ok.current = null;
  }
  function Tk(a) {
    var b2 = a;
    do {
      var c2 = b2.alternate;
      a = b2.return;
      if (0 === (b2.flags & 32768)) {
        if (c2 = Fj(c2, b2, gj), null !== c2) {
          Y = c2;
          return;
        }
      } else {
        c2 = Jj(c2, b2);
        if (null !== c2) {
          c2.flags &= 32767;
          Y = c2;
          return;
        }
        if (null !== a)
          a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
        else {
          T = 6;
          Y = null;
          return;
        }
      }
      b2 = b2.sibling;
      if (null !== b2) {
        Y = b2;
        return;
      }
      Y = b2 = a;
    } while (null !== b2);
    0 === T && (T = 5);
  }
  function Qk(a, b2, c2) {
    var d2 = C, e2 = pk.transition;
    try {
      pk.transition = null, C = 1, Xk(a, b2, c2, d2);
    } finally {
      pk.transition = e2, C = d2;
    }
    return null;
  }
  function Xk(a, b2, c2, d2) {
    do
      Ik();
    while (null !== xk);
    if (0 !== (K & 6))
      throw Error(p$3(327));
    c2 = a.finishedWork;
    var e2 = a.finishedLanes;
    if (null === c2)
      return null;
    a.finishedWork = null;
    a.finishedLanes = 0;
    if (c2 === a.current)
      throw Error(p$3(177));
    a.callbackNode = null;
    a.callbackPriority = 0;
    var f2 = c2.lanes | c2.childLanes;
    Bc(a, f2);
    a === R && (Y = R = null, Z = 0);
    0 === (c2.subtreeFlags & 2064) && 0 === (c2.flags & 2064) || wk || (wk = true, Gk(hc, function() {
      Ik();
      return null;
    }));
    f2 = 0 !== (c2.flags & 15990);
    if (0 !== (c2.subtreeFlags & 15990) || f2) {
      f2 = pk.transition;
      pk.transition = null;
      var g2 = C;
      C = 1;
      var h2 = K;
      K |= 4;
      ok.current = null;
      Pj(a, c2);
      ek(c2, a);
      Oe(Df);
      dd = !!Cf;
      Df = Cf = null;
      a.current = c2;
      ik(c2);
      dc();
      K = h2;
      C = g2;
      pk.transition = f2;
    } else
      a.current = c2;
    wk && (wk = false, xk = a, yk = e2);
    f2 = a.pendingLanes;
    0 === f2 && (Si = null);
    mc(c2.stateNode);
    Ek(a, B());
    if (null !== b2)
      for (d2 = a.onRecoverableError, c2 = 0; c2 < b2.length; c2++)
        e2 = b2[c2], d2(e2.value, { componentStack: e2.stack, digest: e2.digest });
    if (Pi)
      throw Pi = false, a = Qi, Qi = null, a;
    0 !== (yk & 1) && 0 !== a.tag && Ik();
    f2 = a.pendingLanes;
    0 !== (f2 & 1) ? a === Ak ? zk++ : (zk = 0, Ak = a) : zk = 0;
    jg();
    return null;
  }
  function Ik() {
    if (null !== xk) {
      var a = Dc(yk), b2 = pk.transition, c2 = C;
      try {
        pk.transition = null;
        C = 16 > a ? 16 : a;
        if (null === xk)
          var d2 = false;
        else {
          a = xk;
          xk = null;
          yk = 0;
          if (0 !== (K & 6))
            throw Error(p$3(331));
          var e2 = K;
          K |= 4;
          for (V = a.current; null !== V; ) {
            var f2 = V, g2 = f2.child;
            if (0 !== (V.flags & 16)) {
              var h2 = f2.deletions;
              if (null !== h2) {
                for (var k2 = 0; k2 < h2.length; k2++) {
                  var l2 = h2[k2];
                  for (V = l2; null !== V; ) {
                    var m2 = V;
                    switch (m2.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Qj(8, m2, f2);
                    }
                    var q2 = m2.child;
                    if (null !== q2)
                      q2.return = m2, V = q2;
                    else
                      for (; null !== V; ) {
                        m2 = V;
                        var r2 = m2.sibling, y2 = m2.return;
                        Tj(m2);
                        if (m2 === l2) {
                          V = null;
                          break;
                        }
                        if (null !== r2) {
                          r2.return = y2;
                          V = r2;
                          break;
                        }
                        V = y2;
                      }
                  }
                }
                var n2 = f2.alternate;
                if (null !== n2) {
                  var t2 = n2.child;
                  if (null !== t2) {
                    n2.child = null;
                    do {
                      var J2 = t2.sibling;
                      t2.sibling = null;
                      t2 = J2;
                    } while (null !== t2);
                  }
                }
                V = f2;
              }
            }
            if (0 !== (f2.subtreeFlags & 2064) && null !== g2)
              g2.return = f2, V = g2;
            else
              b:
                for (; null !== V; ) {
                  f2 = V;
                  if (0 !== (f2.flags & 2048))
                    switch (f2.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Qj(9, f2, f2.return);
                    }
                  var x2 = f2.sibling;
                  if (null !== x2) {
                    x2.return = f2.return;
                    V = x2;
                    break b;
                  }
                  V = f2.return;
                }
          }
          var w2 = a.current;
          for (V = w2; null !== V; ) {
            g2 = V;
            var u2 = g2.child;
            if (0 !== (g2.subtreeFlags & 2064) && null !== u2)
              u2.return = g2, V = u2;
            else
              b:
                for (g2 = w2; null !== V; ) {
                  h2 = V;
                  if (0 !== (h2.flags & 2048))
                    try {
                      switch (h2.tag) {
                        case 0:
                        case 11:
                        case 15:
                          Rj(9, h2);
                      }
                    } catch (na) {
                      W(h2, h2.return, na);
                    }
                  if (h2 === g2) {
                    V = null;
                    break b;
                  }
                  var F2 = h2.sibling;
                  if (null !== F2) {
                    F2.return = h2.return;
                    V = F2;
                    break b;
                  }
                  V = h2.return;
                }
          }
          K = e2;
          jg();
          if (lc && "function" === typeof lc.onPostCommitFiberRoot)
            try {
              lc.onPostCommitFiberRoot(kc, a);
            } catch (na) {
            }
          d2 = true;
        }
        return d2;
      } finally {
        C = c2, pk.transition = b2;
      }
    }
    return false;
  }
  function Yk(a, b2, c2) {
    b2 = Ki(c2, b2);
    b2 = Oi(a, b2, 1);
    a = dh(a, b2, 1);
    b2 = L();
    null !== a && (Ac(a, 1, b2), Ek(a, b2));
  }
  function W(a, b2, c2) {
    if (3 === a.tag)
      Yk(a, a, c2);
    else
      for (; null !== b2; ) {
        if (3 === b2.tag) {
          Yk(b2, a, c2);
          break;
        } else if (1 === b2.tag) {
          var d2 = b2.stateNode;
          if ("function" === typeof b2.type.getDerivedStateFromError || "function" === typeof d2.componentDidCatch && (null === Si || !Si.has(d2))) {
            a = Ki(c2, a);
            a = Ri(b2, a, 1);
            b2 = dh(b2, a, 1);
            a = L();
            null !== b2 && (Ac(b2, 1, a), Ek(b2, a));
            break;
          }
        }
        b2 = b2.return;
      }
  }
  function Ui(a, b2, c2) {
    var d2 = a.pingCache;
    null !== d2 && d2.delete(b2);
    b2 = L();
    a.pingedLanes |= a.suspendedLanes & c2;
    R === a && (Z & c2) === c2 && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - gk ? Lk(a, 0) : sk |= c2);
    Ek(a, b2);
  }
  function Zk(a, b2) {
    0 === b2 && (0 === (a.mode & 1) ? b2 = 1 : (b2 = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
    var c2 = L();
    a = Zg(a, b2);
    null !== a && (Ac(a, b2, c2), Ek(a, c2));
  }
  function vj(a) {
    var b2 = a.memoizedState, c2 = 0;
    null !== b2 && (c2 = b2.retryLane);
    Zk(a, c2);
  }
  function ck(a, b2) {
    var c2 = 0;
    switch (a.tag) {
      case 13:
        var d2 = a.stateNode;
        var e2 = a.memoizedState;
        null !== e2 && (c2 = e2.retryLane);
        break;
      case 19:
        d2 = a.stateNode;
        break;
      default:
        throw Error(p$3(314));
    }
    null !== d2 && d2.delete(b2);
    Zk(a, c2);
  }
  var Wk;
  Wk = function(a, b2, c2) {
    if (null !== a)
      if (a.memoizedProps !== b2.pendingProps || Wf.current)
        Ug = true;
      else {
        if (0 === (a.lanes & c2) && 0 === (b2.flags & 128))
          return Ug = false, zj(a, b2, c2);
        Ug = 0 !== (a.flags & 131072) ? true : false;
      }
    else
      Ug = false, I && 0 !== (b2.flags & 1048576) && ug(b2, ng, b2.index);
    b2.lanes = 0;
    switch (b2.tag) {
      case 2:
        var d2 = b2.type;
        jj(a, b2);
        a = b2.pendingProps;
        var e2 = Yf(b2, H.current);
        Tg(b2, c2);
        e2 = Xh(null, b2, d2, a, e2, c2);
        var f2 = bi();
        b2.flags |= 1;
        "object" === typeof e2 && null !== e2 && "function" === typeof e2.render && void 0 === e2.$$typeof ? (b2.tag = 1, b2.memoizedState = null, b2.updateQueue = null, Zf(d2) ? (f2 = true, cg(b2)) : f2 = false, b2.memoizedState = null !== e2.state && void 0 !== e2.state ? e2.state : null, ah(b2), e2.updater = nh, b2.stateNode = e2, e2._reactInternals = b2, rh(b2, d2, a, c2), b2 = kj(null, b2, d2, true, f2, c2)) : (b2.tag = 0, I && f2 && vg(b2), Yi(null, b2, e2, c2), b2 = b2.child);
        return b2;
      case 16:
        d2 = b2.elementType;
        a: {
          jj(a, b2);
          a = b2.pendingProps;
          e2 = d2._init;
          d2 = e2(d2._payload);
          b2.type = d2;
          e2 = b2.tag = $k(d2);
          a = Lg(d2, a);
          switch (e2) {
            case 0:
              b2 = dj(null, b2, d2, a, c2);
              break a;
            case 1:
              b2 = ij(null, b2, d2, a, c2);
              break a;
            case 11:
              b2 = Zi(null, b2, d2, a, c2);
              break a;
            case 14:
              b2 = aj(null, b2, d2, Lg(d2.type, a), c2);
              break a;
          }
          throw Error(p$3(
            306,
            d2,
            ""
          ));
        }
        return b2;
      case 0:
        return d2 = b2.type, e2 = b2.pendingProps, e2 = b2.elementType === d2 ? e2 : Lg(d2, e2), dj(a, b2, d2, e2, c2);
      case 1:
        return d2 = b2.type, e2 = b2.pendingProps, e2 = b2.elementType === d2 ? e2 : Lg(d2, e2), ij(a, b2, d2, e2, c2);
      case 3:
        a: {
          lj(b2);
          if (null === a)
            throw Error(p$3(387));
          d2 = b2.pendingProps;
          f2 = b2.memoizedState;
          e2 = f2.element;
          bh(a, b2);
          gh(b2, d2, null, c2);
          var g2 = b2.memoizedState;
          d2 = g2.element;
          if (f2.isDehydrated)
            if (f2 = { element: d2, isDehydrated: false, cache: g2.cache, pendingSuspenseBoundaries: g2.pendingSuspenseBoundaries, transitions: g2.transitions }, b2.updateQueue.baseState = f2, b2.memoizedState = f2, b2.flags & 256) {
              e2 = Ki(Error(p$3(423)), b2);
              b2 = mj(a, b2, d2, c2, e2);
              break a;
            } else if (d2 !== e2) {
              e2 = Ki(Error(p$3(424)), b2);
              b2 = mj(a, b2, d2, c2, e2);
              break a;
            } else
              for (yg = Lf(b2.stateNode.containerInfo.firstChild), xg = b2, I = true, zg = null, c2 = Ch(b2, null, d2, c2), b2.child = c2; c2; )
                c2.flags = c2.flags & -3 | 4096, c2 = c2.sibling;
          else {
            Ig();
            if (d2 === e2) {
              b2 = $i(a, b2, c2);
              break a;
            }
            Yi(a, b2, d2, c2);
          }
          b2 = b2.child;
        }
        return b2;
      case 5:
        return Kh(b2), null === a && Eg(b2), d2 = b2.type, e2 = b2.pendingProps, f2 = null !== a ? a.memoizedProps : null, g2 = e2.children, Ef(d2, e2) ? g2 = null : null !== f2 && Ef(d2, f2) && (b2.flags |= 32), hj(a, b2), Yi(a, b2, g2, c2), b2.child;
      case 6:
        return null === a && Eg(b2), null;
      case 13:
        return pj(a, b2, c2);
      case 4:
        return Ih(b2, b2.stateNode.containerInfo), d2 = b2.pendingProps, null === a ? b2.child = Bh(b2, null, d2, c2) : Yi(a, b2, d2, c2), b2.child;
      case 11:
        return d2 = b2.type, e2 = b2.pendingProps, e2 = b2.elementType === d2 ? e2 : Lg(d2, e2), Zi(a, b2, d2, e2, c2);
      case 7:
        return Yi(a, b2, b2.pendingProps, c2), b2.child;
      case 8:
        return Yi(a, b2, b2.pendingProps.children, c2), b2.child;
      case 12:
        return Yi(a, b2, b2.pendingProps.children, c2), b2.child;
      case 10:
        a: {
          d2 = b2.type._context;
          e2 = b2.pendingProps;
          f2 = b2.memoizedProps;
          g2 = e2.value;
          G(Mg, d2._currentValue);
          d2._currentValue = g2;
          if (null !== f2)
            if (He(f2.value, g2)) {
              if (f2.children === e2.children && !Wf.current) {
                b2 = $i(a, b2, c2);
                break a;
              }
            } else
              for (f2 = b2.child, null !== f2 && (f2.return = b2); null !== f2; ) {
                var h2 = f2.dependencies;
                if (null !== h2) {
                  g2 = f2.child;
                  for (var k2 = h2.firstContext; null !== k2; ) {
                    if (k2.context === d2) {
                      if (1 === f2.tag) {
                        k2 = ch(-1, c2 & -c2);
                        k2.tag = 2;
                        var l2 = f2.updateQueue;
                        if (null !== l2) {
                          l2 = l2.shared;
                          var m2 = l2.pending;
                          null === m2 ? k2.next = k2 : (k2.next = m2.next, m2.next = k2);
                          l2.pending = k2;
                        }
                      }
                      f2.lanes |= c2;
                      k2 = f2.alternate;
                      null !== k2 && (k2.lanes |= c2);
                      Sg(
                        f2.return,
                        c2,
                        b2
                      );
                      h2.lanes |= c2;
                      break;
                    }
                    k2 = k2.next;
                  }
                } else if (10 === f2.tag)
                  g2 = f2.type === b2.type ? null : f2.child;
                else if (18 === f2.tag) {
                  g2 = f2.return;
                  if (null === g2)
                    throw Error(p$3(341));
                  g2.lanes |= c2;
                  h2 = g2.alternate;
                  null !== h2 && (h2.lanes |= c2);
                  Sg(g2, c2, b2);
                  g2 = f2.sibling;
                } else
                  g2 = f2.child;
                if (null !== g2)
                  g2.return = f2;
                else
                  for (g2 = f2; null !== g2; ) {
                    if (g2 === b2) {
                      g2 = null;
                      break;
                    }
                    f2 = g2.sibling;
                    if (null !== f2) {
                      f2.return = g2.return;
                      g2 = f2;
                      break;
                    }
                    g2 = g2.return;
                  }
                f2 = g2;
              }
          Yi(a, b2, e2.children, c2);
          b2 = b2.child;
        }
        return b2;
      case 9:
        return e2 = b2.type, d2 = b2.pendingProps.children, Tg(b2, c2), e2 = Vg(e2), d2 = d2(e2), b2.flags |= 1, Yi(a, b2, d2, c2), b2.child;
      case 14:
        return d2 = b2.type, e2 = Lg(d2, b2.pendingProps), e2 = Lg(d2.type, e2), aj(a, b2, d2, e2, c2);
      case 15:
        return cj(a, b2, b2.type, b2.pendingProps, c2);
      case 17:
        return d2 = b2.type, e2 = b2.pendingProps, e2 = b2.elementType === d2 ? e2 : Lg(d2, e2), jj(a, b2), b2.tag = 1, Zf(d2) ? (a = true, cg(b2)) : a = false, Tg(b2, c2), ph(b2, d2, e2), rh(b2, d2, e2, c2), kj(null, b2, d2, true, a, c2);
      case 19:
        return yj(a, b2, c2);
      case 22:
        return ej(a, b2, c2);
    }
    throw Error(p$3(156, b2.tag));
  };
  function Gk(a, b2) {
    return ac(a, b2);
  }
  function al(a, b2, c2, d2) {
    this.tag = a;
    this.key = c2;
    this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
    this.index = 0;
    this.ref = null;
    this.pendingProps = b2;
    this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
    this.mode = d2;
    this.subtreeFlags = this.flags = 0;
    this.deletions = null;
    this.childLanes = this.lanes = 0;
    this.alternate = null;
  }
  function Bg(a, b2, c2, d2) {
    return new al(a, b2, c2, d2);
  }
  function bj(a) {
    a = a.prototype;
    return !(!a || !a.isReactComponent);
  }
  function $k(a) {
    if ("function" === typeof a)
      return bj(a) ? 1 : 0;
    if (void 0 !== a && null !== a) {
      a = a.$$typeof;
      if (a === Da)
        return 11;
      if (a === Ga)
        return 14;
    }
    return 2;
  }
  function wh(a, b2) {
    var c2 = a.alternate;
    null === c2 ? (c2 = Bg(a.tag, b2, a.key, a.mode), c2.elementType = a.elementType, c2.type = a.type, c2.stateNode = a.stateNode, c2.alternate = a, a.alternate = c2) : (c2.pendingProps = b2, c2.type = a.type, c2.flags = 0, c2.subtreeFlags = 0, c2.deletions = null);
    c2.flags = a.flags & 14680064;
    c2.childLanes = a.childLanes;
    c2.lanes = a.lanes;
    c2.child = a.child;
    c2.memoizedProps = a.memoizedProps;
    c2.memoizedState = a.memoizedState;
    c2.updateQueue = a.updateQueue;
    b2 = a.dependencies;
    c2.dependencies = null === b2 ? null : { lanes: b2.lanes, firstContext: b2.firstContext };
    c2.sibling = a.sibling;
    c2.index = a.index;
    c2.ref = a.ref;
    return c2;
  }
  function yh(a, b2, c2, d2, e2, f2) {
    var g2 = 2;
    d2 = a;
    if ("function" === typeof a)
      bj(a) && (g2 = 1);
    else if ("string" === typeof a)
      g2 = 5;
    else
      a:
        switch (a) {
          case ya:
            return Ah(c2.children, e2, f2, b2);
          case za:
            g2 = 8;
            e2 |= 8;
            break;
          case Aa:
            return a = Bg(12, c2, b2, e2 | 2), a.elementType = Aa, a.lanes = f2, a;
          case Ea:
            return a = Bg(13, c2, b2, e2), a.elementType = Ea, a.lanes = f2, a;
          case Fa:
            return a = Bg(19, c2, b2, e2), a.elementType = Fa, a.lanes = f2, a;
          case Ia:
            return qj(c2, e2, f2, b2);
          default:
            if ("object" === typeof a && null !== a)
              switch (a.$$typeof) {
                case Ba:
                  g2 = 10;
                  break a;
                case Ca:
                  g2 = 9;
                  break a;
                case Da:
                  g2 = 11;
                  break a;
                case Ga:
                  g2 = 14;
                  break a;
                case Ha:
                  g2 = 16;
                  d2 = null;
                  break a;
              }
            throw Error(p$3(130, null == a ? a : typeof a, ""));
        }
    b2 = Bg(g2, c2, b2, e2);
    b2.elementType = a;
    b2.type = d2;
    b2.lanes = f2;
    return b2;
  }
  function Ah(a, b2, c2, d2) {
    a = Bg(7, a, d2, b2);
    a.lanes = c2;
    return a;
  }
  function qj(a, b2, c2, d2) {
    a = Bg(22, a, d2, b2);
    a.elementType = Ia;
    a.lanes = c2;
    a.stateNode = { isHidden: false };
    return a;
  }
  function xh(a, b2, c2) {
    a = Bg(6, a, null, b2);
    a.lanes = c2;
    return a;
  }
  function zh(a, b2, c2) {
    b2 = Bg(4, null !== a.children ? a.children : [], a.key, b2);
    b2.lanes = c2;
    b2.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
    return b2;
  }
  function bl(a, b2, c2, d2, e2) {
    this.tag = b2;
    this.containerInfo = a;
    this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
    this.timeoutHandle = -1;
    this.callbackNode = this.pendingContext = this.context = null;
    this.callbackPriority = 0;
    this.eventTimes = zc(0);
    this.expirationTimes = zc(-1);
    this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
    this.entanglements = zc(0);
    this.identifierPrefix = d2;
    this.onRecoverableError = e2;
    this.mutableSourceEagerHydrationData = null;
  }
  function cl(a, b2, c2, d2, e2, f2, g2, h2, k2) {
    a = new bl(a, b2, c2, h2, k2);
    1 === b2 ? (b2 = 1, true === f2 && (b2 |= 8)) : b2 = 0;
    f2 = Bg(3, null, null, b2);
    a.current = f2;
    f2.stateNode = a;
    f2.memoizedState = { element: d2, isDehydrated: c2, cache: null, transitions: null, pendingSuspenseBoundaries: null };
    ah(f2);
    return a;
  }
  function dl(a, b2, c2) {
    var d2 = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
    return { $$typeof: wa, key: null == d2 ? null : "" + d2, children: a, containerInfo: b2, implementation: c2 };
  }
  function el(a) {
    if (!a)
      return Vf;
    a = a._reactInternals;
    a: {
      if (Vb(a) !== a || 1 !== a.tag)
        throw Error(p$3(170));
      var b2 = a;
      do {
        switch (b2.tag) {
          case 3:
            b2 = b2.stateNode.context;
            break a;
          case 1:
            if (Zf(b2.type)) {
              b2 = b2.stateNode.__reactInternalMemoizedMergedChildContext;
              break a;
            }
        }
        b2 = b2.return;
      } while (null !== b2);
      throw Error(p$3(171));
    }
    if (1 === a.tag) {
      var c2 = a.type;
      if (Zf(c2))
        return bg(a, c2, b2);
    }
    return b2;
  }
  function fl(a, b2, c2, d2, e2, f2, g2, h2, k2) {
    a = cl(c2, d2, true, a, e2, f2, g2, h2, k2);
    a.context = el(null);
    c2 = a.current;
    d2 = L();
    e2 = lh(c2);
    f2 = ch(d2, e2);
    f2.callback = void 0 !== b2 && null !== b2 ? b2 : null;
    dh(c2, f2, e2);
    a.current.lanes = e2;
    Ac(a, e2, d2);
    Ek(a, d2);
    return a;
  }
  function gl(a, b2, c2, d2) {
    var e2 = b2.current, f2 = L(), g2 = lh(e2);
    c2 = el(c2);
    null === b2.context ? b2.context = c2 : b2.pendingContext = c2;
    b2 = ch(f2, g2);
    b2.payload = { element: a };
    d2 = void 0 === d2 ? null : d2;
    null !== d2 && (b2.callback = d2);
    a = dh(e2, b2, g2);
    null !== a && (mh(a, e2, g2, f2), eh(a, e2, g2));
    return g2;
  }
  function hl(a) {
    a = a.current;
    if (!a.child)
      return null;
    switch (a.child.tag) {
      case 5:
        return a.child.stateNode;
      default:
        return a.child.stateNode;
    }
  }
  function il(a, b2) {
    a = a.memoizedState;
    if (null !== a && null !== a.dehydrated) {
      var c2 = a.retryLane;
      a.retryLane = 0 !== c2 && c2 < b2 ? c2 : b2;
    }
  }
  function jl(a, b2) {
    il(a, b2);
    (a = a.alternate) && il(a, b2);
  }
  function kl() {
    return null;
  }
  var ll = "function" === typeof reportError ? reportError : function(a) {
    console.error(a);
  };
  function ml(a) {
    this._internalRoot = a;
  }
  nl.prototype.render = ml.prototype.render = function(a) {
    var b2 = this._internalRoot;
    if (null === b2)
      throw Error(p$3(409));
    gl(a, b2, null, null);
  };
  nl.prototype.unmount = ml.prototype.unmount = function() {
    var a = this._internalRoot;
    if (null !== a) {
      this._internalRoot = null;
      var b2 = a.containerInfo;
      Sk(function() {
        gl(null, a, null, null);
      });
      b2[uf] = null;
    }
  };
  function nl(a) {
    this._internalRoot = a;
  }
  nl.prototype.unstable_scheduleHydration = function(a) {
    if (a) {
      var b2 = Hc();
      a = { blockedOn: null, target: a, priority: b2 };
      for (var c2 = 0; c2 < Qc.length && 0 !== b2 && b2 < Qc[c2].priority; c2++)
        ;
      Qc.splice(c2, 0, a);
      0 === c2 && Vc(a);
    }
  };
  function ol(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
  }
  function pl(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
  }
  function ql() {
  }
  function rl(a, b2, c2, d2, e2) {
    if (e2) {
      if ("function" === typeof d2) {
        var f2 = d2;
        d2 = function() {
          var a2 = hl(g2);
          f2.call(a2);
        };
      }
      var g2 = fl(b2, d2, a, 0, null, false, false, "", ql);
      a._reactRootContainer = g2;
      a[uf] = g2.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      Sk();
      return g2;
    }
    for (; e2 = a.lastChild; )
      a.removeChild(e2);
    if ("function" === typeof d2) {
      var h2 = d2;
      d2 = function() {
        var a2 = hl(k2);
        h2.call(a2);
      };
    }
    var k2 = cl(a, 0, false, null, null, false, false, "", ql);
    a._reactRootContainer = k2;
    a[uf] = k2.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    Sk(function() {
      gl(b2, k2, c2, d2);
    });
    return k2;
  }
  function sl(a, b2, c2, d2, e2) {
    var f2 = c2._reactRootContainer;
    if (f2) {
      var g2 = f2;
      if ("function" === typeof e2) {
        var h2 = e2;
        e2 = function() {
          var a2 = hl(g2);
          h2.call(a2);
        };
      }
      gl(b2, g2, a, e2);
    } else
      g2 = rl(c2, b2, a, e2, d2);
    return hl(g2);
  }
  Ec = function(a) {
    switch (a.tag) {
      case 3:
        var b2 = a.stateNode;
        if (b2.current.memoizedState.isDehydrated) {
          var c2 = tc(b2.pendingLanes);
          0 !== c2 && (Cc(b2, c2 | 1), Ek(b2, B()), 0 === (K & 6) && (Hj = B() + 500, jg()));
        }
        break;
      case 13:
        Sk(function() {
          var b3 = Zg(a, 1);
          if (null !== b3) {
            var c3 = L();
            mh(b3, a, 1, c3);
          }
        }), jl(a, 1);
    }
  };
  Fc = function(a) {
    if (13 === a.tag) {
      var b2 = Zg(a, 134217728);
      if (null !== b2) {
        var c2 = L();
        mh(b2, a, 134217728, c2);
      }
      jl(a, 134217728);
    }
  };
  Gc = function(a) {
    if (13 === a.tag) {
      var b2 = lh(a), c2 = Zg(a, b2);
      if (null !== c2) {
        var d2 = L();
        mh(c2, a, b2, d2);
      }
      jl(a, b2);
    }
  };
  Hc = function() {
    return C;
  };
  Ic = function(a, b2) {
    var c2 = C;
    try {
      return C = a, b2();
    } finally {
      C = c2;
    }
  };
  yb = function(a, b2, c2) {
    switch (b2) {
      case "input":
        bb(a, c2);
        b2 = c2.name;
        if ("radio" === c2.type && null != b2) {
          for (c2 = a; c2.parentNode; )
            c2 = c2.parentNode;
          c2 = c2.querySelectorAll("input[name=" + JSON.stringify("" + b2) + '][type="radio"]');
          for (b2 = 0; b2 < c2.length; b2++) {
            var d2 = c2[b2];
            if (d2 !== a && d2.form === a.form) {
              var e2 = Db(d2);
              if (!e2)
                throw Error(p$3(90));
              Wa(d2);
              bb(d2, e2);
            }
          }
        }
        break;
      case "textarea":
        ib(a, c2);
        break;
      case "select":
        b2 = c2.value, null != b2 && fb(a, !!c2.multiple, b2, false);
    }
  };
  Gb = Rk;
  Hb = Sk;
  var tl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Rk] }, ul = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.2.0", rendererPackageName: "react-dom" };
  var vl = { bundleType: ul.bundleType, version: ul.version, rendererPackageName: ul.rendererPackageName, rendererConfig: ul.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
    a = Zb(a);
    return null === a ? null : a.stateNode;
  }, findFiberByHostInstance: ul.findFiberByHostInstance || kl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.2.0-next-9e3b772b8-20220608" };
  if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
    var wl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!wl.isDisabled && wl.supportsFiber)
      try {
        kc = wl.inject(vl), lc = wl;
      } catch (a) {
      }
  }
  reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = tl;
  reactDom_production_min.createPortal = function(a, b2) {
    var c2 = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
    if (!ol(b2))
      throw Error(p$3(200));
    return dl(a, b2, null, c2);
  };
  reactDom_production_min.createRoot = function(a, b2) {
    if (!ol(a))
      throw Error(p$3(299));
    var c2 = false, d2 = "", e2 = ll;
    null !== b2 && void 0 !== b2 && (true === b2.unstable_strictMode && (c2 = true), void 0 !== b2.identifierPrefix && (d2 = b2.identifierPrefix), void 0 !== b2.onRecoverableError && (e2 = b2.onRecoverableError));
    b2 = cl(a, 1, false, null, null, c2, false, d2, e2);
    a[uf] = b2.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    return new ml(b2);
  };
  reactDom_production_min.findDOMNode = function(a) {
    if (null == a)
      return null;
    if (1 === a.nodeType)
      return a;
    var b2 = a._reactInternals;
    if (void 0 === b2) {
      if ("function" === typeof a.render)
        throw Error(p$3(188));
      a = Object.keys(a).join(",");
      throw Error(p$3(268, a));
    }
    a = Zb(b2);
    a = null === a ? null : a.stateNode;
    return a;
  };
  reactDom_production_min.flushSync = function(a) {
    return Sk(a);
  };
  reactDom_production_min.hydrate = function(a, b2, c2) {
    if (!pl(b2))
      throw Error(p$3(200));
    return sl(null, a, b2, true, c2);
  };
  reactDom_production_min.hydrateRoot = function(a, b2, c2) {
    if (!ol(a))
      throw Error(p$3(405));
    var d2 = null != c2 && c2.hydratedSources || null, e2 = false, f2 = "", g2 = ll;
    null !== c2 && void 0 !== c2 && (true === c2.unstable_strictMode && (e2 = true), void 0 !== c2.identifierPrefix && (f2 = c2.identifierPrefix), void 0 !== c2.onRecoverableError && (g2 = c2.onRecoverableError));
    b2 = fl(b2, null, a, 1, null != c2 ? c2 : null, e2, false, f2, g2);
    a[uf] = b2.current;
    sf(a);
    if (d2)
      for (a = 0; a < d2.length; a++)
        c2 = d2[a], e2 = c2._getVersion, e2 = e2(c2._source), null == b2.mutableSourceEagerHydrationData ? b2.mutableSourceEagerHydrationData = [c2, e2] : b2.mutableSourceEagerHydrationData.push(
          c2,
          e2
        );
    return new nl(b2);
  };
  reactDom_production_min.render = function(a, b2, c2) {
    if (!pl(b2))
      throw Error(p$3(200));
    return sl(null, a, b2, false, c2);
  };
  reactDom_production_min.unmountComponentAtNode = function(a) {
    if (!pl(a))
      throw Error(p$3(40));
    return a._reactRootContainer ? (Sk(function() {
      sl(null, null, a, false, function() {
        a._reactRootContainer = null;
        a[uf] = null;
      });
    }), true) : false;
  };
  reactDom_production_min.unstable_batchedUpdates = Rk;
  reactDom_production_min.unstable_renderSubtreeIntoContainer = function(a, b2, c2, d2) {
    if (!pl(c2))
      throw Error(p$3(200));
    if (null == a || void 0 === a._reactInternals)
      throw Error(p$3(38));
    return sl(a, b2, c2, false, d2);
  };
  reactDom_production_min.version = "18.2.0-next-9e3b772b8-20220608";
  (function(module) {
    function checkDCE() {
      if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
        return;
      }
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
      } catch (err) {
        console.error(err);
      }
    }
    {
      checkDCE();
      module.exports = reactDom_production_min;
    }
  })(reactDom);
  const ReactDOM = /* @__PURE__ */ getDefaultExportFromCjs(reactDom.exports);
  var createRoot;
  var m$3 = reactDom.exports;
  {
    createRoot = m$3.createRoot;
    m$3.hydrateRoot;
  }
  const CLS = {
    HIDDEN: "au-hidden"
  };
  const common = {
    black: "#000",
    white: "#fff"
  };
  const common$1 = common;
  const red = {
    50: "#ffebee",
    100: "#ffcdd2",
    200: "#ef9a9a",
    300: "#e57373",
    400: "#ef5350",
    500: "#f44336",
    600: "#e53935",
    700: "#d32f2f",
    800: "#c62828",
    900: "#b71c1c",
    A100: "#ff8a80",
    A200: "#ff5252",
    A400: "#ff1744",
    A700: "#d50000"
  };
  const red$1 = red;
  const purple = {
    50: "#f3e5f5",
    100: "#e1bee7",
    200: "#ce93d8",
    300: "#ba68c8",
    400: "#ab47bc",
    500: "#9c27b0",
    600: "#8e24aa",
    700: "#7b1fa2",
    800: "#6a1b9a",
    900: "#4a148c",
    A100: "#ea80fc",
    A200: "#e040fb",
    A400: "#d500f9",
    A700: "#aa00ff"
  };
  const purple$1 = purple;
  const blue = {
    50: "#e3f2fd",
    100: "#bbdefb",
    200: "#90caf9",
    300: "#64b5f6",
    400: "#42a5f5",
    500: "#2196f3",
    600: "#1e88e5",
    700: "#1976d2",
    800: "#1565c0",
    900: "#0d47a1",
    A100: "#82b1ff",
    A200: "#448aff",
    A400: "#2979ff",
    A700: "#2962ff"
  };
  const blue$1 = blue;
  const lightBlue = {
    50: "#e1f5fe",
    100: "#b3e5fc",
    200: "#81d4fa",
    300: "#4fc3f7",
    400: "#29b6f6",
    500: "#03a9f4",
    600: "#039be5",
    700: "#0288d1",
    800: "#0277bd",
    900: "#01579b",
    A100: "#80d8ff",
    A200: "#40c4ff",
    A400: "#00b0ff",
    A700: "#0091ea"
  };
  const lightBlue$1 = lightBlue;
  const green = {
    50: "#e8f5e9",
    100: "#c8e6c9",
    200: "#a5d6a7",
    300: "#81c784",
    400: "#66bb6a",
    500: "#4caf50",
    600: "#43a047",
    700: "#388e3c",
    800: "#2e7d32",
    900: "#1b5e20",
    A100: "#b9f6ca",
    A200: "#69f0ae",
    A400: "#00e676",
    A700: "#00c853"
  };
  const green$1 = green;
  const orange = {
    50: "#fff3e0",
    100: "#ffe0b2",
    200: "#ffcc80",
    300: "#ffb74d",
    400: "#ffa726",
    500: "#ff9800",
    600: "#fb8c00",
    700: "#f57c00",
    800: "#ef6c00",
    900: "#e65100",
    A100: "#ffd180",
    A200: "#ffab40",
    A400: "#ff9100",
    A700: "#ff6d00"
  };
  const orange$1 = orange;
  const grey = {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#eeeeee",
    300: "#e0e0e0",
    400: "#bdbdbd",
    500: "#9e9e9e",
    600: "#757575",
    700: "#616161",
    800: "#424242",
    900: "#212121",
    A100: "#f5f5f5",
    A200: "#eeeeee",
    A400: "#bdbdbd",
    A700: "#616161"
  };
  const grey$1 = grey;
  function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    return _extends.apply(this, arguments);
  }
  function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null)
      return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
      key = sourceKeys[i];
      if (excluded.indexOf(key) >= 0)
        continue;
      target[key] = source[key];
    }
    return target;
  }
  function memoize$2(fn) {
    var cache = /* @__PURE__ */ Object.create(null);
    return function(arg) {
      if (cache[arg] === void 0)
        cache[arg] = fn(arg);
      return cache[arg];
    };
  }
  var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|download|draggable|encType|enterKeyHint|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/;
  var isPropValid = /* @__PURE__ */ memoize$2(
    function(prop) {
      return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110 && prop.charCodeAt(2) < 91;
    }
  );
  function sheetForTag(tag) {
    if (tag.sheet) {
      return tag.sheet;
    }
    for (var i = 0; i < document.styleSheets.length; i++) {
      if (document.styleSheets[i].ownerNode === tag) {
        return document.styleSheets[i];
      }
    }
  }
  function createStyleElement(options) {
    var tag = document.createElement("style");
    tag.setAttribute("data-emotion", options.key);
    if (options.nonce !== void 0) {
      tag.setAttribute("nonce", options.nonce);
    }
    tag.appendChild(document.createTextNode(""));
    tag.setAttribute("data-s", "");
    return tag;
  }
  var StyleSheet = /* @__PURE__ */ function() {
    function StyleSheet2(options) {
      var _this = this;
      this._insertTag = function(tag) {
        var before;
        if (_this.tags.length === 0) {
          if (_this.insertionPoint) {
            before = _this.insertionPoint.nextSibling;
          } else if (_this.prepend) {
            before = _this.container.firstChild;
          } else {
            before = _this.before;
          }
        } else {
          before = _this.tags[_this.tags.length - 1].nextSibling;
        }
        _this.container.insertBefore(tag, before);
        _this.tags.push(tag);
      };
      this.isSpeedy = options.speedy === void 0 ? true : options.speedy;
      this.tags = [];
      this.ctr = 0;
      this.nonce = options.nonce;
      this.key = options.key;
      this.container = options.container;
      this.prepend = options.prepend;
      this.insertionPoint = options.insertionPoint;
      this.before = null;
    }
    var _proto = StyleSheet2.prototype;
    _proto.hydrate = function hydrate(nodes) {
      nodes.forEach(this._insertTag);
    };
    _proto.insert = function insert(rule) {
      if (this.ctr % (this.isSpeedy ? 65e3 : 1) === 0) {
        this._insertTag(createStyleElement(this));
      }
      var tag = this.tags[this.tags.length - 1];
      if (this.isSpeedy) {
        var sheet = sheetForTag(tag);
        try {
          sheet.insertRule(rule, sheet.cssRules.length);
        } catch (e2) {
        }
      } else {
        tag.appendChild(document.createTextNode(rule));
      }
      this.ctr++;
    };
    _proto.flush = function flush() {
      this.tags.forEach(function(tag) {
        return tag.parentNode && tag.parentNode.removeChild(tag);
      });
      this.tags = [];
      this.ctr = 0;
    };
    return StyleSheet2;
  }();
  var MS = "-ms-";
  var MOZ = "-moz-";
  var WEBKIT = "-webkit-";
  var COMMENT = "comm";
  var RULESET = "rule";
  var DECLARATION = "decl";
  var IMPORT = "@import";
  var KEYFRAMES = "@keyframes";
  var abs = Math.abs;
  var from = String.fromCharCode;
  var assign = Object.assign;
  function hash$2(value, length2) {
    return (((length2 << 2 ^ charat(value, 0)) << 2 ^ charat(value, 1)) << 2 ^ charat(value, 2)) << 2 ^ charat(value, 3);
  }
  function trim(value) {
    return value.trim();
  }
  function match(value, pattern) {
    return (value = pattern.exec(value)) ? value[0] : value;
  }
  function replace(value, pattern, replacement) {
    return value.replace(pattern, replacement);
  }
  function indexof(value, search) {
    return value.indexOf(search);
  }
  function charat(value, index) {
    return value.charCodeAt(index) | 0;
  }
  function substr(value, begin, end2) {
    return value.slice(begin, end2);
  }
  function strlen(value) {
    return value.length;
  }
  function sizeof(value) {
    return value.length;
  }
  function append(value, array) {
    return array.push(value), value;
  }
  function combine(array, callback) {
    return array.map(callback).join("");
  }
  var line = 1;
  var column = 1;
  var length = 0;
  var position$1 = 0;
  var character = 0;
  var characters = "";
  function node(value, root, parent, type, props, children, length2) {
    return { value, root, parent, type, props, children, line, column, length: length2, return: "" };
  }
  function copy(root, props) {
    return assign(node("", null, null, "", null, null, 0), root, { length: -root.length }, props);
  }
  function char() {
    return character;
  }
  function prev() {
    character = position$1 > 0 ? charat(characters, --position$1) : 0;
    if (column--, character === 10)
      column = 1, line--;
    return character;
  }
  function next() {
    character = position$1 < length ? charat(characters, position$1++) : 0;
    if (column++, character === 10)
      column = 1, line++;
    return character;
  }
  function peek() {
    return charat(characters, position$1);
  }
  function caret() {
    return position$1;
  }
  function slice(begin, end2) {
    return substr(characters, begin, end2);
  }
  function token(type) {
    switch (type) {
      case 0:
      case 9:
      case 10:
      case 13:
      case 32:
        return 5;
      case 33:
      case 43:
      case 44:
      case 47:
      case 62:
      case 64:
      case 126:
      case 59:
      case 123:
      case 125:
        return 4;
      case 58:
        return 3;
      case 34:
      case 39:
      case 40:
      case 91:
        return 2;
      case 41:
      case 93:
        return 1;
    }
    return 0;
  }
  function alloc(value) {
    return line = column = 1, length = strlen(characters = value), position$1 = 0, [];
  }
  function dealloc(value) {
    return characters = "", value;
  }
  function delimit(type) {
    return trim(slice(position$1 - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
  }
  function whitespace(type) {
    while (character = peek())
      if (character < 33)
        next();
      else
        break;
    return token(type) > 2 || token(character) > 3 ? "" : " ";
  }
  function escaping(index, count) {
    while (--count && next())
      if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97)
        break;
    return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
  }
  function delimiter(type) {
    while (next())
      switch (character) {
        case type:
          return position$1;
        case 34:
        case 39:
          if (type !== 34 && type !== 39)
            delimiter(character);
          break;
        case 40:
          if (type === 41)
            delimiter(type);
          break;
        case 92:
          next();
          break;
      }
    return position$1;
  }
  function commenter(type, index) {
    while (next())
      if (type + character === 47 + 10)
        break;
      else if (type + character === 42 + 42 && peek() === 47)
        break;
    return "/*" + slice(index, position$1 - 1) + "*" + from(type === 47 ? type : next());
  }
  function identifier(index) {
    while (!token(peek()))
      next();
    return slice(index, position$1);
  }
  function compile(value) {
    return dealloc(parse("", null, null, null, [""], value = alloc(value), 0, [0], value));
  }
  function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
    var index = 0;
    var offset2 = 0;
    var length2 = pseudo;
    var atrule = 0;
    var property = 0;
    var previous = 0;
    var variable = 1;
    var scanning = 1;
    var ampersand = 1;
    var character2 = 0;
    var type = "";
    var props = rules;
    var children = rulesets;
    var reference2 = rule;
    var characters2 = type;
    while (scanning)
      switch (previous = character2, character2 = next()) {
        case 40:
          if (previous != 108 && characters2.charCodeAt(length2 - 1) == 58) {
            if (indexof(characters2 += replace(delimit(character2), "&", "&\f"), "&\f") != -1)
              ampersand = -1;
            break;
          }
        case 34:
        case 39:
        case 91:
          characters2 += delimit(character2);
          break;
        case 9:
        case 10:
        case 13:
        case 32:
          characters2 += whitespace(previous);
          break;
        case 92:
          characters2 += escaping(caret() - 1, 7);
          continue;
        case 47:
          switch (peek()) {
            case 42:
            case 47:
              append(comment(commenter(next(), caret()), root, parent), declarations);
              break;
            default:
              characters2 += "/";
          }
          break;
        case 123 * variable:
          points[index++] = strlen(characters2) * ampersand;
        case 125 * variable:
        case 59:
        case 0:
          switch (character2) {
            case 0:
            case 125:
              scanning = 0;
            case 59 + offset2:
              if (property > 0 && strlen(characters2) - length2)
                append(property > 32 ? declaration(characters2 + ";", rule, parent, length2 - 1) : declaration(replace(characters2, " ", "") + ";", rule, parent, length2 - 2), declarations);
              break;
            case 59:
              characters2 += ";";
            default:
              append(reference2 = ruleset(characters2, root, parent, index, offset2, rules, points, type, props = [], children = [], length2), rulesets);
              if (character2 === 123)
                if (offset2 === 0)
                  parse(characters2, root, reference2, reference2, props, rulesets, length2, points, children);
                else
                  switch (atrule) {
                    case 100:
                    case 109:
                    case 115:
                      parse(value, reference2, reference2, rule && append(ruleset(value, reference2, reference2, 0, 0, rules, points, type, rules, props = [], length2), children), rules, children, length2, points, rule ? props : children);
                      break;
                    default:
                      parse(characters2, reference2, reference2, reference2, [""], children, 0, points, children);
                  }
          }
          index = offset2 = property = 0, variable = ampersand = 1, type = characters2 = "", length2 = pseudo;
          break;
        case 58:
          length2 = 1 + strlen(characters2), property = previous;
        default:
          if (variable < 1) {
            if (character2 == 123)
              --variable;
            else if (character2 == 125 && variable++ == 0 && prev() == 125)
              continue;
          }
          switch (characters2 += from(character2), character2 * variable) {
            case 38:
              ampersand = offset2 > 0 ? 1 : (characters2 += "\f", -1);
              break;
            case 44:
              points[index++] = (strlen(characters2) - 1) * ampersand, ampersand = 1;
              break;
            case 64:
              if (peek() === 45)
                characters2 += delimit(next());
              atrule = peek(), offset2 = length2 = strlen(type = characters2 += identifier(caret())), character2++;
              break;
            case 45:
              if (previous === 45 && strlen(characters2) == 2)
                variable = 0;
          }
      }
    return rulesets;
  }
  function ruleset(value, root, parent, index, offset2, rules, points, type, props, children, length2) {
    var post = offset2 - 1;
    var rule = offset2 === 0 ? rules : [""];
    var size = sizeof(rule);
    for (var i = 0, j = 0, k2 = 0; i < index; ++i)
      for (var x2 = 0, y2 = substr(value, post + 1, post = abs(j = points[i])), z2 = value; x2 < size; ++x2)
        if (z2 = trim(j > 0 ? rule[x2] + " " + y2 : replace(y2, /&\f/g, rule[x2])))
          props[k2++] = z2;
    return node(value, root, parent, offset2 === 0 ? RULESET : type, props, children, length2);
  }
  function comment(value, root, parent) {
    return node(value, root, parent, COMMENT, from(char()), substr(value, 2, -2), 0);
  }
  function declaration(value, root, parent, length2) {
    return node(value, root, parent, DECLARATION, substr(value, 0, length2), substr(value, length2 + 1, -1), length2);
  }
  function prefix(value, length2) {
    switch (hash$2(value, length2)) {
      case 5103:
        return WEBKIT + "print-" + value + value;
      case 5737:
      case 4201:
      case 3177:
      case 3433:
      case 1641:
      case 4457:
      case 2921:
      case 5572:
      case 6356:
      case 5844:
      case 3191:
      case 6645:
      case 3005:
      case 6391:
      case 5879:
      case 5623:
      case 6135:
      case 4599:
      case 4855:
      case 4215:
      case 6389:
      case 5109:
      case 5365:
      case 5621:
      case 3829:
        return WEBKIT + value + value;
      case 5349:
      case 4246:
      case 4810:
      case 6968:
      case 2756:
        return WEBKIT + value + MOZ + value + MS + value + value;
      case 6828:
      case 4268:
        return WEBKIT + value + MS + value + value;
      case 6165:
        return WEBKIT + value + MS + "flex-" + value + value;
      case 5187:
        return WEBKIT + value + replace(value, /(\w+).+(:[^]+)/, WEBKIT + "box-$1$2" + MS + "flex-$1$2") + value;
      case 5443:
        return WEBKIT + value + MS + "flex-item-" + replace(value, /flex-|-self/, "") + value;
      case 4675:
        return WEBKIT + value + MS + "flex-line-pack" + replace(value, /align-content|flex-|-self/, "") + value;
      case 5548:
        return WEBKIT + value + MS + replace(value, "shrink", "negative") + value;
      case 5292:
        return WEBKIT + value + MS + replace(value, "basis", "preferred-size") + value;
      case 6060:
        return WEBKIT + "box-" + replace(value, "-grow", "") + WEBKIT + value + MS + replace(value, "grow", "positive") + value;
      case 4554:
        return WEBKIT + replace(value, /([^-])(transform)/g, "$1" + WEBKIT + "$2") + value;
      case 6187:
        return replace(replace(replace(value, /(zoom-|grab)/, WEBKIT + "$1"), /(image-set)/, WEBKIT + "$1"), value, "") + value;
      case 5495:
      case 3959:
        return replace(value, /(image-set\([^]*)/, WEBKIT + "$1$`$1");
      case 4968:
        return replace(replace(value, /(.+:)(flex-)?(.*)/, WEBKIT + "box-pack:$3" + MS + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + WEBKIT + value + value;
      case 4095:
      case 3583:
      case 4068:
      case 2532:
        return replace(value, /(.+)-inline(.+)/, WEBKIT + "$1$2") + value;
      case 8116:
      case 7059:
      case 5753:
      case 5535:
      case 5445:
      case 5701:
      case 4933:
      case 4677:
      case 5533:
      case 5789:
      case 5021:
      case 4765:
        if (strlen(value) - 1 - length2 > 6)
          switch (charat(value, length2 + 1)) {
            case 109:
              if (charat(value, length2 + 4) !== 45)
                break;
            case 102:
              return replace(value, /(.+:)(.+)-([^]+)/, "$1" + WEBKIT + "$2-$3$1" + MOZ + (charat(value, length2 + 3) == 108 ? "$3" : "$2-$3")) + value;
            case 115:
              return ~indexof(value, "stretch") ? prefix(replace(value, "stretch", "fill-available"), length2) + value : value;
          }
        break;
      case 4949:
        if (charat(value, length2 + 1) !== 115)
          break;
      case 6444:
        switch (charat(value, strlen(value) - 3 - (~indexof(value, "!important") && 10))) {
          case 107:
            return replace(value, ":", ":" + WEBKIT) + value;
          case 101:
            return replace(value, /(.+:)([^;!]+)(;|!.+)?/, "$1" + WEBKIT + (charat(value, 14) === 45 ? "inline-" : "") + "box$3$1" + WEBKIT + "$2$3$1" + MS + "$2box$3") + value;
        }
        break;
      case 5936:
        switch (charat(value, length2 + 11)) {
          case 114:
            return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb") + value;
          case 108:
            return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "tb-rl") + value;
          case 45:
            return WEBKIT + value + MS + replace(value, /[svh]\w+-[tblr]{2}/, "lr") + value;
        }
        return WEBKIT + value + MS + value + value;
    }
    return value;
  }
  function serialize(children, callback) {
    var output = "";
    var length2 = sizeof(children);
    for (var i = 0; i < length2; i++)
      output += callback(children[i], i, children, callback) || "";
    return output;
  }
  function stringify(element, index, children, callback) {
    switch (element.type) {
      case IMPORT:
      case DECLARATION:
        return element.return = element.return || element.value;
      case COMMENT:
        return "";
      case KEYFRAMES:
        return element.return = element.value + "{" + serialize(element.children, callback) + "}";
      case RULESET:
        element.value = element.props.join(",");
    }
    return strlen(children = serialize(element.children, callback)) ? element.return = element.value + "{" + children + "}" : "";
  }
  function middleware(collection) {
    var length2 = sizeof(collection);
    return function(element, index, children, callback) {
      var output = "";
      for (var i = 0; i < length2; i++)
        output += collection[i](element, index, children, callback) || "";
      return output;
    };
  }
  function rulesheet(callback) {
    return function(element) {
      if (!element.root) {
        if (element = element.return)
          callback(element);
      }
    };
  }
  function prefixer(element, index, children, callback) {
    if (element.length > -1) {
      if (!element.return)
        switch (element.type) {
          case DECLARATION:
            element.return = prefix(element.value, element.length);
            break;
          case KEYFRAMES:
            return serialize([copy(element, { value: replace(element.value, "@", "@" + WEBKIT) })], callback);
          case RULESET:
            if (element.length)
              return combine(element.props, function(value) {
                switch (match(value, /(::plac\w+|:read-\w+)/)) {
                  case ":read-only":
                  case ":read-write":
                    return serialize([copy(element, { props: [replace(value, /:(read-\w+)/, ":" + MOZ + "$1")] })], callback);
                  case "::placeholder":
                    return serialize([
                      copy(element, { props: [replace(value, /:(plac\w+)/, ":" + WEBKIT + "input-$1")] }),
                      copy(element, { props: [replace(value, /:(plac\w+)/, ":" + MOZ + "$1")] }),
                      copy(element, { props: [replace(value, /:(plac\w+)/, MS + "input-$1")] })
                    ], callback);
                }
                return "";
              });
        }
    }
  }
  var identifierWithPointTracking = function identifierWithPointTracking2(begin, points, index) {
    var previous = 0;
    var character2 = 0;
    while (true) {
      previous = character2;
      character2 = peek();
      if (previous === 38 && character2 === 12) {
        points[index] = 1;
      }
      if (token(character2)) {
        break;
      }
      next();
    }
    return slice(begin, position$1);
  };
  var toRules = function toRules2(parsed, points) {
    var index = -1;
    var character2 = 44;
    do {
      switch (token(character2)) {
        case 0:
          if (character2 === 38 && peek() === 12) {
            points[index] = 1;
          }
          parsed[index] += identifierWithPointTracking(position$1 - 1, points, index);
          break;
        case 2:
          parsed[index] += delimit(character2);
          break;
        case 4:
          if (character2 === 44) {
            parsed[++index] = peek() === 58 ? "&\f" : "";
            points[index] = parsed[index].length;
            break;
          }
        default:
          parsed[index] += from(character2);
      }
    } while (character2 = next());
    return parsed;
  };
  var getRules = function getRules2(value, points) {
    return dealloc(toRules(alloc(value), points));
  };
  var fixedElements = /* @__PURE__ */ new WeakMap();
  var compat = function compat2(element) {
    if (element.type !== "rule" || !element.parent || element.length < 1) {
      return;
    }
    var value = element.value, parent = element.parent;
    var isImplicitRule = element.column === parent.column && element.line === parent.line;
    while (parent.type !== "rule") {
      parent = parent.parent;
      if (!parent)
        return;
    }
    if (element.props.length === 1 && value.charCodeAt(0) !== 58 && !fixedElements.get(parent)) {
      return;
    }
    if (isImplicitRule) {
      return;
    }
    fixedElements.set(element, true);
    var points = [];
    var rules = getRules(value, points);
    var parentRules = parent.props;
    for (var i = 0, k2 = 0; i < rules.length; i++) {
      for (var j = 0; j < parentRules.length; j++, k2++) {
        element.props[k2] = points[i] ? rules[i].replace(/&\f/g, parentRules[j]) : parentRules[j] + " " + rules[i];
      }
    }
  };
  var removeLabel = function removeLabel2(element) {
    if (element.type === "decl") {
      var value = element.value;
      if (value.charCodeAt(0) === 108 && value.charCodeAt(2) === 98) {
        element["return"] = "";
        element.value = "";
      }
    }
  };
  var defaultStylisPlugins = [prefixer];
  var createCache = function createCache2(options) {
    var key = options.key;
    if (key === "css") {
      var ssrStyles = document.querySelectorAll("style[data-emotion]:not([data-s])");
      Array.prototype.forEach.call(ssrStyles, function(node2) {
        var dataEmotionAttribute = node2.getAttribute("data-emotion");
        if (dataEmotionAttribute.indexOf(" ") === -1) {
          return;
        }
        document.head.appendChild(node2);
        node2.setAttribute("data-s", "");
      });
    }
    var stylisPlugins = options.stylisPlugins || defaultStylisPlugins;
    var inserted = {};
    var container;
    var nodesToHydrate = [];
    {
      container = options.container || document.head;
      Array.prototype.forEach.call(
        document.querySelectorAll('style[data-emotion^="' + key + ' "]'),
        function(node2) {
          var attrib = node2.getAttribute("data-emotion").split(" ");
          for (var i = 1; i < attrib.length; i++) {
            inserted[attrib[i]] = true;
          }
          nodesToHydrate.push(node2);
        }
      );
    }
    var _insert;
    var omnipresentPlugins = [compat, removeLabel];
    {
      var currentSheet;
      var finalizingPlugins = [stringify, rulesheet(function(rule) {
        currentSheet.insert(rule);
      })];
      var serializer = middleware(omnipresentPlugins.concat(stylisPlugins, finalizingPlugins));
      var stylis = function stylis2(styles2) {
        return serialize(compile(styles2), serializer);
      };
      _insert = function insert(selector, serialized, sheet, shouldCache) {
        currentSheet = sheet;
        stylis(selector ? selector + "{" + serialized.styles + "}" : serialized.styles);
        if (shouldCache) {
          cache.inserted[serialized.name] = true;
        }
      };
    }
    var cache = {
      key,
      sheet: new StyleSheet({
        key,
        container,
        nonce: options.nonce,
        speedy: options.speedy,
        prepend: options.prepend,
        insertionPoint: options.insertionPoint
      }),
      nonce: options.nonce,
      inserted,
      registered: {},
      insert: _insert
    };
    cache.sheet.hydrate(nodesToHydrate);
    return cache;
  };
  var reactIs$2 = { exports: {} };
  var reactIs_production_min$1 = {};
  /** @license React v16.13.1
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var b$1 = "function" === typeof Symbol && Symbol.for, c$1 = b$1 ? Symbol.for("react.element") : 60103, d$1 = b$1 ? Symbol.for("react.portal") : 60106, e$1 = b$1 ? Symbol.for("react.fragment") : 60107, f$2 = b$1 ? Symbol.for("react.strict_mode") : 60108, g$1 = b$1 ? Symbol.for("react.profiler") : 60114, h$1 = b$1 ? Symbol.for("react.provider") : 60109, k$2 = b$1 ? Symbol.for("react.context") : 60110, l$2 = b$1 ? Symbol.for("react.async_mode") : 60111, m$2 = b$1 ? Symbol.for("react.concurrent_mode") : 60111, n$2 = b$1 ? Symbol.for("react.forward_ref") : 60112, p$2 = b$1 ? Symbol.for("react.suspense") : 60113, q$2 = b$1 ? Symbol.for("react.suspense_list") : 60120, r$1 = b$1 ? Symbol.for("react.memo") : 60115, t$1 = b$1 ? Symbol.for("react.lazy") : 60116, v$1 = b$1 ? Symbol.for("react.block") : 60121, w = b$1 ? Symbol.for("react.fundamental") : 60117, x = b$1 ? Symbol.for("react.responder") : 60118, y = b$1 ? Symbol.for("react.scope") : 60119;
  function z(a) {
    if ("object" === typeof a && null !== a) {
      var u2 = a.$$typeof;
      switch (u2) {
        case c$1:
          switch (a = a.type, a) {
            case l$2:
            case m$2:
            case e$1:
            case g$1:
            case f$2:
            case p$2:
              return a;
            default:
              switch (a = a && a.$$typeof, a) {
                case k$2:
                case n$2:
                case t$1:
                case r$1:
                case h$1:
                  return a;
                default:
                  return u2;
              }
          }
        case d$1:
          return u2;
      }
    }
  }
  function A(a) {
    return z(a) === m$2;
  }
  reactIs_production_min$1.AsyncMode = l$2;
  reactIs_production_min$1.ConcurrentMode = m$2;
  reactIs_production_min$1.ContextConsumer = k$2;
  reactIs_production_min$1.ContextProvider = h$1;
  reactIs_production_min$1.Element = c$1;
  reactIs_production_min$1.ForwardRef = n$2;
  reactIs_production_min$1.Fragment = e$1;
  reactIs_production_min$1.Lazy = t$1;
  reactIs_production_min$1.Memo = r$1;
  reactIs_production_min$1.Portal = d$1;
  reactIs_production_min$1.Profiler = g$1;
  reactIs_production_min$1.StrictMode = f$2;
  reactIs_production_min$1.Suspense = p$2;
  reactIs_production_min$1.isAsyncMode = function(a) {
    return A(a) || z(a) === l$2;
  };
  reactIs_production_min$1.isConcurrentMode = A;
  reactIs_production_min$1.isContextConsumer = function(a) {
    return z(a) === k$2;
  };
  reactIs_production_min$1.isContextProvider = function(a) {
    return z(a) === h$1;
  };
  reactIs_production_min$1.isElement = function(a) {
    return "object" === typeof a && null !== a && a.$$typeof === c$1;
  };
  reactIs_production_min$1.isForwardRef = function(a) {
    return z(a) === n$2;
  };
  reactIs_production_min$1.isFragment = function(a) {
    return z(a) === e$1;
  };
  reactIs_production_min$1.isLazy = function(a) {
    return z(a) === t$1;
  };
  reactIs_production_min$1.isMemo = function(a) {
    return z(a) === r$1;
  };
  reactIs_production_min$1.isPortal = function(a) {
    return z(a) === d$1;
  };
  reactIs_production_min$1.isProfiler = function(a) {
    return z(a) === g$1;
  };
  reactIs_production_min$1.isStrictMode = function(a) {
    return z(a) === f$2;
  };
  reactIs_production_min$1.isSuspense = function(a) {
    return z(a) === p$2;
  };
  reactIs_production_min$1.isValidElementType = function(a) {
    return "string" === typeof a || "function" === typeof a || a === e$1 || a === m$2 || a === g$1 || a === f$2 || a === p$2 || a === q$2 || "object" === typeof a && null !== a && (a.$$typeof === t$1 || a.$$typeof === r$1 || a.$$typeof === h$1 || a.$$typeof === k$2 || a.$$typeof === n$2 || a.$$typeof === w || a.$$typeof === x || a.$$typeof === y || a.$$typeof === v$1);
  };
  reactIs_production_min$1.typeOf = z;
  (function(module) {
    {
      module.exports = reactIs_production_min$1;
    }
  })(reactIs$2);
  var reactIs$1 = reactIs$2.exports;
  var FORWARD_REF_STATICS = {
    "$$typeof": true,
    render: true,
    defaultProps: true,
    displayName: true,
    propTypes: true
  };
  var MEMO_STATICS = {
    "$$typeof": true,
    compare: true,
    defaultProps: true,
    displayName: true,
    propTypes: true,
    type: true
  };
  var TYPE_STATICS = {};
  TYPE_STATICS[reactIs$1.ForwardRef] = FORWARD_REF_STATICS;
  TYPE_STATICS[reactIs$1.Memo] = MEMO_STATICS;
  var isBrowser = true;
  function getRegisteredStyles(registered, registeredStyles, classNames) {
    var rawClassName = "";
    classNames.split(" ").forEach(function(className) {
      if (registered[className] !== void 0) {
        registeredStyles.push(registered[className] + ";");
      } else {
        rawClassName += className + " ";
      }
    });
    return rawClassName;
  }
  var registerStyles = function registerStyles2(cache, serialized, isStringTag2) {
    var className = cache.key + "-" + serialized.name;
    if ((isStringTag2 === false || isBrowser === false) && cache.registered[className] === void 0) {
      cache.registered[className] = serialized.styles;
    }
  };
  var insertStyles = function insertStyles2(cache, serialized, isStringTag2) {
    registerStyles(cache, serialized, isStringTag2);
    var className = cache.key + "-" + serialized.name;
    if (cache.inserted[serialized.name] === void 0) {
      var current = serialized;
      do {
        cache.insert(serialized === current ? "." + className : "", current, cache.sheet, true);
        current = current.next;
      } while (current !== void 0);
    }
  };
  function murmur2(str) {
    var h2 = 0;
    var k2, i = 0, len = str.length;
    for (; len >= 4; ++i, len -= 4) {
      k2 = str.charCodeAt(i) & 255 | (str.charCodeAt(++i) & 255) << 8 | (str.charCodeAt(++i) & 255) << 16 | (str.charCodeAt(++i) & 255) << 24;
      k2 = (k2 & 65535) * 1540483477 + ((k2 >>> 16) * 59797 << 16);
      k2 ^= k2 >>> 24;
      h2 = (k2 & 65535) * 1540483477 + ((k2 >>> 16) * 59797 << 16) ^ (h2 & 65535) * 1540483477 + ((h2 >>> 16) * 59797 << 16);
    }
    switch (len) {
      case 3:
        h2 ^= (str.charCodeAt(i + 2) & 255) << 16;
      case 2:
        h2 ^= (str.charCodeAt(i + 1) & 255) << 8;
      case 1:
        h2 ^= str.charCodeAt(i) & 255;
        h2 = (h2 & 65535) * 1540483477 + ((h2 >>> 16) * 59797 << 16);
    }
    h2 ^= h2 >>> 13;
    h2 = (h2 & 65535) * 1540483477 + ((h2 >>> 16) * 59797 << 16);
    return ((h2 ^ h2 >>> 15) >>> 0).toString(36);
  }
  var unitlessKeys = {
    animationIterationCount: 1,
    borderImageOutset: 1,
    borderImageSlice: 1,
    borderImageWidth: 1,
    boxFlex: 1,
    boxFlexGroup: 1,
    boxOrdinalGroup: 1,
    columnCount: 1,
    columns: 1,
    flex: 1,
    flexGrow: 1,
    flexPositive: 1,
    flexShrink: 1,
    flexNegative: 1,
    flexOrder: 1,
    gridRow: 1,
    gridRowEnd: 1,
    gridRowSpan: 1,
    gridRowStart: 1,
    gridColumn: 1,
    gridColumnEnd: 1,
    gridColumnSpan: 1,
    gridColumnStart: 1,
    msGridRow: 1,
    msGridRowSpan: 1,
    msGridColumn: 1,
    msGridColumnSpan: 1,
    fontWeight: 1,
    lineHeight: 1,
    opacity: 1,
    order: 1,
    orphans: 1,
    tabSize: 1,
    widows: 1,
    zIndex: 1,
    zoom: 1,
    WebkitLineClamp: 1,
    fillOpacity: 1,
    floodOpacity: 1,
    stopOpacity: 1,
    strokeDasharray: 1,
    strokeDashoffset: 1,
    strokeMiterlimit: 1,
    strokeOpacity: 1,
    strokeWidth: 1
  };
  var hyphenateRegex = /[A-Z]|^ms/g;
  var animationRegex = /_EMO_([^_]+?)_([^]*?)_EMO_/g;
  var isCustomProperty = function isCustomProperty2(property) {
    return property.charCodeAt(1) === 45;
  };
  var isProcessableValue = function isProcessableValue2(value) {
    return value != null && typeof value !== "boolean";
  };
  var processStyleName = /* @__PURE__ */ memoize$2(function(styleName) {
    return isCustomProperty(styleName) ? styleName : styleName.replace(hyphenateRegex, "-$&").toLowerCase();
  });
  var processStyleValue = function processStyleValue2(key, value) {
    switch (key) {
      case "animation":
      case "animationName": {
        if (typeof value === "string") {
          return value.replace(animationRegex, function(match2, p1, p2) {
            cursor = {
              name: p1,
              styles: p2,
              next: cursor
            };
            return p1;
          });
        }
      }
    }
    if (unitlessKeys[key] !== 1 && !isCustomProperty(key) && typeof value === "number" && value !== 0) {
      return value + "px";
    }
    return value;
  };
  var noComponentSelectorMessage = "Component selectors can only be used in conjunction with @emotion/babel-plugin, the swc Emotion plugin, or another Emotion-aware compiler transform.";
  function handleInterpolation(mergedProps, registered, interpolation) {
    if (interpolation == null) {
      return "";
    }
    if (interpolation.__emotion_styles !== void 0) {
      return interpolation;
    }
    switch (typeof interpolation) {
      case "boolean": {
        return "";
      }
      case "object": {
        if (interpolation.anim === 1) {
          cursor = {
            name: interpolation.name,
            styles: interpolation.styles,
            next: cursor
          };
          return interpolation.name;
        }
        if (interpolation.styles !== void 0) {
          var next2 = interpolation.next;
          if (next2 !== void 0) {
            while (next2 !== void 0) {
              cursor = {
                name: next2.name,
                styles: next2.styles,
                next: cursor
              };
              next2 = next2.next;
            }
          }
          var styles2 = interpolation.styles + ";";
          return styles2;
        }
        return createStringFromObject(mergedProps, registered, interpolation);
      }
      case "function": {
        if (mergedProps !== void 0) {
          var previousCursor = cursor;
          var result = interpolation(mergedProps);
          cursor = previousCursor;
          return handleInterpolation(mergedProps, registered, result);
        }
        break;
      }
    }
    if (registered == null) {
      return interpolation;
    }
    var cached = registered[interpolation];
    return cached !== void 0 ? cached : interpolation;
  }
  function createStringFromObject(mergedProps, registered, obj) {
    var string = "";
    if (Array.isArray(obj)) {
      for (var i = 0; i < obj.length; i++) {
        string += handleInterpolation(mergedProps, registered, obj[i]) + ";";
      }
    } else {
      for (var _key in obj) {
        var value = obj[_key];
        if (typeof value !== "object") {
          if (registered != null && registered[value] !== void 0) {
            string += _key + "{" + registered[value] + "}";
          } else if (isProcessableValue(value)) {
            string += processStyleName(_key) + ":" + processStyleValue(_key, value) + ";";
          }
        } else {
          if (_key === "NO_COMPONENT_SELECTOR" && false) {
            throw new Error(noComponentSelectorMessage);
          }
          if (Array.isArray(value) && typeof value[0] === "string" && (registered == null || registered[value[0]] === void 0)) {
            for (var _i = 0; _i < value.length; _i++) {
              if (isProcessableValue(value[_i])) {
                string += processStyleName(_key) + ":" + processStyleValue(_key, value[_i]) + ";";
              }
            }
          } else {
            var interpolated = handleInterpolation(mergedProps, registered, value);
            switch (_key) {
              case "animation":
              case "animationName": {
                string += processStyleName(_key) + ":" + interpolated + ";";
                break;
              }
              default: {
                string += _key + "{" + interpolated + "}";
              }
            }
          }
        }
      }
    }
    return string;
  }
  var labelPattern = /label:\s*([^\s;\n{]+)\s*(;|$)/g;
  var cursor;
  var serializeStyles = function serializeStyles2(args, registered, mergedProps) {
    if (args.length === 1 && typeof args[0] === "object" && args[0] !== null && args[0].styles !== void 0) {
      return args[0];
    }
    var stringMode = true;
    var styles2 = "";
    cursor = void 0;
    var strings = args[0];
    if (strings == null || strings.raw === void 0) {
      stringMode = false;
      styles2 += handleInterpolation(mergedProps, registered, strings);
    } else {
      styles2 += strings[0];
    }
    for (var i = 1; i < args.length; i++) {
      styles2 += handleInterpolation(mergedProps, registered, args[i]);
      if (stringMode) {
        styles2 += strings[i];
      }
    }
    labelPattern.lastIndex = 0;
    var identifierName = "";
    var match2;
    while ((match2 = labelPattern.exec(styles2)) !== null) {
      identifierName += "-" + match2[1];
    }
    var name = murmur2(styles2) + identifierName;
    return {
      name,
      styles: styles2,
      next: cursor
    };
  };
  var syncFallback = function syncFallback2(create) {
    return create();
  };
  var useInsertionEffect = React$2["useInsertionEffect"] ? React$2["useInsertionEffect"] : false;
  var useInsertionEffectAlwaysWithSyncFallback = useInsertionEffect || syncFallback;
  var useInsertionEffectWithLayoutFallback = useInsertionEffect || react.exports.useLayoutEffect;
  var EmotionCacheContext = /* @__PURE__ */ react.exports.createContext(
    typeof HTMLElement !== "undefined" ? /* @__PURE__ */ createCache({
      key: "css"
    }) : null
  );
  EmotionCacheContext.Provider;
  var withEmotionCache = function withEmotionCache2(func) {
    return /* @__PURE__ */ react.exports.forwardRef(function(props, ref) {
      var cache = react.exports.useContext(EmotionCacheContext);
      return func(props, cache, ref);
    });
  };
  var ThemeContext$2 = /* @__PURE__ */ react.exports.createContext({});
  var Global = /* @__PURE__ */ withEmotionCache(function(props, cache) {
    var styles2 = props.styles;
    var serialized = serializeStyles([styles2], void 0, react.exports.useContext(ThemeContext$2));
    var sheetRef = react.exports.useRef();
    useInsertionEffectWithLayoutFallback(function() {
      var key = cache.key + "-global";
      var sheet = new cache.sheet.constructor({
        key,
        nonce: cache.sheet.nonce,
        container: cache.sheet.container,
        speedy: cache.sheet.isSpeedy
      });
      var rehydrating = false;
      var node2 = document.querySelector('style[data-emotion="' + key + " " + serialized.name + '"]');
      if (cache.sheet.tags.length) {
        sheet.before = cache.sheet.tags[0];
      }
      if (node2 !== null) {
        rehydrating = true;
        node2.setAttribute("data-emotion", key);
        sheet.hydrate([node2]);
      }
      sheetRef.current = [sheet, rehydrating];
      return function() {
        sheet.flush();
      };
    }, [cache]);
    useInsertionEffectWithLayoutFallback(function() {
      var sheetRefCurrent = sheetRef.current;
      var sheet = sheetRefCurrent[0], rehydrating = sheetRefCurrent[1];
      if (rehydrating) {
        sheetRefCurrent[1] = false;
        return;
      }
      if (serialized.next !== void 0) {
        insertStyles(cache, serialized.next, true);
      }
      if (sheet.tags.length) {
        var element = sheet.tags[sheet.tags.length - 1].nextElementSibling;
        sheet.before = element;
        sheet.flush();
      }
      cache.insert("", serialized, sheet, false);
    }, [cache, serialized.name]);
    return null;
  });
  function css() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return serializeStyles(args);
  }
  var keyframes = function keyframes2() {
    var insertable = css.apply(void 0, arguments);
    var name = "animation-" + insertable.name;
    return {
      name,
      styles: "@keyframes " + name + "{" + insertable.styles + "}",
      anim: 1,
      toString: function toString() {
        return "_EMO_" + this.name + "_" + this.styles + "_EMO_";
      }
    };
  };
  var testOmitPropsOnStringTag = isPropValid;
  var testOmitPropsOnComponent = function testOmitPropsOnComponent2(key) {
    return key !== "theme";
  };
  var getDefaultShouldForwardProp = function getDefaultShouldForwardProp2(tag) {
    return typeof tag === "string" && tag.charCodeAt(0) > 96 ? testOmitPropsOnStringTag : testOmitPropsOnComponent;
  };
  var composeShouldForwardProps = function composeShouldForwardProps2(tag, options, isReal) {
    var shouldForwardProp2;
    if (options) {
      var optionsShouldForwardProp = options.shouldForwardProp;
      shouldForwardProp2 = tag.__emotion_forwardProp && optionsShouldForwardProp ? function(propName) {
        return tag.__emotion_forwardProp(propName) && optionsShouldForwardProp(propName);
      } : optionsShouldForwardProp;
    }
    if (typeof shouldForwardProp2 !== "function" && isReal) {
      shouldForwardProp2 = tag.__emotion_forwardProp;
    }
    return shouldForwardProp2;
  };
  var Insertion = function Insertion2(_ref) {
    var cache = _ref.cache, serialized = _ref.serialized, isStringTag2 = _ref.isStringTag;
    registerStyles(cache, serialized, isStringTag2);
    useInsertionEffectAlwaysWithSyncFallback(function() {
      return insertStyles(cache, serialized, isStringTag2);
    });
    return null;
  };
  var createStyled$1 = function createStyled2(tag, options) {
    var isReal = tag.__emotion_real === tag;
    var baseTag = isReal && tag.__emotion_base || tag;
    var identifierName;
    var targetClassName;
    if (options !== void 0) {
      identifierName = options.label;
      targetClassName = options.target;
    }
    var shouldForwardProp2 = composeShouldForwardProps(tag, options, isReal);
    var defaultShouldForwardProp = shouldForwardProp2 || getDefaultShouldForwardProp(baseTag);
    var shouldUseAs = !defaultShouldForwardProp("as");
    return function() {
      var args = arguments;
      var styles2 = isReal && tag.__emotion_styles !== void 0 ? tag.__emotion_styles.slice(0) : [];
      if (identifierName !== void 0) {
        styles2.push("label:" + identifierName + ";");
      }
      if (args[0] == null || args[0].raw === void 0) {
        styles2.push.apply(styles2, args);
      } else {
        styles2.push(args[0][0]);
        var len = args.length;
        var i = 1;
        for (; i < len; i++) {
          styles2.push(args[i], args[0][i]);
        }
      }
      var Styled = withEmotionCache(function(props, cache, ref) {
        var FinalTag = shouldUseAs && props.as || baseTag;
        var className = "";
        var classInterpolations = [];
        var mergedProps = props;
        if (props.theme == null) {
          mergedProps = {};
          for (var key in props) {
            mergedProps[key] = props[key];
          }
          mergedProps.theme = react.exports.useContext(ThemeContext$2);
        }
        if (typeof props.className === "string") {
          className = getRegisteredStyles(cache.registered, classInterpolations, props.className);
        } else if (props.className != null) {
          className = props.className + " ";
        }
        var serialized = serializeStyles(styles2.concat(classInterpolations), cache.registered, mergedProps);
        className += cache.key + "-" + serialized.name;
        if (targetClassName !== void 0) {
          className += " " + targetClassName;
        }
        var finalShouldForwardProp = shouldUseAs && shouldForwardProp2 === void 0 ? getDefaultShouldForwardProp(FinalTag) : defaultShouldForwardProp;
        var newProps = {};
        for (var _key in props) {
          if (shouldUseAs && _key === "as")
            continue;
          if (finalShouldForwardProp(_key)) {
            newProps[_key] = props[_key];
          }
        }
        newProps.className = className;
        newProps.ref = ref;
        return /* @__PURE__ */ react.exports.createElement(react.exports.Fragment, null, /* @__PURE__ */ react.exports.createElement(Insertion, {
          cache,
          serialized,
          isStringTag: typeof FinalTag === "string"
        }), /* @__PURE__ */ react.exports.createElement(FinalTag, newProps));
      });
      Styled.displayName = identifierName !== void 0 ? identifierName : "Styled(" + (typeof baseTag === "string" ? baseTag : baseTag.displayName || baseTag.name || "Component") + ")";
      Styled.defaultProps = tag.defaultProps;
      Styled.__emotion_real = Styled;
      Styled.__emotion_base = baseTag;
      Styled.__emotion_styles = styles2;
      Styled.__emotion_forwardProp = shouldForwardProp2;
      Object.defineProperty(Styled, "toString", {
        value: function value() {
          if (targetClassName === void 0 && false) {
            return "NO_COMPONENT_SELECTOR";
          }
          return "." + targetClassName;
        }
      });
      Styled.withComponent = function(nextTag, nextOptions) {
        return createStyled2(nextTag, _extends({}, options, nextOptions, {
          shouldForwardProp: composeShouldForwardProps(Styled, nextOptions, true)
        })).apply(void 0, styles2);
      };
      return Styled;
    };
  };
  var tags = [
    "a",
    "abbr",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "base",
    "bdi",
    "bdo",
    "big",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dfn",
    "dialog",
    "div",
    "dl",
    "dt",
    "em",
    "embed",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "iframe",
    "img",
    "input",
    "ins",
    "kbd",
    "keygen",
    "label",
    "legend",
    "li",
    "link",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "menuitem",
    "meta",
    "meter",
    "nav",
    "noscript",
    "object",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "param",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "script",
    "section",
    "select",
    "small",
    "source",
    "span",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "title",
    "tr",
    "track",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
    "circle",
    "clipPath",
    "defs",
    "ellipse",
    "foreignObject",
    "g",
    "image",
    "line",
    "linearGradient",
    "mask",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialGradient",
    "rect",
    "stop",
    "svg",
    "text",
    "tspan"
  ];
  var newStyled = createStyled$1.bind();
  tags.forEach(function(tagName) {
    newStyled[tagName] = newStyled(tagName);
  });
  var propTypes = { exports: {} };
  var ReactPropTypesSecret$1 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  var ReactPropTypesSecret_1 = ReactPropTypesSecret$1;
  var ReactPropTypesSecret = ReactPropTypesSecret_1;
  function emptyFunction() {
  }
  function emptyFunctionWithReset() {
  }
  emptyFunctionWithReset.resetWarningCache = emptyFunction;
  var factoryWithThrowingShims = function() {
    function shim(props, propName, componentName, location, propFullName, secret) {
      if (secret === ReactPropTypesSecret) {
        return;
      }
      var err = new Error(
        "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
      );
      err.name = "Invariant Violation";
      throw err;
    }
    shim.isRequired = shim;
    function getShim() {
      return shim;
    }
    var ReactPropTypes = {
      array: shim,
      bigint: shim,
      bool: shim,
      func: shim,
      number: shim,
      object: shim,
      string: shim,
      symbol: shim,
      any: shim,
      arrayOf: getShim,
      element: shim,
      elementType: shim,
      instanceOf: getShim,
      node: shim,
      objectOf: getShim,
      oneOf: getShim,
      oneOfType: getShim,
      shape: getShim,
      exact: getShim,
      checkPropTypes: emptyFunctionWithReset,
      resetWarningCache: emptyFunction
    };
    ReactPropTypes.PropTypes = ReactPropTypes;
    return ReactPropTypes;
  };
  {
    propTypes.exports = factoryWithThrowingShims();
  }
  var jsxRuntime$1 = { exports: {} };
  var reactJsxRuntime_production_min = {};
  /**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var f$1 = react.exports, k$1 = Symbol.for("react.element"), l$1 = Symbol.for("react.fragment"), m$1 = Object.prototype.hasOwnProperty, n$1 = f$1.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p$1 = { key: true, ref: true, __self: true, __source: true };
  function q$1(c2, a, g2) {
    var b2, d2 = {}, e2 = null, h2 = null;
    void 0 !== g2 && (e2 = "" + g2);
    void 0 !== a.key && (e2 = "" + a.key);
    void 0 !== a.ref && (h2 = a.ref);
    for (b2 in a)
      m$1.call(a, b2) && !p$1.hasOwnProperty(b2) && (d2[b2] = a[b2]);
    if (c2 && c2.defaultProps)
      for (b2 in a = c2.defaultProps, a)
        void 0 === d2[b2] && (d2[b2] = a[b2]);
    return { $$typeof: k$1, type: c2, key: e2, ref: h2, props: d2, _owner: n$1.current };
  }
  reactJsxRuntime_production_min.Fragment = l$1;
  reactJsxRuntime_production_min.jsx = q$1;
  reactJsxRuntime_production_min.jsxs = q$1;
  (function(module) {
    {
      module.exports = reactJsxRuntime_production_min;
    }
  })(jsxRuntime$1);
  const Fragment = jsxRuntime$1.exports.Fragment;
  const jsx = jsxRuntime$1.exports.jsx;
  const jsxs = jsxRuntime$1.exports.jsxs;
  const jsxRuntime = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    Fragment,
    jsx,
    jsxs
  }, Symbol.toStringTag, { value: "Module" }));
  function isEmpty$4(obj) {
    return obj === void 0 || obj === null || Object.keys(obj).length === 0;
  }
  function GlobalStyles$1(props) {
    const {
      styles: styles2,
      defaultTheme: defaultTheme2 = {}
    } = props;
    const globalStyles = typeof styles2 === "function" ? (themeInput) => styles2(isEmpty$4(themeInput) ? defaultTheme2 : themeInput) : styles2;
    return /* @__PURE__ */ jsx(Global, {
      styles: globalStyles
    });
  }
  /** @license MUI v5.10.8
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  function styled$2(tag, options) {
    const stylesFactory = newStyled(tag, options);
    return stylesFactory;
  }
  const internal_processStyles = (tag, processor) => {
    if (Array.isArray(tag.__emotion_styles)) {
      tag.__emotion_styles = processor(tag.__emotion_styles);
    }
  };
  function isPlainObject(item) {
    return item !== null && typeof item === "object" && item.constructor === Object;
  }
  function deepmerge(target, source, options = {
    clone: true
  }) {
    const output = options.clone ? _extends({}, target) : target;
    if (isPlainObject(target) && isPlainObject(source)) {
      Object.keys(source).forEach((key) => {
        if (key === "__proto__") {
          return;
        }
        if (isPlainObject(source[key]) && key in target && isPlainObject(target[key])) {
          output[key] = deepmerge(target[key], source[key], options);
        } else {
          output[key] = source[key];
        }
      });
    }
    return output;
  }
  function formatMuiErrorMessage(code) {
    let url = "https://mui.com/production-error/?code=" + code;
    for (let i = 1; i < arguments.length; i += 1) {
      url += "&args[]=" + encodeURIComponent(arguments[i]);
    }
    return "Minified MUI error #" + code + "; visit " + url + " for the full message.";
  }
  function capitalize(string) {
    if (typeof string !== "string") {
      throw new Error(formatMuiErrorMessage(7));
    }
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  function createChainedFunction(...funcs) {
    return funcs.reduce((acc, func) => {
      if (func == null) {
        return acc;
      }
      return function chainedFunction(...args) {
        acc.apply(this, args);
        func.apply(this, args);
      };
    }, () => {
    });
  }
  function debounce$1(func, wait = 166) {
    let timeout;
    function debounced(...args) {
      const later = () => {
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    }
    debounced.clear = () => {
      clearTimeout(timeout);
    };
    return debounced;
  }
  function deprecatedPropType(validator, reason) {
    {
      return () => null;
    }
  }
  function isMuiElement(element, muiNames) {
    return /* @__PURE__ */ react.exports.isValidElement(element) && muiNames.indexOf(element.type.muiName) !== -1;
  }
  function ownerDocument(node2) {
    return node2 && node2.ownerDocument || document;
  }
  function ownerWindow(node2) {
    const doc = ownerDocument(node2);
    return doc.defaultView || window;
  }
  function requirePropFactory(componentNameInError, Component) {
    {
      return () => null;
    }
  }
  function setRef(ref, value) {
    if (typeof ref === "function") {
      ref(value);
    } else if (ref) {
      ref.current = value;
    }
  }
  const useEnhancedEffect = typeof window !== "undefined" ? react.exports.useLayoutEffect : react.exports.useEffect;
  const useEnhancedEffect$1 = useEnhancedEffect;
  let globalId = 0;
  function useGlobalId(idOverride) {
    const [defaultId, setDefaultId] = react.exports.useState(idOverride);
    const id2 = idOverride || defaultId;
    react.exports.useEffect(() => {
      if (defaultId == null) {
        globalId += 1;
        setDefaultId(`mui-${globalId}`);
      }
    }, [defaultId]);
    return id2;
  }
  const maybeReactUseId = React$2["useId"];
  function useId(idOverride) {
    if (maybeReactUseId !== void 0) {
      const reactId = maybeReactUseId();
      return idOverride != null ? idOverride : reactId;
    }
    return useGlobalId(idOverride);
  }
  function unsupportedProp(props, propName, componentName, location, propFullName) {
    {
      return null;
    }
  }
  function useControlled({
    controlled,
    default: defaultProp,
    name,
    state = "value"
  }) {
    const {
      current: isControlled
    } = react.exports.useRef(controlled !== void 0);
    const [valueState, setValue] = react.exports.useState(defaultProp);
    const value = isControlled ? controlled : valueState;
    const setValueIfUncontrolled = react.exports.useCallback((newValue) => {
      if (!isControlled) {
        setValue(newValue);
      }
    }, []);
    return [value, setValueIfUncontrolled];
  }
  function useEventCallback(fn) {
    const ref = react.exports.useRef(fn);
    useEnhancedEffect$1(() => {
      ref.current = fn;
    });
    return react.exports.useCallback((...args) => (0, ref.current)(...args), []);
  }
  function useForkRef(refA, refB) {
    return react.exports.useMemo(() => {
      if (refA == null && refB == null) {
        return null;
      }
      return (refValue) => {
        setRef(refA, refValue);
        setRef(refB, refValue);
      };
    }, [refA, refB]);
  }
  let hadKeyboardEvent = true;
  let hadFocusVisibleRecently = false;
  let hadFocusVisibleRecentlyTimeout;
  const inputTypesWhitelist = {
    text: true,
    search: true,
    url: true,
    tel: true,
    email: true,
    password: true,
    number: true,
    date: true,
    month: true,
    week: true,
    time: true,
    datetime: true,
    "datetime-local": true
  };
  function focusTriggersKeyboardModality(node2) {
    const {
      type,
      tagName
    } = node2;
    if (tagName === "INPUT" && inputTypesWhitelist[type] && !node2.readOnly) {
      return true;
    }
    if (tagName === "TEXTAREA" && !node2.readOnly) {
      return true;
    }
    if (node2.isContentEditable) {
      return true;
    }
    return false;
  }
  function handleKeyDown(event) {
    if (event.metaKey || event.altKey || event.ctrlKey) {
      return;
    }
    hadKeyboardEvent = true;
  }
  function handlePointerDown() {
    hadKeyboardEvent = false;
  }
  function handleVisibilityChange() {
    if (this.visibilityState === "hidden") {
      if (hadFocusVisibleRecently) {
        hadKeyboardEvent = true;
      }
    }
  }
  function prepare(doc) {
    doc.addEventListener("keydown", handleKeyDown, true);
    doc.addEventListener("mousedown", handlePointerDown, true);
    doc.addEventListener("pointerdown", handlePointerDown, true);
    doc.addEventListener("touchstart", handlePointerDown, true);
    doc.addEventListener("visibilitychange", handleVisibilityChange, true);
  }
  function isFocusVisible(event) {
    const {
      target
    } = event;
    try {
      return target.matches(":focus-visible");
    } catch (error) {
    }
    return hadKeyboardEvent || focusTriggersKeyboardModality(target);
  }
  function useIsFocusVisible() {
    const ref = react.exports.useCallback((node2) => {
      if (node2 != null) {
        prepare(node2.ownerDocument);
      }
    }, []);
    const isFocusVisibleRef = react.exports.useRef(false);
    function handleBlurVisible() {
      if (isFocusVisibleRef.current) {
        hadFocusVisibleRecently = true;
        window.clearTimeout(hadFocusVisibleRecentlyTimeout);
        hadFocusVisibleRecentlyTimeout = window.setTimeout(() => {
          hadFocusVisibleRecently = false;
        }, 100);
        isFocusVisibleRef.current = false;
        return true;
      }
      return false;
    }
    function handleFocusVisible(event) {
      if (isFocusVisible(event)) {
        isFocusVisibleRef.current = true;
        return true;
      }
      return false;
    }
    return {
      isFocusVisibleRef,
      onFocus: handleFocusVisible,
      onBlur: handleBlurVisible,
      ref
    };
  }
  function getScrollbarSize(doc) {
    const documentWidth = doc.documentElement.clientWidth;
    return Math.abs(window.innerWidth - documentWidth);
  }
  function resolveProps(defaultProps2, props) {
    const output = _extends({}, props);
    Object.keys(defaultProps2).forEach((propName) => {
      if (output[propName] === void 0) {
        output[propName] = defaultProps2[propName];
      }
    });
    return output;
  }
  function composeClasses(slots, getUtilityClass, classes) {
    const output = {};
    Object.keys(slots).forEach(
      (slot) => {
        output[slot] = slots[slot].reduce((acc, key) => {
          if (key) {
            acc.push(getUtilityClass(key));
            if (classes && classes[key]) {
              acc.push(classes[key]);
            }
          }
          return acc;
        }, []).join(" ");
      }
    );
    return output;
  }
  const defaultGenerator = (componentName) => componentName;
  const createClassNameGenerator = () => {
    let generate = defaultGenerator;
    return {
      configure(generator) {
        generate = generator;
      },
      generate(componentName) {
        return generate(componentName);
      },
      reset() {
        generate = defaultGenerator;
      }
    };
  };
  const ClassNameGenerator = createClassNameGenerator();
  const ClassNameGenerator$1 = ClassNameGenerator;
  const globalStateClassesMapping = {
    active: "active",
    checked: "checked",
    completed: "completed",
    disabled: "disabled",
    error: "error",
    expanded: "expanded",
    focused: "focused",
    focusVisible: "focusVisible",
    required: "required",
    selected: "selected"
  };
  function generateUtilityClass(componentName, slot, globalStatePrefix = "Mui") {
    const globalStateClass = globalStateClassesMapping[slot];
    return globalStateClass ? `${globalStatePrefix}-${globalStateClass}` : `${ClassNameGenerator$1.generate(componentName)}-${slot}`;
  }
  function generateUtilityClasses(componentName, slots, globalStatePrefix = "Mui") {
    const result = {};
    slots.forEach((slot) => {
      result[slot] = generateUtilityClass(componentName, slot, globalStatePrefix);
    });
    return result;
  }
  function merge(acc, item) {
    if (!item) {
      return acc;
    }
    return deepmerge(acc, item, {
      clone: false
    });
  }
  const values$1 = {
    xs: 0,
    sm: 600,
    md: 900,
    lg: 1200,
    xl: 1536
  };
  const defaultBreakpoints = {
    keys: ["xs", "sm", "md", "lg", "xl"],
    up: (key) => `@media (min-width:${values$1[key]}px)`
  };
  function handleBreakpoints(props, propValue, styleFromPropValue) {
    const theme = props.theme || {};
    if (Array.isArray(propValue)) {
      const themeBreakpoints = theme.breakpoints || defaultBreakpoints;
      return propValue.reduce((acc, item, index) => {
        acc[themeBreakpoints.up(themeBreakpoints.keys[index])] = styleFromPropValue(propValue[index]);
        return acc;
      }, {});
    }
    if (typeof propValue === "object") {
      const themeBreakpoints = theme.breakpoints || defaultBreakpoints;
      return Object.keys(propValue).reduce((acc, breakpoint) => {
        if (Object.keys(themeBreakpoints.values || values$1).indexOf(breakpoint) !== -1) {
          const mediaKey = themeBreakpoints.up(breakpoint);
          acc[mediaKey] = styleFromPropValue(propValue[breakpoint], breakpoint);
        } else {
          const cssKey = breakpoint;
          acc[cssKey] = propValue[cssKey];
        }
        return acc;
      }, {});
    }
    const output = styleFromPropValue(propValue);
    return output;
  }
  function createEmptyBreakpointObject(breakpointsInput = {}) {
    var _breakpointsInput$key;
    const breakpointsInOrder = (_breakpointsInput$key = breakpointsInput.keys) == null ? void 0 : _breakpointsInput$key.reduce((acc, key) => {
      const breakpointStyleKey = breakpointsInput.up(key);
      acc[breakpointStyleKey] = {};
      return acc;
    }, {});
    return breakpointsInOrder || {};
  }
  function removeUnusedBreakpoints(breakpointKeys, style2) {
    return breakpointKeys.reduce((acc, key) => {
      const breakpointOutput = acc[key];
      const isBreakpointUnused = !breakpointOutput || Object.keys(breakpointOutput).length === 0;
      if (isBreakpointUnused) {
        delete acc[key];
      }
      return acc;
    }, style2);
  }
  function mergeBreakpointsInOrder(breakpointsInput, ...styles2) {
    const emptyBreakpoints = createEmptyBreakpointObject(breakpointsInput);
    const mergedOutput = [emptyBreakpoints, ...styles2].reduce((prev2, next2) => deepmerge(prev2, next2), {});
    return removeUnusedBreakpoints(Object.keys(emptyBreakpoints), mergedOutput);
  }
  function computeBreakpointsBase(breakpointValues, themeBreakpoints) {
    if (typeof breakpointValues !== "object") {
      return {};
    }
    const base = {};
    const breakpointsKeys = Object.keys(themeBreakpoints);
    if (Array.isArray(breakpointValues)) {
      breakpointsKeys.forEach((breakpoint, i) => {
        if (i < breakpointValues.length) {
          base[breakpoint] = true;
        }
      });
    } else {
      breakpointsKeys.forEach((breakpoint) => {
        if (breakpointValues[breakpoint] != null) {
          base[breakpoint] = true;
        }
      });
    }
    return base;
  }
  function resolveBreakpointValues({
    values: breakpointValues,
    breakpoints: themeBreakpoints,
    base: customBase
  }) {
    const base = customBase || computeBreakpointsBase(breakpointValues, themeBreakpoints);
    const keys = Object.keys(base);
    if (keys.length === 0) {
      return breakpointValues;
    }
    let previous;
    return keys.reduce((acc, breakpoint, i) => {
      if (Array.isArray(breakpointValues)) {
        acc[breakpoint] = breakpointValues[i] != null ? breakpointValues[i] : breakpointValues[previous];
        previous = i;
      } else if (typeof breakpointValues === "object") {
        acc[breakpoint] = breakpointValues[breakpoint] != null ? breakpointValues[breakpoint] : breakpointValues[previous];
        previous = breakpoint;
      } else {
        acc[breakpoint] = breakpointValues;
      }
      return acc;
    }, {});
  }
  function getPath(obj, path, checkVars = true) {
    if (!path || typeof path !== "string") {
      return null;
    }
    if (obj && obj.vars && checkVars) {
      const val = `vars.${path}`.split(".").reduce((acc, item) => acc && acc[item] ? acc[item] : null, obj);
      if (val != null) {
        return val;
      }
    }
    return path.split(".").reduce((acc, item) => {
      if (acc && acc[item] != null) {
        return acc[item];
      }
      return null;
    }, obj);
  }
  function getValue$1(themeMapping, transform2, propValueFinal, userValue = propValueFinal) {
    let value;
    if (typeof themeMapping === "function") {
      value = themeMapping(propValueFinal);
    } else if (Array.isArray(themeMapping)) {
      value = themeMapping[propValueFinal] || userValue;
    } else {
      value = getPath(themeMapping, propValueFinal) || userValue;
    }
    if (transform2) {
      value = transform2(value);
    }
    return value;
  }
  function style$2(options) {
    const {
      prop,
      cssProperty = options.prop,
      themeKey,
      transform: transform2
    } = options;
    const fn = (props) => {
      if (props[prop] == null) {
        return null;
      }
      const propValue = props[prop];
      const theme = props.theme;
      const themeMapping = getPath(theme, themeKey) || {};
      const styleFromPropValue = (propValueFinal) => {
        let value = getValue$1(themeMapping, transform2, propValueFinal);
        if (propValueFinal === value && typeof propValueFinal === "string") {
          value = getValue$1(themeMapping, transform2, `${prop}${propValueFinal === "default" ? "" : capitalize(propValueFinal)}`, propValueFinal);
        }
        if (cssProperty === false) {
          return value;
        }
        return {
          [cssProperty]: value
        };
      };
      return handleBreakpoints(props, propValue, styleFromPropValue);
    };
    fn.propTypes = {};
    fn.filterProps = [prop];
    return fn;
  }
  function compose(...styles2) {
    const handlers = styles2.reduce((acc, style2) => {
      style2.filterProps.forEach((prop) => {
        acc[prop] = style2;
      });
      return acc;
    }, {});
    const fn = (props) => {
      return Object.keys(props).reduce((acc, prop) => {
        if (handlers[prop]) {
          return merge(acc, handlers[prop](props));
        }
        return acc;
      }, {});
    };
    fn.propTypes = {};
    fn.filterProps = styles2.reduce((acc, style2) => acc.concat(style2.filterProps), []);
    return fn;
  }
  function memoize$1(fn) {
    const cache = {};
    return (arg) => {
      if (cache[arg] === void 0) {
        cache[arg] = fn(arg);
      }
      return cache[arg];
    };
  }
  const properties = {
    m: "margin",
    p: "padding"
  };
  const directions = {
    t: "Top",
    r: "Right",
    b: "Bottom",
    l: "Left",
    x: ["Left", "Right"],
    y: ["Top", "Bottom"]
  };
  const aliases = {
    marginX: "mx",
    marginY: "my",
    paddingX: "px",
    paddingY: "py"
  };
  const getCssProperties = memoize$1((prop) => {
    if (prop.length > 2) {
      if (aliases[prop]) {
        prop = aliases[prop];
      } else {
        return [prop];
      }
    }
    const [a, b2] = prop.split("");
    const property = properties[a];
    const direction = directions[b2] || "";
    return Array.isArray(direction) ? direction.map((dir) => property + dir) : [property + direction];
  });
  const marginKeys = ["m", "mt", "mr", "mb", "ml", "mx", "my", "margin", "marginTop", "marginRight", "marginBottom", "marginLeft", "marginX", "marginY", "marginInline", "marginInlineStart", "marginInlineEnd", "marginBlock", "marginBlockStart", "marginBlockEnd"];
  const paddingKeys = ["p", "pt", "pr", "pb", "pl", "px", "py", "padding", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "paddingX", "paddingY", "paddingInline", "paddingInlineStart", "paddingInlineEnd", "paddingBlock", "paddingBlockStart", "paddingBlockEnd"];
  const spacingKeys = [...marginKeys, ...paddingKeys];
  function createUnaryUnit(theme, themeKey, defaultValue, propName) {
    var _getPath;
    const themeSpacing = (_getPath = getPath(theme, themeKey, false)) != null ? _getPath : defaultValue;
    if (typeof themeSpacing === "number") {
      return (abs2) => {
        if (typeof abs2 === "string") {
          return abs2;
        }
        return themeSpacing * abs2;
      };
    }
    if (Array.isArray(themeSpacing)) {
      return (abs2) => {
        if (typeof abs2 === "string") {
          return abs2;
        }
        return themeSpacing[abs2];
      };
    }
    if (typeof themeSpacing === "function") {
      return themeSpacing;
    }
    return () => void 0;
  }
  function createUnarySpacing(theme) {
    return createUnaryUnit(theme, "spacing", 8);
  }
  function getValue(transformer, propValue) {
    if (typeof propValue === "string" || propValue == null) {
      return propValue;
    }
    const abs2 = Math.abs(propValue);
    const transformed = transformer(abs2);
    if (propValue >= 0) {
      return transformed;
    }
    if (typeof transformed === "number") {
      return -transformed;
    }
    return `-${transformed}`;
  }
  function getStyleFromPropValue(cssProperties, transformer) {
    return (propValue) => cssProperties.reduce((acc, cssProperty) => {
      acc[cssProperty] = getValue(transformer, propValue);
      return acc;
    }, {});
  }
  function resolveCssProperty(props, keys, prop, transformer) {
    if (keys.indexOf(prop) === -1) {
      return null;
    }
    const cssProperties = getCssProperties(prop);
    const styleFromPropValue = getStyleFromPropValue(cssProperties, transformer);
    const propValue = props[prop];
    return handleBreakpoints(props, propValue, styleFromPropValue);
  }
  function style$1(props, keys) {
    const transformer = createUnarySpacing(props.theme);
    return Object.keys(props).map((prop) => resolveCssProperty(props, keys, prop, transformer)).reduce(merge, {});
  }
  function spacing(props) {
    return style$1(props, spacingKeys);
  }
  spacing.propTypes = {};
  spacing.filterProps = spacingKeys;
  function getBorder(value) {
    if (typeof value !== "number") {
      return value;
    }
    return `${value}px solid`;
  }
  const border = style$2({
    prop: "border",
    themeKey: "borders",
    transform: getBorder
  });
  const borderTop = style$2({
    prop: "borderTop",
    themeKey: "borders",
    transform: getBorder
  });
  const borderRight = style$2({
    prop: "borderRight",
    themeKey: "borders",
    transform: getBorder
  });
  const borderBottom = style$2({
    prop: "borderBottom",
    themeKey: "borders",
    transform: getBorder
  });
  const borderLeft = style$2({
    prop: "borderLeft",
    themeKey: "borders",
    transform: getBorder
  });
  const borderColor = style$2({
    prop: "borderColor",
    themeKey: "palette"
  });
  const borderTopColor = style$2({
    prop: "borderTopColor",
    themeKey: "palette"
  });
  const borderRightColor = style$2({
    prop: "borderRightColor",
    themeKey: "palette"
  });
  const borderBottomColor = style$2({
    prop: "borderBottomColor",
    themeKey: "palette"
  });
  const borderLeftColor = style$2({
    prop: "borderLeftColor",
    themeKey: "palette"
  });
  const borderRadius = (props) => {
    if (props.borderRadius !== void 0 && props.borderRadius !== null) {
      const transformer = createUnaryUnit(props.theme, "shape.borderRadius", 4);
      const styleFromPropValue = (propValue) => ({
        borderRadius: getValue(transformer, propValue)
      });
      return handleBreakpoints(props, props.borderRadius, styleFromPropValue);
    }
    return null;
  };
  borderRadius.propTypes = {};
  borderRadius.filterProps = ["borderRadius"];
  const borders = compose(border, borderTop, borderRight, borderBottom, borderLeft, borderColor, borderTopColor, borderRightColor, borderBottomColor, borderLeftColor, borderRadius);
  const borders$1 = borders;
  const displayPrint = style$2({
    prop: "displayPrint",
    cssProperty: false,
    transform: (value) => ({
      "@media print": {
        display: value
      }
    })
  });
  const displayRaw = style$2({
    prop: "display"
  });
  const overflow = style$2({
    prop: "overflow"
  });
  const textOverflow = style$2({
    prop: "textOverflow"
  });
  const visibility = style$2({
    prop: "visibility"
  });
  const whiteSpace = style$2({
    prop: "whiteSpace"
  });
  const display = compose(displayPrint, displayRaw, overflow, textOverflow, visibility, whiteSpace);
  const flexBasis = style$2({
    prop: "flexBasis"
  });
  const flexDirection = style$2({
    prop: "flexDirection"
  });
  const flexWrap = style$2({
    prop: "flexWrap"
  });
  const justifyContent = style$2({
    prop: "justifyContent"
  });
  const alignItems = style$2({
    prop: "alignItems"
  });
  const alignContent = style$2({
    prop: "alignContent"
  });
  const order$1 = style$2({
    prop: "order"
  });
  const flex = style$2({
    prop: "flex"
  });
  const flexGrow = style$2({
    prop: "flexGrow"
  });
  const flexShrink = style$2({
    prop: "flexShrink"
  });
  const alignSelf = style$2({
    prop: "alignSelf"
  });
  const justifyItems = style$2({
    prop: "justifyItems"
  });
  const justifySelf = style$2({
    prop: "justifySelf"
  });
  const flexbox = compose(flexBasis, flexDirection, flexWrap, justifyContent, alignItems, alignContent, order$1, flex, flexGrow, flexShrink, alignSelf, justifyItems, justifySelf);
  const flexbox$1 = flexbox;
  const gap = (props) => {
    if (props.gap !== void 0 && props.gap !== null) {
      const transformer = createUnaryUnit(props.theme, "spacing", 8);
      const styleFromPropValue = (propValue) => ({
        gap: getValue(transformer, propValue)
      });
      return handleBreakpoints(props, props.gap, styleFromPropValue);
    }
    return null;
  };
  gap.propTypes = {};
  gap.filterProps = ["gap"];
  const columnGap = (props) => {
    if (props.columnGap !== void 0 && props.columnGap !== null) {
      const transformer = createUnaryUnit(props.theme, "spacing", 8);
      const styleFromPropValue = (propValue) => ({
        columnGap: getValue(transformer, propValue)
      });
      return handleBreakpoints(props, props.columnGap, styleFromPropValue);
    }
    return null;
  };
  columnGap.propTypes = {};
  columnGap.filterProps = ["columnGap"];
  const rowGap = (props) => {
    if (props.rowGap !== void 0 && props.rowGap !== null) {
      const transformer = createUnaryUnit(props.theme, "spacing", 8);
      const styleFromPropValue = (propValue) => ({
        rowGap: getValue(transformer, propValue)
      });
      return handleBreakpoints(props, props.rowGap, styleFromPropValue);
    }
    return null;
  };
  rowGap.propTypes = {};
  rowGap.filterProps = ["rowGap"];
  const gridColumn = style$2({
    prop: "gridColumn"
  });
  const gridRow = style$2({
    prop: "gridRow"
  });
  const gridAutoFlow = style$2({
    prop: "gridAutoFlow"
  });
  const gridAutoColumns = style$2({
    prop: "gridAutoColumns"
  });
  const gridAutoRows = style$2({
    prop: "gridAutoRows"
  });
  const gridTemplateColumns = style$2({
    prop: "gridTemplateColumns"
  });
  const gridTemplateRows = style$2({
    prop: "gridTemplateRows"
  });
  const gridTemplateAreas = style$2({
    prop: "gridTemplateAreas"
  });
  const gridArea = style$2({
    prop: "gridArea"
  });
  const grid = compose(gap, columnGap, rowGap, gridColumn, gridRow, gridAutoFlow, gridAutoColumns, gridAutoRows, gridTemplateColumns, gridTemplateRows, gridTemplateAreas, gridArea);
  const grid$1 = grid;
  const color = style$2({
    prop: "color",
    themeKey: "palette"
  });
  const bgcolor = style$2({
    prop: "bgcolor",
    cssProperty: "backgroundColor",
    themeKey: "palette"
  });
  const backgroundColor = style$2({
    prop: "backgroundColor",
    themeKey: "palette"
  });
  const palette = compose(color, bgcolor, backgroundColor);
  const palette$1 = palette;
  const position = style$2({
    prop: "position"
  });
  const zIndex$2 = style$2({
    prop: "zIndex",
    themeKey: "zIndex"
  });
  const top$1 = style$2({
    prop: "top"
  });
  const right$1 = style$2({
    prop: "right"
  });
  const bottom$1 = style$2({
    prop: "bottom"
  });
  const left$1 = style$2({
    prop: "left"
  });
  const positions = compose(position, zIndex$2, top$1, right$1, bottom$1, left$1);
  const boxShadow = style$2({
    prop: "boxShadow",
    themeKey: "shadows"
  });
  const shadows$2 = boxShadow;
  function transform(value) {
    return value <= 1 && value !== 0 ? `${value * 100}%` : value;
  }
  const width = style$2({
    prop: "width",
    transform
  });
  const maxWidth = (props) => {
    if (props.maxWidth !== void 0 && props.maxWidth !== null) {
      const styleFromPropValue = (propValue) => {
        var _props$theme, _props$theme$breakpoi, _props$theme$breakpoi2;
        const breakpoint = ((_props$theme = props.theme) == null ? void 0 : (_props$theme$breakpoi = _props$theme.breakpoints) == null ? void 0 : (_props$theme$breakpoi2 = _props$theme$breakpoi.values) == null ? void 0 : _props$theme$breakpoi2[propValue]) || values$1[propValue];
        return {
          maxWidth: breakpoint || transform(propValue)
        };
      };
      return handleBreakpoints(props, props.maxWidth, styleFromPropValue);
    }
    return null;
  };
  maxWidth.filterProps = ["maxWidth"];
  const minWidth = style$2({
    prop: "minWidth",
    transform
  });
  const height = style$2({
    prop: "height",
    transform
  });
  const maxHeight = style$2({
    prop: "maxHeight",
    transform
  });
  const minHeight = style$2({
    prop: "minHeight",
    transform
  });
  style$2({
    prop: "size",
    cssProperty: "width",
    transform
  });
  style$2({
    prop: "size",
    cssProperty: "height",
    transform
  });
  const boxSizing = style$2({
    prop: "boxSizing"
  });
  const sizing = compose(width, maxWidth, minWidth, height, maxHeight, minHeight, boxSizing);
  const sizing$1 = sizing;
  const fontFamily = style$2({
    prop: "fontFamily",
    themeKey: "typography"
  });
  const fontSize = style$2({
    prop: "fontSize",
    themeKey: "typography"
  });
  const fontStyle = style$2({
    prop: "fontStyle",
    themeKey: "typography"
  });
  const fontWeight = style$2({
    prop: "fontWeight",
    themeKey: "typography"
  });
  const letterSpacing = style$2({
    prop: "letterSpacing"
  });
  const textTransform = style$2({
    prop: "textTransform"
  });
  const lineHeight = style$2({
    prop: "lineHeight"
  });
  const textAlign = style$2({
    prop: "textAlign"
  });
  const typographyVariant = style$2({
    prop: "typography",
    cssProperty: false,
    themeKey: "typography"
  });
  const typography = compose(typographyVariant, fontFamily, fontSize, fontStyle, fontWeight, letterSpacing, lineHeight, textAlign, textTransform);
  const typography$1 = typography;
  const filterPropsMapping = {
    borders: borders$1.filterProps,
    display: display.filterProps,
    flexbox: flexbox$1.filterProps,
    grid: grid$1.filterProps,
    positions: positions.filterProps,
    palette: palette$1.filterProps,
    shadows: shadows$2.filterProps,
    sizing: sizing$1.filterProps,
    spacing: spacing.filterProps,
    typography: typography$1.filterProps
  };
  const styleFunctionMapping = {
    borders: borders$1,
    display,
    flexbox: flexbox$1,
    grid: grid$1,
    positions,
    palette: palette$1,
    shadows: shadows$2,
    sizing: sizing$1,
    spacing,
    typography: typography$1
  };
  const propToStyleFunction = Object.keys(filterPropsMapping).reduce((acc, styleFnName) => {
    filterPropsMapping[styleFnName].forEach((propName) => {
      acc[propName] = styleFunctionMapping[styleFnName];
    });
    return acc;
  }, {});
  function objectsHaveSameKeys(...objects) {
    const allKeys = objects.reduce((keys, object) => keys.concat(Object.keys(object)), []);
    const union = new Set(allKeys);
    return objects.every((object) => union.size === Object.keys(object).length);
  }
  function callIfFn(maybeFn, arg) {
    return typeof maybeFn === "function" ? maybeFn(arg) : maybeFn;
  }
  function unstable_createStyleFunctionSx(styleFunctionMapping$1 = styleFunctionMapping) {
    const propToStyleFunction2 = Object.keys(styleFunctionMapping$1).reduce((acc, styleFnName) => {
      styleFunctionMapping$1[styleFnName].filterProps.forEach((propName) => {
        acc[propName] = styleFunctionMapping$1[styleFnName];
      });
      return acc;
    }, {});
    function getThemeValue(prop, value, theme) {
      const inputProps = {
        [prop]: value,
        theme
      };
      const styleFunction = propToStyleFunction2[prop];
      return styleFunction ? styleFunction(inputProps) : {
        [prop]: value
      };
    }
    function styleFunctionSx2(props) {
      const {
        sx,
        theme = {}
      } = props || {};
      if (!sx) {
        return null;
      }
      function traverse(sxInput) {
        let sxObject = sxInput;
        if (typeof sxInput === "function") {
          sxObject = sxInput(theme);
        } else if (typeof sxInput !== "object") {
          return sxInput;
        }
        if (!sxObject) {
          return null;
        }
        const emptyBreakpoints = createEmptyBreakpointObject(theme.breakpoints);
        const breakpointsKeys = Object.keys(emptyBreakpoints);
        let css2 = emptyBreakpoints;
        Object.keys(sxObject).forEach((styleKey) => {
          const value = callIfFn(sxObject[styleKey], theme);
          if (value !== null && value !== void 0) {
            if (typeof value === "object") {
              if (propToStyleFunction2[styleKey]) {
                css2 = merge(css2, getThemeValue(styleKey, value, theme));
              } else {
                const breakpointsValues = handleBreakpoints({
                  theme
                }, value, (x2) => ({
                  [styleKey]: x2
                }));
                if (objectsHaveSameKeys(breakpointsValues, value)) {
                  css2[styleKey] = styleFunctionSx2({
                    sx: value,
                    theme
                  });
                } else {
                  css2 = merge(css2, breakpointsValues);
                }
              }
            } else {
              css2 = merge(css2, getThemeValue(styleKey, value, theme));
            }
          }
        });
        return removeUnusedBreakpoints(breakpointsKeys, css2);
      }
      return Array.isArray(sx) ? sx.map(traverse) : traverse(sx);
    }
    return styleFunctionSx2;
  }
  const styleFunctionSx = unstable_createStyleFunctionSx();
  styleFunctionSx.filterProps = ["sx"];
  const defaultStyleFunctionSx = styleFunctionSx;
  const _excluded$O = ["sx"];
  const splitProps = (props) => {
    const result = {
      systemProps: {},
      otherProps: {}
    };
    Object.keys(props).forEach((prop) => {
      if (propToStyleFunction[prop]) {
        result.systemProps[prop] = props[prop];
      } else {
        result.otherProps[prop] = props[prop];
      }
    });
    return result;
  };
  function extendSxProp(props) {
    const {
      sx: inSx
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$O);
    const {
      systemProps,
      otherProps
    } = splitProps(other);
    let finalSx;
    if (Array.isArray(inSx)) {
      finalSx = [systemProps, ...inSx];
    } else if (typeof inSx === "function") {
      finalSx = (...args) => {
        const result = inSx(...args);
        if (!isPlainObject(result)) {
          return systemProps;
        }
        return _extends({}, systemProps, result);
      };
    } else {
      finalSx = _extends({}, systemProps, inSx);
    }
    return _extends({}, otherProps, {
      sx: finalSx
    });
  }
  function r(e2) {
    var t2, f2, n2 = "";
    if ("string" == typeof e2 || "number" == typeof e2)
      n2 += e2;
    else if ("object" == typeof e2)
      if (Array.isArray(e2))
        for (t2 = 0; t2 < e2.length; t2++)
          e2[t2] && (f2 = r(e2[t2])) && (n2 && (n2 += " "), n2 += f2);
      else
        for (t2 in e2)
          e2[t2] && (n2 && (n2 += " "), n2 += t2);
    return n2;
  }
  function clsx() {
    for (var e2, t2, f2 = 0, n2 = ""; f2 < arguments.length; )
      (e2 = arguments[f2++]) && (t2 = r(e2)) && (n2 && (n2 += " "), n2 += t2);
    return n2;
  }
  const clsx_m = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    clsx,
    default: clsx
  }, Symbol.toStringTag, { value: "Module" }));
  const _excluded$N = ["values", "unit", "step"];
  const sortBreakpointsValues = (values2) => {
    const breakpointsAsArray = Object.keys(values2).map((key) => ({
      key,
      val: values2[key]
    })) || [];
    breakpointsAsArray.sort((breakpoint1, breakpoint2) => breakpoint1.val - breakpoint2.val);
    return breakpointsAsArray.reduce((acc, obj) => {
      return _extends({}, acc, {
        [obj.key]: obj.val
      });
    }, {});
  };
  function createBreakpoints(breakpoints) {
    const {
      values: values2 = {
        xs: 0,
        sm: 600,
        md: 900,
        lg: 1200,
        xl: 1536
      },
      unit = "px",
      step = 5
    } = breakpoints, other = _objectWithoutPropertiesLoose(breakpoints, _excluded$N);
    const sortedValues = sortBreakpointsValues(values2);
    const keys = Object.keys(sortedValues);
    function up(key) {
      const value = typeof values2[key] === "number" ? values2[key] : key;
      return `@media (min-width:${value}${unit})`;
    }
    function down(key) {
      const value = typeof values2[key] === "number" ? values2[key] : key;
      return `@media (max-width:${value - step / 100}${unit})`;
    }
    function between(start2, end2) {
      const endIndex = keys.indexOf(end2);
      return `@media (min-width:${typeof values2[start2] === "number" ? values2[start2] : start2}${unit}) and (max-width:${(endIndex !== -1 && typeof values2[keys[endIndex]] === "number" ? values2[keys[endIndex]] : end2) - step / 100}${unit})`;
    }
    function only(key) {
      if (keys.indexOf(key) + 1 < keys.length) {
        return between(key, keys[keys.indexOf(key) + 1]);
      }
      return up(key);
    }
    function not(key) {
      const keyIndex = keys.indexOf(key);
      if (keyIndex === 0) {
        return up(keys[1]);
      }
      if (keyIndex === keys.length - 1) {
        return down(keys[keyIndex]);
      }
      return between(key, keys[keys.indexOf(key) + 1]).replace("@media", "@media not all and");
    }
    return _extends({
      keys,
      values: sortedValues,
      up,
      down,
      between,
      only,
      not,
      unit
    }, other);
  }
  const shape = {
    borderRadius: 4
  };
  const shape$1 = shape;
  function createSpacing(spacingInput = 8) {
    if (spacingInput.mui) {
      return spacingInput;
    }
    const transform2 = createUnarySpacing({
      spacing: spacingInput
    });
    const spacing2 = (...argsInput) => {
      const args = argsInput.length === 0 ? [1] : argsInput;
      return args.map((argument) => {
        const output = transform2(argument);
        return typeof output === "number" ? `${output}px` : output;
      }).join(" ");
    };
    spacing2.mui = true;
    return spacing2;
  }
  const _excluded$M = ["breakpoints", "palette", "spacing", "shape"];
  function createTheme$1(options = {}, ...args) {
    const {
      breakpoints: breakpointsInput = {},
      palette: paletteInput = {},
      spacing: spacingInput,
      shape: shapeInput = {}
    } = options, other = _objectWithoutPropertiesLoose(options, _excluded$M);
    const breakpoints = createBreakpoints(breakpointsInput);
    const spacing2 = createSpacing(spacingInput);
    let muiTheme = deepmerge({
      breakpoints,
      direction: "ltr",
      components: {},
      palette: _extends({
        mode: "light"
      }, paletteInput),
      spacing: spacing2,
      shape: _extends({}, shape$1, shapeInput)
    }, other);
    muiTheme = args.reduce((acc, argument) => deepmerge(acc, argument), muiTheme);
    return muiTheme;
  }
  const ThemeContext = /* @__PURE__ */ react.exports.createContext(null);
  const ThemeContext$1 = ThemeContext;
  function useTheme$3() {
    const theme = react.exports.useContext(ThemeContext$1);
    return theme;
  }
  function isObjectEmpty(obj) {
    return Object.keys(obj).length === 0;
  }
  function useTheme$2(defaultTheme2 = null) {
    const contextTheme = useTheme$3();
    return !contextTheme || isObjectEmpty(contextTheme) ? defaultTheme2 : contextTheme;
  }
  const systemDefaultTheme$1 = createTheme$1();
  function useTheme$1(defaultTheme2 = systemDefaultTheme$1) {
    return useTheme$2(defaultTheme2);
  }
  const _excluded$L = ["className", "component"];
  function createBox(options = {}) {
    const {
      defaultTheme: defaultTheme2,
      defaultClassName = "MuiBox-root",
      generateClassName,
      styleFunctionSx: styleFunctionSx2 = defaultStyleFunctionSx
    } = options;
    const BoxRoot = styled$2("div", {
      shouldForwardProp: (prop) => prop !== "theme" && prop !== "sx" && prop !== "as"
    })(styleFunctionSx2);
    const Box2 = /* @__PURE__ */ react.exports.forwardRef(function Box3(inProps, ref) {
      const theme = useTheme$1(defaultTheme2);
      const _extendSxProp = extendSxProp(inProps), {
        className,
        component = "div"
      } = _extendSxProp, other = _objectWithoutPropertiesLoose(_extendSxProp, _excluded$L);
      return /* @__PURE__ */ jsx(BoxRoot, _extends({
        as: component,
        ref,
        className: clsx(className, generateClassName ? generateClassName(defaultClassName) : defaultClassName),
        theme
      }, other));
    });
    return Box2;
  }
  const _excluded$K = ["variant"];
  function isEmpty$3(string) {
    return string.length === 0;
  }
  function propsToClassKey(props) {
    const {
      variant
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$K);
    let classKey = variant || "";
    Object.keys(other).sort().forEach((key) => {
      if (key === "color") {
        classKey += isEmpty$3(classKey) ? props[key] : capitalize(props[key]);
      } else {
        classKey += `${isEmpty$3(classKey) ? key : capitalize(key)}${capitalize(props[key].toString())}`;
      }
    });
    return classKey;
  }
  const _excluded$J = ["name", "slot", "skipVariantsResolver", "skipSx", "overridesResolver"], _excluded2$3 = ["theme"], _excluded3 = ["theme"];
  function isEmpty$2(obj) {
    return Object.keys(obj).length === 0;
  }
  function isStringTag(tag) {
    return typeof tag === "string" && tag.charCodeAt(0) > 96;
  }
  const getStyleOverrides = (name, theme) => {
    if (theme.components && theme.components[name] && theme.components[name].styleOverrides) {
      return theme.components[name].styleOverrides;
    }
    return null;
  };
  const getVariantStyles = (name, theme) => {
    let variants = [];
    if (theme && theme.components && theme.components[name] && theme.components[name].variants) {
      variants = theme.components[name].variants;
    }
    const variantsStyles = {};
    variants.forEach((definition) => {
      const key = propsToClassKey(definition.props);
      variantsStyles[key] = definition.style;
    });
    return variantsStyles;
  };
  const variantsResolver = (props, styles2, theme, name) => {
    var _theme$components, _theme$components$nam;
    const {
      ownerState = {}
    } = props;
    const variantsStyles = [];
    const themeVariants = theme == null ? void 0 : (_theme$components = theme.components) == null ? void 0 : (_theme$components$nam = _theme$components[name]) == null ? void 0 : _theme$components$nam.variants;
    if (themeVariants) {
      themeVariants.forEach((themeVariant) => {
        let isMatch = true;
        Object.keys(themeVariant.props).forEach((key) => {
          if (ownerState[key] !== themeVariant.props[key] && props[key] !== themeVariant.props[key]) {
            isMatch = false;
          }
        });
        if (isMatch) {
          variantsStyles.push(styles2[propsToClassKey(themeVariant.props)]);
        }
      });
    }
    return variantsStyles;
  };
  function shouldForwardProp(prop) {
    return prop !== "ownerState" && prop !== "theme" && prop !== "sx" && prop !== "as";
  }
  const systemDefaultTheme = createTheme$1();
  function createStyled(input = {}) {
    const {
      defaultTheme: defaultTheme2 = systemDefaultTheme,
      rootShouldForwardProp: rootShouldForwardProp2 = shouldForwardProp,
      slotShouldForwardProp: slotShouldForwardProp2 = shouldForwardProp,
      styleFunctionSx: styleFunctionSx2 = defaultStyleFunctionSx
    } = input;
    const systemSx = (props) => {
      const theme = isEmpty$2(props.theme) ? defaultTheme2 : props.theme;
      return styleFunctionSx2(_extends({}, props, {
        theme
      }));
    };
    systemSx.__mui_systemSx = true;
    return (tag, inputOptions = {}) => {
      internal_processStyles(tag, (styles2) => styles2.filter((style2) => !(style2 != null && style2.__mui_systemSx)));
      const {
        name: componentName,
        slot: componentSlot,
        skipVariantsResolver: inputSkipVariantsResolver,
        skipSx: inputSkipSx,
        overridesResolver: overridesResolver2
      } = inputOptions, options = _objectWithoutPropertiesLoose(inputOptions, _excluded$J);
      const skipVariantsResolver = inputSkipVariantsResolver !== void 0 ? inputSkipVariantsResolver : componentSlot && componentSlot !== "Root" || false;
      const skipSx = inputSkipSx || false;
      let label;
      let shouldForwardPropOption = shouldForwardProp;
      if (componentSlot === "Root") {
        shouldForwardPropOption = rootShouldForwardProp2;
      } else if (componentSlot) {
        shouldForwardPropOption = slotShouldForwardProp2;
      } else if (isStringTag(tag)) {
        shouldForwardPropOption = void 0;
      }
      const defaultStyledResolver = styled$2(tag, _extends({
        shouldForwardProp: shouldForwardPropOption,
        label
      }, options));
      const muiStyledResolver = (styleArg, ...expressions) => {
        const expressionsWithDefaultTheme = expressions ? expressions.map((stylesArg) => {
          return typeof stylesArg === "function" && stylesArg.__emotion_real !== stylesArg ? (_ref) => {
            let {
              theme: themeInput
            } = _ref, other = _objectWithoutPropertiesLoose(_ref, _excluded2$3);
            return stylesArg(_extends({
              theme: isEmpty$2(themeInput) ? defaultTheme2 : themeInput
            }, other));
          } : stylesArg;
        }) : [];
        let transformedStyleArg = styleArg;
        if (componentName && overridesResolver2) {
          expressionsWithDefaultTheme.push((props) => {
            const theme = isEmpty$2(props.theme) ? defaultTheme2 : props.theme;
            const styleOverrides = getStyleOverrides(componentName, theme);
            if (styleOverrides) {
              const resolvedStyleOverrides = {};
              Object.entries(styleOverrides).forEach(([slotKey, slotStyle]) => {
                resolvedStyleOverrides[slotKey] = typeof slotStyle === "function" ? slotStyle(_extends({}, props, {
                  theme
                })) : slotStyle;
              });
              return overridesResolver2(props, resolvedStyleOverrides);
            }
            return null;
          });
        }
        if (componentName && !skipVariantsResolver) {
          expressionsWithDefaultTheme.push((props) => {
            const theme = isEmpty$2(props.theme) ? defaultTheme2 : props.theme;
            return variantsResolver(props, getVariantStyles(componentName, theme), theme, componentName);
          });
        }
        if (!skipSx) {
          expressionsWithDefaultTheme.push(systemSx);
        }
        const numOfCustomFnsApplied = expressionsWithDefaultTheme.length - expressions.length;
        if (Array.isArray(styleArg) && numOfCustomFnsApplied > 0) {
          const placeholders = new Array(numOfCustomFnsApplied).fill("");
          transformedStyleArg = [...styleArg, ...placeholders];
          transformedStyleArg.raw = [...styleArg.raw, ...placeholders];
        } else if (typeof styleArg === "function" && styleArg.__emotion_real !== styleArg) {
          transformedStyleArg = (_ref2) => {
            let {
              theme: themeInput
            } = _ref2, other = _objectWithoutPropertiesLoose(_ref2, _excluded3);
            return styleArg(_extends({
              theme: isEmpty$2(themeInput) ? defaultTheme2 : themeInput
            }, other));
          };
        }
        const Component = defaultStyledResolver(transformedStyleArg, ...expressionsWithDefaultTheme);
        return Component;
      };
      if (defaultStyledResolver.withConfig) {
        muiStyledResolver.withConfig = defaultStyledResolver.withConfig;
      }
      return muiStyledResolver;
    };
  }
  function getThemeProps(params) {
    const {
      theme,
      name,
      props
    } = params;
    if (!theme || !theme.components || !theme.components[name] || !theme.components[name].defaultProps) {
      return props;
    }
    return resolveProps(theme.components[name].defaultProps, props);
  }
  function useThemeProps$1({
    props,
    name,
    defaultTheme: defaultTheme2
  }) {
    const theme = useTheme$1(defaultTheme2);
    const mergedProps = getThemeProps({
      theme,
      name,
      props
    });
    return mergedProps;
  }
  function clamp$1(value, min2 = 0, max2 = 1) {
    return Math.min(Math.max(min2, value), max2);
  }
  function hexToRgb(color2) {
    color2 = color2.slice(1);
    const re2 = new RegExp(`.{1,${color2.length >= 6 ? 2 : 1}}`, "g");
    let colors = color2.match(re2);
    if (colors && colors[0].length === 1) {
      colors = colors.map((n2) => n2 + n2);
    }
    return colors ? `rgb${colors.length === 4 ? "a" : ""}(${colors.map((n2, index) => {
      return index < 3 ? parseInt(n2, 16) : Math.round(parseInt(n2, 16) / 255 * 1e3) / 1e3;
    }).join(", ")})` : "";
  }
  function decomposeColor(color2) {
    if (color2.type) {
      return color2;
    }
    if (color2.charAt(0) === "#") {
      return decomposeColor(hexToRgb(color2));
    }
    const marker = color2.indexOf("(");
    const type = color2.substring(0, marker);
    if (["rgb", "rgba", "hsl", "hsla", "color"].indexOf(type) === -1) {
      throw new Error(formatMuiErrorMessage(9, color2));
    }
    let values2 = color2.substring(marker + 1, color2.length - 1);
    let colorSpace;
    if (type === "color") {
      values2 = values2.split(" ");
      colorSpace = values2.shift();
      if (values2.length === 4 && values2[3].charAt(0) === "/") {
        values2[3] = values2[3].slice(1);
      }
      if (["srgb", "display-p3", "a98-rgb", "prophoto-rgb", "rec-2020"].indexOf(colorSpace) === -1) {
        throw new Error(formatMuiErrorMessage(10, colorSpace));
      }
    } else {
      values2 = values2.split(",");
    }
    values2 = values2.map((value) => parseFloat(value));
    return {
      type,
      values: values2,
      colorSpace
    };
  }
  function recomposeColor(color2) {
    const {
      type,
      colorSpace
    } = color2;
    let {
      values: values2
    } = color2;
    if (type.indexOf("rgb") !== -1) {
      values2 = values2.map((n2, i) => i < 3 ? parseInt(n2, 10) : n2);
    } else if (type.indexOf("hsl") !== -1) {
      values2[1] = `${values2[1]}%`;
      values2[2] = `${values2[2]}%`;
    }
    if (type.indexOf("color") !== -1) {
      values2 = `${colorSpace} ${values2.join(" ")}`;
    } else {
      values2 = `${values2.join(", ")}`;
    }
    return `${type}(${values2})`;
  }
  function hslToRgb(color2) {
    color2 = decomposeColor(color2);
    const {
      values: values2
    } = color2;
    const h2 = values2[0];
    const s = values2[1] / 100;
    const l2 = values2[2] / 100;
    const a = s * Math.min(l2, 1 - l2);
    const f2 = (n2, k2 = (n2 + h2 / 30) % 12) => l2 - a * Math.max(Math.min(k2 - 3, 9 - k2, 1), -1);
    let type = "rgb";
    const rgb = [Math.round(f2(0) * 255), Math.round(f2(8) * 255), Math.round(f2(4) * 255)];
    if (color2.type === "hsla") {
      type += "a";
      rgb.push(values2[3]);
    }
    return recomposeColor({
      type,
      values: rgb
    });
  }
  function getLuminance(color2) {
    color2 = decomposeColor(color2);
    let rgb = color2.type === "hsl" || color2.type === "hsla" ? decomposeColor(hslToRgb(color2)).values : color2.values;
    rgb = rgb.map((val) => {
      if (color2.type !== "color") {
        val /= 255;
      }
      return val <= 0.03928 ? val / 12.92 : ((val + 0.055) / 1.055) ** 2.4;
    });
    return Number((0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]).toFixed(3));
  }
  function getContrastRatio(foreground, background) {
    const lumA = getLuminance(foreground);
    const lumB = getLuminance(background);
    return (Math.max(lumA, lumB) + 0.05) / (Math.min(lumA, lumB) + 0.05);
  }
  function alpha(color2, value) {
    color2 = decomposeColor(color2);
    value = clamp$1(value);
    if (color2.type === "rgb" || color2.type === "hsl") {
      color2.type += "a";
    }
    if (color2.type === "color") {
      color2.values[3] = `/${value}`;
    } else {
      color2.values[3] = value;
    }
    return recomposeColor(color2);
  }
  function darken(color2, coefficient) {
    color2 = decomposeColor(color2);
    coefficient = clamp$1(coefficient);
    if (color2.type.indexOf("hsl") !== -1) {
      color2.values[2] *= 1 - coefficient;
    } else if (color2.type.indexOf("rgb") !== -1 || color2.type.indexOf("color") !== -1) {
      for (let i = 0; i < 3; i += 1) {
        color2.values[i] *= 1 - coefficient;
      }
    }
    return recomposeColor(color2);
  }
  function lighten(color2, coefficient) {
    color2 = decomposeColor(color2);
    coefficient = clamp$1(coefficient);
    if (color2.type.indexOf("hsl") !== -1) {
      color2.values[2] += (100 - color2.values[2]) * coefficient;
    } else if (color2.type.indexOf("rgb") !== -1) {
      for (let i = 0; i < 3; i += 1) {
        color2.values[i] += (255 - color2.values[i]) * coefficient;
      }
    } else if (color2.type.indexOf("color") !== -1) {
      for (let i = 0; i < 3; i += 1) {
        color2.values[i] += (1 - color2.values[i]) * coefficient;
      }
    }
    return recomposeColor(color2);
  }
  function isHostComponent(element) {
    return typeof element === "string";
  }
  function appendOwnerState(elementType, otherProps = {}, ownerState) {
    if (isHostComponent(elementType)) {
      return otherProps;
    }
    return _extends({}, otherProps, {
      ownerState: _extends({}, otherProps.ownerState, ownerState)
    });
  }
  function extractEventHandlers(object, excludeKeys = []) {
    if (object === void 0) {
      return {};
    }
    const result = {};
    Object.keys(object).filter((prop) => prop.match(/^on[A-Z]/) && typeof object[prop] === "function" && !excludeKeys.includes(prop)).forEach((prop) => {
      result[prop] = object[prop];
    });
    return result;
  }
  function resolveComponentProps(componentProps, ownerState) {
    if (typeof componentProps === "function") {
      return componentProps(ownerState);
    }
    return componentProps;
  }
  function omitEventHandlers(object) {
    if (object === void 0) {
      return {};
    }
    const result = {};
    Object.keys(object).filter((prop) => !(prop.match(/^on[A-Z]/) && typeof object[prop] === "function")).forEach((prop) => {
      result[prop] = object[prop];
    });
    return result;
  }
  function mergeSlotProps(parameters) {
    const {
      getSlotProps,
      additionalProps,
      externalSlotProps,
      externalForwardedProps,
      className
    } = parameters;
    if (!getSlotProps) {
      const joinedClasses2 = clsx(externalForwardedProps == null ? void 0 : externalForwardedProps.className, externalSlotProps == null ? void 0 : externalSlotProps.className, className, additionalProps == null ? void 0 : additionalProps.className);
      const mergedStyle2 = _extends({}, additionalProps == null ? void 0 : additionalProps.style, externalForwardedProps == null ? void 0 : externalForwardedProps.style, externalSlotProps == null ? void 0 : externalSlotProps.style);
      const props2 = _extends({}, additionalProps, externalForwardedProps, externalSlotProps);
      if (joinedClasses2.length > 0) {
        props2.className = joinedClasses2;
      }
      if (Object.keys(mergedStyle2).length > 0) {
        props2.style = mergedStyle2;
      }
      return {
        props: props2,
        internalRef: void 0
      };
    }
    const eventHandlers = extractEventHandlers(_extends({}, externalForwardedProps, externalSlotProps));
    const componentsPropsWithoutEventHandlers = omitEventHandlers(externalSlotProps);
    const otherPropsWithoutEventHandlers = omitEventHandlers(externalForwardedProps);
    const internalSlotProps = getSlotProps(eventHandlers);
    const joinedClasses = clsx(internalSlotProps == null ? void 0 : internalSlotProps.className, additionalProps == null ? void 0 : additionalProps.className, className, externalForwardedProps == null ? void 0 : externalForwardedProps.className, externalSlotProps == null ? void 0 : externalSlotProps.className);
    const mergedStyle = _extends({}, internalSlotProps == null ? void 0 : internalSlotProps.style, additionalProps == null ? void 0 : additionalProps.style, externalForwardedProps == null ? void 0 : externalForwardedProps.style, externalSlotProps == null ? void 0 : externalSlotProps.style);
    const props = _extends({}, internalSlotProps, additionalProps, otherPropsWithoutEventHandlers, componentsPropsWithoutEventHandlers);
    if (joinedClasses.length > 0) {
      props.className = joinedClasses;
    }
    if (Object.keys(mergedStyle).length > 0) {
      props.style = mergedStyle;
    }
    return {
      props,
      internalRef: internalSlotProps.ref
    };
  }
  const _excluded$I = ["elementType", "externalSlotProps", "ownerState"];
  function useSlotProps(parameters) {
    var _parameters$additiona;
    const {
      elementType,
      externalSlotProps,
      ownerState
    } = parameters, rest = _objectWithoutPropertiesLoose(parameters, _excluded$I);
    const resolvedComponentsProps = resolveComponentProps(externalSlotProps, ownerState);
    const {
      props: mergedProps,
      internalRef
    } = mergeSlotProps(_extends({}, rest, {
      externalSlotProps: resolvedComponentsProps
    }));
    const ref = useForkRef(internalRef, useForkRef(resolvedComponentsProps == null ? void 0 : resolvedComponentsProps.ref, (_parameters$additiona = parameters.additionalProps) == null ? void 0 : _parameters$additiona.ref));
    const props = appendOwnerState(elementType, _extends({}, mergedProps, {
      ref
    }), ownerState);
    return props;
  }
  function stripDiacritics(string) {
    return typeof string.normalize !== "undefined" ? string.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : string;
  }
  function createFilterOptions(config2 = {}) {
    const {
      ignoreAccents = true,
      ignoreCase = true,
      limit,
      matchFrom = "any",
      stringify: stringify2,
      trim: trim2 = false
    } = config2;
    return (options, {
      inputValue,
      getOptionLabel
    }) => {
      let input = trim2 ? inputValue.trim() : inputValue;
      if (ignoreCase) {
        input = input.toLowerCase();
      }
      if (ignoreAccents) {
        input = stripDiacritics(input);
      }
      const filteredOptions = !input ? options : options.filter((option) => {
        let candidate = (stringify2 || getOptionLabel)(option);
        if (ignoreCase) {
          candidate = candidate.toLowerCase();
        }
        if (ignoreAccents) {
          candidate = stripDiacritics(candidate);
        }
        return matchFrom === "start" ? candidate.indexOf(input) === 0 : candidate.indexOf(input) > -1;
      });
      return typeof limit === "number" ? filteredOptions.slice(0, limit) : filteredOptions;
    };
  }
  function findIndex(array, comp) {
    for (let i = 0; i < array.length; i += 1) {
      if (comp(array[i])) {
        return i;
      }
    }
    return -1;
  }
  const defaultFilterOptions = createFilterOptions();
  const pageSize = 5;
  function useAutocomplete(props) {
    const {
      autoComplete = false,
      autoHighlight = false,
      autoSelect = false,
      blurOnSelect = false,
      clearOnBlur = !props.freeSolo,
      clearOnEscape = false,
      componentName = "useAutocomplete",
      defaultValue = props.multiple ? [] : null,
      disableClearable = false,
      disableCloseOnSelect = false,
      disabled: disabledProp,
      disabledItemsFocusable = false,
      disableListWrap = false,
      filterOptions = defaultFilterOptions,
      filterSelectedOptions = false,
      freeSolo = false,
      getOptionDisabled,
      getOptionLabel: getOptionLabelProp = (option) => {
        var _option$label;
        return (_option$label = option.label) != null ? _option$label : option;
      },
      groupBy,
      handleHomeEndKeys = !props.freeSolo,
      id: idProp,
      includeInputInList = false,
      inputValue: inputValueProp,
      isOptionEqualToValue = (option, value2) => option === value2,
      multiple = false,
      onChange,
      onClose,
      onHighlightChange,
      onInputChange,
      onOpen,
      open: openProp,
      openOnFocus = false,
      options,
      readOnly = false,
      selectOnFocus = !props.freeSolo,
      value: valueProp
    } = props;
    const id2 = useId(idProp);
    let getOptionLabel = getOptionLabelProp;
    getOptionLabel = (option) => {
      const optionLabel = getOptionLabelProp(option);
      if (typeof optionLabel !== "string") {
        return String(optionLabel);
      }
      return optionLabel;
    };
    const ignoreFocus = react.exports.useRef(false);
    const firstFocus = react.exports.useRef(true);
    const inputRef = react.exports.useRef(null);
    const listboxRef = react.exports.useRef(null);
    const [anchorEl, setAnchorEl] = react.exports.useState(null);
    const [focusedTag, setFocusedTag] = react.exports.useState(-1);
    const defaultHighlighted = autoHighlight ? 0 : -1;
    const highlightedIndexRef = react.exports.useRef(defaultHighlighted);
    const [value, setValueState] = useControlled({
      controlled: valueProp,
      default: defaultValue,
      name: componentName
    });
    const [inputValue, setInputValueState] = useControlled({
      controlled: inputValueProp,
      default: "",
      name: componentName,
      state: "inputValue"
    });
    const [focused, setFocused] = react.exports.useState(false);
    const resetInputValue = react.exports.useCallback((event, newValue) => {
      const isOptionSelected = multiple ? value.length < newValue.length : newValue !== null;
      if (!isOptionSelected && !clearOnBlur) {
        return;
      }
      let newInputValue;
      if (multiple) {
        newInputValue = "";
      } else if (newValue == null) {
        newInputValue = "";
      } else {
        const optionLabel = getOptionLabel(newValue);
        newInputValue = typeof optionLabel === "string" ? optionLabel : "";
      }
      if (inputValue === newInputValue) {
        return;
      }
      setInputValueState(newInputValue);
      if (onInputChange) {
        onInputChange(event, newInputValue, "reset");
      }
    }, [getOptionLabel, inputValue, multiple, onInputChange, setInputValueState, clearOnBlur, value]);
    const prevValue = react.exports.useRef();
    react.exports.useEffect(() => {
      const valueChange = value !== prevValue.current;
      prevValue.current = value;
      if (focused && !valueChange) {
        return;
      }
      if (freeSolo && !valueChange) {
        return;
      }
      resetInputValue(null, value);
    }, [value, resetInputValue, focused, prevValue, freeSolo]);
    const [open, setOpenState] = useControlled({
      controlled: openProp,
      default: false,
      name: componentName,
      state: "open"
    });
    const [inputPristine, setInputPristine] = react.exports.useState(true);
    const inputValueIsSelectedValue = !multiple && value != null && inputValue === getOptionLabel(value);
    const popupOpen = open && !readOnly;
    const filteredOptions = popupOpen ? filterOptions(
      options.filter((option) => {
        if (filterSelectedOptions && (multiple ? value : [value]).some((value2) => value2 !== null && isOptionEqualToValue(option, value2))) {
          return false;
        }
        return true;
      }),
      {
        inputValue: inputValueIsSelectedValue && inputPristine ? "" : inputValue,
        getOptionLabel
      }
    ) : [];
    const listboxAvailable = open && filteredOptions.length > 0 && !readOnly;
    const focusTag = useEventCallback((tagToFocus) => {
      if (tagToFocus === -1) {
        inputRef.current.focus();
      } else {
        anchorEl.querySelector(`[data-tag-index="${tagToFocus}"]`).focus();
      }
    });
    react.exports.useEffect(() => {
      if (multiple && focusedTag > value.length - 1) {
        setFocusedTag(-1);
        focusTag(-1);
      }
    }, [value, multiple, focusedTag, focusTag]);
    function validOptionIndex(index, direction) {
      if (!listboxRef.current || index === -1) {
        return -1;
      }
      let nextFocus = index;
      while (true) {
        if (direction === "next" && nextFocus === filteredOptions.length || direction === "previous" && nextFocus === -1) {
          return -1;
        }
        const option = listboxRef.current.querySelector(`[data-option-index="${nextFocus}"]`);
        const nextFocusDisabled = disabledItemsFocusable ? false : !option || option.disabled || option.getAttribute("aria-disabled") === "true";
        if (option && !option.hasAttribute("tabindex") || nextFocusDisabled) {
          nextFocus += direction === "next" ? 1 : -1;
        } else {
          return nextFocus;
        }
      }
    }
    const setHighlightedIndex = useEventCallback(({
      event,
      index,
      reason = "auto"
    }) => {
      highlightedIndexRef.current = index;
      if (index === -1) {
        inputRef.current.removeAttribute("aria-activedescendant");
      } else {
        inputRef.current.setAttribute("aria-activedescendant", `${id2}-option-${index}`);
      }
      if (onHighlightChange) {
        onHighlightChange(event, index === -1 ? null : filteredOptions[index], reason);
      }
      if (!listboxRef.current) {
        return;
      }
      const prev2 = listboxRef.current.querySelector('[role="option"].Mui-focused');
      if (prev2) {
        prev2.classList.remove("Mui-focused");
        prev2.classList.remove("Mui-focusVisible");
      }
      const listboxNode = listboxRef.current.parentElement.querySelector('[role="listbox"]');
      if (!listboxNode) {
        return;
      }
      if (index === -1) {
        listboxNode.scrollTop = 0;
        return;
      }
      const option = listboxRef.current.querySelector(`[data-option-index="${index}"]`);
      if (!option) {
        return;
      }
      option.classList.add("Mui-focused");
      if (reason === "keyboard") {
        option.classList.add("Mui-focusVisible");
      }
      if (listboxNode.scrollHeight > listboxNode.clientHeight && reason !== "mouse") {
        const element = option;
        const scrollBottom = listboxNode.clientHeight + listboxNode.scrollTop;
        const elementBottom = element.offsetTop + element.offsetHeight;
        if (elementBottom > scrollBottom) {
          listboxNode.scrollTop = elementBottom - listboxNode.clientHeight;
        } else if (element.offsetTop - element.offsetHeight * (groupBy ? 1.3 : 0) < listboxNode.scrollTop) {
          listboxNode.scrollTop = element.offsetTop - element.offsetHeight * (groupBy ? 1.3 : 0);
        }
      }
    });
    const changeHighlightedIndex = useEventCallback(({
      event,
      diff,
      direction = "next",
      reason = "auto"
    }) => {
      if (!popupOpen) {
        return;
      }
      const getNextIndex = () => {
        const maxIndex = filteredOptions.length - 1;
        if (diff === "reset") {
          return defaultHighlighted;
        }
        if (diff === "start") {
          return 0;
        }
        if (diff === "end") {
          return maxIndex;
        }
        const newIndex = highlightedIndexRef.current + diff;
        if (newIndex < 0) {
          if (newIndex === -1 && includeInputInList) {
            return -1;
          }
          if (disableListWrap && highlightedIndexRef.current !== -1 || Math.abs(diff) > 1) {
            return 0;
          }
          return maxIndex;
        }
        if (newIndex > maxIndex) {
          if (newIndex === maxIndex + 1 && includeInputInList) {
            return -1;
          }
          if (disableListWrap || Math.abs(diff) > 1) {
            return maxIndex;
          }
          return 0;
        }
        return newIndex;
      };
      const nextIndex = validOptionIndex(getNextIndex(), direction);
      setHighlightedIndex({
        index: nextIndex,
        reason,
        event
      });
      if (autoComplete && diff !== "reset") {
        if (nextIndex === -1) {
          inputRef.current.value = inputValue;
        } else {
          const option = getOptionLabel(filteredOptions[nextIndex]);
          inputRef.current.value = option;
          const index = option.toLowerCase().indexOf(inputValue.toLowerCase());
          if (index === 0 && inputValue.length > 0) {
            inputRef.current.setSelectionRange(inputValue.length, option.length);
          }
        }
      }
    });
    const syncHighlightedIndex = react.exports.useCallback(() => {
      if (!popupOpen) {
        return;
      }
      const valueItem = multiple ? value[0] : value;
      if (filteredOptions.length === 0 || valueItem == null) {
        changeHighlightedIndex({
          diff: "reset"
        });
        return;
      }
      if (!listboxRef.current) {
        return;
      }
      if (valueItem != null) {
        const currentOption = filteredOptions[highlightedIndexRef.current];
        if (multiple && currentOption && findIndex(value, (val) => isOptionEqualToValue(currentOption, val)) !== -1) {
          return;
        }
        const itemIndex = findIndex(filteredOptions, (optionItem) => isOptionEqualToValue(optionItem, valueItem));
        if (itemIndex === -1) {
          changeHighlightedIndex({
            diff: "reset"
          });
        } else {
          setHighlightedIndex({
            index: itemIndex
          });
        }
        return;
      }
      if (highlightedIndexRef.current >= filteredOptions.length - 1) {
        setHighlightedIndex({
          index: filteredOptions.length - 1
        });
        return;
      }
      setHighlightedIndex({
        index: highlightedIndexRef.current
      });
    }, [
      filteredOptions.length,
      multiple ? false : value,
      filterSelectedOptions,
      changeHighlightedIndex,
      setHighlightedIndex,
      popupOpen,
      inputValue,
      multiple
    ]);
    const handleListboxRef = useEventCallback((node2) => {
      setRef(listboxRef, node2);
      if (!node2) {
        return;
      }
      syncHighlightedIndex();
    });
    react.exports.useEffect(() => {
      syncHighlightedIndex();
    }, [syncHighlightedIndex]);
    const handleOpen = (event) => {
      if (open) {
        return;
      }
      setOpenState(true);
      setInputPristine(true);
      if (onOpen) {
        onOpen(event);
      }
    };
    const handleClose = (event, reason) => {
      if (!open) {
        return;
      }
      setOpenState(false);
      if (onClose) {
        onClose(event, reason);
      }
    };
    const handleValue = (event, newValue, reason, details) => {
      if (multiple) {
        if (value.length === newValue.length && value.every((val, i) => val === newValue[i])) {
          return;
        }
      } else if (value === newValue) {
        return;
      }
      if (onChange) {
        onChange(event, newValue, reason, details);
      }
      setValueState(newValue);
    };
    const isTouch = react.exports.useRef(false);
    const selectNewValue = (event, option, reasonProp = "selectOption", origin = "options") => {
      let reason = reasonProp;
      let newValue = option;
      if (multiple) {
        newValue = Array.isArray(value) ? value.slice() : [];
        const itemIndex = findIndex(newValue, (valueItem) => isOptionEqualToValue(option, valueItem));
        if (itemIndex === -1) {
          newValue.push(option);
        } else if (origin !== "freeSolo") {
          newValue.splice(itemIndex, 1);
          reason = "removeOption";
        }
      }
      resetInputValue(event, newValue);
      handleValue(event, newValue, reason, {
        option
      });
      if (!disableCloseOnSelect && (!event || !event.ctrlKey && !event.metaKey)) {
        handleClose(event, reason);
      }
      if (blurOnSelect === true || blurOnSelect === "touch" && isTouch.current || blurOnSelect === "mouse" && !isTouch.current) {
        inputRef.current.blur();
      }
    };
    function validTagIndex(index, direction) {
      if (index === -1) {
        return -1;
      }
      let nextFocus = index;
      while (true) {
        if (direction === "next" && nextFocus === value.length || direction === "previous" && nextFocus === -1) {
          return -1;
        }
        const option = anchorEl.querySelector(`[data-tag-index="${nextFocus}"]`);
        if (!option || !option.hasAttribute("tabindex") || option.disabled || option.getAttribute("aria-disabled") === "true") {
          nextFocus += direction === "next" ? 1 : -1;
        } else {
          return nextFocus;
        }
      }
    }
    const handleFocusTag = (event, direction) => {
      if (!multiple) {
        return;
      }
      if (inputValue === "") {
        handleClose(event, "toggleInput");
      }
      let nextTag = focusedTag;
      if (focusedTag === -1) {
        if (inputValue === "" && direction === "previous") {
          nextTag = value.length - 1;
        }
      } else {
        nextTag += direction === "next" ? 1 : -1;
        if (nextTag < 0) {
          nextTag = 0;
        }
        if (nextTag === value.length) {
          nextTag = -1;
        }
      }
      nextTag = validTagIndex(nextTag, direction);
      setFocusedTag(nextTag);
      focusTag(nextTag);
    };
    const handleClear = (event) => {
      ignoreFocus.current = true;
      setInputValueState("");
      if (onInputChange) {
        onInputChange(event, "", "clear");
      }
      handleValue(event, multiple ? [] : null, "clear");
    };
    const handleKeyDown2 = (other) => (event) => {
      if (other.onKeyDown) {
        other.onKeyDown(event);
      }
      if (event.defaultMuiPrevented) {
        return;
      }
      if (focusedTag !== -1 && ["ArrowLeft", "ArrowRight"].indexOf(event.key) === -1) {
        setFocusedTag(-1);
        focusTag(-1);
      }
      if (event.which !== 229) {
        switch (event.key) {
          case "Home":
            if (popupOpen && handleHomeEndKeys) {
              event.preventDefault();
              changeHighlightedIndex({
                diff: "start",
                direction: "next",
                reason: "keyboard",
                event
              });
            }
            break;
          case "End":
            if (popupOpen && handleHomeEndKeys) {
              event.preventDefault();
              changeHighlightedIndex({
                diff: "end",
                direction: "previous",
                reason: "keyboard",
                event
              });
            }
            break;
          case "PageUp":
            event.preventDefault();
            changeHighlightedIndex({
              diff: -pageSize,
              direction: "previous",
              reason: "keyboard",
              event
            });
            handleOpen(event);
            break;
          case "PageDown":
            event.preventDefault();
            changeHighlightedIndex({
              diff: pageSize,
              direction: "next",
              reason: "keyboard",
              event
            });
            handleOpen(event);
            break;
          case "ArrowDown":
            event.preventDefault();
            changeHighlightedIndex({
              diff: 1,
              direction: "next",
              reason: "keyboard",
              event
            });
            handleOpen(event);
            break;
          case "ArrowUp":
            event.preventDefault();
            changeHighlightedIndex({
              diff: -1,
              direction: "previous",
              reason: "keyboard",
              event
            });
            handleOpen(event);
            break;
          case "ArrowLeft":
            handleFocusTag(event, "previous");
            break;
          case "ArrowRight":
            handleFocusTag(event, "next");
            break;
          case "Enter":
            if (highlightedIndexRef.current !== -1 && popupOpen) {
              const option = filteredOptions[highlightedIndexRef.current];
              const disabled = getOptionDisabled ? getOptionDisabled(option) : false;
              event.preventDefault();
              if (disabled) {
                return;
              }
              selectNewValue(event, option, "selectOption");
              if (autoComplete) {
                inputRef.current.setSelectionRange(inputRef.current.value.length, inputRef.current.value.length);
              }
            } else if (freeSolo && inputValue !== "" && inputValueIsSelectedValue === false) {
              if (multiple) {
                event.preventDefault();
              }
              selectNewValue(event, inputValue, "createOption", "freeSolo");
            }
            break;
          case "Escape":
            if (popupOpen) {
              event.preventDefault();
              event.stopPropagation();
              handleClose(event, "escape");
            } else if (clearOnEscape && (inputValue !== "" || multiple && value.length > 0)) {
              event.preventDefault();
              event.stopPropagation();
              handleClear(event);
            }
            break;
          case "Backspace":
            if (multiple && !readOnly && inputValue === "" && value.length > 0) {
              const index = focusedTag === -1 ? value.length - 1 : focusedTag;
              const newValue = value.slice();
              newValue.splice(index, 1);
              handleValue(event, newValue, "removeOption", {
                option: value[index]
              });
            }
            break;
        }
      }
    };
    const handleFocus = (event) => {
      setFocused(true);
      if (openOnFocus && !ignoreFocus.current) {
        handleOpen(event);
      }
    };
    const handleBlur = (event) => {
      if (listboxRef.current !== null && listboxRef.current.parentElement.contains(document.activeElement)) {
        inputRef.current.focus();
        return;
      }
      setFocused(false);
      firstFocus.current = true;
      ignoreFocus.current = false;
      if (autoSelect && highlightedIndexRef.current !== -1 && popupOpen) {
        selectNewValue(event, filteredOptions[highlightedIndexRef.current], "blur");
      } else if (autoSelect && freeSolo && inputValue !== "") {
        selectNewValue(event, inputValue, "blur", "freeSolo");
      } else if (clearOnBlur) {
        resetInputValue(event, value);
      }
      handleClose(event, "blur");
    };
    const handleInputChange = (event) => {
      const newValue = event.target.value;
      if (inputValue !== newValue) {
        setInputValueState(newValue);
        setInputPristine(false);
        if (onInputChange) {
          onInputChange(event, newValue, "input");
        }
      }
      if (newValue === "") {
        if (!disableClearable && !multiple) {
          handleValue(event, null, "clear");
        }
      } else {
        handleOpen(event);
      }
    };
    const handleOptionMouseOver = (event) => {
      setHighlightedIndex({
        event,
        index: Number(event.currentTarget.getAttribute("data-option-index")),
        reason: "mouse"
      });
    };
    const handleOptionTouchStart = () => {
      isTouch.current = true;
    };
    const handleOptionClick = (event) => {
      const index = Number(event.currentTarget.getAttribute("data-option-index"));
      selectNewValue(event, filteredOptions[index], "selectOption");
      isTouch.current = false;
    };
    const handleTagDelete = (index) => (event) => {
      const newValue = value.slice();
      newValue.splice(index, 1);
      handleValue(event, newValue, "removeOption", {
        option: value[index]
      });
    };
    const handlePopupIndicator = (event) => {
      if (open) {
        handleClose(event, "toggleInput");
      } else {
        handleOpen(event);
      }
    };
    const handleMouseDown = (event) => {
      if (event.target.getAttribute("id") !== id2) {
        event.preventDefault();
      }
    };
    const handleClick = () => {
      inputRef.current.focus();
      if (selectOnFocus && firstFocus.current && inputRef.current.selectionEnd - inputRef.current.selectionStart === 0) {
        inputRef.current.select();
      }
      firstFocus.current = false;
    };
    const handleInputMouseDown = (event) => {
      if (inputValue === "" || !open) {
        handlePopupIndicator(event);
      }
    };
    let dirty = freeSolo && inputValue.length > 0;
    dirty = dirty || (multiple ? value.length > 0 : value !== null);
    let groupedOptions = filteredOptions;
    if (groupBy) {
      groupedOptions = filteredOptions.reduce((acc, option, index) => {
        const group = groupBy(option);
        if (acc.length > 0 && acc[acc.length - 1].group === group) {
          acc[acc.length - 1].options.push(option);
        } else {
          acc.push({
            key: index,
            index,
            group,
            options: [option]
          });
        }
        return acc;
      }, []);
    }
    if (disabledProp && focused) {
      handleBlur();
    }
    return {
      getRootProps: (other = {}) => _extends({
        "aria-owns": listboxAvailable ? `${id2}-listbox` : null
      }, other, {
        onKeyDown: handleKeyDown2(other),
        onMouseDown: handleMouseDown,
        onClick: handleClick
      }),
      getInputLabelProps: () => ({
        id: `${id2}-label`,
        htmlFor: id2
      }),
      getInputProps: () => ({
        id: id2,
        value: inputValue,
        onBlur: handleBlur,
        onFocus: handleFocus,
        onChange: handleInputChange,
        onMouseDown: handleInputMouseDown,
        "aria-activedescendant": popupOpen ? "" : null,
        "aria-autocomplete": autoComplete ? "both" : "list",
        "aria-controls": listboxAvailable ? `${id2}-listbox` : void 0,
        "aria-expanded": listboxAvailable,
        autoComplete: "off",
        ref: inputRef,
        autoCapitalize: "none",
        spellCheck: "false",
        role: "combobox"
      }),
      getClearProps: () => ({
        tabIndex: -1,
        onClick: handleClear
      }),
      getPopupIndicatorProps: () => ({
        tabIndex: -1,
        onClick: handlePopupIndicator
      }),
      getTagProps: ({
        index
      }) => _extends({
        key: index,
        "data-tag-index": index,
        tabIndex: -1
      }, !readOnly && {
        onDelete: handleTagDelete(index)
      }),
      getListboxProps: () => ({
        role: "listbox",
        id: `${id2}-listbox`,
        "aria-labelledby": `${id2}-label`,
        ref: handleListboxRef,
        onMouseDown: (event) => {
          event.preventDefault();
        }
      }),
      getOptionProps: ({
        index,
        option
      }) => {
        const selected = (multiple ? value : [value]).some((value2) => value2 != null && isOptionEqualToValue(option, value2));
        const disabled = getOptionDisabled ? getOptionDisabled(option) : false;
        return {
          key: getOptionLabel(option),
          tabIndex: -1,
          role: "option",
          id: `${id2}-option-${index}`,
          onMouseOver: handleOptionMouseOver,
          onClick: handleOptionClick,
          onTouchStart: handleOptionTouchStart,
          "data-option-index": index,
          "aria-disabled": disabled,
          "aria-selected": selected
        };
      },
      id: id2,
      inputValue,
      value,
      dirty,
      popupOpen,
      focused: focused || focusedTag !== -1,
      anchorEl,
      setAnchorEl,
      focusedTag,
      groupedOptions
    };
  }
  const candidatesSelector = ["input", "select", "textarea", "a[href]", "button", "[tabindex]", "audio[controls]", "video[controls]", '[contenteditable]:not([contenteditable="false"])'].join(",");
  function getTabIndex(node2) {
    const tabindexAttr = parseInt(node2.getAttribute("tabindex"), 10);
    if (!Number.isNaN(tabindexAttr)) {
      return tabindexAttr;
    }
    if (node2.contentEditable === "true" || (node2.nodeName === "AUDIO" || node2.nodeName === "VIDEO" || node2.nodeName === "DETAILS") && node2.getAttribute("tabindex") === null) {
      return 0;
    }
    return node2.tabIndex;
  }
  function isNonTabbableRadio(node2) {
    if (node2.tagName !== "INPUT" || node2.type !== "radio") {
      return false;
    }
    if (!node2.name) {
      return false;
    }
    const getRadio = (selector) => node2.ownerDocument.querySelector(`input[type="radio"]${selector}`);
    let roving = getRadio(`[name="${node2.name}"]:checked`);
    if (!roving) {
      roving = getRadio(`[name="${node2.name}"]`);
    }
    return roving !== node2;
  }
  function isNodeMatchingSelectorFocusable(node2) {
    if (node2.disabled || node2.tagName === "INPUT" && node2.type === "hidden" || isNonTabbableRadio(node2)) {
      return false;
    }
    return true;
  }
  function defaultGetTabbable(root) {
    const regularTabNodes = [];
    const orderedTabNodes = [];
    Array.from(root.querySelectorAll(candidatesSelector)).forEach((node2, i) => {
      const nodeTabIndex = getTabIndex(node2);
      if (nodeTabIndex === -1 || !isNodeMatchingSelectorFocusable(node2)) {
        return;
      }
      if (nodeTabIndex === 0) {
        regularTabNodes.push(node2);
      } else {
        orderedTabNodes.push({
          documentOrder: i,
          tabIndex: nodeTabIndex,
          node: node2
        });
      }
    });
    return orderedTabNodes.sort((a, b2) => a.tabIndex === b2.tabIndex ? a.documentOrder - b2.documentOrder : a.tabIndex - b2.tabIndex).map((a) => a.node).concat(regularTabNodes);
  }
  function defaultIsEnabled() {
    return true;
  }
  function FocusTrap(props) {
    const {
      children,
      disableAutoFocus = false,
      disableEnforceFocus = false,
      disableRestoreFocus = false,
      getTabbable = defaultGetTabbable,
      isEnabled = defaultIsEnabled,
      open
    } = props;
    const ignoreNextEnforceFocus = react.exports.useRef();
    const sentinelStart = react.exports.useRef(null);
    const sentinelEnd = react.exports.useRef(null);
    const nodeToRestore = react.exports.useRef(null);
    const reactFocusEventTarget = react.exports.useRef(null);
    const activated = react.exports.useRef(false);
    const rootRef = react.exports.useRef(null);
    const handleRef = useForkRef(children.ref, rootRef);
    const lastKeydown = react.exports.useRef(null);
    react.exports.useEffect(() => {
      if (!open || !rootRef.current) {
        return;
      }
      activated.current = !disableAutoFocus;
    }, [disableAutoFocus, open]);
    react.exports.useEffect(() => {
      if (!open || !rootRef.current) {
        return;
      }
      const doc = ownerDocument(rootRef.current);
      if (!rootRef.current.contains(doc.activeElement)) {
        if (!rootRef.current.hasAttribute("tabIndex")) {
          rootRef.current.setAttribute("tabIndex", -1);
        }
        if (activated.current) {
          rootRef.current.focus();
        }
      }
      return () => {
        if (!disableRestoreFocus) {
          if (nodeToRestore.current && nodeToRestore.current.focus) {
            ignoreNextEnforceFocus.current = true;
            nodeToRestore.current.focus();
          }
          nodeToRestore.current = null;
        }
      };
    }, [open]);
    react.exports.useEffect(() => {
      if (!open || !rootRef.current) {
        return;
      }
      const doc = ownerDocument(rootRef.current);
      const contain = (nativeEvent) => {
        const {
          current: rootElement
        } = rootRef;
        if (rootElement === null) {
          return;
        }
        if (!doc.hasFocus() || disableEnforceFocus || !isEnabled() || ignoreNextEnforceFocus.current) {
          ignoreNextEnforceFocus.current = false;
          return;
        }
        if (!rootElement.contains(doc.activeElement)) {
          if (nativeEvent && reactFocusEventTarget.current !== nativeEvent.target || doc.activeElement !== reactFocusEventTarget.current) {
            reactFocusEventTarget.current = null;
          } else if (reactFocusEventTarget.current !== null) {
            return;
          }
          if (!activated.current) {
            return;
          }
          let tabbable = [];
          if (doc.activeElement === sentinelStart.current || doc.activeElement === sentinelEnd.current) {
            tabbable = getTabbable(rootRef.current);
          }
          if (tabbable.length > 0) {
            var _lastKeydown$current, _lastKeydown$current2;
            const isShiftTab = Boolean(((_lastKeydown$current = lastKeydown.current) == null ? void 0 : _lastKeydown$current.shiftKey) && ((_lastKeydown$current2 = lastKeydown.current) == null ? void 0 : _lastKeydown$current2.key) === "Tab");
            const focusNext = tabbable[0];
            const focusPrevious = tabbable[tabbable.length - 1];
            if (isShiftTab) {
              focusPrevious.focus();
            } else {
              focusNext.focus();
            }
          } else {
            rootElement.focus();
          }
        }
      };
      const loopFocus = (nativeEvent) => {
        lastKeydown.current = nativeEvent;
        if (disableEnforceFocus || !isEnabled() || nativeEvent.key !== "Tab") {
          return;
        }
        if (doc.activeElement === rootRef.current && nativeEvent.shiftKey) {
          ignoreNextEnforceFocus.current = true;
          sentinelEnd.current.focus();
        }
      };
      doc.addEventListener("focusin", contain);
      doc.addEventListener("keydown", loopFocus, true);
      const interval = setInterval(() => {
        if (doc.activeElement.tagName === "BODY") {
          contain();
        }
      }, 50);
      return () => {
        clearInterval(interval);
        doc.removeEventListener("focusin", contain);
        doc.removeEventListener("keydown", loopFocus, true);
      };
    }, [disableAutoFocus, disableEnforceFocus, disableRestoreFocus, isEnabled, open, getTabbable]);
    const onFocus = (event) => {
      if (nodeToRestore.current === null) {
        nodeToRestore.current = event.relatedTarget;
      }
      activated.current = true;
      reactFocusEventTarget.current = event.target;
      const childrenPropsHandler = children.props.onFocus;
      if (childrenPropsHandler) {
        childrenPropsHandler(event);
      }
    };
    const handleFocusSentinel = (event) => {
      if (nodeToRestore.current === null) {
        nodeToRestore.current = event.relatedTarget;
      }
      activated.current = true;
    };
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx("div", {
        tabIndex: open ? 0 : -1,
        onFocus: handleFocusSentinel,
        ref: sentinelStart,
        "data-testid": "sentinelStart"
      }), /* @__PURE__ */ react.exports.cloneElement(children, {
        ref: handleRef,
        onFocus
      }), /* @__PURE__ */ jsx("div", {
        tabIndex: open ? 0 : -1,
        onFocus: handleFocusSentinel,
        ref: sentinelEnd,
        "data-testid": "sentinelEnd"
      })]
    });
  }
  var top = "top";
  var bottom = "bottom";
  var right = "right";
  var left = "left";
  var auto = "auto";
  var basePlacements = [top, bottom, right, left];
  var start = "start";
  var end = "end";
  var clippingParents = "clippingParents";
  var viewport = "viewport";
  var popper = "popper";
  var reference = "reference";
  var variationPlacements = /* @__PURE__ */ basePlacements.reduce(function(acc, placement) {
    return acc.concat([placement + "-" + start, placement + "-" + end]);
  }, []);
  var placements = /* @__PURE__ */ [].concat(basePlacements, [auto]).reduce(function(acc, placement) {
    return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
  }, []);
  var beforeRead = "beforeRead";
  var read = "read";
  var afterRead = "afterRead";
  var beforeMain = "beforeMain";
  var main = "main";
  var afterMain = "afterMain";
  var beforeWrite = "beforeWrite";
  var write = "write";
  var afterWrite = "afterWrite";
  var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];
  function getNodeName(element) {
    return element ? (element.nodeName || "").toLowerCase() : null;
  }
  function getWindow(node2) {
    if (node2 == null) {
      return window;
    }
    if (node2.toString() !== "[object Window]") {
      var ownerDocument2 = node2.ownerDocument;
      return ownerDocument2 ? ownerDocument2.defaultView || window : window;
    }
    return node2;
  }
  function isElement(node2) {
    var OwnElement = getWindow(node2).Element;
    return node2 instanceof OwnElement || node2 instanceof Element;
  }
  function isHTMLElement(node2) {
    var OwnElement = getWindow(node2).HTMLElement;
    return node2 instanceof OwnElement || node2 instanceof HTMLElement;
  }
  function isShadowRoot(node2) {
    if (typeof ShadowRoot === "undefined") {
      return false;
    }
    var OwnElement = getWindow(node2).ShadowRoot;
    return node2 instanceof OwnElement || node2 instanceof ShadowRoot;
  }
  function applyStyles(_ref) {
    var state = _ref.state;
    Object.keys(state.elements).forEach(function(name) {
      var style2 = state.styles[name] || {};
      var attributes = state.attributes[name] || {};
      var element = state.elements[name];
      if (!isHTMLElement(element) || !getNodeName(element)) {
        return;
      }
      Object.assign(element.style, style2);
      Object.keys(attributes).forEach(function(name2) {
        var value = attributes[name2];
        if (value === false) {
          element.removeAttribute(name2);
        } else {
          element.setAttribute(name2, value === true ? "" : value);
        }
      });
    });
  }
  function effect$2(_ref2) {
    var state = _ref2.state;
    var initialStyles = {
      popper: {
        position: state.options.strategy,
        left: "0",
        top: "0",
        margin: "0"
      },
      arrow: {
        position: "absolute"
      },
      reference: {}
    };
    Object.assign(state.elements.popper.style, initialStyles.popper);
    state.styles = initialStyles;
    if (state.elements.arrow) {
      Object.assign(state.elements.arrow.style, initialStyles.arrow);
    }
    return function() {
      Object.keys(state.elements).forEach(function(name) {
        var element = state.elements[name];
        var attributes = state.attributes[name] || {};
        var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]);
        var style2 = styleProperties.reduce(function(style3, property) {
          style3[property] = "";
          return style3;
        }, {});
        if (!isHTMLElement(element) || !getNodeName(element)) {
          return;
        }
        Object.assign(element.style, style2);
        Object.keys(attributes).forEach(function(attribute) {
          element.removeAttribute(attribute);
        });
      });
    };
  }
  const applyStyles$1 = {
    name: "applyStyles",
    enabled: true,
    phase: "write",
    fn: applyStyles,
    effect: effect$2,
    requires: ["computeStyles"]
  };
  function getBasePlacement(placement) {
    return placement.split("-")[0];
  }
  var max = Math.max;
  var min = Math.min;
  var round$1 = Math.round;
  function getUAString() {
    var uaData = navigator.userAgentData;
    if (uaData != null && uaData.brands) {
      return uaData.brands.map(function(item) {
        return item.brand + "/" + item.version;
      }).join(" ");
    }
    return navigator.userAgent;
  }
  function isLayoutViewport() {
    return !/^((?!chrome|android).)*safari/i.test(getUAString());
  }
  function getBoundingClientRect(element, includeScale, isFixedStrategy) {
    if (includeScale === void 0) {
      includeScale = false;
    }
    if (isFixedStrategy === void 0) {
      isFixedStrategy = false;
    }
    var clientRect = element.getBoundingClientRect();
    var scaleX = 1;
    var scaleY = 1;
    if (includeScale && isHTMLElement(element)) {
      scaleX = element.offsetWidth > 0 ? round$1(clientRect.width) / element.offsetWidth || 1 : 1;
      scaleY = element.offsetHeight > 0 ? round$1(clientRect.height) / element.offsetHeight || 1 : 1;
    }
    var _ref = isElement(element) ? getWindow(element) : window, visualViewport = _ref.visualViewport;
    var addVisualOffsets = !isLayoutViewport() && isFixedStrategy;
    var x2 = (clientRect.left + (addVisualOffsets && visualViewport ? visualViewport.offsetLeft : 0)) / scaleX;
    var y2 = (clientRect.top + (addVisualOffsets && visualViewport ? visualViewport.offsetTop : 0)) / scaleY;
    var width2 = clientRect.width / scaleX;
    var height2 = clientRect.height / scaleY;
    return {
      width: width2,
      height: height2,
      top: y2,
      right: x2 + width2,
      bottom: y2 + height2,
      left: x2,
      x: x2,
      y: y2
    };
  }
  function getLayoutRect(element) {
    var clientRect = getBoundingClientRect(element);
    var width2 = element.offsetWidth;
    var height2 = element.offsetHeight;
    if (Math.abs(clientRect.width - width2) <= 1) {
      width2 = clientRect.width;
    }
    if (Math.abs(clientRect.height - height2) <= 1) {
      height2 = clientRect.height;
    }
    return {
      x: element.offsetLeft,
      y: element.offsetTop,
      width: width2,
      height: height2
    };
  }
  function contains(parent, child) {
    var rootNode = child.getRootNode && child.getRootNode();
    if (parent.contains(child)) {
      return true;
    } else if (rootNode && isShadowRoot(rootNode)) {
      var next2 = child;
      do {
        if (next2 && parent.isSameNode(next2)) {
          return true;
        }
        next2 = next2.parentNode || next2.host;
      } while (next2);
    }
    return false;
  }
  function getComputedStyle(element) {
    return getWindow(element).getComputedStyle(element);
  }
  function isTableElement(element) {
    return ["table", "td", "th"].indexOf(getNodeName(element)) >= 0;
  }
  function getDocumentElement(element) {
    return ((isElement(element) ? element.ownerDocument : element.document) || window.document).documentElement;
  }
  function getParentNode(element) {
    if (getNodeName(element) === "html") {
      return element;
    }
    return element.assignedSlot || element.parentNode || (isShadowRoot(element) ? element.host : null) || getDocumentElement(element);
  }
  function getTrueOffsetParent(element) {
    if (!isHTMLElement(element) || getComputedStyle(element).position === "fixed") {
      return null;
    }
    return element.offsetParent;
  }
  function getContainingBlock(element) {
    var isFirefox = /firefox/i.test(getUAString());
    var isIE = /Trident/i.test(getUAString());
    if (isIE && isHTMLElement(element)) {
      var elementCss = getComputedStyle(element);
      if (elementCss.position === "fixed") {
        return null;
      }
    }
    var currentNode = getParentNode(element);
    if (isShadowRoot(currentNode)) {
      currentNode = currentNode.host;
    }
    while (isHTMLElement(currentNode) && ["html", "body"].indexOf(getNodeName(currentNode)) < 0) {
      var css2 = getComputedStyle(currentNode);
      if (css2.transform !== "none" || css2.perspective !== "none" || css2.contain === "paint" || ["transform", "perspective"].indexOf(css2.willChange) !== -1 || isFirefox && css2.willChange === "filter" || isFirefox && css2.filter && css2.filter !== "none") {
        return currentNode;
      } else {
        currentNode = currentNode.parentNode;
      }
    }
    return null;
  }
  function getOffsetParent(element) {
    var window2 = getWindow(element);
    var offsetParent = getTrueOffsetParent(element);
    while (offsetParent && isTableElement(offsetParent) && getComputedStyle(offsetParent).position === "static") {
      offsetParent = getTrueOffsetParent(offsetParent);
    }
    if (offsetParent && (getNodeName(offsetParent) === "html" || getNodeName(offsetParent) === "body" && getComputedStyle(offsetParent).position === "static")) {
      return window2;
    }
    return offsetParent || getContainingBlock(element) || window2;
  }
  function getMainAxisFromPlacement(placement) {
    return ["top", "bottom"].indexOf(placement) >= 0 ? "x" : "y";
  }
  function within(min$1, value, max$1) {
    return max(min$1, min(value, max$1));
  }
  function withinMaxClamp(min2, value, max2) {
    var v2 = within(min2, value, max2);
    return v2 > max2 ? max2 : v2;
  }
  function getFreshSideObject() {
    return {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0
    };
  }
  function mergePaddingObject(paddingObject) {
    return Object.assign({}, getFreshSideObject(), paddingObject);
  }
  function expandToHashMap(value, keys) {
    return keys.reduce(function(hashMap, key) {
      hashMap[key] = value;
      return hashMap;
    }, {});
  }
  var toPaddingObject = function toPaddingObject2(padding, state) {
    padding = typeof padding === "function" ? padding(Object.assign({}, state.rects, {
      placement: state.placement
    })) : padding;
    return mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
  };
  function arrow(_ref) {
    var _state$modifiersData$;
    var state = _ref.state, name = _ref.name, options = _ref.options;
    var arrowElement = state.elements.arrow;
    var popperOffsets2 = state.modifiersData.popperOffsets;
    var basePlacement = getBasePlacement(state.placement);
    var axis = getMainAxisFromPlacement(basePlacement);
    var isVertical = [left, right].indexOf(basePlacement) >= 0;
    var len = isVertical ? "height" : "width";
    if (!arrowElement || !popperOffsets2) {
      return;
    }
    var paddingObject = toPaddingObject(options.padding, state);
    var arrowRect = getLayoutRect(arrowElement);
    var minProp = axis === "y" ? top : left;
    var maxProp = axis === "y" ? bottom : right;
    var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets2[axis] - state.rects.popper[len];
    var startDiff = popperOffsets2[axis] - state.rects.reference[axis];
    var arrowOffsetParent = getOffsetParent(arrowElement);
    var clientSize = arrowOffsetParent ? axis === "y" ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
    var centerToReference = endDiff / 2 - startDiff / 2;
    var min2 = paddingObject[minProp];
    var max2 = clientSize - arrowRect[len] - paddingObject[maxProp];
    var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
    var offset2 = within(min2, center, max2);
    var axisProp = axis;
    state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset2, _state$modifiersData$.centerOffset = offset2 - center, _state$modifiersData$);
  }
  function effect$1(_ref2) {
    var state = _ref2.state, options = _ref2.options;
    var _options$element = options.element, arrowElement = _options$element === void 0 ? "[data-popper-arrow]" : _options$element;
    if (arrowElement == null) {
      return;
    }
    if (typeof arrowElement === "string") {
      arrowElement = state.elements.popper.querySelector(arrowElement);
      if (!arrowElement) {
        return;
      }
    }
    if (!contains(state.elements.popper, arrowElement)) {
      return;
    }
    state.elements.arrow = arrowElement;
  }
  const arrow$1 = {
    name: "arrow",
    enabled: true,
    phase: "main",
    fn: arrow,
    effect: effect$1,
    requires: ["popperOffsets"],
    requiresIfExists: ["preventOverflow"]
  };
  function getVariation(placement) {
    return placement.split("-")[1];
  }
  var unsetSides = {
    top: "auto",
    right: "auto",
    bottom: "auto",
    left: "auto"
  };
  function roundOffsetsByDPR(_ref) {
    var x2 = _ref.x, y2 = _ref.y;
    var win = window;
    var dpr = win.devicePixelRatio || 1;
    return {
      x: round$1(x2 * dpr) / dpr || 0,
      y: round$1(y2 * dpr) / dpr || 0
    };
  }
  function mapToStyles(_ref2) {
    var _Object$assign2;
    var popper2 = _ref2.popper, popperRect = _ref2.popperRect, placement = _ref2.placement, variation = _ref2.variation, offsets = _ref2.offsets, position2 = _ref2.position, gpuAcceleration = _ref2.gpuAcceleration, adaptive = _ref2.adaptive, roundOffsets = _ref2.roundOffsets, isFixed = _ref2.isFixed;
    var _offsets$x = offsets.x, x2 = _offsets$x === void 0 ? 0 : _offsets$x, _offsets$y = offsets.y, y2 = _offsets$y === void 0 ? 0 : _offsets$y;
    var _ref3 = typeof roundOffsets === "function" ? roundOffsets({
      x: x2,
      y: y2
    }) : {
      x: x2,
      y: y2
    };
    x2 = _ref3.x;
    y2 = _ref3.y;
    var hasX = offsets.hasOwnProperty("x");
    var hasY = offsets.hasOwnProperty("y");
    var sideX = left;
    var sideY = top;
    var win = window;
    if (adaptive) {
      var offsetParent = getOffsetParent(popper2);
      var heightProp = "clientHeight";
      var widthProp = "clientWidth";
      if (offsetParent === getWindow(popper2)) {
        offsetParent = getDocumentElement(popper2);
        if (getComputedStyle(offsetParent).position !== "static" && position2 === "absolute") {
          heightProp = "scrollHeight";
          widthProp = "scrollWidth";
        }
      }
      offsetParent = offsetParent;
      if (placement === top || (placement === left || placement === right) && variation === end) {
        sideY = bottom;
        var offsetY = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.height : offsetParent[heightProp];
        y2 -= offsetY - popperRect.height;
        y2 *= gpuAcceleration ? 1 : -1;
      }
      if (placement === left || (placement === top || placement === bottom) && variation === end) {
        sideX = right;
        var offsetX = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.width : offsetParent[widthProp];
        x2 -= offsetX - popperRect.width;
        x2 *= gpuAcceleration ? 1 : -1;
      }
    }
    var commonStyles = Object.assign({
      position: position2
    }, adaptive && unsetSides);
    var _ref4 = roundOffsets === true ? roundOffsetsByDPR({
      x: x2,
      y: y2
    }) : {
      x: x2,
      y: y2
    };
    x2 = _ref4.x;
    y2 = _ref4.y;
    if (gpuAcceleration) {
      var _Object$assign;
      return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? "0" : "", _Object$assign[sideX] = hasX ? "0" : "", _Object$assign.transform = (win.devicePixelRatio || 1) <= 1 ? "translate(" + x2 + "px, " + y2 + "px)" : "translate3d(" + x2 + "px, " + y2 + "px, 0)", _Object$assign));
    }
    return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y2 + "px" : "", _Object$assign2[sideX] = hasX ? x2 + "px" : "", _Object$assign2.transform = "", _Object$assign2));
  }
  function computeStyles(_ref5) {
    var state = _ref5.state, options = _ref5.options;
    var _options$gpuAccelerat = options.gpuAcceleration, gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat, _options$adaptive = options.adaptive, adaptive = _options$adaptive === void 0 ? true : _options$adaptive, _options$roundOffsets = options.roundOffsets, roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
    var commonStyles = {
      placement: getBasePlacement(state.placement),
      variation: getVariation(state.placement),
      popper: state.elements.popper,
      popperRect: state.rects.popper,
      gpuAcceleration,
      isFixed: state.options.strategy === "fixed"
    };
    if (state.modifiersData.popperOffsets != null) {
      state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
        offsets: state.modifiersData.popperOffsets,
        position: state.options.strategy,
        adaptive,
        roundOffsets
      })));
    }
    if (state.modifiersData.arrow != null) {
      state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
        offsets: state.modifiersData.arrow,
        position: "absolute",
        adaptive: false,
        roundOffsets
      })));
    }
    state.attributes.popper = Object.assign({}, state.attributes.popper, {
      "data-popper-placement": state.placement
    });
  }
  const computeStyles$1 = {
    name: "computeStyles",
    enabled: true,
    phase: "beforeWrite",
    fn: computeStyles,
    data: {}
  };
  var passive = {
    passive: true
  };
  function effect(_ref) {
    var state = _ref.state, instance = _ref.instance, options = _ref.options;
    var _options$scroll = options.scroll, scroll = _options$scroll === void 0 ? true : _options$scroll, _options$resize = options.resize, resize = _options$resize === void 0 ? true : _options$resize;
    var window2 = getWindow(state.elements.popper);
    var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);
    if (scroll) {
      scrollParents.forEach(function(scrollParent) {
        scrollParent.addEventListener("scroll", instance.update, passive);
      });
    }
    if (resize) {
      window2.addEventListener("resize", instance.update, passive);
    }
    return function() {
      if (scroll) {
        scrollParents.forEach(function(scrollParent) {
          scrollParent.removeEventListener("scroll", instance.update, passive);
        });
      }
      if (resize) {
        window2.removeEventListener("resize", instance.update, passive);
      }
    };
  }
  const eventListeners = {
    name: "eventListeners",
    enabled: true,
    phase: "write",
    fn: function fn() {
    },
    effect,
    data: {}
  };
  var hash$1 = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
  };
  function getOppositePlacement(placement) {
    return placement.replace(/left|right|bottom|top/g, function(matched) {
      return hash$1[matched];
    });
  }
  var hash = {
    start: "end",
    end: "start"
  };
  function getOppositeVariationPlacement(placement) {
    return placement.replace(/start|end/g, function(matched) {
      return hash[matched];
    });
  }
  function getWindowScroll(node2) {
    var win = getWindow(node2);
    var scrollLeft = win.pageXOffset;
    var scrollTop = win.pageYOffset;
    return {
      scrollLeft,
      scrollTop
    };
  }
  function getWindowScrollBarX(element) {
    return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
  }
  function getViewportRect(element, strategy) {
    var win = getWindow(element);
    var html = getDocumentElement(element);
    var visualViewport = win.visualViewport;
    var width2 = html.clientWidth;
    var height2 = html.clientHeight;
    var x2 = 0;
    var y2 = 0;
    if (visualViewport) {
      width2 = visualViewport.width;
      height2 = visualViewport.height;
      var layoutViewport = isLayoutViewport();
      if (layoutViewport || !layoutViewport && strategy === "fixed") {
        x2 = visualViewport.offsetLeft;
        y2 = visualViewport.offsetTop;
      }
    }
    return {
      width: width2,
      height: height2,
      x: x2 + getWindowScrollBarX(element),
      y: y2
    };
  }
  function getDocumentRect(element) {
    var _element$ownerDocumen;
    var html = getDocumentElement(element);
    var winScroll = getWindowScroll(element);
    var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
    var width2 = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
    var height2 = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
    var x2 = -winScroll.scrollLeft + getWindowScrollBarX(element);
    var y2 = -winScroll.scrollTop;
    if (getComputedStyle(body || html).direction === "rtl") {
      x2 += max(html.clientWidth, body ? body.clientWidth : 0) - width2;
    }
    return {
      width: width2,
      height: height2,
      x: x2,
      y: y2
    };
  }
  function isScrollParent(element) {
    var _getComputedStyle = getComputedStyle(element), overflow2 = _getComputedStyle.overflow, overflowX = _getComputedStyle.overflowX, overflowY = _getComputedStyle.overflowY;
    return /auto|scroll|overlay|hidden/.test(overflow2 + overflowY + overflowX);
  }
  function getScrollParent(node2) {
    if (["html", "body", "#document"].indexOf(getNodeName(node2)) >= 0) {
      return node2.ownerDocument.body;
    }
    if (isHTMLElement(node2) && isScrollParent(node2)) {
      return node2;
    }
    return getScrollParent(getParentNode(node2));
  }
  function listScrollParents(element, list) {
    var _element$ownerDocumen;
    if (list === void 0) {
      list = [];
    }
    var scrollParent = getScrollParent(element);
    var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
    var win = getWindow(scrollParent);
    var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
    var updatedList = list.concat(target);
    return isBody ? updatedList : updatedList.concat(listScrollParents(getParentNode(target)));
  }
  function rectToClientRect(rect) {
    return Object.assign({}, rect, {
      left: rect.x,
      top: rect.y,
      right: rect.x + rect.width,
      bottom: rect.y + rect.height
    });
  }
  function getInnerBoundingClientRect(element, strategy) {
    var rect = getBoundingClientRect(element, false, strategy === "fixed");
    rect.top = rect.top + element.clientTop;
    rect.left = rect.left + element.clientLeft;
    rect.bottom = rect.top + element.clientHeight;
    rect.right = rect.left + element.clientWidth;
    rect.width = element.clientWidth;
    rect.height = element.clientHeight;
    rect.x = rect.left;
    rect.y = rect.top;
    return rect;
  }
  function getClientRectFromMixedType(element, clippingParent, strategy) {
    return clippingParent === viewport ? rectToClientRect(getViewportRect(element, strategy)) : isElement(clippingParent) ? getInnerBoundingClientRect(clippingParent, strategy) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
  }
  function getClippingParents(element) {
    var clippingParents2 = listScrollParents(getParentNode(element));
    var canEscapeClipping = ["absolute", "fixed"].indexOf(getComputedStyle(element).position) >= 0;
    var clipperElement = canEscapeClipping && isHTMLElement(element) ? getOffsetParent(element) : element;
    if (!isElement(clipperElement)) {
      return [];
    }
    return clippingParents2.filter(function(clippingParent) {
      return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== "body";
    });
  }
  function getClippingRect(element, boundary, rootBoundary, strategy) {
    var mainClippingParents = boundary === "clippingParents" ? getClippingParents(element) : [].concat(boundary);
    var clippingParents2 = [].concat(mainClippingParents, [rootBoundary]);
    var firstClippingParent = clippingParents2[0];
    var clippingRect = clippingParents2.reduce(function(accRect, clippingParent) {
      var rect = getClientRectFromMixedType(element, clippingParent, strategy);
      accRect.top = max(rect.top, accRect.top);
      accRect.right = min(rect.right, accRect.right);
      accRect.bottom = min(rect.bottom, accRect.bottom);
      accRect.left = max(rect.left, accRect.left);
      return accRect;
    }, getClientRectFromMixedType(element, firstClippingParent, strategy));
    clippingRect.width = clippingRect.right - clippingRect.left;
    clippingRect.height = clippingRect.bottom - clippingRect.top;
    clippingRect.x = clippingRect.left;
    clippingRect.y = clippingRect.top;
    return clippingRect;
  }
  function computeOffsets(_ref) {
    var reference2 = _ref.reference, element = _ref.element, placement = _ref.placement;
    var basePlacement = placement ? getBasePlacement(placement) : null;
    var variation = placement ? getVariation(placement) : null;
    var commonX = reference2.x + reference2.width / 2 - element.width / 2;
    var commonY = reference2.y + reference2.height / 2 - element.height / 2;
    var offsets;
    switch (basePlacement) {
      case top:
        offsets = {
          x: commonX,
          y: reference2.y - element.height
        };
        break;
      case bottom:
        offsets = {
          x: commonX,
          y: reference2.y + reference2.height
        };
        break;
      case right:
        offsets = {
          x: reference2.x + reference2.width,
          y: commonY
        };
        break;
      case left:
        offsets = {
          x: reference2.x - element.width,
          y: commonY
        };
        break;
      default:
        offsets = {
          x: reference2.x,
          y: reference2.y
        };
    }
    var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;
    if (mainAxis != null) {
      var len = mainAxis === "y" ? "height" : "width";
      switch (variation) {
        case start:
          offsets[mainAxis] = offsets[mainAxis] - (reference2[len] / 2 - element[len] / 2);
          break;
        case end:
          offsets[mainAxis] = offsets[mainAxis] + (reference2[len] / 2 - element[len] / 2);
          break;
      }
    }
    return offsets;
  }
  function detectOverflow(state, options) {
    if (options === void 0) {
      options = {};
    }
    var _options = options, _options$placement = _options.placement, placement = _options$placement === void 0 ? state.placement : _options$placement, _options$strategy = _options.strategy, strategy = _options$strategy === void 0 ? state.strategy : _options$strategy, _options$boundary = _options.boundary, boundary = _options$boundary === void 0 ? clippingParents : _options$boundary, _options$rootBoundary = _options.rootBoundary, rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary, _options$elementConte = _options.elementContext, elementContext = _options$elementConte === void 0 ? popper : _options$elementConte, _options$altBoundary = _options.altBoundary, altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary, _options$padding = _options.padding, padding = _options$padding === void 0 ? 0 : _options$padding;
    var paddingObject = mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
    var altContext = elementContext === popper ? reference : popper;
    var popperRect = state.rects.popper;
    var element = state.elements[altBoundary ? altContext : elementContext];
    var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary, strategy);
    var referenceClientRect = getBoundingClientRect(state.elements.reference);
    var popperOffsets2 = computeOffsets({
      reference: referenceClientRect,
      element: popperRect,
      strategy: "absolute",
      placement
    });
    var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets2));
    var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect;
    var overflowOffsets = {
      top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
      bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
      left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
      right: elementClientRect.right - clippingClientRect.right + paddingObject.right
    };
    var offsetData = state.modifiersData.offset;
    if (elementContext === popper && offsetData) {
      var offset2 = offsetData[placement];
      Object.keys(overflowOffsets).forEach(function(key) {
        var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
        var axis = [top, bottom].indexOf(key) >= 0 ? "y" : "x";
        overflowOffsets[key] += offset2[axis] * multiply;
      });
    }
    return overflowOffsets;
  }
  function computeAutoPlacement(state, options) {
    if (options === void 0) {
      options = {};
    }
    var _options = options, placement = _options.placement, boundary = _options.boundary, rootBoundary = _options.rootBoundary, padding = _options.padding, flipVariations = _options.flipVariations, _options$allowedAutoP = _options.allowedAutoPlacements, allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
    var variation = getVariation(placement);
    var placements$1 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function(placement2) {
      return getVariation(placement2) === variation;
    }) : basePlacements;
    var allowedPlacements = placements$1.filter(function(placement2) {
      return allowedAutoPlacements.indexOf(placement2) >= 0;
    });
    if (allowedPlacements.length === 0) {
      allowedPlacements = placements$1;
    }
    var overflows = allowedPlacements.reduce(function(acc, placement2) {
      acc[placement2] = detectOverflow(state, {
        placement: placement2,
        boundary,
        rootBoundary,
        padding
      })[getBasePlacement(placement2)];
      return acc;
    }, {});
    return Object.keys(overflows).sort(function(a, b2) {
      return overflows[a] - overflows[b2];
    });
  }
  function getExpandedFallbackPlacements(placement) {
    if (getBasePlacement(placement) === auto) {
      return [];
    }
    var oppositePlacement = getOppositePlacement(placement);
    return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
  }
  function flip(_ref) {
    var state = _ref.state, options = _ref.options, name = _ref.name;
    if (state.modifiersData[name]._skip) {
      return;
    }
    var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis, specifiedFallbackPlacements = options.fallbackPlacements, padding = options.padding, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, _options$flipVariatio = options.flipVariations, flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio, allowedAutoPlacements = options.allowedAutoPlacements;
    var preferredPlacement = state.options.placement;
    var basePlacement = getBasePlacement(preferredPlacement);
    var isBasePlacement = basePlacement === preferredPlacement;
    var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
    var placements2 = [preferredPlacement].concat(fallbackPlacements).reduce(function(acc, placement2) {
      return acc.concat(getBasePlacement(placement2) === auto ? computeAutoPlacement(state, {
        placement: placement2,
        boundary,
        rootBoundary,
        padding,
        flipVariations,
        allowedAutoPlacements
      }) : placement2);
    }, []);
    var referenceRect = state.rects.reference;
    var popperRect = state.rects.popper;
    var checksMap = /* @__PURE__ */ new Map();
    var makeFallbackChecks = true;
    var firstFittingPlacement = placements2[0];
    for (var i = 0; i < placements2.length; i++) {
      var placement = placements2[i];
      var _basePlacement = getBasePlacement(placement);
      var isStartVariation = getVariation(placement) === start;
      var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
      var len = isVertical ? "width" : "height";
      var overflow2 = detectOverflow(state, {
        placement,
        boundary,
        rootBoundary,
        altBoundary,
        padding
      });
      var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;
      if (referenceRect[len] > popperRect[len]) {
        mainVariationSide = getOppositePlacement(mainVariationSide);
      }
      var altVariationSide = getOppositePlacement(mainVariationSide);
      var checks = [];
      if (checkMainAxis) {
        checks.push(overflow2[_basePlacement] <= 0);
      }
      if (checkAltAxis) {
        checks.push(overflow2[mainVariationSide] <= 0, overflow2[altVariationSide] <= 0);
      }
      if (checks.every(function(check) {
        return check;
      })) {
        firstFittingPlacement = placement;
        makeFallbackChecks = false;
        break;
      }
      checksMap.set(placement, checks);
    }
    if (makeFallbackChecks) {
      var numberOfChecks = flipVariations ? 3 : 1;
      var _loop = function _loop2(_i2) {
        var fittingPlacement = placements2.find(function(placement2) {
          var checks2 = checksMap.get(placement2);
          if (checks2) {
            return checks2.slice(0, _i2).every(function(check) {
              return check;
            });
          }
        });
        if (fittingPlacement) {
          firstFittingPlacement = fittingPlacement;
          return "break";
        }
      };
      for (var _i = numberOfChecks; _i > 0; _i--) {
        var _ret = _loop(_i);
        if (_ret === "break")
          break;
      }
    }
    if (state.placement !== firstFittingPlacement) {
      state.modifiersData[name]._skip = true;
      state.placement = firstFittingPlacement;
      state.reset = true;
    }
  }
  const flip$1 = {
    name: "flip",
    enabled: true,
    phase: "main",
    fn: flip,
    requiresIfExists: ["offset"],
    data: {
      _skip: false
    }
  };
  function getSideOffsets(overflow2, rect, preventedOffsets) {
    if (preventedOffsets === void 0) {
      preventedOffsets = {
        x: 0,
        y: 0
      };
    }
    return {
      top: overflow2.top - rect.height - preventedOffsets.y,
      right: overflow2.right - rect.width + preventedOffsets.x,
      bottom: overflow2.bottom - rect.height + preventedOffsets.y,
      left: overflow2.left - rect.width - preventedOffsets.x
    };
  }
  function isAnySideFullyClipped(overflow2) {
    return [top, right, bottom, left].some(function(side) {
      return overflow2[side] >= 0;
    });
  }
  function hide(_ref) {
    var state = _ref.state, name = _ref.name;
    var referenceRect = state.rects.reference;
    var popperRect = state.rects.popper;
    var preventedOffsets = state.modifiersData.preventOverflow;
    var referenceOverflow = detectOverflow(state, {
      elementContext: "reference"
    });
    var popperAltOverflow = detectOverflow(state, {
      altBoundary: true
    });
    var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
    var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
    var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
    var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
    state.modifiersData[name] = {
      referenceClippingOffsets,
      popperEscapeOffsets,
      isReferenceHidden,
      hasPopperEscaped
    };
    state.attributes.popper = Object.assign({}, state.attributes.popper, {
      "data-popper-reference-hidden": isReferenceHidden,
      "data-popper-escaped": hasPopperEscaped
    });
  }
  const hide$1 = {
    name: "hide",
    enabled: true,
    phase: "main",
    requiresIfExists: ["preventOverflow"],
    fn: hide
  };
  function distanceAndSkiddingToXY(placement, rects, offset2) {
    var basePlacement = getBasePlacement(placement);
    var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;
    var _ref = typeof offset2 === "function" ? offset2(Object.assign({}, rects, {
      placement
    })) : offset2, skidding = _ref[0], distance = _ref[1];
    skidding = skidding || 0;
    distance = (distance || 0) * invertDistance;
    return [left, right].indexOf(basePlacement) >= 0 ? {
      x: distance,
      y: skidding
    } : {
      x: skidding,
      y: distance
    };
  }
  function offset(_ref2) {
    var state = _ref2.state, options = _ref2.options, name = _ref2.name;
    var _options$offset = options.offset, offset2 = _options$offset === void 0 ? [0, 0] : _options$offset;
    var data = placements.reduce(function(acc, placement) {
      acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset2);
      return acc;
    }, {});
    var _data$state$placement = data[state.placement], x2 = _data$state$placement.x, y2 = _data$state$placement.y;
    if (state.modifiersData.popperOffsets != null) {
      state.modifiersData.popperOffsets.x += x2;
      state.modifiersData.popperOffsets.y += y2;
    }
    state.modifiersData[name] = data;
  }
  const offset$1 = {
    name: "offset",
    enabled: true,
    phase: "main",
    requires: ["popperOffsets"],
    fn: offset
  };
  function popperOffsets(_ref) {
    var state = _ref.state, name = _ref.name;
    state.modifiersData[name] = computeOffsets({
      reference: state.rects.reference,
      element: state.rects.popper,
      strategy: "absolute",
      placement: state.placement
    });
  }
  const popperOffsets$1 = {
    name: "popperOffsets",
    enabled: true,
    phase: "read",
    fn: popperOffsets,
    data: {}
  };
  function getAltAxis(axis) {
    return axis === "x" ? "y" : "x";
  }
  function preventOverflow(_ref) {
    var state = _ref.state, options = _ref.options, name = _ref.name;
    var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, padding = options.padding, _options$tether = options.tether, tether = _options$tether === void 0 ? true : _options$tether, _options$tetherOffset = options.tetherOffset, tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
    var overflow2 = detectOverflow(state, {
      boundary,
      rootBoundary,
      padding,
      altBoundary
    });
    var basePlacement = getBasePlacement(state.placement);
    var variation = getVariation(state.placement);
    var isBasePlacement = !variation;
    var mainAxis = getMainAxisFromPlacement(basePlacement);
    var altAxis = getAltAxis(mainAxis);
    var popperOffsets2 = state.modifiersData.popperOffsets;
    var referenceRect = state.rects.reference;
    var popperRect = state.rects.popper;
    var tetherOffsetValue = typeof tetherOffset === "function" ? tetherOffset(Object.assign({}, state.rects, {
      placement: state.placement
    })) : tetherOffset;
    var normalizedTetherOffsetValue = typeof tetherOffsetValue === "number" ? {
      mainAxis: tetherOffsetValue,
      altAxis: tetherOffsetValue
    } : Object.assign({
      mainAxis: 0,
      altAxis: 0
    }, tetherOffsetValue);
    var offsetModifierState = state.modifiersData.offset ? state.modifiersData.offset[state.placement] : null;
    var data = {
      x: 0,
      y: 0
    };
    if (!popperOffsets2) {
      return;
    }
    if (checkMainAxis) {
      var _offsetModifierState$;
      var mainSide = mainAxis === "y" ? top : left;
      var altSide = mainAxis === "y" ? bottom : right;
      var len = mainAxis === "y" ? "height" : "width";
      var offset2 = popperOffsets2[mainAxis];
      var min$1 = offset2 + overflow2[mainSide];
      var max$1 = offset2 - overflow2[altSide];
      var additive = tether ? -popperRect[len] / 2 : 0;
      var minLen = variation === start ? referenceRect[len] : popperRect[len];
      var maxLen = variation === start ? -popperRect[len] : -referenceRect[len];
      var arrowElement = state.elements.arrow;
      var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
        width: 0,
        height: 0
      };
      var arrowPaddingObject = state.modifiersData["arrow#persistent"] ? state.modifiersData["arrow#persistent"].padding : getFreshSideObject();
      var arrowPaddingMin = arrowPaddingObject[mainSide];
      var arrowPaddingMax = arrowPaddingObject[altSide];
      var arrowLen = within(0, referenceRect[len], arrowRect[len]);
      var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis : minLen - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis;
      var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis : maxLen + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis;
      var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
      var clientOffset = arrowOffsetParent ? mainAxis === "y" ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
      var offsetModifierValue = (_offsetModifierState$ = offsetModifierState == null ? void 0 : offsetModifierState[mainAxis]) != null ? _offsetModifierState$ : 0;
      var tetherMin = offset2 + minOffset - offsetModifierValue - clientOffset;
      var tetherMax = offset2 + maxOffset - offsetModifierValue;
      var preventedOffset = within(tether ? min(min$1, tetherMin) : min$1, offset2, tether ? max(max$1, tetherMax) : max$1);
      popperOffsets2[mainAxis] = preventedOffset;
      data[mainAxis] = preventedOffset - offset2;
    }
    if (checkAltAxis) {
      var _offsetModifierState$2;
      var _mainSide = mainAxis === "x" ? top : left;
      var _altSide = mainAxis === "x" ? bottom : right;
      var _offset = popperOffsets2[altAxis];
      var _len = altAxis === "y" ? "height" : "width";
      var _min = _offset + overflow2[_mainSide];
      var _max = _offset - overflow2[_altSide];
      var isOriginSide = [top, left].indexOf(basePlacement) !== -1;
      var _offsetModifierValue = (_offsetModifierState$2 = offsetModifierState == null ? void 0 : offsetModifierState[altAxis]) != null ? _offsetModifierState$2 : 0;
      var _tetherMin = isOriginSide ? _min : _offset - referenceRect[_len] - popperRect[_len] - _offsetModifierValue + normalizedTetherOffsetValue.altAxis;
      var _tetherMax = isOriginSide ? _offset + referenceRect[_len] + popperRect[_len] - _offsetModifierValue - normalizedTetherOffsetValue.altAxis : _max;
      var _preventedOffset = tether && isOriginSide ? withinMaxClamp(_tetherMin, _offset, _tetherMax) : within(tether ? _tetherMin : _min, _offset, tether ? _tetherMax : _max);
      popperOffsets2[altAxis] = _preventedOffset;
      data[altAxis] = _preventedOffset - _offset;
    }
    state.modifiersData[name] = data;
  }
  const preventOverflow$1 = {
    name: "preventOverflow",
    enabled: true,
    phase: "main",
    fn: preventOverflow,
    requiresIfExists: ["offset"]
  };
  function getHTMLElementScroll(element) {
    return {
      scrollLeft: element.scrollLeft,
      scrollTop: element.scrollTop
    };
  }
  function getNodeScroll(node2) {
    if (node2 === getWindow(node2) || !isHTMLElement(node2)) {
      return getWindowScroll(node2);
    } else {
      return getHTMLElementScroll(node2);
    }
  }
  function isElementScaled(element) {
    var rect = element.getBoundingClientRect();
    var scaleX = round$1(rect.width) / element.offsetWidth || 1;
    var scaleY = round$1(rect.height) / element.offsetHeight || 1;
    return scaleX !== 1 || scaleY !== 1;
  }
  function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
    if (isFixed === void 0) {
      isFixed = false;
    }
    var isOffsetParentAnElement = isHTMLElement(offsetParent);
    var offsetParentIsScaled = isHTMLElement(offsetParent) && isElementScaled(offsetParent);
    var documentElement = getDocumentElement(offsetParent);
    var rect = getBoundingClientRect(elementOrVirtualElement, offsetParentIsScaled, isFixed);
    var scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    var offsets = {
      x: 0,
      y: 0
    };
    if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isScrollParent(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isHTMLElement(offsetParent)) {
        offsets = getBoundingClientRect(offsetParent, true);
        offsets.x += offsetParent.clientLeft;
        offsets.y += offsetParent.clientTop;
      } else if (documentElement) {
        offsets.x = getWindowScrollBarX(documentElement);
      }
    }
    return {
      x: rect.left + scroll.scrollLeft - offsets.x,
      y: rect.top + scroll.scrollTop - offsets.y,
      width: rect.width,
      height: rect.height
    };
  }
  function order(modifiers) {
    var map = /* @__PURE__ */ new Map();
    var visited = /* @__PURE__ */ new Set();
    var result = [];
    modifiers.forEach(function(modifier) {
      map.set(modifier.name, modifier);
    });
    function sort(modifier) {
      visited.add(modifier.name);
      var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
      requires.forEach(function(dep) {
        if (!visited.has(dep)) {
          var depModifier = map.get(dep);
          if (depModifier) {
            sort(depModifier);
          }
        }
      });
      result.push(modifier);
    }
    modifiers.forEach(function(modifier) {
      if (!visited.has(modifier.name)) {
        sort(modifier);
      }
    });
    return result;
  }
  function orderModifiers(modifiers) {
    var orderedModifiers = order(modifiers);
    return modifierPhases.reduce(function(acc, phase) {
      return acc.concat(orderedModifiers.filter(function(modifier) {
        return modifier.phase === phase;
      }));
    }, []);
  }
  function debounce(fn) {
    var pending;
    return function() {
      if (!pending) {
        pending = new Promise(function(resolve) {
          Promise.resolve().then(function() {
            pending = void 0;
            resolve(fn());
          });
        });
      }
      return pending;
    };
  }
  function mergeByName(modifiers) {
    var merged = modifiers.reduce(function(merged2, current) {
      var existing = merged2[current.name];
      merged2[current.name] = existing ? Object.assign({}, existing, current, {
        options: Object.assign({}, existing.options, current.options),
        data: Object.assign({}, existing.data, current.data)
      }) : current;
      return merged2;
    }, {});
    return Object.keys(merged).map(function(key) {
      return merged[key];
    });
  }
  var DEFAULT_OPTIONS = {
    placement: "bottom",
    modifiers: [],
    strategy: "absolute"
  };
  function areValidElements() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return !args.some(function(element) {
      return !(element && typeof element.getBoundingClientRect === "function");
    });
  }
  function popperGenerator(generatorOptions) {
    if (generatorOptions === void 0) {
      generatorOptions = {};
    }
    var _generatorOptions = generatorOptions, _generatorOptions$def = _generatorOptions.defaultModifiers, defaultModifiers2 = _generatorOptions$def === void 0 ? [] : _generatorOptions$def, _generatorOptions$def2 = _generatorOptions.defaultOptions, defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
    return function createPopper2(reference2, popper2, options) {
      if (options === void 0) {
        options = defaultOptions;
      }
      var state = {
        placement: "bottom",
        orderedModifiers: [],
        options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
        modifiersData: {},
        elements: {
          reference: reference2,
          popper: popper2
        },
        attributes: {},
        styles: {}
      };
      var effectCleanupFns = [];
      var isDestroyed = false;
      var instance = {
        state,
        setOptions: function setOptions(setOptionsAction) {
          var options2 = typeof setOptionsAction === "function" ? setOptionsAction(state.options) : setOptionsAction;
          cleanupModifierEffects();
          state.options = Object.assign({}, defaultOptions, state.options, options2);
          state.scrollParents = {
            reference: isElement(reference2) ? listScrollParents(reference2) : reference2.contextElement ? listScrollParents(reference2.contextElement) : [],
            popper: listScrollParents(popper2)
          };
          var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers2, state.options.modifiers)));
          state.orderedModifiers = orderedModifiers.filter(function(m2) {
            return m2.enabled;
          });
          runModifierEffects();
          return instance.update();
        },
        forceUpdate: function forceUpdate() {
          if (isDestroyed) {
            return;
          }
          var _state$elements = state.elements, reference3 = _state$elements.reference, popper3 = _state$elements.popper;
          if (!areValidElements(reference3, popper3)) {
            return;
          }
          state.rects = {
            reference: getCompositeRect(reference3, getOffsetParent(popper3), state.options.strategy === "fixed"),
            popper: getLayoutRect(popper3)
          };
          state.reset = false;
          state.placement = state.options.placement;
          state.orderedModifiers.forEach(function(modifier) {
            return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
          });
          for (var index = 0; index < state.orderedModifiers.length; index++) {
            if (state.reset === true) {
              state.reset = false;
              index = -1;
              continue;
            }
            var _state$orderedModifie = state.orderedModifiers[index], fn = _state$orderedModifie.fn, _state$orderedModifie2 = _state$orderedModifie.options, _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2, name = _state$orderedModifie.name;
            if (typeof fn === "function") {
              state = fn({
                state,
                options: _options,
                name,
                instance
              }) || state;
            }
          }
        },
        update: debounce(function() {
          return new Promise(function(resolve) {
            instance.forceUpdate();
            resolve(state);
          });
        }),
        destroy: function destroy() {
          cleanupModifierEffects();
          isDestroyed = true;
        }
      };
      if (!areValidElements(reference2, popper2)) {
        return instance;
      }
      instance.setOptions(options).then(function(state2) {
        if (!isDestroyed && options.onFirstUpdate) {
          options.onFirstUpdate(state2);
        }
      });
      function runModifierEffects() {
        state.orderedModifiers.forEach(function(_ref3) {
          var name = _ref3.name, _ref3$options = _ref3.options, options2 = _ref3$options === void 0 ? {} : _ref3$options, effect2 = _ref3.effect;
          if (typeof effect2 === "function") {
            var cleanupFn = effect2({
              state,
              name,
              instance,
              options: options2
            });
            var noopFn = function noopFn2() {
            };
            effectCleanupFns.push(cleanupFn || noopFn);
          }
        });
      }
      function cleanupModifierEffects() {
        effectCleanupFns.forEach(function(fn) {
          return fn();
        });
        effectCleanupFns = [];
      }
      return instance;
    };
  }
  var defaultModifiers = [eventListeners, popperOffsets$1, computeStyles$1, applyStyles$1, offset$1, flip$1, preventOverflow$1, arrow$1, hide$1];
  var createPopper = /* @__PURE__ */ popperGenerator({
    defaultModifiers
  });
  function getContainer$1(container) {
    return typeof container === "function" ? container() : container;
  }
  const Portal = /* @__PURE__ */ react.exports.forwardRef(function Portal2(props, ref) {
    const {
      children,
      container,
      disablePortal = false
    } = props;
    const [mountNode, setMountNode] = react.exports.useState(null);
    const handleRef = useForkRef(/* @__PURE__ */ react.exports.isValidElement(children) ? children.ref : null, ref);
    useEnhancedEffect$1(() => {
      if (!disablePortal) {
        setMountNode(getContainer$1(container) || document.body);
      }
    }, [container, disablePortal]);
    useEnhancedEffect$1(() => {
      if (mountNode && !disablePortal) {
        setRef(ref, mountNode);
        return () => {
          setRef(ref, null);
        };
      }
      return void 0;
    }, [ref, mountNode, disablePortal]);
    if (disablePortal) {
      if (/* @__PURE__ */ react.exports.isValidElement(children)) {
        return /* @__PURE__ */ react.exports.cloneElement(children, {
          ref: handleRef
        });
      }
      return children;
    }
    return /* @__PURE__ */ jsx(react.exports.Fragment, {
      children: mountNode ? /* @__PURE__ */ reactDom.exports.createPortal(children, mountNode) : mountNode
    });
  });
  const Portal$1 = Portal;
  function getPopperUnstyledUtilityClass(slot) {
    return generateUtilityClass("MuiPopperUnstyled", slot);
  }
  generateUtilityClasses("MuiPopperUnstyled", ["root"]);
  const _excluded$H = ["anchorEl", "children", "component", "components", "componentsProps", "direction", "disablePortal", "modifiers", "open", "ownerState", "placement", "popperOptions", "popperRef", "TransitionProps"], _excluded2$2 = ["anchorEl", "children", "container", "direction", "disablePortal", "keepMounted", "modifiers", "open", "placement", "popperOptions", "popperRef", "style", "transition"];
  function flipPlacement(placement, direction) {
    if (direction === "ltr") {
      return placement;
    }
    switch (placement) {
      case "bottom-end":
        return "bottom-start";
      case "bottom-start":
        return "bottom-end";
      case "top-end":
        return "top-start";
      case "top-start":
        return "top-end";
      default:
        return placement;
    }
  }
  function resolveAnchorEl$1(anchorEl) {
    return typeof anchorEl === "function" ? anchorEl() : anchorEl;
  }
  const useUtilityClasses$v = () => {
    const slots = {
      root: ["root"]
    };
    return composeClasses(slots, getPopperUnstyledUtilityClass, {});
  };
  const defaultPopperOptions = {};
  const PopperTooltip = /* @__PURE__ */ react.exports.forwardRef(function PopperTooltip2(props, ref) {
    var _ref;
    const {
      anchorEl,
      children,
      component,
      components = {},
      componentsProps = {},
      direction,
      disablePortal,
      modifiers,
      open,
      ownerState,
      placement: initialPlacement,
      popperOptions,
      popperRef: popperRefProp,
      TransitionProps
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$H);
    const tooltipRef = react.exports.useRef(null);
    const ownRef = useForkRef(tooltipRef, ref);
    const popperRef = react.exports.useRef(null);
    const handlePopperRef = useForkRef(popperRef, popperRefProp);
    const handlePopperRefRef = react.exports.useRef(handlePopperRef);
    useEnhancedEffect$1(() => {
      handlePopperRefRef.current = handlePopperRef;
    }, [handlePopperRef]);
    react.exports.useImperativeHandle(popperRefProp, () => popperRef.current, []);
    const rtlPlacement = flipPlacement(initialPlacement, direction);
    const [placement, setPlacement] = react.exports.useState(rtlPlacement);
    react.exports.useEffect(() => {
      if (popperRef.current) {
        popperRef.current.forceUpdate();
      }
    });
    useEnhancedEffect$1(() => {
      if (!anchorEl || !open) {
        return void 0;
      }
      const handlePopperUpdate = (data) => {
        setPlacement(data.placement);
      };
      resolveAnchorEl$1(anchorEl);
      let popperModifiers = [{
        name: "preventOverflow",
        options: {
          altBoundary: disablePortal
        }
      }, {
        name: "flip",
        options: {
          altBoundary: disablePortal
        }
      }, {
        name: "onUpdate",
        enabled: true,
        phase: "afterWrite",
        fn: ({
          state
        }) => {
          handlePopperUpdate(state);
        }
      }];
      if (modifiers != null) {
        popperModifiers = popperModifiers.concat(modifiers);
      }
      if (popperOptions && popperOptions.modifiers != null) {
        popperModifiers = popperModifiers.concat(popperOptions.modifiers);
      }
      const popper2 = createPopper(resolveAnchorEl$1(anchorEl), tooltipRef.current, _extends({
        placement: rtlPlacement
      }, popperOptions, {
        modifiers: popperModifiers
      }));
      handlePopperRefRef.current(popper2);
      return () => {
        popper2.destroy();
        handlePopperRefRef.current(null);
      };
    }, [anchorEl, disablePortal, modifiers, open, popperOptions, rtlPlacement]);
    const childProps = {
      placement
    };
    if (TransitionProps !== null) {
      childProps.TransitionProps = TransitionProps;
    }
    const classes = useUtilityClasses$v();
    const Root = (_ref = component != null ? component : components.Root) != null ? _ref : "div";
    const rootProps = useSlotProps({
      elementType: Root,
      externalSlotProps: componentsProps.root,
      externalForwardedProps: other,
      additionalProps: {
        role: "tooltip",
        ref: ownRef
      },
      ownerState: _extends({}, props, ownerState),
      className: classes.root
    });
    return /* @__PURE__ */ jsx(Root, _extends({}, rootProps, {
      children: typeof children === "function" ? children(childProps) : children
    }));
  });
  const PopperUnstyled = /* @__PURE__ */ react.exports.forwardRef(function PopperUnstyled2(props, ref) {
    const {
      anchorEl,
      children,
      container: containerProp,
      direction = "ltr",
      disablePortal = false,
      keepMounted = false,
      modifiers,
      open,
      placement = "bottom",
      popperOptions = defaultPopperOptions,
      popperRef,
      style: style2,
      transition = false
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded2$2);
    const [exited, setExited] = react.exports.useState(true);
    const handleEnter = () => {
      setExited(false);
    };
    const handleExited = () => {
      setExited(true);
    };
    if (!keepMounted && !open && (!transition || exited)) {
      return null;
    }
    const container = containerProp || (anchorEl ? ownerDocument(resolveAnchorEl$1(anchorEl)).body : void 0);
    return /* @__PURE__ */ jsx(Portal$1, {
      disablePortal,
      container,
      children: /* @__PURE__ */ jsx(PopperTooltip, _extends({
        anchorEl,
        direction,
        disablePortal,
        modifiers,
        ref,
        open: transition ? !exited : open,
        placement,
        popperOptions,
        popperRef
      }, other, {
        style: _extends({
          position: "fixed",
          top: 0,
          left: 0,
          display: !open && keepMounted && (!transition || exited) ? "none" : null
        }, style2),
        TransitionProps: transition ? {
          in: open,
          onEnter: handleEnter,
          onExited: handleExited
        } : null,
        children
      }))
    });
  });
  const PopperUnstyled$1 = PopperUnstyled;
  function isOverflowing(container) {
    const doc = ownerDocument(container);
    if (doc.body === container) {
      return ownerWindow(container).innerWidth > doc.documentElement.clientWidth;
    }
    return container.scrollHeight > container.clientHeight;
  }
  function ariaHidden(element, show) {
    if (show) {
      element.setAttribute("aria-hidden", "true");
    } else {
      element.removeAttribute("aria-hidden");
    }
  }
  function getPaddingRight(element) {
    return parseInt(ownerWindow(element).getComputedStyle(element).paddingRight, 10) || 0;
  }
  function isAriaHiddenForbiddenOnElement(element) {
    const forbiddenTagNames = ["TEMPLATE", "SCRIPT", "STYLE", "LINK", "MAP", "META", "NOSCRIPT", "PICTURE", "COL", "COLGROUP", "PARAM", "SLOT", "SOURCE", "TRACK"];
    const isForbiddenTagName = forbiddenTagNames.indexOf(element.tagName) !== -1;
    const isInputHidden = element.tagName === "INPUT" && element.getAttribute("type") === "hidden";
    return isForbiddenTagName || isInputHidden;
  }
  function ariaHiddenSiblings(container, mountElement, currentElement, elementsToExclude = [], show) {
    const blacklist = [mountElement, currentElement, ...elementsToExclude];
    [].forEach.call(container.children, (element) => {
      const isNotExcludedElement = blacklist.indexOf(element) === -1;
      const isNotForbiddenElement = !isAriaHiddenForbiddenOnElement(element);
      if (isNotExcludedElement && isNotForbiddenElement) {
        ariaHidden(element, show);
      }
    });
  }
  function findIndexOf(items, callback) {
    let idx = -1;
    items.some((item, index) => {
      if (callback(item)) {
        idx = index;
        return true;
      }
      return false;
    });
    return idx;
  }
  function handleContainer(containerInfo, props) {
    const restoreStyle = [];
    const container = containerInfo.container;
    if (!props.disableScrollLock) {
      if (isOverflowing(container)) {
        const scrollbarSize = getScrollbarSize(ownerDocument(container));
        restoreStyle.push({
          value: container.style.paddingRight,
          property: "padding-right",
          el: container
        });
        container.style.paddingRight = `${getPaddingRight(container) + scrollbarSize}px`;
        const fixedElements2 = ownerDocument(container).querySelectorAll(".mui-fixed");
        [].forEach.call(fixedElements2, (element) => {
          restoreStyle.push({
            value: element.style.paddingRight,
            property: "padding-right",
            el: element
          });
          element.style.paddingRight = `${getPaddingRight(element) + scrollbarSize}px`;
        });
      }
      let scrollContainer;
      if (container.parentNode instanceof DocumentFragment) {
        scrollContainer = ownerDocument(container).body;
      } else {
        const parent = container.parentElement;
        const containerWindow = ownerWindow(container);
        scrollContainer = (parent == null ? void 0 : parent.nodeName) === "HTML" && containerWindow.getComputedStyle(parent).overflowY === "scroll" ? parent : container;
      }
      restoreStyle.push({
        value: scrollContainer.style.overflow,
        property: "overflow",
        el: scrollContainer
      }, {
        value: scrollContainer.style.overflowX,
        property: "overflow-x",
        el: scrollContainer
      }, {
        value: scrollContainer.style.overflowY,
        property: "overflow-y",
        el: scrollContainer
      });
      scrollContainer.style.overflow = "hidden";
    }
    const restore = () => {
      restoreStyle.forEach(({
        value,
        el: el2,
        property
      }) => {
        if (value) {
          el2.style.setProperty(property, value);
        } else {
          el2.style.removeProperty(property);
        }
      });
    };
    return restore;
  }
  function getHiddenSiblings(container) {
    const hiddenSiblings = [];
    [].forEach.call(container.children, (element) => {
      if (element.getAttribute("aria-hidden") === "true") {
        hiddenSiblings.push(element);
      }
    });
    return hiddenSiblings;
  }
  class ModalManager {
    constructor() {
      this.containers = void 0;
      this.modals = void 0;
      this.modals = [];
      this.containers = [];
    }
    add(modal, container) {
      let modalIndex = this.modals.indexOf(modal);
      if (modalIndex !== -1) {
        return modalIndex;
      }
      modalIndex = this.modals.length;
      this.modals.push(modal);
      if (modal.modalRef) {
        ariaHidden(modal.modalRef, false);
      }
      const hiddenSiblings = getHiddenSiblings(container);
      ariaHiddenSiblings(container, modal.mount, modal.modalRef, hiddenSiblings, true);
      const containerIndex = findIndexOf(this.containers, (item) => item.container === container);
      if (containerIndex !== -1) {
        this.containers[containerIndex].modals.push(modal);
        return modalIndex;
      }
      this.containers.push({
        modals: [modal],
        container,
        restore: null,
        hiddenSiblings
      });
      return modalIndex;
    }
    mount(modal, props) {
      const containerIndex = findIndexOf(this.containers, (item) => item.modals.indexOf(modal) !== -1);
      const containerInfo = this.containers[containerIndex];
      if (!containerInfo.restore) {
        containerInfo.restore = handleContainer(containerInfo, props);
      }
    }
    remove(modal, ariaHiddenState = true) {
      const modalIndex = this.modals.indexOf(modal);
      if (modalIndex === -1) {
        return modalIndex;
      }
      const containerIndex = findIndexOf(this.containers, (item) => item.modals.indexOf(modal) !== -1);
      const containerInfo = this.containers[containerIndex];
      containerInfo.modals.splice(containerInfo.modals.indexOf(modal), 1);
      this.modals.splice(modalIndex, 1);
      if (containerInfo.modals.length === 0) {
        if (containerInfo.restore) {
          containerInfo.restore();
        }
        if (modal.modalRef) {
          ariaHidden(modal.modalRef, ariaHiddenState);
        }
        ariaHiddenSiblings(containerInfo.container, modal.mount, modal.modalRef, containerInfo.hiddenSiblings, false);
        this.containers.splice(containerIndex, 1);
      } else {
        const nextTop = containerInfo.modals[containerInfo.modals.length - 1];
        if (nextTop.modalRef) {
          ariaHidden(nextTop.modalRef, false);
        }
      }
      return modalIndex;
    }
    isTopModal(modal) {
      return this.modals.length > 0 && this.modals[this.modals.length - 1] === modal;
    }
  }
  function getModalUtilityClass(slot) {
    return generateUtilityClass("MuiModal", slot);
  }
  generateUtilityClasses("MuiModal", ["root", "hidden"]);
  const _excluded$G = ["children", "classes", "closeAfterTransition", "component", "components", "componentsProps", "container", "disableAutoFocus", "disableEnforceFocus", "disableEscapeKeyDown", "disablePortal", "disableRestoreFocus", "disableScrollLock", "hideBackdrop", "keepMounted", "manager", "onBackdropClick", "onClose", "onKeyDown", "open", "onTransitionEnter", "onTransitionExited"];
  const useUtilityClasses$u = (ownerState) => {
    const {
      open,
      exited,
      classes
    } = ownerState;
    const slots = {
      root: ["root", !open && exited && "hidden"]
    };
    return composeClasses(slots, getModalUtilityClass, classes);
  };
  function getContainer(container) {
    return typeof container === "function" ? container() : container;
  }
  function getHasTransition(props) {
    return props.children ? props.children.props.hasOwnProperty("in") : false;
  }
  const defaultManager = new ModalManager();
  const ModalUnstyled = /* @__PURE__ */ react.exports.forwardRef(function ModalUnstyled2(props, ref) {
    var _props$ariaHidden;
    const {
      children,
      classes: classesProp,
      closeAfterTransition = false,
      component = "div",
      components = {},
      componentsProps = {},
      container,
      disableAutoFocus = false,
      disableEnforceFocus = false,
      disableEscapeKeyDown = false,
      disablePortal = false,
      disableRestoreFocus = false,
      disableScrollLock = false,
      hideBackdrop = false,
      keepMounted = false,
      manager = defaultManager,
      onBackdropClick,
      onClose,
      onKeyDown,
      open,
      onTransitionEnter,
      onTransitionExited
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$G);
    const [exited, setExited] = react.exports.useState(true);
    const modal = react.exports.useRef({});
    const mountNodeRef = react.exports.useRef(null);
    const modalRef = react.exports.useRef(null);
    const handleRef = useForkRef(modalRef, ref);
    const hasTransition = getHasTransition(props);
    const ariaHiddenProp = (_props$ariaHidden = props["aria-hidden"]) != null ? _props$ariaHidden : true;
    const getDoc = () => ownerDocument(mountNodeRef.current);
    const getModal = () => {
      modal.current.modalRef = modalRef.current;
      modal.current.mountNode = mountNodeRef.current;
      return modal.current;
    };
    const handleMounted = () => {
      manager.mount(getModal(), {
        disableScrollLock
      });
      modalRef.current.scrollTop = 0;
    };
    const handleOpen = useEventCallback(() => {
      const resolvedContainer = getContainer(container) || getDoc().body;
      manager.add(getModal(), resolvedContainer);
      if (modalRef.current) {
        handleMounted();
      }
    });
    const isTopModal = react.exports.useCallback(() => manager.isTopModal(getModal()), [manager]);
    const handlePortalRef = useEventCallback((node2) => {
      mountNodeRef.current = node2;
      if (!node2) {
        return;
      }
      if (open && isTopModal()) {
        handleMounted();
      } else {
        ariaHidden(modalRef.current, ariaHiddenProp);
      }
    });
    const handleClose = react.exports.useCallback(() => {
      manager.remove(getModal(), ariaHiddenProp);
    }, [manager, ariaHiddenProp]);
    react.exports.useEffect(() => {
      return () => {
        handleClose();
      };
    }, [handleClose]);
    react.exports.useEffect(() => {
      if (open) {
        handleOpen();
      } else if (!hasTransition || !closeAfterTransition) {
        handleClose();
      }
    }, [open, handleClose, hasTransition, closeAfterTransition, handleOpen]);
    const ownerState = _extends({}, props, {
      classes: classesProp,
      closeAfterTransition,
      disableAutoFocus,
      disableEnforceFocus,
      disableEscapeKeyDown,
      disablePortal,
      disableRestoreFocus,
      disableScrollLock,
      exited,
      hideBackdrop,
      keepMounted
    });
    const classes = useUtilityClasses$u(ownerState);
    const handleEnter = () => {
      setExited(false);
      if (onTransitionEnter) {
        onTransitionEnter();
      }
    };
    const handleExited = () => {
      setExited(true);
      if (onTransitionExited) {
        onTransitionExited();
      }
      if (closeAfterTransition) {
        handleClose();
      }
    };
    const handleBackdropClick = (event) => {
      if (event.target !== event.currentTarget) {
        return;
      }
      if (onBackdropClick) {
        onBackdropClick(event);
      }
      if (onClose) {
        onClose(event, "backdropClick");
      }
    };
    const handleKeyDown2 = (event) => {
      if (onKeyDown) {
        onKeyDown(event);
      }
      if (event.key !== "Escape" || !isTopModal()) {
        return;
      }
      if (!disableEscapeKeyDown) {
        event.stopPropagation();
        if (onClose) {
          onClose(event, "escapeKeyDown");
        }
      }
    };
    const childProps = {};
    if (children.props.tabIndex === void 0) {
      childProps.tabIndex = "-1";
    }
    if (hasTransition) {
      childProps.onEnter = createChainedFunction(handleEnter, children.props.onEnter);
      childProps.onExited = createChainedFunction(handleExited, children.props.onExited);
    }
    const Root = components.Root || component;
    const rootProps = useSlotProps({
      elementType: Root,
      externalSlotProps: componentsProps.root,
      externalForwardedProps: other,
      additionalProps: {
        ref: handleRef,
        role: "presentation",
        onKeyDown: handleKeyDown2
      },
      className: classes.root,
      ownerState
    });
    const BackdropComponent = components.Backdrop;
    const backdropProps = useSlotProps({
      elementType: BackdropComponent,
      externalSlotProps: componentsProps.backdrop,
      additionalProps: {
        "aria-hidden": true,
        onClick: handleBackdropClick,
        open
      },
      ownerState
    });
    if (!keepMounted && !open && (!hasTransition || exited)) {
      return null;
    }
    return /* @__PURE__ */ jsx(Portal$1, {
      ref: handlePortalRef,
      container,
      disablePortal,
      children: /* @__PURE__ */ jsxs(Root, _extends({}, rootProps, {
        children: [!hideBackdrop && BackdropComponent ? /* @__PURE__ */ jsx(BackdropComponent, _extends({}, backdropProps)) : null, /* @__PURE__ */ jsx(FocusTrap, {
          disableEnforceFocus,
          disableAutoFocus,
          disableRestoreFocus,
          isEnabled: isTopModal,
          open,
          children: /* @__PURE__ */ react.exports.cloneElement(children, childProps)
        })]
      }))
    });
  });
  const ModalUnstyled$1 = ModalUnstyled;
  const _excluded$F = ["onChange", "maxRows", "minRows", "style", "value"];
  function getStyleValue(computedStyle, property) {
    return parseInt(computedStyle[property], 10) || 0;
  }
  const styles$3 = {
    shadow: {
      visibility: "hidden",
      position: "absolute",
      overflow: "hidden",
      height: 0,
      top: 0,
      left: 0,
      transform: "translateZ(0)"
    }
  };
  function isEmpty$1(obj) {
    return obj === void 0 || obj === null || Object.keys(obj).length === 0;
  }
  const TextareaAutosize = /* @__PURE__ */ react.exports.forwardRef(function TextareaAutosize2(props, ref) {
    const {
      onChange,
      maxRows,
      minRows = 1,
      style: style2,
      value
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$F);
    const {
      current: isControlled
    } = react.exports.useRef(value != null);
    const inputRef = react.exports.useRef(null);
    const handleRef = useForkRef(ref, inputRef);
    const shadowRef = react.exports.useRef(null);
    const renders = react.exports.useRef(0);
    const [state, setState] = react.exports.useState({});
    const getUpdatedState = react.exports.useCallback(() => {
      const input = inputRef.current;
      const containerWindow = ownerWindow(input);
      const computedStyle = containerWindow.getComputedStyle(input);
      if (computedStyle.width === "0px") {
        return {};
      }
      const inputShallow = shadowRef.current;
      inputShallow.style.width = computedStyle.width;
      inputShallow.value = input.value || props.placeholder || "x";
      if (inputShallow.value.slice(-1) === "\n") {
        inputShallow.value += " ";
      }
      const boxSizing2 = computedStyle["box-sizing"];
      const padding = getStyleValue(computedStyle, "padding-bottom") + getStyleValue(computedStyle, "padding-top");
      const border2 = getStyleValue(computedStyle, "border-bottom-width") + getStyleValue(computedStyle, "border-top-width");
      const innerHeight2 = inputShallow.scrollHeight;
      inputShallow.value = "x";
      const singleRowHeight = inputShallow.scrollHeight;
      let outerHeight2 = innerHeight2;
      if (minRows) {
        outerHeight2 = Math.max(Number(minRows) * singleRowHeight, outerHeight2);
      }
      if (maxRows) {
        outerHeight2 = Math.min(Number(maxRows) * singleRowHeight, outerHeight2);
      }
      outerHeight2 = Math.max(outerHeight2, singleRowHeight);
      const outerHeightStyle = outerHeight2 + (boxSizing2 === "border-box" ? padding + border2 : 0);
      const overflow2 = Math.abs(outerHeight2 - innerHeight2) <= 1;
      return {
        outerHeightStyle,
        overflow: overflow2
      };
    }, [maxRows, minRows, props.placeholder]);
    const updateState = (prevState, newState) => {
      const {
        outerHeightStyle,
        overflow: overflow2
      } = newState;
      if (renders.current < 20 && (outerHeightStyle > 0 && Math.abs((prevState.outerHeightStyle || 0) - outerHeightStyle) > 1 || prevState.overflow !== overflow2)) {
        renders.current += 1;
        return {
          overflow: overflow2,
          outerHeightStyle
        };
      }
      return prevState;
    };
    const syncHeight = react.exports.useCallback(() => {
      const newState = getUpdatedState();
      if (isEmpty$1(newState)) {
        return;
      }
      setState((prevState) => {
        return updateState(prevState, newState);
      });
    }, [getUpdatedState]);
    const syncHeightWithFlushSycn = () => {
      const newState = getUpdatedState();
      if (isEmpty$1(newState)) {
        return;
      }
      reactDom.exports.flushSync(() => {
        setState((prevState) => {
          return updateState(prevState, newState);
        });
      });
    };
    react.exports.useEffect(() => {
      const handleResize = debounce$1(() => {
        renders.current = 0;
        if (inputRef.current) {
          syncHeightWithFlushSycn();
        }
      });
      const containerWindow = ownerWindow(inputRef.current);
      containerWindow.addEventListener("resize", handleResize);
      let resizeObserver;
      if (typeof ResizeObserver !== "undefined") {
        resizeObserver = new ResizeObserver(handleResize);
        resizeObserver.observe(inputRef.current);
      }
      return () => {
        handleResize.clear();
        containerWindow.removeEventListener("resize", handleResize);
        if (resizeObserver) {
          resizeObserver.disconnect();
        }
      };
    });
    useEnhancedEffect$1(() => {
      syncHeight();
    });
    react.exports.useEffect(() => {
      renders.current = 0;
    }, [value]);
    const handleChange = (event) => {
      renders.current = 0;
      if (!isControlled) {
        syncHeight();
      }
      if (onChange) {
        onChange(event);
      }
    };
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx("textarea", _extends({
        value,
        onChange: handleChange,
        ref: handleRef,
        rows: minRows,
        style: _extends({
          height: state.outerHeightStyle,
          overflow: state.overflow ? "hidden" : null
        }, style2)
      }, other)), /* @__PURE__ */ jsx("textarea", {
        "aria-hidden": true,
        className: props.className,
        readOnly: true,
        ref: shadowRef,
        tabIndex: -1,
        style: _extends({}, styles$3.shadow, style2, {
          padding: 0
        })
      })]
    });
  });
  const TextareaAutosize$1 = TextareaAutosize;
  function createMixins(breakpoints, mixins) {
    return _extends({
      toolbar: {
        minHeight: 56,
        [breakpoints.up("xs")]: {
          "@media (orientation: landscape)": {
            minHeight: 48
          }
        },
        [breakpoints.up("sm")]: {
          minHeight: 64
        }
      }
    }, mixins);
  }
  const _excluded$E = ["mode", "contrastThreshold", "tonalOffset"];
  const light = {
    text: {
      primary: "rgba(0, 0, 0, 0.87)",
      secondary: "rgba(0, 0, 0, 0.6)",
      disabled: "rgba(0, 0, 0, 0.38)"
    },
    divider: "rgba(0, 0, 0, 0.12)",
    background: {
      paper: common$1.white,
      default: common$1.white
    },
    action: {
      active: "rgba(0, 0, 0, 0.54)",
      hover: "rgba(0, 0, 0, 0.04)",
      hoverOpacity: 0.04,
      selected: "rgba(0, 0, 0, 0.08)",
      selectedOpacity: 0.08,
      disabled: "rgba(0, 0, 0, 0.26)",
      disabledBackground: "rgba(0, 0, 0, 0.12)",
      disabledOpacity: 0.38,
      focus: "rgba(0, 0, 0, 0.12)",
      focusOpacity: 0.12,
      activatedOpacity: 0.12
    }
  };
  const dark = {
    text: {
      primary: common$1.white,
      secondary: "rgba(255, 255, 255, 0.7)",
      disabled: "rgba(255, 255, 255, 0.5)",
      icon: "rgba(255, 255, 255, 0.5)"
    },
    divider: "rgba(255, 255, 255, 0.12)",
    background: {
      paper: "#121212",
      default: "#121212"
    },
    action: {
      active: common$1.white,
      hover: "rgba(255, 255, 255, 0.08)",
      hoverOpacity: 0.08,
      selected: "rgba(255, 255, 255, 0.16)",
      selectedOpacity: 0.16,
      disabled: "rgba(255, 255, 255, 0.3)",
      disabledBackground: "rgba(255, 255, 255, 0.12)",
      disabledOpacity: 0.38,
      focus: "rgba(255, 255, 255, 0.12)",
      focusOpacity: 0.12,
      activatedOpacity: 0.24
    }
  };
  function addLightOrDark(intent, direction, shade, tonalOffset) {
    const tonalOffsetLight = tonalOffset.light || tonalOffset;
    const tonalOffsetDark = tonalOffset.dark || tonalOffset * 1.5;
    if (!intent[direction]) {
      if (intent.hasOwnProperty(shade)) {
        intent[direction] = intent[shade];
      } else if (direction === "light") {
        intent.light = lighten(intent.main, tonalOffsetLight);
      } else if (direction === "dark") {
        intent.dark = darken(intent.main, tonalOffsetDark);
      }
    }
  }
  function getDefaultPrimary(mode = "light") {
    if (mode === "dark") {
      return {
        main: blue$1[200],
        light: blue$1[50],
        dark: blue$1[400]
      };
    }
    return {
      main: blue$1[700],
      light: blue$1[400],
      dark: blue$1[800]
    };
  }
  function getDefaultSecondary(mode = "light") {
    if (mode === "dark") {
      return {
        main: purple$1[200],
        light: purple$1[50],
        dark: purple$1[400]
      };
    }
    return {
      main: purple$1[500],
      light: purple$1[300],
      dark: purple$1[700]
    };
  }
  function getDefaultError(mode = "light") {
    if (mode === "dark") {
      return {
        main: red$1[500],
        light: red$1[300],
        dark: red$1[700]
      };
    }
    return {
      main: red$1[700],
      light: red$1[400],
      dark: red$1[800]
    };
  }
  function getDefaultInfo(mode = "light") {
    if (mode === "dark") {
      return {
        main: lightBlue$1[400],
        light: lightBlue$1[300],
        dark: lightBlue$1[700]
      };
    }
    return {
      main: lightBlue$1[700],
      light: lightBlue$1[500],
      dark: lightBlue$1[900]
    };
  }
  function getDefaultSuccess(mode = "light") {
    if (mode === "dark") {
      return {
        main: green$1[400],
        light: green$1[300],
        dark: green$1[700]
      };
    }
    return {
      main: green$1[800],
      light: green$1[500],
      dark: green$1[900]
    };
  }
  function getDefaultWarning(mode = "light") {
    if (mode === "dark") {
      return {
        main: orange$1[400],
        light: orange$1[300],
        dark: orange$1[700]
      };
    }
    return {
      main: "#ed6c02",
      light: orange$1[500],
      dark: orange$1[900]
    };
  }
  function createPalette(palette2) {
    const {
      mode = "light",
      contrastThreshold = 3,
      tonalOffset = 0.2
    } = palette2, other = _objectWithoutPropertiesLoose(palette2, _excluded$E);
    const primary = palette2.primary || getDefaultPrimary(mode);
    const secondary = palette2.secondary || getDefaultSecondary(mode);
    const error = palette2.error || getDefaultError(mode);
    const info = palette2.info || getDefaultInfo(mode);
    const success = palette2.success || getDefaultSuccess(mode);
    const warning = palette2.warning || getDefaultWarning(mode);
    function getContrastText(background) {
      const contrastText = getContrastRatio(background, dark.text.primary) >= contrastThreshold ? dark.text.primary : light.text.primary;
      return contrastText;
    }
    const augmentColor = ({
      color: color2,
      name,
      mainShade = 500,
      lightShade = 300,
      darkShade = 700
    }) => {
      color2 = _extends({}, color2);
      if (!color2.main && color2[mainShade]) {
        color2.main = color2[mainShade];
      }
      if (!color2.hasOwnProperty("main")) {
        throw new Error(formatMuiErrorMessage(11, name ? ` (${name})` : "", mainShade));
      }
      if (typeof color2.main !== "string") {
        throw new Error(formatMuiErrorMessage(12, name ? ` (${name})` : "", JSON.stringify(color2.main)));
      }
      addLightOrDark(color2, "light", lightShade, tonalOffset);
      addLightOrDark(color2, "dark", darkShade, tonalOffset);
      if (!color2.contrastText) {
        color2.contrastText = getContrastText(color2.main);
      }
      return color2;
    };
    const modes = {
      dark,
      light
    };
    const paletteOutput = deepmerge(_extends({
      common: _extends({}, common$1),
      mode,
      primary: augmentColor({
        color: primary,
        name: "primary"
      }),
      secondary: augmentColor({
        color: secondary,
        name: "secondary",
        mainShade: "A400",
        lightShade: "A200",
        darkShade: "A700"
      }),
      error: augmentColor({
        color: error,
        name: "error"
      }),
      warning: augmentColor({
        color: warning,
        name: "warning"
      }),
      info: augmentColor({
        color: info,
        name: "info"
      }),
      success: augmentColor({
        color: success,
        name: "success"
      }),
      grey: grey$1,
      contrastThreshold,
      getContrastText,
      augmentColor,
      tonalOffset
    }, modes[mode]), other);
    return paletteOutput;
  }
  const _excluded$D = ["fontFamily", "fontSize", "fontWeightLight", "fontWeightRegular", "fontWeightMedium", "fontWeightBold", "htmlFontSize", "allVariants", "pxToRem"];
  function round(value) {
    return Math.round(value * 1e5) / 1e5;
  }
  const caseAllCaps = {
    textTransform: "uppercase"
  };
  const defaultFontFamily = '"Roboto", "Helvetica", "Arial", sans-serif';
  function createTypography(palette2, typography2) {
    const _ref = typeof typography2 === "function" ? typography2(palette2) : typography2, {
      fontFamily: fontFamily2 = defaultFontFamily,
      fontSize: fontSize2 = 14,
      fontWeightLight = 300,
      fontWeightRegular = 400,
      fontWeightMedium = 500,
      fontWeightBold = 700,
      htmlFontSize = 16,
      allVariants,
      pxToRem: pxToRem2
    } = _ref, other = _objectWithoutPropertiesLoose(_ref, _excluded$D);
    const coef = fontSize2 / 14;
    const pxToRem = pxToRem2 || ((size) => `${size / htmlFontSize * coef}rem`);
    const buildVariant = (fontWeight2, size, lineHeight2, letterSpacing2, casing) => _extends({
      fontFamily: fontFamily2,
      fontWeight: fontWeight2,
      fontSize: pxToRem(size),
      lineHeight: lineHeight2
    }, fontFamily2 === defaultFontFamily ? {
      letterSpacing: `${round(letterSpacing2 / size)}em`
    } : {}, casing, allVariants);
    const variants = {
      h1: buildVariant(fontWeightLight, 96, 1.167, -1.5),
      h2: buildVariant(fontWeightLight, 60, 1.2, -0.5),
      h3: buildVariant(fontWeightRegular, 48, 1.167, 0),
      h4: buildVariant(fontWeightRegular, 34, 1.235, 0.25),
      h5: buildVariant(fontWeightRegular, 24, 1.334, 0),
      h6: buildVariant(fontWeightMedium, 20, 1.6, 0.15),
      subtitle1: buildVariant(fontWeightRegular, 16, 1.75, 0.15),
      subtitle2: buildVariant(fontWeightMedium, 14, 1.57, 0.1),
      body1: buildVariant(fontWeightRegular, 16, 1.5, 0.15),
      body2: buildVariant(fontWeightRegular, 14, 1.43, 0.15),
      button: buildVariant(fontWeightMedium, 14, 1.75, 0.4, caseAllCaps),
      caption: buildVariant(fontWeightRegular, 12, 1.66, 0.4),
      overline: buildVariant(fontWeightRegular, 12, 2.66, 1, caseAllCaps)
    };
    return deepmerge(_extends({
      htmlFontSize,
      pxToRem,
      fontFamily: fontFamily2,
      fontSize: fontSize2,
      fontWeightLight,
      fontWeightRegular,
      fontWeightMedium,
      fontWeightBold
    }, variants), other, {
      clone: false
    });
  }
  const shadowKeyUmbraOpacity = 0.2;
  const shadowKeyPenumbraOpacity = 0.14;
  const shadowAmbientShadowOpacity = 0.12;
  function createShadow(...px) {
    return [`${px[0]}px ${px[1]}px ${px[2]}px ${px[3]}px rgba(0,0,0,${shadowKeyUmbraOpacity})`, `${px[4]}px ${px[5]}px ${px[6]}px ${px[7]}px rgba(0,0,0,${shadowKeyPenumbraOpacity})`, `${px[8]}px ${px[9]}px ${px[10]}px ${px[11]}px rgba(0,0,0,${shadowAmbientShadowOpacity})`].join(",");
  }
  const shadows = ["none", createShadow(0, 2, 1, -1, 0, 1, 1, 0, 0, 1, 3, 0), createShadow(0, 3, 1, -2, 0, 2, 2, 0, 0, 1, 5, 0), createShadow(0, 3, 3, -2, 0, 3, 4, 0, 0, 1, 8, 0), createShadow(0, 2, 4, -1, 0, 4, 5, 0, 0, 1, 10, 0), createShadow(0, 3, 5, -1, 0, 5, 8, 0, 0, 1, 14, 0), createShadow(0, 3, 5, -1, 0, 6, 10, 0, 0, 1, 18, 0), createShadow(0, 4, 5, -2, 0, 7, 10, 1, 0, 2, 16, 1), createShadow(0, 5, 5, -3, 0, 8, 10, 1, 0, 3, 14, 2), createShadow(0, 5, 6, -3, 0, 9, 12, 1, 0, 3, 16, 2), createShadow(0, 6, 6, -3, 0, 10, 14, 1, 0, 4, 18, 3), createShadow(0, 6, 7, -4, 0, 11, 15, 1, 0, 4, 20, 3), createShadow(0, 7, 8, -4, 0, 12, 17, 2, 0, 5, 22, 4), createShadow(0, 7, 8, -4, 0, 13, 19, 2, 0, 5, 24, 4), createShadow(0, 7, 9, -4, 0, 14, 21, 2, 0, 5, 26, 4), createShadow(0, 8, 9, -5, 0, 15, 22, 2, 0, 6, 28, 5), createShadow(0, 8, 10, -5, 0, 16, 24, 2, 0, 6, 30, 5), createShadow(0, 8, 11, -5, 0, 17, 26, 2, 0, 6, 32, 5), createShadow(0, 9, 11, -5, 0, 18, 28, 2, 0, 7, 34, 6), createShadow(0, 9, 12, -6, 0, 19, 29, 2, 0, 7, 36, 6), createShadow(0, 10, 13, -6, 0, 20, 31, 3, 0, 8, 38, 7), createShadow(0, 10, 13, -6, 0, 21, 33, 3, 0, 8, 40, 7), createShadow(0, 10, 14, -6, 0, 22, 35, 3, 0, 8, 42, 7), createShadow(0, 11, 14, -7, 0, 23, 36, 3, 0, 9, 44, 8), createShadow(0, 11, 15, -7, 0, 24, 38, 3, 0, 9, 46, 8)];
  const shadows$1 = shadows;
  const _excluded$C = ["duration", "easing", "delay"];
  const easing = {
    easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
    easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
    easeIn: "cubic-bezier(0.4, 0, 1, 1)",
    sharp: "cubic-bezier(0.4, 0, 0.6, 1)"
  };
  const duration = {
    shortest: 150,
    shorter: 200,
    short: 250,
    standard: 300,
    complex: 375,
    enteringScreen: 225,
    leavingScreen: 195
  };
  function formatMs(milliseconds) {
    return `${Math.round(milliseconds)}ms`;
  }
  function getAutoHeightDuration(height2) {
    if (!height2) {
      return 0;
    }
    const constant = height2 / 36;
    return Math.round((4 + 15 * constant ** 0.25 + constant / 5) * 10);
  }
  function createTransitions(inputTransitions) {
    const mergedEasing = _extends({}, easing, inputTransitions.easing);
    const mergedDuration = _extends({}, duration, inputTransitions.duration);
    const create = (props = ["all"], options = {}) => {
      const {
        duration: durationOption = mergedDuration.standard,
        easing: easingOption = mergedEasing.easeInOut,
        delay = 0
      } = options;
      _objectWithoutPropertiesLoose(options, _excluded$C);
      return (Array.isArray(props) ? props : [props]).map((animatedProp) => `${animatedProp} ${typeof durationOption === "string" ? durationOption : formatMs(durationOption)} ${easingOption} ${typeof delay === "string" ? delay : formatMs(delay)}`).join(",");
    };
    return _extends({
      getAutoHeightDuration,
      create
    }, inputTransitions, {
      easing: mergedEasing,
      duration: mergedDuration
    });
  }
  const zIndex = {
    mobileStepper: 1e3,
    fab: 1050,
    speedDial: 1050,
    appBar: 1100,
    drawer: 1200,
    modal: 1300,
    snackbar: 1400,
    tooltip: 1500
  };
  const zIndex$1 = zIndex;
  const _excluded$B = ["breakpoints", "mixins", "spacing", "palette", "transitions", "typography", "shape"];
  function createTheme(options = {}, ...args) {
    const {
      mixins: mixinsInput = {},
      palette: paletteInput = {},
      transitions: transitionsInput = {},
      typography: typographyInput = {}
    } = options, other = _objectWithoutPropertiesLoose(options, _excluded$B);
    if (options.vars) {
      throw new Error(formatMuiErrorMessage(18));
    }
    const palette2 = createPalette(paletteInput);
    const systemTheme = createTheme$1(options);
    let muiTheme = deepmerge(systemTheme, {
      mixins: createMixins(systemTheme.breakpoints, mixinsInput),
      palette: palette2,
      shadows: shadows$1.slice(),
      typography: createTypography(palette2, typographyInput),
      transitions: createTransitions(transitionsInput),
      zIndex: _extends({}, zIndex$1)
    });
    muiTheme = deepmerge(muiTheme, other);
    muiTheme = args.reduce((acc, argument) => deepmerge(acc, argument), muiTheme);
    return muiTheme;
  }
  const defaultTheme$1 = createTheme();
  const defaultTheme$2 = defaultTheme$1;
  function useTheme() {
    const theme = useTheme$1(defaultTheme$2);
    return theme;
  }
  function useThemeProps({
    props,
    name
  }) {
    return useThemeProps$1({
      props,
      name,
      defaultTheme: defaultTheme$2
    });
  }
  const rootShouldForwardProp = (prop) => shouldForwardProp(prop) && prop !== "classes";
  const slotShouldForwardProp = shouldForwardProp;
  const styled = createStyled({
    defaultTheme: defaultTheme$2,
    rootShouldForwardProp
  });
  const styled$1 = styled;
  function getPaperUtilityClass(slot) {
    return generateUtilityClass("MuiPaper", slot);
  }
  generateUtilityClasses("MuiPaper", ["root", "rounded", "outlined", "elevation", "elevation0", "elevation1", "elevation2", "elevation3", "elevation4", "elevation5", "elevation6", "elevation7", "elevation8", "elevation9", "elevation10", "elevation11", "elevation12", "elevation13", "elevation14", "elevation15", "elevation16", "elevation17", "elevation18", "elevation19", "elevation20", "elevation21", "elevation22", "elevation23", "elevation24"]);
  const _excluded$A = ["className", "component", "elevation", "square", "variant"];
  const getOverlayAlpha = (elevation) => {
    let alphaValue;
    if (elevation < 1) {
      alphaValue = 5.11916 * elevation ** 2;
    } else {
      alphaValue = 4.5 * Math.log(elevation + 1) + 2;
    }
    return (alphaValue / 100).toFixed(2);
  };
  const useUtilityClasses$t = (ownerState) => {
    const {
      square,
      elevation,
      variant,
      classes
    } = ownerState;
    const slots = {
      root: ["root", variant, !square && "rounded", variant === "elevation" && `elevation${elevation}`]
    };
    return composeClasses(slots, getPaperUtilityClass, classes);
  };
  const PaperRoot = styled$1("div", {
    name: "MuiPaper",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, styles2[ownerState.variant], !ownerState.square && styles2.rounded, ownerState.variant === "elevation" && styles2[`elevation${ownerState.elevation}`]];
    }
  })(({
    theme,
    ownerState
  }) => {
    var _theme$vars$overlays;
    return _extends({
      backgroundColor: (theme.vars || theme).palette.background.paper,
      color: (theme.vars || theme).palette.text.primary,
      transition: theme.transitions.create("box-shadow")
    }, !ownerState.square && {
      borderRadius: theme.shape.borderRadius
    }, ownerState.variant === "outlined" && {
      border: `1px solid ${(theme.vars || theme).palette.divider}`
    }, ownerState.variant === "elevation" && _extends({
      boxShadow: (theme.vars || theme).shadows[ownerState.elevation]
    }, !theme.vars && theme.palette.mode === "dark" && {
      backgroundImage: `linear-gradient(${alpha("#fff", getOverlayAlpha(ownerState.elevation))}, ${alpha("#fff", getOverlayAlpha(ownerState.elevation))})`
    }, theme.vars && {
      backgroundImage: (_theme$vars$overlays = theme.vars.overlays) == null ? void 0 : _theme$vars$overlays[ownerState.elevation]
    }));
  });
  const Paper = /* @__PURE__ */ react.exports.forwardRef(function Paper2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiPaper"
    });
    const {
      className,
      component = "div",
      elevation = 1,
      square = false,
      variant = "elevation"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$A);
    const ownerState = _extends({}, props, {
      component,
      elevation,
      square,
      variant
    });
    const classes = useUtilityClasses$t(ownerState);
    return /* @__PURE__ */ jsx(PaperRoot, _extends({
      as: component,
      ownerState,
      className: clsx(classes.root, className),
      ref
    }, other));
  });
  const Paper$1 = Paper;
  function getSvgIconUtilityClass(slot) {
    return generateUtilityClass("MuiSvgIcon", slot);
  }
  generateUtilityClasses("MuiSvgIcon", ["root", "colorPrimary", "colorSecondary", "colorAction", "colorError", "colorDisabled", "fontSizeInherit", "fontSizeSmall", "fontSizeMedium", "fontSizeLarge"]);
  const _excluded$z = ["children", "className", "color", "component", "fontSize", "htmlColor", "inheritViewBox", "titleAccess", "viewBox"];
  const useUtilityClasses$s = (ownerState) => {
    const {
      color: color2,
      fontSize: fontSize2,
      classes
    } = ownerState;
    const slots = {
      root: ["root", color2 !== "inherit" && `color${capitalize(color2)}`, `fontSize${capitalize(fontSize2)}`]
    };
    return composeClasses(slots, getSvgIconUtilityClass, classes);
  };
  const SvgIconRoot = styled$1("svg", {
    name: "MuiSvgIcon",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.color !== "inherit" && styles2[`color${capitalize(ownerState.color)}`], styles2[`fontSize${capitalize(ownerState.fontSize)}`]];
    }
  })(({
    theme,
    ownerState
  }) => {
    var _theme$transitions, _theme$transitions$cr, _theme$transitions2, _theme$transitions2$d, _theme$typography, _theme$typography$pxT, _theme$typography2, _theme$typography2$px, _theme$typography3, _theme$typography3$px, _palette$ownerState$c, _palette, _palette$ownerState$c2, _palette2, _palette2$action, _palette3, _palette3$action;
    return {
      userSelect: "none",
      width: "1em",
      height: "1em",
      display: "inline-block",
      fill: "currentColor",
      flexShrink: 0,
      transition: (_theme$transitions = theme.transitions) == null ? void 0 : (_theme$transitions$cr = _theme$transitions.create) == null ? void 0 : _theme$transitions$cr.call(_theme$transitions, "fill", {
        duration: (_theme$transitions2 = theme.transitions) == null ? void 0 : (_theme$transitions2$d = _theme$transitions2.duration) == null ? void 0 : _theme$transitions2$d.shorter
      }),
      fontSize: {
        inherit: "inherit",
        small: ((_theme$typography = theme.typography) == null ? void 0 : (_theme$typography$pxT = _theme$typography.pxToRem) == null ? void 0 : _theme$typography$pxT.call(_theme$typography, 20)) || "1.25rem",
        medium: ((_theme$typography2 = theme.typography) == null ? void 0 : (_theme$typography2$px = _theme$typography2.pxToRem) == null ? void 0 : _theme$typography2$px.call(_theme$typography2, 24)) || "1.5rem",
        large: ((_theme$typography3 = theme.typography) == null ? void 0 : (_theme$typography3$px = _theme$typography3.pxToRem) == null ? void 0 : _theme$typography3$px.call(_theme$typography3, 35)) || "2.1875rem"
      }[ownerState.fontSize],
      color: (_palette$ownerState$c = (_palette = (theme.vars || theme).palette) == null ? void 0 : (_palette$ownerState$c2 = _palette[ownerState.color]) == null ? void 0 : _palette$ownerState$c2.main) != null ? _palette$ownerState$c : {
        action: (_palette2 = (theme.vars || theme).palette) == null ? void 0 : (_palette2$action = _palette2.action) == null ? void 0 : _palette2$action.active,
        disabled: (_palette3 = (theme.vars || theme).palette) == null ? void 0 : (_palette3$action = _palette3.action) == null ? void 0 : _palette3$action.disabled,
        inherit: void 0
      }[ownerState.color]
    };
  });
  const SvgIcon = /* @__PURE__ */ react.exports.forwardRef(function SvgIcon2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiSvgIcon"
    });
    const {
      children,
      className,
      color: color2 = "inherit",
      component = "svg",
      fontSize: fontSize2 = "medium",
      htmlColor,
      inheritViewBox = false,
      titleAccess,
      viewBox = "0 0 24 24"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$z);
    const ownerState = _extends({}, props, {
      color: color2,
      component,
      fontSize: fontSize2,
      instanceFontSize: inProps.fontSize,
      inheritViewBox,
      viewBox
    });
    const more = {};
    if (!inheritViewBox) {
      more.viewBox = viewBox;
    }
    const classes = useUtilityClasses$s(ownerState);
    return /* @__PURE__ */ jsxs(SvgIconRoot, _extends({
      as: component,
      className: clsx(classes.root, className),
      focusable: "false",
      color: htmlColor,
      "aria-hidden": titleAccess ? void 0 : true,
      role: titleAccess ? "img" : void 0,
      ref
    }, more, other, {
      ownerState,
      children: [children, titleAccess ? /* @__PURE__ */ jsx("title", {
        children: titleAccess
      }) : null]
    }));
  });
  SvgIcon.muiName = "SvgIcon";
  const SvgIcon$1 = SvgIcon;
  function createSvgIcon$1(path, displayName) {
    const Component = (props, ref) => /* @__PURE__ */ jsx(SvgIcon$1, _extends({
      "data-testid": `${displayName}Icon`,
      ref
    }, props, {
      children: path
    }));
    Component.muiName = SvgIcon$1.muiName;
    return /* @__PURE__ */ react.exports.memo(/* @__PURE__ */ react.exports.forwardRef(Component));
  }
  const unstable_ClassNameGenerator = {
    configure: (generator) => {
      console.warn(["MUI: `ClassNameGenerator` import from `@mui/material/utils` is outdated and might cause unexpected issues.", "", "You should use `import { unstable_ClassNameGenerator } from '@mui/material/className'` instead", "", "The detail of the issue: https://github.com/mui/material-ui/issues/30011#issuecomment-1024993401", "", "The updated documentation: https://mui.com/guides/classname-generator/"].join("\n"));
      ClassNameGenerator$1.configure(generator);
    }
  };
  const utils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    unstable_ClassNameGenerator,
    capitalize,
    createChainedFunction,
    createSvgIcon: createSvgIcon$1,
    debounce: debounce$1,
    deprecatedPropType,
    isMuiElement,
    ownerDocument,
    ownerWindow,
    requirePropFactory,
    setRef,
    unstable_useEnhancedEffect: useEnhancedEffect$1,
    unstable_useId: useId,
    unsupportedProp,
    useControlled,
    useEventCallback,
    useForkRef,
    useIsFocusVisible
  }, Symbol.toStringTag, { value: "Module" }));
  var reactIs = { exports: {} };
  var reactIs_production_min = {};
  /**
   * @license React
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var b = Symbol.for("react.element"), c = Symbol.for("react.portal"), d = Symbol.for("react.fragment"), e = Symbol.for("react.strict_mode"), f = Symbol.for("react.profiler"), g = Symbol.for("react.provider"), h = Symbol.for("react.context"), k = Symbol.for("react.server_context"), l = Symbol.for("react.forward_ref"), m = Symbol.for("react.suspense"), n = Symbol.for("react.suspense_list"), p = Symbol.for("react.memo"), q = Symbol.for("react.lazy"), t = Symbol.for("react.offscreen"), u;
  u = Symbol.for("react.module.reference");
  function v(a) {
    if ("object" === typeof a && null !== a) {
      var r2 = a.$$typeof;
      switch (r2) {
        case b:
          switch (a = a.type, a) {
            case d:
            case f:
            case e:
            case m:
            case n:
              return a;
            default:
              switch (a = a && a.$$typeof, a) {
                case k:
                case h:
                case l:
                case q:
                case p:
                case g:
                  return a;
                default:
                  return r2;
              }
          }
        case c:
          return r2;
      }
    }
  }
  reactIs_production_min.ContextConsumer = h;
  reactIs_production_min.ContextProvider = g;
  reactIs_production_min.Element = b;
  reactIs_production_min.ForwardRef = l;
  reactIs_production_min.Fragment = d;
  reactIs_production_min.Lazy = q;
  reactIs_production_min.Memo = p;
  reactIs_production_min.Portal = c;
  reactIs_production_min.Profiler = f;
  reactIs_production_min.StrictMode = e;
  reactIs_production_min.Suspense = m;
  reactIs_production_min.SuspenseList = n;
  reactIs_production_min.isAsyncMode = function() {
    return false;
  };
  reactIs_production_min.isConcurrentMode = function() {
    return false;
  };
  reactIs_production_min.isContextConsumer = function(a) {
    return v(a) === h;
  };
  reactIs_production_min.isContextProvider = function(a) {
    return v(a) === g;
  };
  reactIs_production_min.isElement = function(a) {
    return "object" === typeof a && null !== a && a.$$typeof === b;
  };
  reactIs_production_min.isForwardRef = function(a) {
    return v(a) === l;
  };
  reactIs_production_min.isFragment = function(a) {
    return v(a) === d;
  };
  reactIs_production_min.isLazy = function(a) {
    return v(a) === q;
  };
  reactIs_production_min.isMemo = function(a) {
    return v(a) === p;
  };
  reactIs_production_min.isPortal = function(a) {
    return v(a) === c;
  };
  reactIs_production_min.isProfiler = function(a) {
    return v(a) === f;
  };
  reactIs_production_min.isStrictMode = function(a) {
    return v(a) === e;
  };
  reactIs_production_min.isSuspense = function(a) {
    return v(a) === m;
  };
  reactIs_production_min.isSuspenseList = function(a) {
    return v(a) === n;
  };
  reactIs_production_min.isValidElementType = function(a) {
    return "string" === typeof a || "function" === typeof a || a === d || a === f || a === e || a === m || a === n || a === t || "object" === typeof a && null !== a && (a.$$typeof === q || a.$$typeof === p || a.$$typeof === g || a.$$typeof === h || a.$$typeof === l || a.$$typeof === u || void 0 !== a.getModuleId) ? true : false;
  };
  reactIs_production_min.typeOf = v;
  (function(module) {
    {
      module.exports = reactIs_production_min;
    }
  })(reactIs);
  function _setPrototypeOf$1(o, p2) {
    _setPrototypeOf$1 = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf2(o2, p3) {
      o2.__proto__ = p3;
      return o2;
    };
    return _setPrototypeOf$1(o, p2);
  }
  function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf$1(subClass, superClass);
  }
  const config = {
    disabled: false
  };
  const TransitionGroupContext = React$1.createContext(null);
  var forceReflow = function forceReflow2(node2) {
    return node2.scrollTop;
  };
  var UNMOUNTED = "unmounted";
  var EXITED = "exited";
  var ENTERING = "entering";
  var ENTERED = "entered";
  var EXITING = "exiting";
  var Transition = /* @__PURE__ */ function(_React$Component) {
    _inheritsLoose(Transition2, _React$Component);
    function Transition2(props, context) {
      var _this;
      _this = _React$Component.call(this, props, context) || this;
      var parentGroup = context;
      var appear = parentGroup && !parentGroup.isMounting ? props.enter : props.appear;
      var initialStatus;
      _this.appearStatus = null;
      if (props.in) {
        if (appear) {
          initialStatus = EXITED;
          _this.appearStatus = ENTERING;
        } else {
          initialStatus = ENTERED;
        }
      } else {
        if (props.unmountOnExit || props.mountOnEnter) {
          initialStatus = UNMOUNTED;
        } else {
          initialStatus = EXITED;
        }
      }
      _this.state = {
        status: initialStatus
      };
      _this.nextCallback = null;
      return _this;
    }
    Transition2.getDerivedStateFromProps = function getDerivedStateFromProps(_ref, prevState) {
      var nextIn = _ref.in;
      if (nextIn && prevState.status === UNMOUNTED) {
        return {
          status: EXITED
        };
      }
      return null;
    };
    var _proto = Transition2.prototype;
    _proto.componentDidMount = function componentDidMount() {
      this.updateStatus(true, this.appearStatus);
    };
    _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
      var nextStatus = null;
      if (prevProps !== this.props) {
        var status = this.state.status;
        if (this.props.in) {
          if (status !== ENTERING && status !== ENTERED) {
            nextStatus = ENTERING;
          }
        } else {
          if (status === ENTERING || status === ENTERED) {
            nextStatus = EXITING;
          }
        }
      }
      this.updateStatus(false, nextStatus);
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
      this.cancelNextCallback();
    };
    _proto.getTimeouts = function getTimeouts() {
      var timeout = this.props.timeout;
      var exit, enter, appear;
      exit = enter = appear = timeout;
      if (timeout != null && typeof timeout !== "number") {
        exit = timeout.exit;
        enter = timeout.enter;
        appear = timeout.appear !== void 0 ? timeout.appear : enter;
      }
      return {
        exit,
        enter,
        appear
      };
    };
    _proto.updateStatus = function updateStatus(mounting, nextStatus) {
      if (mounting === void 0) {
        mounting = false;
      }
      if (nextStatus !== null) {
        this.cancelNextCallback();
        if (nextStatus === ENTERING) {
          if (this.props.unmountOnExit || this.props.mountOnEnter) {
            var node2 = this.props.nodeRef ? this.props.nodeRef.current : ReactDOM.findDOMNode(this);
            if (node2)
              forceReflow(node2);
          }
          this.performEnter(mounting);
        } else {
          this.performExit();
        }
      } else if (this.props.unmountOnExit && this.state.status === EXITED) {
        this.setState({
          status: UNMOUNTED
        });
      }
    };
    _proto.performEnter = function performEnter(mounting) {
      var _this2 = this;
      var enter = this.props.enter;
      var appearing = this.context ? this.context.isMounting : mounting;
      var _ref2 = this.props.nodeRef ? [appearing] : [ReactDOM.findDOMNode(this), appearing], maybeNode = _ref2[0], maybeAppearing = _ref2[1];
      var timeouts = this.getTimeouts();
      var enterTimeout = appearing ? timeouts.appear : timeouts.enter;
      if (!mounting && !enter || config.disabled) {
        this.safeSetState({
          status: ENTERED
        }, function() {
          _this2.props.onEntered(maybeNode);
        });
        return;
      }
      this.props.onEnter(maybeNode, maybeAppearing);
      this.safeSetState({
        status: ENTERING
      }, function() {
        _this2.props.onEntering(maybeNode, maybeAppearing);
        _this2.onTransitionEnd(enterTimeout, function() {
          _this2.safeSetState({
            status: ENTERED
          }, function() {
            _this2.props.onEntered(maybeNode, maybeAppearing);
          });
        });
      });
    };
    _proto.performExit = function performExit() {
      var _this3 = this;
      var exit = this.props.exit;
      var timeouts = this.getTimeouts();
      var maybeNode = this.props.nodeRef ? void 0 : ReactDOM.findDOMNode(this);
      if (!exit || config.disabled) {
        this.safeSetState({
          status: EXITED
        }, function() {
          _this3.props.onExited(maybeNode);
        });
        return;
      }
      this.props.onExit(maybeNode);
      this.safeSetState({
        status: EXITING
      }, function() {
        _this3.props.onExiting(maybeNode);
        _this3.onTransitionEnd(timeouts.exit, function() {
          _this3.safeSetState({
            status: EXITED
          }, function() {
            _this3.props.onExited(maybeNode);
          });
        });
      });
    };
    _proto.cancelNextCallback = function cancelNextCallback() {
      if (this.nextCallback !== null) {
        this.nextCallback.cancel();
        this.nextCallback = null;
      }
    };
    _proto.safeSetState = function safeSetState(nextState, callback) {
      callback = this.setNextCallback(callback);
      this.setState(nextState, callback);
    };
    _proto.setNextCallback = function setNextCallback(callback) {
      var _this4 = this;
      var active = true;
      this.nextCallback = function(event) {
        if (active) {
          active = false;
          _this4.nextCallback = null;
          callback(event);
        }
      };
      this.nextCallback.cancel = function() {
        active = false;
      };
      return this.nextCallback;
    };
    _proto.onTransitionEnd = function onTransitionEnd(timeout, handler) {
      this.setNextCallback(handler);
      var node2 = this.props.nodeRef ? this.props.nodeRef.current : ReactDOM.findDOMNode(this);
      var doesNotHaveTimeoutOrListener = timeout == null && !this.props.addEndListener;
      if (!node2 || doesNotHaveTimeoutOrListener) {
        setTimeout(this.nextCallback, 0);
        return;
      }
      if (this.props.addEndListener) {
        var _ref3 = this.props.nodeRef ? [this.nextCallback] : [node2, this.nextCallback], maybeNode = _ref3[0], maybeNextCallback = _ref3[1];
        this.props.addEndListener(maybeNode, maybeNextCallback);
      }
      if (timeout != null) {
        setTimeout(this.nextCallback, timeout);
      }
    };
    _proto.render = function render() {
      var status = this.state.status;
      if (status === UNMOUNTED) {
        return null;
      }
      var _this$props = this.props, children = _this$props.children;
      _this$props.in;
      _this$props.mountOnEnter;
      _this$props.unmountOnExit;
      _this$props.appear;
      _this$props.enter;
      _this$props.exit;
      _this$props.timeout;
      _this$props.addEndListener;
      _this$props.onEnter;
      _this$props.onEntering;
      _this$props.onEntered;
      _this$props.onExit;
      _this$props.onExiting;
      _this$props.onExited;
      _this$props.nodeRef;
      var childProps = _objectWithoutPropertiesLoose(_this$props, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]);
      return /* @__PURE__ */ jsx(TransitionGroupContext.Provider, {
        value: null,
        children: typeof children === "function" ? children(status, childProps) : React$1.cloneElement(React$1.Children.only(children), childProps)
      });
    };
    return Transition2;
  }(React$1.Component);
  Transition.contextType = TransitionGroupContext;
  Transition.propTypes = {};
  function noop() {
  }
  Transition.defaultProps = {
    in: false,
    mountOnEnter: false,
    unmountOnExit: false,
    appear: false,
    enter: true,
    exit: true,
    onEnter: noop,
    onEntering: noop,
    onEntered: noop,
    onExit: noop,
    onExiting: noop,
    onExited: noop
  };
  Transition.UNMOUNTED = UNMOUNTED;
  Transition.EXITED = EXITED;
  Transition.ENTERING = ENTERING;
  Transition.ENTERED = ENTERED;
  Transition.EXITING = EXITING;
  const Transition$1 = Transition;
  function _assertThisInitialized$1(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function getChildMapping(children, mapFn) {
    var mapper = function mapper2(child) {
      return mapFn && react.exports.isValidElement(child) ? mapFn(child) : child;
    };
    var result = /* @__PURE__ */ Object.create(null);
    if (children)
      react.exports.Children.map(children, function(c2) {
        return c2;
      }).forEach(function(child) {
        result[child.key] = mapper(child);
      });
    return result;
  }
  function mergeChildMappings(prev2, next2) {
    prev2 = prev2 || {};
    next2 = next2 || {};
    function getValueForKey(key) {
      return key in next2 ? next2[key] : prev2[key];
    }
    var nextKeysPending = /* @__PURE__ */ Object.create(null);
    var pendingKeys = [];
    for (var prevKey in prev2) {
      if (prevKey in next2) {
        if (pendingKeys.length) {
          nextKeysPending[prevKey] = pendingKeys;
          pendingKeys = [];
        }
      } else {
        pendingKeys.push(prevKey);
      }
    }
    var i;
    var childMapping = {};
    for (var nextKey in next2) {
      if (nextKeysPending[nextKey]) {
        for (i = 0; i < nextKeysPending[nextKey].length; i++) {
          var pendingNextKey = nextKeysPending[nextKey][i];
          childMapping[nextKeysPending[nextKey][i]] = getValueForKey(pendingNextKey);
        }
      }
      childMapping[nextKey] = getValueForKey(nextKey);
    }
    for (i = 0; i < pendingKeys.length; i++) {
      childMapping[pendingKeys[i]] = getValueForKey(pendingKeys[i]);
    }
    return childMapping;
  }
  function getProp(child, prop, props) {
    return props[prop] != null ? props[prop] : child.props[prop];
  }
  function getInitialChildMapping(props, onExited) {
    return getChildMapping(props.children, function(child) {
      return react.exports.cloneElement(child, {
        onExited: onExited.bind(null, child),
        in: true,
        appear: getProp(child, "appear", props),
        enter: getProp(child, "enter", props),
        exit: getProp(child, "exit", props)
      });
    });
  }
  function getNextChildMapping(nextProps, prevChildMapping, onExited) {
    var nextChildMapping = getChildMapping(nextProps.children);
    var children = mergeChildMappings(prevChildMapping, nextChildMapping);
    Object.keys(children).forEach(function(key) {
      var child = children[key];
      if (!react.exports.isValidElement(child))
        return;
      var hasPrev = key in prevChildMapping;
      var hasNext = key in nextChildMapping;
      var prevChild = prevChildMapping[key];
      var isLeaving = react.exports.isValidElement(prevChild) && !prevChild.props.in;
      if (hasNext && (!hasPrev || isLeaving)) {
        children[key] = react.exports.cloneElement(child, {
          onExited: onExited.bind(null, child),
          in: true,
          exit: getProp(child, "exit", nextProps),
          enter: getProp(child, "enter", nextProps)
        });
      } else if (!hasNext && hasPrev && !isLeaving) {
        children[key] = react.exports.cloneElement(child, {
          in: false
        });
      } else if (hasNext && hasPrev && react.exports.isValidElement(prevChild)) {
        children[key] = react.exports.cloneElement(child, {
          onExited: onExited.bind(null, child),
          in: prevChild.props.in,
          exit: getProp(child, "exit", nextProps),
          enter: getProp(child, "enter", nextProps)
        });
      }
    });
    return children;
  }
  var values = Object.values || function(obj) {
    return Object.keys(obj).map(function(k2) {
      return obj[k2];
    });
  };
  var defaultProps = {
    component: "div",
    childFactory: function childFactory(child) {
      return child;
    }
  };
  var TransitionGroup = /* @__PURE__ */ function(_React$Component) {
    _inheritsLoose(TransitionGroup2, _React$Component);
    function TransitionGroup2(props, context) {
      var _this;
      _this = _React$Component.call(this, props, context) || this;
      var handleExited = _this.handleExited.bind(_assertThisInitialized$1(_this));
      _this.state = {
        contextValue: {
          isMounting: true
        },
        handleExited,
        firstRender: true
      };
      return _this;
    }
    var _proto = TransitionGroup2.prototype;
    _proto.componentDidMount = function componentDidMount() {
      this.mounted = true;
      this.setState({
        contextValue: {
          isMounting: false
        }
      });
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
      this.mounted = false;
    };
    TransitionGroup2.getDerivedStateFromProps = function getDerivedStateFromProps(nextProps, _ref) {
      var prevChildMapping = _ref.children, handleExited = _ref.handleExited, firstRender = _ref.firstRender;
      return {
        children: firstRender ? getInitialChildMapping(nextProps, handleExited) : getNextChildMapping(nextProps, prevChildMapping, handleExited),
        firstRender: false
      };
    };
    _proto.handleExited = function handleExited(child, node2) {
      var currentChildMapping = getChildMapping(this.props.children);
      if (child.key in currentChildMapping)
        return;
      if (child.props.onExited) {
        child.props.onExited(node2);
      }
      if (this.mounted) {
        this.setState(function(state) {
          var children = _extends({}, state.children);
          delete children[child.key];
          return {
            children
          };
        });
      }
    };
    _proto.render = function render() {
      var _this$props = this.props, Component = _this$props.component, childFactory = _this$props.childFactory, props = _objectWithoutPropertiesLoose(_this$props, ["component", "childFactory"]);
      var contextValue = this.state.contextValue;
      var children = values(this.state.children).map(childFactory);
      delete props.appear;
      delete props.enter;
      delete props.exit;
      if (Component === null) {
        return /* @__PURE__ */ jsx(TransitionGroupContext.Provider, {
          value: contextValue,
          children
        });
      }
      return /* @__PURE__ */ jsx(TransitionGroupContext.Provider, {
        value: contextValue,
        children: /* @__PURE__ */ jsx(Component, {
          ...props,
          children
        })
      });
    };
    return TransitionGroup2;
  }(React$1.Component);
  TransitionGroup.propTypes = {};
  TransitionGroup.defaultProps = defaultProps;
  const TransitionGroup$1 = TransitionGroup;
  const reflow = (node2) => node2.scrollTop;
  function getTransitionProps(props, options) {
    var _style$transitionDura, _style$transitionTimi;
    const {
      timeout,
      easing: easing2,
      style: style2 = {}
    } = props;
    return {
      duration: (_style$transitionDura = style2.transitionDuration) != null ? _style$transitionDura : typeof timeout === "number" ? timeout : timeout[options.mode] || 0,
      easing: (_style$transitionTimi = style2.transitionTimingFunction) != null ? _style$transitionTimi : typeof easing2 === "object" ? easing2[options.mode] : easing2,
      delay: style2.transitionDelay
    };
  }
  function Ripple(props) {
    const {
      className,
      classes,
      pulsate = false,
      rippleX,
      rippleY,
      rippleSize,
      in: inProp,
      onExited,
      timeout
    } = props;
    const [leaving, setLeaving] = react.exports.useState(false);
    const rippleClassName = clsx(className, classes.ripple, classes.rippleVisible, pulsate && classes.ripplePulsate);
    const rippleStyles = {
      width: rippleSize,
      height: rippleSize,
      top: -(rippleSize / 2) + rippleY,
      left: -(rippleSize / 2) + rippleX
    };
    const childClassName = clsx(classes.child, leaving && classes.childLeaving, pulsate && classes.childPulsate);
    if (!inProp && !leaving) {
      setLeaving(true);
    }
    react.exports.useEffect(() => {
      if (!inProp && onExited != null) {
        const timeoutId = setTimeout(onExited, timeout);
        return () => {
          clearTimeout(timeoutId);
        };
      }
      return void 0;
    }, [onExited, inProp, timeout]);
    return /* @__PURE__ */ jsx("span", {
      className: rippleClassName,
      style: rippleStyles,
      children: /* @__PURE__ */ jsx("span", {
        className: childClassName
      })
    });
  }
  const touchRippleClasses = generateUtilityClasses("MuiTouchRipple", ["root", "ripple", "rippleVisible", "ripplePulsate", "child", "childLeaving", "childPulsate"]);
  const touchRippleClasses$1 = touchRippleClasses;
  const _excluded$y = ["center", "classes", "className"];
  let _$1 = (t2) => t2, _t$1, _t2$1, _t3$1, _t4$1;
  const DURATION = 550;
  const DELAY_RIPPLE = 80;
  const enterKeyframe = keyframes(_t$1 || (_t$1 = _$1`
  0% {
    transform: scale(0);
    opacity: 0.1;
  }

  100% {
    transform: scale(1);
    opacity: 0.3;
  }
`));
  const exitKeyframe = keyframes(_t2$1 || (_t2$1 = _$1`
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }
`));
  const pulsateKeyframe = keyframes(_t3$1 || (_t3$1 = _$1`
  0% {
    transform: scale(1);
  }

  50% {
    transform: scale(0.92);
  }

  100% {
    transform: scale(1);
  }
`));
  const TouchRippleRoot = styled$1("span", {
    name: "MuiTouchRipple",
    slot: "Root"
  })({
    overflow: "hidden",
    pointerEvents: "none",
    position: "absolute",
    zIndex: 0,
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    borderRadius: "inherit"
  });
  const TouchRippleRipple = styled$1(Ripple, {
    name: "MuiTouchRipple",
    slot: "Ripple"
  })(_t4$1 || (_t4$1 = _$1`
  opacity: 0;
  position: absolute;

  &.${0} {
    opacity: 0.3;
    transform: scale(1);
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  &.${0} {
    animation-duration: ${0}ms;
  }

  & .${0} {
    opacity: 1;
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: currentColor;
  }

  & .${0} {
    opacity: 0;
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  & .${0} {
    position: absolute;
    /* @noflip */
    left: 0px;
    top: 0;
    animation-name: ${0};
    animation-duration: 2500ms;
    animation-timing-function: ${0};
    animation-iteration-count: infinite;
    animation-delay: 200ms;
  }
`), touchRippleClasses$1.rippleVisible, enterKeyframe, DURATION, ({
    theme
  }) => theme.transitions.easing.easeInOut, touchRippleClasses$1.ripplePulsate, ({
    theme
  }) => theme.transitions.duration.shorter, touchRippleClasses$1.child, touchRippleClasses$1.childLeaving, exitKeyframe, DURATION, ({
    theme
  }) => theme.transitions.easing.easeInOut, touchRippleClasses$1.childPulsate, pulsateKeyframe, ({
    theme
  }) => theme.transitions.easing.easeInOut);
  const TouchRipple = /* @__PURE__ */ react.exports.forwardRef(function TouchRipple2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiTouchRipple"
    });
    const {
      center: centerProp = false,
      classes = {},
      className
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$y);
    const [ripples, setRipples] = react.exports.useState([]);
    const nextKey = react.exports.useRef(0);
    const rippleCallback = react.exports.useRef(null);
    react.exports.useEffect(() => {
      if (rippleCallback.current) {
        rippleCallback.current();
        rippleCallback.current = null;
      }
    }, [ripples]);
    const ignoringMouseDown = react.exports.useRef(false);
    const startTimer = react.exports.useRef(null);
    const startTimerCommit = react.exports.useRef(null);
    const container = react.exports.useRef(null);
    react.exports.useEffect(() => {
      return () => {
        clearTimeout(startTimer.current);
      };
    }, []);
    const startCommit = react.exports.useCallback((params) => {
      const {
        pulsate: pulsate2,
        rippleX,
        rippleY,
        rippleSize,
        cb: cb2
      } = params;
      setRipples((oldRipples) => [...oldRipples, /* @__PURE__ */ jsx(TouchRippleRipple, {
        classes: {
          ripple: clsx(classes.ripple, touchRippleClasses$1.ripple),
          rippleVisible: clsx(classes.rippleVisible, touchRippleClasses$1.rippleVisible),
          ripplePulsate: clsx(classes.ripplePulsate, touchRippleClasses$1.ripplePulsate),
          child: clsx(classes.child, touchRippleClasses$1.child),
          childLeaving: clsx(classes.childLeaving, touchRippleClasses$1.childLeaving),
          childPulsate: clsx(classes.childPulsate, touchRippleClasses$1.childPulsate)
        },
        timeout: DURATION,
        pulsate: pulsate2,
        rippleX,
        rippleY,
        rippleSize
      }, nextKey.current)]);
      nextKey.current += 1;
      rippleCallback.current = cb2;
    }, [classes]);
    const start2 = react.exports.useCallback((event = {}, options = {}, cb2) => {
      const {
        pulsate: pulsate2 = false,
        center = centerProp || options.pulsate,
        fakeElement = false
      } = options;
      if ((event == null ? void 0 : event.type) === "mousedown" && ignoringMouseDown.current) {
        ignoringMouseDown.current = false;
        return;
      }
      if ((event == null ? void 0 : event.type) === "touchstart") {
        ignoringMouseDown.current = true;
      }
      const element = fakeElement ? null : container.current;
      const rect = element ? element.getBoundingClientRect() : {
        width: 0,
        height: 0,
        left: 0,
        top: 0
      };
      let rippleX;
      let rippleY;
      let rippleSize;
      if (center || event === void 0 || event.clientX === 0 && event.clientY === 0 || !event.clientX && !event.touches) {
        rippleX = Math.round(rect.width / 2);
        rippleY = Math.round(rect.height / 2);
      } else {
        const {
          clientX,
          clientY
        } = event.touches && event.touches.length > 0 ? event.touches[0] : event;
        rippleX = Math.round(clientX - rect.left);
        rippleY = Math.round(clientY - rect.top);
      }
      if (center) {
        rippleSize = Math.sqrt((2 * rect.width ** 2 + rect.height ** 2) / 3);
        if (rippleSize % 2 === 0) {
          rippleSize += 1;
        }
      } else {
        const sizeX = Math.max(Math.abs((element ? element.clientWidth : 0) - rippleX), rippleX) * 2 + 2;
        const sizeY = Math.max(Math.abs((element ? element.clientHeight : 0) - rippleY), rippleY) * 2 + 2;
        rippleSize = Math.sqrt(sizeX ** 2 + sizeY ** 2);
      }
      if (event != null && event.touches) {
        if (startTimerCommit.current === null) {
          startTimerCommit.current = () => {
            startCommit({
              pulsate: pulsate2,
              rippleX,
              rippleY,
              rippleSize,
              cb: cb2
            });
          };
          startTimer.current = setTimeout(() => {
            if (startTimerCommit.current) {
              startTimerCommit.current();
              startTimerCommit.current = null;
            }
          }, DELAY_RIPPLE);
        }
      } else {
        startCommit({
          pulsate: pulsate2,
          rippleX,
          rippleY,
          rippleSize,
          cb: cb2
        });
      }
    }, [centerProp, startCommit]);
    const pulsate = react.exports.useCallback(() => {
      start2({}, {
        pulsate: true
      });
    }, [start2]);
    const stop = react.exports.useCallback((event, cb2) => {
      clearTimeout(startTimer.current);
      if ((event == null ? void 0 : event.type) === "touchend" && startTimerCommit.current) {
        startTimerCommit.current();
        startTimerCommit.current = null;
        startTimer.current = setTimeout(() => {
          stop(event, cb2);
        });
        return;
      }
      startTimerCommit.current = null;
      setRipples((oldRipples) => {
        if (oldRipples.length > 0) {
          return oldRipples.slice(1);
        }
        return oldRipples;
      });
      rippleCallback.current = cb2;
    }, []);
    react.exports.useImperativeHandle(ref, () => ({
      pulsate,
      start: start2,
      stop
    }), [pulsate, start2, stop]);
    return /* @__PURE__ */ jsx(TouchRippleRoot, _extends({
      className: clsx(touchRippleClasses$1.root, classes.root, className),
      ref: container
    }, other, {
      children: /* @__PURE__ */ jsx(TransitionGroup$1, {
        component: null,
        exit: true,
        children: ripples
      })
    }));
  });
  const TouchRipple$1 = TouchRipple;
  function getButtonBaseUtilityClass(slot) {
    return generateUtilityClass("MuiButtonBase", slot);
  }
  const buttonBaseClasses = generateUtilityClasses("MuiButtonBase", ["root", "disabled", "focusVisible"]);
  const buttonBaseClasses$1 = buttonBaseClasses;
  const _excluded$x = ["action", "centerRipple", "children", "className", "component", "disabled", "disableRipple", "disableTouchRipple", "focusRipple", "focusVisibleClassName", "LinkComponent", "onBlur", "onClick", "onContextMenu", "onDragLeave", "onFocus", "onFocusVisible", "onKeyDown", "onKeyUp", "onMouseDown", "onMouseLeave", "onMouseUp", "onTouchEnd", "onTouchMove", "onTouchStart", "tabIndex", "TouchRippleProps", "touchRippleRef", "type"];
  const useUtilityClasses$r = (ownerState) => {
    const {
      disabled,
      focusVisible,
      focusVisibleClassName,
      classes
    } = ownerState;
    const slots = {
      root: ["root", disabled && "disabled", focusVisible && "focusVisible"]
    };
    const composedClasses = composeClasses(slots, getButtonBaseUtilityClass, classes);
    if (focusVisible && focusVisibleClassName) {
      composedClasses.root += ` ${focusVisibleClassName}`;
    }
    return composedClasses;
  };
  const ButtonBaseRoot = styled$1("button", {
    name: "MuiButtonBase",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    boxSizing: "border-box",
    WebkitTapHighlightColor: "transparent",
    backgroundColor: "transparent",
    outline: 0,
    border: 0,
    margin: 0,
    borderRadius: 0,
    padding: 0,
    cursor: "pointer",
    userSelect: "none",
    verticalAlign: "middle",
    MozAppearance: "none",
    WebkitAppearance: "none",
    textDecoration: "none",
    color: "inherit",
    "&::-moz-focus-inner": {
      borderStyle: "none"
    },
    [`&.${buttonBaseClasses$1.disabled}`]: {
      pointerEvents: "none",
      cursor: "default"
    },
    "@media print": {
      colorAdjust: "exact"
    }
  });
  const ButtonBase = /* @__PURE__ */ react.exports.forwardRef(function ButtonBase2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiButtonBase"
    });
    const {
      action,
      centerRipple = false,
      children,
      className,
      component = "button",
      disabled = false,
      disableRipple = false,
      disableTouchRipple = false,
      focusRipple = false,
      LinkComponent = "a",
      onBlur,
      onClick,
      onContextMenu,
      onDragLeave,
      onFocus,
      onFocusVisible,
      onKeyDown,
      onKeyUp,
      onMouseDown,
      onMouseLeave,
      onMouseUp,
      onTouchEnd,
      onTouchMove,
      onTouchStart,
      tabIndex = 0,
      TouchRippleProps,
      touchRippleRef,
      type
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$x);
    const buttonRef = react.exports.useRef(null);
    const rippleRef = react.exports.useRef(null);
    const handleRippleRef = useForkRef(rippleRef, touchRippleRef);
    const {
      isFocusVisibleRef,
      onFocus: handleFocusVisible,
      onBlur: handleBlurVisible,
      ref: focusVisibleRef
    } = useIsFocusVisible();
    const [focusVisible, setFocusVisible] = react.exports.useState(false);
    if (disabled && focusVisible) {
      setFocusVisible(false);
    }
    react.exports.useImperativeHandle(action, () => ({
      focusVisible: () => {
        setFocusVisible(true);
        buttonRef.current.focus();
      }
    }), []);
    const [mountedState, setMountedState] = react.exports.useState(false);
    react.exports.useEffect(() => {
      setMountedState(true);
    }, []);
    const enableTouchRipple = mountedState && !disableRipple && !disabled;
    react.exports.useEffect(() => {
      if (focusVisible && focusRipple && !disableRipple && mountedState) {
        rippleRef.current.pulsate();
      }
    }, [disableRipple, focusRipple, focusVisible, mountedState]);
    function useRippleHandler(rippleAction, eventCallback, skipRippleAction = disableTouchRipple) {
      return useEventCallback((event) => {
        if (eventCallback) {
          eventCallback(event);
        }
        const ignore = skipRippleAction;
        if (!ignore && rippleRef.current) {
          rippleRef.current[rippleAction](event);
        }
        return true;
      });
    }
    const handleMouseDown = useRippleHandler("start", onMouseDown);
    const handleContextMenu = useRippleHandler("stop", onContextMenu);
    const handleDragLeave = useRippleHandler("stop", onDragLeave);
    const handleMouseUp = useRippleHandler("stop", onMouseUp);
    const handleMouseLeave = useRippleHandler("stop", (event) => {
      if (focusVisible) {
        event.preventDefault();
      }
      if (onMouseLeave) {
        onMouseLeave(event);
      }
    });
    const handleTouchStart = useRippleHandler("start", onTouchStart);
    const handleTouchEnd = useRippleHandler("stop", onTouchEnd);
    const handleTouchMove = useRippleHandler("stop", onTouchMove);
    const handleBlur = useRippleHandler("stop", (event) => {
      handleBlurVisible(event);
      if (isFocusVisibleRef.current === false) {
        setFocusVisible(false);
      }
      if (onBlur) {
        onBlur(event);
      }
    }, false);
    const handleFocus = useEventCallback((event) => {
      if (!buttonRef.current) {
        buttonRef.current = event.currentTarget;
      }
      handleFocusVisible(event);
      if (isFocusVisibleRef.current === true) {
        setFocusVisible(true);
        if (onFocusVisible) {
          onFocusVisible(event);
        }
      }
      if (onFocus) {
        onFocus(event);
      }
    });
    const isNonNativeButton = () => {
      const button = buttonRef.current;
      return component && component !== "button" && !(button.tagName === "A" && button.href);
    };
    const keydownRef = react.exports.useRef(false);
    const handleKeyDown2 = useEventCallback((event) => {
      if (focusRipple && !keydownRef.current && focusVisible && rippleRef.current && event.key === " ") {
        keydownRef.current = true;
        rippleRef.current.stop(event, () => {
          rippleRef.current.start(event);
        });
      }
      if (event.target === event.currentTarget && isNonNativeButton() && event.key === " ") {
        event.preventDefault();
      }
      if (onKeyDown) {
        onKeyDown(event);
      }
      if (event.target === event.currentTarget && isNonNativeButton() && event.key === "Enter" && !disabled) {
        event.preventDefault();
        if (onClick) {
          onClick(event);
        }
      }
    });
    const handleKeyUp = useEventCallback((event) => {
      if (focusRipple && event.key === " " && rippleRef.current && focusVisible && !event.defaultPrevented) {
        keydownRef.current = false;
        rippleRef.current.stop(event, () => {
          rippleRef.current.pulsate(event);
        });
      }
      if (onKeyUp) {
        onKeyUp(event);
      }
      if (onClick && event.target === event.currentTarget && isNonNativeButton() && event.key === " " && !event.defaultPrevented) {
        onClick(event);
      }
    });
    let ComponentProp = component;
    if (ComponentProp === "button" && (other.href || other.to)) {
      ComponentProp = LinkComponent;
    }
    const buttonProps = {};
    if (ComponentProp === "button") {
      buttonProps.type = type === void 0 ? "button" : type;
      buttonProps.disabled = disabled;
    } else {
      if (!other.href && !other.to) {
        buttonProps.role = "button";
      }
      if (disabled) {
        buttonProps["aria-disabled"] = disabled;
      }
    }
    const handleOwnRef = useForkRef(focusVisibleRef, buttonRef);
    const handleRef = useForkRef(ref, handleOwnRef);
    const ownerState = _extends({}, props, {
      centerRipple,
      component,
      disabled,
      disableRipple,
      disableTouchRipple,
      focusRipple,
      tabIndex,
      focusVisible
    });
    const classes = useUtilityClasses$r(ownerState);
    return /* @__PURE__ */ jsxs(ButtonBaseRoot, _extends({
      as: ComponentProp,
      className: clsx(classes.root, className),
      ownerState,
      onBlur: handleBlur,
      onClick,
      onContextMenu: handleContextMenu,
      onFocus: handleFocus,
      onKeyDown: handleKeyDown2,
      onKeyUp: handleKeyUp,
      onMouseDown: handleMouseDown,
      onMouseLeave: handleMouseLeave,
      onMouseUp: handleMouseUp,
      onDragLeave: handleDragLeave,
      onTouchEnd: handleTouchEnd,
      onTouchMove: handleTouchMove,
      onTouchStart: handleTouchStart,
      ref: handleRef,
      tabIndex: disabled ? -1 : tabIndex,
      type
    }, buttonProps, other, {
      children: [children, enableTouchRipple ? /* @__PURE__ */ jsx(TouchRipple$1, _extends({
        ref: handleRippleRef,
        center: centerRipple
      }, TouchRippleProps)) : null]
    }));
  });
  const ButtonBase$1 = ButtonBase;
  function getIconButtonUtilityClass(slot) {
    return generateUtilityClass("MuiIconButton", slot);
  }
  const iconButtonClasses = generateUtilityClasses("MuiIconButton", ["root", "disabled", "colorInherit", "colorPrimary", "colorSecondary", "edgeStart", "edgeEnd", "sizeSmall", "sizeMedium", "sizeLarge"]);
  const iconButtonClasses$1 = iconButtonClasses;
  const _excluded$w = ["edge", "children", "className", "color", "disabled", "disableFocusRipple", "size"];
  const useUtilityClasses$q = (ownerState) => {
    const {
      classes,
      disabled,
      color: color2,
      edge,
      size
    } = ownerState;
    const slots = {
      root: ["root", disabled && "disabled", color2 !== "default" && `color${capitalize(color2)}`, edge && `edge${capitalize(edge)}`, `size${capitalize(size)}`]
    };
    return composeClasses(slots, getIconButtonUtilityClass, classes);
  };
  const IconButtonRoot = styled$1(ButtonBase$1, {
    name: "MuiIconButton",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`], ownerState.edge && styles2[`edge${capitalize(ownerState.edge)}`], styles2[`size${capitalize(ownerState.size)}`]];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    textAlign: "center",
    flex: "0 0 auto",
    fontSize: theme.typography.pxToRem(24),
    padding: 8,
    borderRadius: "50%",
    overflow: "visible",
    color: (theme.vars || theme).palette.action.active,
    transition: theme.transitions.create("background-color", {
      duration: theme.transitions.duration.shortest
    })
  }, !ownerState.disableRipple && {
    "&:hover": {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.activeChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette.action.active, theme.palette.action.hoverOpacity),
      "@media (hover: none)": {
        backgroundColor: "transparent"
      }
    }
  }, ownerState.edge === "start" && {
    marginLeft: ownerState.size === "small" ? -3 : -12
  }, ownerState.edge === "end" && {
    marginRight: ownerState.size === "small" ? -3 : -12
  }), ({
    theme,
    ownerState
  }) => _extends({}, ownerState.color === "inherit" && {
    color: "inherit"
  }, ownerState.color !== "inherit" && ownerState.color !== "default" && _extends({
    color: (theme.vars || theme).palette[ownerState.color].main
  }, !ownerState.disableRipple && {
    "&:hover": {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity),
      "@media (hover: none)": {
        backgroundColor: "transparent"
      }
    }
  }), ownerState.size === "small" && {
    padding: 5,
    fontSize: theme.typography.pxToRem(18)
  }, ownerState.size === "large" && {
    padding: 12,
    fontSize: theme.typography.pxToRem(28)
  }, {
    [`&.${iconButtonClasses$1.disabled}`]: {
      backgroundColor: "transparent",
      color: (theme.vars || theme).palette.action.disabled
    }
  }));
  const IconButton = /* @__PURE__ */ react.exports.forwardRef(function IconButton2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiIconButton"
    });
    const {
      edge = false,
      children,
      className,
      color: color2 = "default",
      disabled = false,
      disableFocusRipple = false,
      size = "medium"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$w);
    const ownerState = _extends({}, props, {
      edge,
      color: color2,
      disabled,
      disableFocusRipple,
      size
    });
    const classes = useUtilityClasses$q(ownerState);
    return /* @__PURE__ */ jsx(IconButtonRoot, _extends({
      className: clsx(classes.root, className),
      centerRipple: true,
      focusRipple: !disableFocusRipple,
      disabled,
      ref,
      ownerState
    }, other, {
      children
    }));
  });
  const IconButton$1 = IconButton;
  const ClearIcon = createSvgIcon$1(/* @__PURE__ */ jsx("path", {
    d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
  }), "Close");
  function getTypographyUtilityClass(slot) {
    return generateUtilityClass("MuiTypography", slot);
  }
  generateUtilityClasses("MuiTypography", ["root", "h1", "h2", "h3", "h4", "h5", "h6", "subtitle1", "subtitle2", "body1", "body2", "inherit", "button", "caption", "overline", "alignLeft", "alignRight", "alignCenter", "alignJustify", "noWrap", "gutterBottom", "paragraph"]);
  const _excluded$v = ["align", "className", "component", "gutterBottom", "noWrap", "paragraph", "variant", "variantMapping"];
  const useUtilityClasses$p = (ownerState) => {
    const {
      align,
      gutterBottom,
      noWrap,
      paragraph,
      variant,
      classes
    } = ownerState;
    const slots = {
      root: ["root", variant, ownerState.align !== "inherit" && `align${capitalize(align)}`, gutterBottom && "gutterBottom", noWrap && "noWrap", paragraph && "paragraph"]
    };
    return composeClasses(slots, getTypographyUtilityClass, classes);
  };
  const TypographyRoot = styled$1("span", {
    name: "MuiTypography",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.variant && styles2[ownerState.variant], ownerState.align !== "inherit" && styles2[`align${capitalize(ownerState.align)}`], ownerState.noWrap && styles2.noWrap, ownerState.gutterBottom && styles2.gutterBottom, ownerState.paragraph && styles2.paragraph];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    margin: 0
  }, ownerState.variant && theme.typography[ownerState.variant], ownerState.align !== "inherit" && {
    textAlign: ownerState.align
  }, ownerState.noWrap && {
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap"
  }, ownerState.gutterBottom && {
    marginBottom: "0.35em"
  }, ownerState.paragraph && {
    marginBottom: 16
  }));
  const defaultVariantMapping = {
    h1: "h1",
    h2: "h2",
    h3: "h3",
    h4: "h4",
    h5: "h5",
    h6: "h6",
    subtitle1: "h6",
    subtitle2: "h6",
    body1: "p",
    body2: "p",
    inherit: "p"
  };
  const colorTransformations = {
    primary: "primary.main",
    textPrimary: "text.primary",
    secondary: "secondary.main",
    textSecondary: "text.secondary",
    error: "error.main"
  };
  const transformDeprecatedColors = (color2) => {
    return colorTransformations[color2] || color2;
  };
  const Typography = /* @__PURE__ */ react.exports.forwardRef(function Typography2(inProps, ref) {
    const themeProps = useThemeProps({
      props: inProps,
      name: "MuiTypography"
    });
    const color2 = transformDeprecatedColors(themeProps.color);
    const props = extendSxProp(_extends({}, themeProps, {
      color: color2
    }));
    const {
      align = "inherit",
      className,
      component,
      gutterBottom = false,
      noWrap = false,
      paragraph = false,
      variant = "body1",
      variantMapping = defaultVariantMapping
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$v);
    const ownerState = _extends({}, props, {
      align,
      color: color2,
      className,
      component,
      gutterBottom,
      noWrap,
      paragraph,
      variant,
      variantMapping
    });
    const Component = component || (paragraph ? "p" : variantMapping[variant] || defaultVariantMapping[variant]) || "span";
    const classes = useUtilityClasses$p(ownerState);
    return /* @__PURE__ */ jsx(TypographyRoot, _extends({
      as: Component,
      ref,
      ownerState,
      className: clsx(classes.root, className)
    }, other));
  });
  const Typography$1 = Typography;
  const PopperRoot = styled$1(PopperUnstyled$1, {
    name: "MuiPopper",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({});
  const Popper = /* @__PURE__ */ react.exports.forwardRef(function Popper2(inProps, ref) {
    const theme = useTheme$2();
    const props = useThemeProps({
      props: inProps,
      name: "MuiPopper"
    });
    return /* @__PURE__ */ jsx(PopperRoot, _extends({
      direction: theme == null ? void 0 : theme.direction
    }, props, {
      ref
    }));
  });
  const Popper$1 = Popper;
  function getListSubheaderUtilityClass(slot) {
    return generateUtilityClass("MuiListSubheader", slot);
  }
  generateUtilityClasses("MuiListSubheader", ["root", "colorPrimary", "colorInherit", "gutters", "inset", "sticky"]);
  const _excluded$u = ["className", "color", "component", "disableGutters", "disableSticky", "inset"];
  const useUtilityClasses$o = (ownerState) => {
    const {
      classes,
      color: color2,
      disableGutters,
      inset,
      disableSticky
    } = ownerState;
    const slots = {
      root: ["root", color2 !== "default" && `color${capitalize(color2)}`, !disableGutters && "gutters", inset && "inset", !disableSticky && "sticky"]
    };
    return composeClasses(slots, getListSubheaderUtilityClass, classes);
  };
  const ListSubheaderRoot = styled$1("li", {
    name: "MuiListSubheader",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`], !ownerState.disableGutters && styles2.gutters, ownerState.inset && styles2.inset, !ownerState.disableSticky && styles2.sticky];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    boxSizing: "border-box",
    lineHeight: "48px",
    listStyle: "none",
    color: (theme.vars || theme).palette.text.secondary,
    fontFamily: theme.typography.fontFamily,
    fontWeight: theme.typography.fontWeightMedium,
    fontSize: theme.typography.pxToRem(14)
  }, ownerState.color === "primary" && {
    color: (theme.vars || theme).palette.primary.main
  }, ownerState.color === "inherit" && {
    color: "inherit"
  }, !ownerState.disableGutters && {
    paddingLeft: 16,
    paddingRight: 16
  }, ownerState.inset && {
    paddingLeft: 72
  }, !ownerState.disableSticky && {
    position: "sticky",
    top: 0,
    zIndex: 1,
    backgroundColor: (theme.vars || theme).palette.background.paper
  }));
  const ListSubheader = /* @__PURE__ */ react.exports.forwardRef(function ListSubheader2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiListSubheader"
    });
    const {
      className,
      color: color2 = "default",
      component = "li",
      disableGutters = false,
      disableSticky = false,
      inset = false
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$u);
    const ownerState = _extends({}, props, {
      color: color2,
      component,
      disableGutters,
      disableSticky,
      inset
    });
    const classes = useUtilityClasses$o(ownerState);
    return /* @__PURE__ */ jsx(ListSubheaderRoot, _extends({
      as: component,
      className: clsx(classes.root, className),
      ref,
      ownerState
    }, other));
  });
  const ListSubheader$1 = ListSubheader;
  const CancelIcon = createSvgIcon$1(/* @__PURE__ */ jsx("path", {
    d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"
  }), "Cancel");
  function getChipUtilityClass(slot) {
    return generateUtilityClass("MuiChip", slot);
  }
  const chipClasses = generateUtilityClasses("MuiChip", ["root", "sizeSmall", "sizeMedium", "colorError", "colorInfo", "colorPrimary", "colorSecondary", "colorSuccess", "colorWarning", "disabled", "clickable", "clickableColorPrimary", "clickableColorSecondary", "deletable", "deletableColorPrimary", "deletableColorSecondary", "outlined", "filled", "outlinedPrimary", "outlinedSecondary", "filledPrimary", "filledSecondary", "avatar", "avatarSmall", "avatarMedium", "avatarColorPrimary", "avatarColorSecondary", "icon", "iconSmall", "iconMedium", "iconColorPrimary", "iconColorSecondary", "label", "labelSmall", "labelMedium", "deleteIcon", "deleteIconSmall", "deleteIconMedium", "deleteIconColorPrimary", "deleteIconColorSecondary", "deleteIconOutlinedColorPrimary", "deleteIconOutlinedColorSecondary", "deleteIconFilledColorPrimary", "deleteIconFilledColorSecondary", "focusVisible"]);
  const chipClasses$1 = chipClasses;
  const _excluded$t = ["avatar", "className", "clickable", "color", "component", "deleteIcon", "disabled", "icon", "label", "onClick", "onDelete", "onKeyDown", "onKeyUp", "size", "variant"];
  const useUtilityClasses$n = (ownerState) => {
    const {
      classes,
      disabled,
      size,
      color: color2,
      onDelete,
      clickable,
      variant
    } = ownerState;
    const slots = {
      root: ["root", variant, disabled && "disabled", `size${capitalize(size)}`, `color${capitalize(color2)}`, clickable && "clickable", clickable && `clickableColor${capitalize(color2)}`, onDelete && "deletable", onDelete && `deletableColor${capitalize(color2)}`, `${variant}${capitalize(color2)}`],
      label: ["label", `label${capitalize(size)}`],
      avatar: ["avatar", `avatar${capitalize(size)}`, `avatarColor${capitalize(color2)}`],
      icon: ["icon", `icon${capitalize(size)}`, `iconColor${capitalize(color2)}`],
      deleteIcon: ["deleteIcon", `deleteIcon${capitalize(size)}`, `deleteIconColor${capitalize(color2)}`, `deleteIcon${capitalize(variant)}Color${capitalize(color2)}`]
    };
    return composeClasses(slots, getChipUtilityClass, classes);
  };
  const ChipRoot = styled$1("div", {
    name: "MuiChip",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      const {
        color: color2,
        clickable,
        onDelete,
        size,
        variant
      } = ownerState;
      return [{
        [`& .${chipClasses$1.avatar}`]: styles2.avatar
      }, {
        [`& .${chipClasses$1.avatar}`]: styles2[`avatar${capitalize(size)}`]
      }, {
        [`& .${chipClasses$1.avatar}`]: styles2[`avatarColor${capitalize(color2)}`]
      }, {
        [`& .${chipClasses$1.icon}`]: styles2.icon
      }, {
        [`& .${chipClasses$1.icon}`]: styles2[`icon${capitalize(size)}`]
      }, {
        [`& .${chipClasses$1.icon}`]: styles2[`iconColor${capitalize(color2)}`]
      }, {
        [`& .${chipClasses$1.deleteIcon}`]: styles2.deleteIcon
      }, {
        [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIcon${capitalize(size)}`]
      }, {
        [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIconColor${capitalize(color2)}`]
      }, {
        [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIcon${capitalize(variant)}Color${capitalize(color2)}`]
      }, styles2.root, styles2[`size${capitalize(size)}`], styles2[`color${capitalize(color2)}`], clickable && styles2.clickable, clickable && color2 !== "default" && styles2[`clickableColor${capitalize(color2)})`], onDelete && styles2.deletable, onDelete && color2 !== "default" && styles2[`deletableColor${capitalize(color2)}`], styles2[variant], styles2[`${variant}${capitalize(color2)}`]];
    }
  })(({
    theme,
    ownerState
  }) => {
    const deleteIconColor = alpha(theme.palette.text.primary, 0.26);
    const textColor = theme.palette.mode === "light" ? theme.palette.grey[700] : theme.palette.grey[300];
    return _extends({
      maxWidth: "100%",
      fontFamily: theme.typography.fontFamily,
      fontSize: theme.typography.pxToRem(13),
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      height: 32,
      color: (theme.vars || theme).palette.text.primary,
      backgroundColor: (theme.vars || theme).palette.action.selected,
      borderRadius: 32 / 2,
      whiteSpace: "nowrap",
      transition: theme.transitions.create(["background-color", "box-shadow"]),
      cursor: "default",
      outline: 0,
      textDecoration: "none",
      border: 0,
      padding: 0,
      verticalAlign: "middle",
      boxSizing: "border-box",
      [`&.${chipClasses$1.disabled}`]: {
        opacity: (theme.vars || theme).palette.action.disabledOpacity,
        pointerEvents: "none"
      },
      [`& .${chipClasses$1.avatar}`]: {
        marginLeft: 5,
        marginRight: -6,
        width: 24,
        height: 24,
        color: theme.vars ? theme.vars.palette.Chip.defaultAvatarColor : textColor,
        fontSize: theme.typography.pxToRem(12)
      },
      [`& .${chipClasses$1.avatarColorPrimary}`]: {
        color: (theme.vars || theme).palette.primary.contrastText,
        backgroundColor: (theme.vars || theme).palette.primary.dark
      },
      [`& .${chipClasses$1.avatarColorSecondary}`]: {
        color: (theme.vars || theme).palette.secondary.contrastText,
        backgroundColor: (theme.vars || theme).palette.secondary.dark
      },
      [`& .${chipClasses$1.avatarSmall}`]: {
        marginLeft: 4,
        marginRight: -4,
        width: 18,
        height: 18,
        fontSize: theme.typography.pxToRem(10)
      },
      [`& .${chipClasses$1.icon}`]: _extends({
        color: theme.vars ? theme.vars.palette.Chip.defaultIconColor : textColor,
        marginLeft: 5,
        marginRight: -6
      }, ownerState.size === "small" && {
        fontSize: 18,
        marginLeft: 4,
        marginRight: -4
      }, ownerState.color !== "default" && {
        color: "inherit"
      }),
      [`& .${chipClasses$1.deleteIcon}`]: _extends({
        WebkitTapHighlightColor: "transparent",
        color: theme.vars ? `rgba(${theme.vars.palette.text.primaryChannel} / 0.26)` : deleteIconColor,
        fontSize: 22,
        cursor: "pointer",
        margin: "0 5px 0 -6px",
        "&:hover": {
          color: theme.vars ? `rgba(${theme.vars.palette.text.primaryChannel} / 0.4)` : alpha(deleteIconColor, 0.4)
        }
      }, ownerState.size === "small" && {
        fontSize: 16,
        marginRight: 4,
        marginLeft: -4
      }, ownerState.color !== "default" && {
        color: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].contrastTextChannel} / 0.7)` : alpha(theme.palette[ownerState.color].contrastText, 0.7),
        "&:hover, &:active": {
          color: (theme.vars || theme).palette[ownerState.color].contrastText
        }
      })
    }, ownerState.size === "small" && {
      height: 24
    }, ownerState.color !== "default" && {
      backgroundColor: (theme.vars || theme).palette[ownerState.color].main,
      color: (theme.vars || theme).palette[ownerState.color].contrastText
    }, ownerState.onDelete && {
      [`&.${chipClasses$1.focusVisible}`]: {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity + theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
      }
    }, ownerState.onDelete && ownerState.color !== "default" && {
      [`&.${chipClasses$1.focusVisible}`]: {
        backgroundColor: (theme.vars || theme).palette[ownerState.color].dark
      }
    });
  }, ({
    theme,
    ownerState
  }) => _extends({}, ownerState.clickable && {
    userSelect: "none",
    WebkitTapHighlightColor: "transparent",
    cursor: "pointer",
    "&:hover": {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity + theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity)
    },
    [`&.${chipClasses$1.focusVisible}`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity + theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    },
    "&:active": {
      boxShadow: (theme.vars || theme).shadows[1]
    }
  }, ownerState.clickable && ownerState.color !== "default" && {
    [`&:hover, &.${chipClasses$1.focusVisible}`]: {
      backgroundColor: (theme.vars || theme).palette[ownerState.color].dark
    }
  }), ({
    theme,
    ownerState
  }) => _extends({}, ownerState.variant === "outlined" && {
    backgroundColor: "transparent",
    border: theme.vars ? `1px solid ${theme.vars.palette.Chip.defaultBorder}` : `1px solid ${theme.palette.mode === "light" ? theme.palette.grey[400] : theme.palette.grey[700]}`,
    [`&.${chipClasses$1.clickable}:hover`]: {
      backgroundColor: (theme.vars || theme).palette.action.hover
    },
    [`&.${chipClasses$1.focusVisible}`]: {
      backgroundColor: (theme.vars || theme).palette.action.focus
    },
    [`& .${chipClasses$1.avatar}`]: {
      marginLeft: 4
    },
    [`& .${chipClasses$1.avatarSmall}`]: {
      marginLeft: 2
    },
    [`& .${chipClasses$1.icon}`]: {
      marginLeft: 4
    },
    [`& .${chipClasses$1.iconSmall}`]: {
      marginLeft: 2
    },
    [`& .${chipClasses$1.deleteIcon}`]: {
      marginRight: 5
    },
    [`& .${chipClasses$1.deleteIconSmall}`]: {
      marginRight: 3
    }
  }, ownerState.variant === "outlined" && ownerState.color !== "default" && {
    color: (theme.vars || theme).palette[ownerState.color].main,
    border: `1px solid ${theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / 0.7)` : alpha(theme.palette[ownerState.color].main, 0.7)}`,
    [`&.${chipClasses$1.clickable}:hover`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity)
    },
    [`&.${chipClasses$1.focusVisible}`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.focusOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.focusOpacity)
    },
    [`& .${chipClasses$1.deleteIcon}`]: {
      color: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / 0.7)` : alpha(theme.palette[ownerState.color].main, 0.7),
      "&:hover, &:active": {
        color: (theme.vars || theme).palette[ownerState.color].main
      }
    }
  }));
  const ChipLabel = styled$1("span", {
    name: "MuiChip",
    slot: "Label",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      const {
        size
      } = ownerState;
      return [styles2.label, styles2[`label${capitalize(size)}`]];
    }
  })(({
    ownerState
  }) => _extends({
    overflow: "hidden",
    textOverflow: "ellipsis",
    paddingLeft: 12,
    paddingRight: 12,
    whiteSpace: "nowrap"
  }, ownerState.size === "small" && {
    paddingLeft: 8,
    paddingRight: 8
  }));
  function isDeleteKeyboardEvent(keyboardEvent) {
    return keyboardEvent.key === "Backspace" || keyboardEvent.key === "Delete";
  }
  const Chip = /* @__PURE__ */ react.exports.forwardRef(function Chip2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiChip"
    });
    const {
      avatar: avatarProp,
      className,
      clickable: clickableProp,
      color: color2 = "default",
      component: ComponentProp,
      deleteIcon: deleteIconProp,
      disabled = false,
      icon: iconProp,
      label,
      onClick,
      onDelete,
      onKeyDown,
      onKeyUp,
      size = "medium",
      variant = "filled"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$t);
    const chipRef = react.exports.useRef(null);
    const handleRef = useForkRef(chipRef, ref);
    const handleDeleteIconClick = (event) => {
      event.stopPropagation();
      if (onDelete) {
        onDelete(event);
      }
    };
    const handleKeyDown2 = (event) => {
      if (event.currentTarget === event.target && isDeleteKeyboardEvent(event)) {
        event.preventDefault();
      }
      if (onKeyDown) {
        onKeyDown(event);
      }
    };
    const handleKeyUp = (event) => {
      if (event.currentTarget === event.target) {
        if (onDelete && isDeleteKeyboardEvent(event)) {
          onDelete(event);
        } else if (event.key === "Escape" && chipRef.current) {
          chipRef.current.blur();
        }
      }
      if (onKeyUp) {
        onKeyUp(event);
      }
    };
    const clickable = clickableProp !== false && onClick ? true : clickableProp;
    const component = clickable || onDelete ? ButtonBase$1 : ComponentProp || "div";
    const ownerState = _extends({}, props, {
      component,
      disabled,
      size,
      color: color2,
      onDelete: !!onDelete,
      clickable,
      variant
    });
    const classes = useUtilityClasses$n(ownerState);
    const moreProps = component === ButtonBase$1 ? _extends({
      component: ComponentProp || "div",
      focusVisibleClassName: classes.focusVisible
    }, onDelete && {
      disableRipple: true
    }) : {};
    let deleteIcon = null;
    if (onDelete) {
      deleteIcon = deleteIconProp && /* @__PURE__ */ react.exports.isValidElement(deleteIconProp) ? /* @__PURE__ */ react.exports.cloneElement(deleteIconProp, {
        className: clsx(deleteIconProp.props.className, classes.deleteIcon),
        onClick: handleDeleteIconClick
      }) : /* @__PURE__ */ jsx(CancelIcon, {
        className: clsx(classes.deleteIcon),
        onClick: handleDeleteIconClick
      });
    }
    let avatar = null;
    if (avatarProp && /* @__PURE__ */ react.exports.isValidElement(avatarProp)) {
      avatar = /* @__PURE__ */ react.exports.cloneElement(avatarProp, {
        className: clsx(classes.avatar, avatarProp.props.className)
      });
    }
    let icon = null;
    if (iconProp && /* @__PURE__ */ react.exports.isValidElement(iconProp)) {
      icon = /* @__PURE__ */ react.exports.cloneElement(iconProp, {
        className: clsx(classes.icon, iconProp.props.className)
      });
    }
    return /* @__PURE__ */ jsxs(ChipRoot, _extends({
      as: component,
      className: clsx(classes.root, className),
      disabled: clickable && disabled ? true : void 0,
      onClick,
      onKeyDown: handleKeyDown2,
      onKeyUp: handleKeyUp,
      ref: handleRef,
      ownerState
    }, moreProps, other, {
      children: [avatar || icon, /* @__PURE__ */ jsx(ChipLabel, {
        className: clsx(classes.label),
        ownerState,
        children: label
      }), deleteIcon]
    }));
  });
  const Chip$1 = Chip;
  function formControlState({
    props,
    states,
    muiFormControl
  }) {
    return states.reduce((acc, state) => {
      acc[state] = props[state];
      if (muiFormControl) {
        if (typeof props[state] === "undefined") {
          acc[state] = muiFormControl[state];
        }
      }
      return acc;
    }, {});
  }
  const FormControlContext = /* @__PURE__ */ react.exports.createContext();
  const FormControlContext$1 = FormControlContext;
  function useFormControl() {
    return react.exports.useContext(FormControlContext$1);
  }
  function GlobalStyles(props) {
    return /* @__PURE__ */ jsx(GlobalStyles$1, _extends({}, props, {
      defaultTheme: defaultTheme$2
    }));
  }
  function hasValue(value) {
    return value != null && !(Array.isArray(value) && value.length === 0);
  }
  function isFilled(obj, SSR = false) {
    return obj && (hasValue(obj.value) && obj.value !== "" || SSR && hasValue(obj.defaultValue) && obj.defaultValue !== "");
  }
  function isAdornedStart(obj) {
    return obj.startAdornment;
  }
  function getInputBaseUtilityClass(slot) {
    return generateUtilityClass("MuiInputBase", slot);
  }
  const inputBaseClasses = generateUtilityClasses("MuiInputBase", ["root", "formControl", "focused", "disabled", "adornedStart", "adornedEnd", "error", "sizeSmall", "multiline", "colorSecondary", "fullWidth", "hiddenLabel", "readOnly", "input", "inputSizeSmall", "inputMultiline", "inputTypeSearch", "inputAdornedStart", "inputAdornedEnd", "inputHiddenLabel"]);
  const inputBaseClasses$1 = inputBaseClasses;
  const _excluded$s = ["aria-describedby", "autoComplete", "autoFocus", "className", "color", "components", "componentsProps", "defaultValue", "disabled", "disableInjectingGlobalStyles", "endAdornment", "error", "fullWidth", "id", "inputComponent", "inputProps", "inputRef", "margin", "maxRows", "minRows", "multiline", "name", "onBlur", "onChange", "onClick", "onFocus", "onKeyDown", "onKeyUp", "placeholder", "readOnly", "renderSuffix", "rows", "size", "startAdornment", "type", "value"];
  const rootOverridesResolver = (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.formControl && styles2.formControl, ownerState.startAdornment && styles2.adornedStart, ownerState.endAdornment && styles2.adornedEnd, ownerState.error && styles2.error, ownerState.size === "small" && styles2.sizeSmall, ownerState.multiline && styles2.multiline, ownerState.color && styles2[`color${capitalize(ownerState.color)}`], ownerState.fullWidth && styles2.fullWidth, ownerState.hiddenLabel && styles2.hiddenLabel];
  };
  const inputOverridesResolver = (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.input, ownerState.size === "small" && styles2.inputSizeSmall, ownerState.multiline && styles2.inputMultiline, ownerState.type === "search" && styles2.inputTypeSearch, ownerState.startAdornment && styles2.inputAdornedStart, ownerState.endAdornment && styles2.inputAdornedEnd, ownerState.hiddenLabel && styles2.inputHiddenLabel];
  };
  const useUtilityClasses$m = (ownerState) => {
    const {
      classes,
      color: color2,
      disabled,
      error,
      endAdornment,
      focused,
      formControl,
      fullWidth,
      hiddenLabel,
      multiline,
      readOnly,
      size,
      startAdornment,
      type
    } = ownerState;
    const slots = {
      root: ["root", `color${capitalize(color2)}`, disabled && "disabled", error && "error", fullWidth && "fullWidth", focused && "focused", formControl && "formControl", size === "small" && "sizeSmall", multiline && "multiline", startAdornment && "adornedStart", endAdornment && "adornedEnd", hiddenLabel && "hiddenLabel", readOnly && "readOnly"],
      input: ["input", disabled && "disabled", type === "search" && "inputTypeSearch", multiline && "inputMultiline", size === "small" && "inputSizeSmall", hiddenLabel && "inputHiddenLabel", startAdornment && "inputAdornedStart", endAdornment && "inputAdornedEnd", readOnly && "readOnly"]
    };
    return composeClasses(slots, getInputBaseUtilityClass, classes);
  };
  const InputBaseRoot = styled$1("div", {
    name: "MuiInputBase",
    slot: "Root",
    overridesResolver: rootOverridesResolver
  })(({
    theme,
    ownerState
  }) => _extends({}, theme.typography.body1, {
    color: (theme.vars || theme).palette.text.primary,
    lineHeight: "1.4375em",
    boxSizing: "border-box",
    position: "relative",
    cursor: "text",
    display: "inline-flex",
    alignItems: "center",
    [`&.${inputBaseClasses$1.disabled}`]: {
      color: (theme.vars || theme).palette.text.disabled,
      cursor: "default"
    }
  }, ownerState.multiline && _extends({
    padding: "4px 0 5px"
  }, ownerState.size === "small" && {
    paddingTop: 1
  }), ownerState.fullWidth && {
    width: "100%"
  }));
  const InputBaseComponent = styled$1("input", {
    name: "MuiInputBase",
    slot: "Input",
    overridesResolver: inputOverridesResolver
  })(({
    theme,
    ownerState
  }) => {
    const light2 = theme.palette.mode === "light";
    const placeholder = _extends({
      color: "currentColor"
    }, theme.vars ? {
      opacity: theme.vars.opacity.inputPlaceholder
    } : {
      opacity: light2 ? 0.42 : 0.5
    }, {
      transition: theme.transitions.create("opacity", {
        duration: theme.transitions.duration.shorter
      })
    });
    const placeholderHidden = {
      opacity: "0 !important"
    };
    const placeholderVisible = theme.vars ? {
      opacity: theme.vars.opacity.inputPlaceholder
    } : {
      opacity: light2 ? 0.42 : 0.5
    };
    return _extends({
      font: "inherit",
      letterSpacing: "inherit",
      color: "currentColor",
      padding: "4px 0 5px",
      border: 0,
      boxSizing: "content-box",
      background: "none",
      height: "1.4375em",
      margin: 0,
      WebkitTapHighlightColor: "transparent",
      display: "block",
      minWidth: 0,
      width: "100%",
      animationName: "mui-auto-fill-cancel",
      animationDuration: "10ms",
      "&::-webkit-input-placeholder": placeholder,
      "&::-moz-placeholder": placeholder,
      "&:-ms-input-placeholder": placeholder,
      "&::-ms-input-placeholder": placeholder,
      "&:focus": {
        outline: 0
      },
      "&:invalid": {
        boxShadow: "none"
      },
      "&::-webkit-search-decoration": {
        WebkitAppearance: "none"
      },
      [`label[data-shrink=false] + .${inputBaseClasses$1.formControl} &`]: {
        "&::-webkit-input-placeholder": placeholderHidden,
        "&::-moz-placeholder": placeholderHidden,
        "&:-ms-input-placeholder": placeholderHidden,
        "&::-ms-input-placeholder": placeholderHidden,
        "&:focus::-webkit-input-placeholder": placeholderVisible,
        "&:focus::-moz-placeholder": placeholderVisible,
        "&:focus:-ms-input-placeholder": placeholderVisible,
        "&:focus::-ms-input-placeholder": placeholderVisible
      },
      [`&.${inputBaseClasses$1.disabled}`]: {
        opacity: 1,
        WebkitTextFillColor: (theme.vars || theme).palette.text.disabled
      },
      "&:-webkit-autofill": {
        animationDuration: "5000s",
        animationName: "mui-auto-fill"
      }
    }, ownerState.size === "small" && {
      paddingTop: 1
    }, ownerState.multiline && {
      height: "auto",
      resize: "none",
      padding: 0,
      paddingTop: 0
    }, ownerState.type === "search" && {
      MozAppearance: "textfield"
    });
  });
  const inputGlobalStyles = /* @__PURE__ */ jsx(GlobalStyles, {
    styles: {
      "@keyframes mui-auto-fill": {
        from: {
          display: "block"
        }
      },
      "@keyframes mui-auto-fill-cancel": {
        from: {
          display: "block"
        }
      }
    }
  });
  const InputBase = /* @__PURE__ */ react.exports.forwardRef(function InputBase2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiInputBase"
    });
    const {
      "aria-describedby": ariaDescribedby,
      autoComplete,
      autoFocus,
      className,
      components = {},
      componentsProps = {},
      defaultValue,
      disabled,
      disableInjectingGlobalStyles,
      endAdornment,
      fullWidth = false,
      id: id2,
      inputComponent = "input",
      inputProps: inputPropsProp = {},
      inputRef: inputRefProp,
      maxRows,
      minRows,
      multiline = false,
      name,
      onBlur,
      onChange,
      onClick,
      onFocus,
      onKeyDown,
      onKeyUp,
      placeholder,
      readOnly,
      renderSuffix,
      rows,
      startAdornment,
      type = "text",
      value: valueProp
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$s);
    const value = inputPropsProp.value != null ? inputPropsProp.value : valueProp;
    const {
      current: isControlled
    } = react.exports.useRef(value != null);
    const inputRef = react.exports.useRef();
    const handleInputRefWarning = react.exports.useCallback((instance) => {
    }, []);
    const handleInputPropsRefProp = useForkRef(inputPropsProp.ref, handleInputRefWarning);
    const handleInputRefProp = useForkRef(inputRefProp, handleInputPropsRefProp);
    const handleInputRef = useForkRef(inputRef, handleInputRefProp);
    const [focused, setFocused] = react.exports.useState(false);
    const muiFormControl = useFormControl();
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["color", "disabled", "error", "hiddenLabel", "size", "required", "filled"]
    });
    fcs.focused = muiFormControl ? muiFormControl.focused : focused;
    react.exports.useEffect(() => {
      if (!muiFormControl && disabled && focused) {
        setFocused(false);
        if (onBlur) {
          onBlur();
        }
      }
    }, [muiFormControl, disabled, focused, onBlur]);
    const onFilled = muiFormControl && muiFormControl.onFilled;
    const onEmpty = muiFormControl && muiFormControl.onEmpty;
    const checkDirty = react.exports.useCallback((obj) => {
      if (isFilled(obj)) {
        if (onFilled) {
          onFilled();
        }
      } else if (onEmpty) {
        onEmpty();
      }
    }, [onFilled, onEmpty]);
    useEnhancedEffect$1(() => {
      if (isControlled) {
        checkDirty({
          value
        });
      }
    }, [value, checkDirty, isControlled]);
    const handleFocus = (event) => {
      if (fcs.disabled) {
        event.stopPropagation();
        return;
      }
      if (onFocus) {
        onFocus(event);
      }
      if (inputPropsProp.onFocus) {
        inputPropsProp.onFocus(event);
      }
      if (muiFormControl && muiFormControl.onFocus) {
        muiFormControl.onFocus(event);
      } else {
        setFocused(true);
      }
    };
    const handleBlur = (event) => {
      if (onBlur) {
        onBlur(event);
      }
      if (inputPropsProp.onBlur) {
        inputPropsProp.onBlur(event);
      }
      if (muiFormControl && muiFormControl.onBlur) {
        muiFormControl.onBlur(event);
      } else {
        setFocused(false);
      }
    };
    const handleChange = (event, ...args) => {
      if (!isControlled) {
        const element = event.target || inputRef.current;
        if (element == null) {
          throw new Error(formatMuiErrorMessage(1));
        }
        checkDirty({
          value: element.value
        });
      }
      if (inputPropsProp.onChange) {
        inputPropsProp.onChange(event, ...args);
      }
      if (onChange) {
        onChange(event, ...args);
      }
    };
    react.exports.useEffect(() => {
      checkDirty(inputRef.current);
    }, []);
    const handleClick = (event) => {
      if (inputRef.current && event.currentTarget === event.target) {
        inputRef.current.focus();
      }
      if (onClick) {
        onClick(event);
      }
    };
    let InputComponent = inputComponent;
    let inputProps = inputPropsProp;
    if (multiline && InputComponent === "input") {
      if (rows) {
        inputProps = _extends({
          type: void 0,
          minRows: rows,
          maxRows: rows
        }, inputProps);
      } else {
        inputProps = _extends({
          type: void 0,
          maxRows,
          minRows
        }, inputProps);
      }
      InputComponent = TextareaAutosize$1;
    }
    const handleAutoFill = (event) => {
      checkDirty(event.animationName === "mui-auto-fill-cancel" ? inputRef.current : {
        value: "x"
      });
    };
    react.exports.useEffect(() => {
      if (muiFormControl) {
        muiFormControl.setAdornedStart(Boolean(startAdornment));
      }
    }, [muiFormControl, startAdornment]);
    const ownerState = _extends({}, props, {
      color: fcs.color || "primary",
      disabled: fcs.disabled,
      endAdornment,
      error: fcs.error,
      focused: fcs.focused,
      formControl: muiFormControl,
      fullWidth,
      hiddenLabel: fcs.hiddenLabel,
      multiline,
      size: fcs.size,
      startAdornment,
      type
    });
    const classes = useUtilityClasses$m(ownerState);
    const Root = components.Root || InputBaseRoot;
    const rootProps = componentsProps.root || {};
    const Input2 = components.Input || InputBaseComponent;
    inputProps = _extends({}, inputProps, componentsProps.input);
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [!disableInjectingGlobalStyles && inputGlobalStyles, /* @__PURE__ */ jsxs(Root, _extends({}, rootProps, !isHostComponent(Root) && {
        ownerState: _extends({}, ownerState, rootProps.ownerState)
      }, {
        ref,
        onClick: handleClick
      }, other, {
        className: clsx(classes.root, rootProps.className, className),
        children: [startAdornment, /* @__PURE__ */ jsx(FormControlContext$1.Provider, {
          value: null,
          children: /* @__PURE__ */ jsx(Input2, _extends({
            ownerState,
            "aria-invalid": fcs.error,
            "aria-describedby": ariaDescribedby,
            autoComplete,
            autoFocus,
            defaultValue,
            disabled: fcs.disabled,
            id: id2,
            onAnimationStart: handleAutoFill,
            name,
            placeholder,
            readOnly,
            required: fcs.required,
            rows,
            value,
            onKeyDown,
            onKeyUp,
            type
          }, inputProps, !isHostComponent(Input2) && {
            as: InputComponent,
            ownerState: _extends({}, ownerState, inputProps.ownerState)
          }, {
            ref: handleInputRef,
            className: clsx(classes.input, inputProps.className),
            onBlur: handleBlur,
            onChange: handleChange,
            onFocus: handleFocus
          }))
        }), endAdornment, renderSuffix ? renderSuffix(_extends({}, fcs, {
          startAdornment
        })) : null]
      }))]
    });
  });
  const InputBase$1 = InputBase;
  function getInputUtilityClass(slot) {
    return generateUtilityClass("MuiInput", slot);
  }
  const inputClasses = _extends({}, inputBaseClasses$1, generateUtilityClasses("MuiInput", ["root", "underline", "input"]));
  const inputClasses$1 = inputClasses;
  function getOutlinedInputUtilityClass(slot) {
    return generateUtilityClass("MuiOutlinedInput", slot);
  }
  const outlinedInputClasses = _extends({}, inputBaseClasses$1, generateUtilityClasses("MuiOutlinedInput", ["root", "notchedOutline", "input"]));
  const outlinedInputClasses$1 = outlinedInputClasses;
  function getFilledInputUtilityClass(slot) {
    return generateUtilityClass("MuiFilledInput", slot);
  }
  const filledInputClasses = _extends({}, inputBaseClasses$1, generateUtilityClasses("MuiFilledInput", ["root", "underline", "input"]));
  const filledInputClasses$1 = filledInputClasses;
  const ArrowDropDownIcon = createSvgIcon$1(/* @__PURE__ */ jsx("path", {
    d: "M7 10l5 5 5-5z"
  }), "ArrowDropDown");
  function getAutocompleteUtilityClass(slot) {
    return generateUtilityClass("MuiAutocomplete", slot);
  }
  const autocompleteClasses = generateUtilityClasses("MuiAutocomplete", ["root", "fullWidth", "focused", "focusVisible", "tag", "tagSizeSmall", "tagSizeMedium", "hasPopupIcon", "hasClearIcon", "inputRoot", "input", "inputFocused", "endAdornment", "clearIndicator", "popupIndicator", "popupIndicatorOpen", "popper", "popperDisablePortal", "paper", "listbox", "loading", "noOptions", "option", "groupLabel", "groupUl"]);
  const autocompleteClasses$1 = autocompleteClasses;
  var _ClearIcon, _ArrowDropDownIcon;
  const _excluded$r = ["autoComplete", "autoHighlight", "autoSelect", "blurOnSelect", "ChipProps", "className", "clearIcon", "clearOnBlur", "clearOnEscape", "clearText", "closeText", "componentsProps", "defaultValue", "disableClearable", "disableCloseOnSelect", "disabled", "disabledItemsFocusable", "disableListWrap", "disablePortal", "filterOptions", "filterSelectedOptions", "forcePopupIcon", "freeSolo", "fullWidth", "getLimitTagsText", "getOptionDisabled", "getOptionLabel", "isOptionEqualToValue", "groupBy", "handleHomeEndKeys", "id", "includeInputInList", "inputValue", "limitTags", "ListboxComponent", "ListboxProps", "loading", "loadingText", "multiple", "noOptionsText", "onChange", "onClose", "onHighlightChange", "onInputChange", "onOpen", "open", "openOnFocus", "openText", "options", "PaperComponent", "PopperComponent", "popupIcon", "readOnly", "renderGroup", "renderInput", "renderOption", "renderTags", "selectOnFocus", "size", "value"];
  const useUtilityClasses$l = (ownerState) => {
    const {
      classes,
      disablePortal,
      focused,
      fullWidth,
      hasClearIcon,
      hasPopupIcon,
      inputFocused,
      popupOpen,
      size
    } = ownerState;
    const slots = {
      root: ["root", focused && "focused", fullWidth && "fullWidth", hasClearIcon && "hasClearIcon", hasPopupIcon && "hasPopupIcon"],
      inputRoot: ["inputRoot"],
      input: ["input", inputFocused && "inputFocused"],
      tag: ["tag", `tagSize${capitalize(size)}`],
      endAdornment: ["endAdornment"],
      clearIndicator: ["clearIndicator"],
      popupIndicator: ["popupIndicator", popupOpen && "popupIndicatorOpen"],
      popper: ["popper", disablePortal && "popperDisablePortal"],
      paper: ["paper"],
      listbox: ["listbox"],
      loading: ["loading"],
      noOptions: ["noOptions"],
      option: ["option"],
      groupLabel: ["groupLabel"],
      groupUl: ["groupUl"]
    };
    return composeClasses(slots, getAutocompleteUtilityClass, classes);
  };
  const AutocompleteRoot = styled$1("div", {
    name: "MuiAutocomplete",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      const {
        fullWidth,
        hasClearIcon,
        hasPopupIcon,
        inputFocused,
        size
      } = ownerState;
      return [{
        [`& .${autocompleteClasses$1.tag}`]: styles2.tag
      }, {
        [`& .${autocompleteClasses$1.tag}`]: styles2[`tagSize${capitalize(size)}`]
      }, {
        [`& .${autocompleteClasses$1.inputRoot}`]: styles2.inputRoot
      }, {
        [`& .${autocompleteClasses$1.input}`]: styles2.input
      }, {
        [`& .${autocompleteClasses$1.input}`]: inputFocused && styles2.inputFocused
      }, styles2.root, fullWidth && styles2.fullWidth, hasPopupIcon && styles2.hasPopupIcon, hasClearIcon && styles2.hasClearIcon];
    }
  })(({
    ownerState
  }) => _extends({
    [`&.${autocompleteClasses$1.focused} .${autocompleteClasses$1.clearIndicator}`]: {
      visibility: "visible"
    },
    "@media (pointer: fine)": {
      [`&:hover .${autocompleteClasses$1.clearIndicator}`]: {
        visibility: "visible"
      }
    }
  }, ownerState.fullWidth && {
    width: "100%"
  }, {
    [`& .${autocompleteClasses$1.tag}`]: _extends({
      margin: 3,
      maxWidth: "calc(100% - 6px)"
    }, ownerState.size === "small" && {
      margin: 2,
      maxWidth: "calc(100% - 4px)"
    }),
    [`& .${autocompleteClasses$1.inputRoot}`]: {
      flexWrap: "wrap",
      [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 26 + 4
      },
      [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 52 + 4
      },
      [`& .${autocompleteClasses$1.input}`]: {
        width: 0,
        minWidth: 30
      }
    },
    [`& .${inputClasses$1.root}`]: {
      paddingBottom: 1,
      "& .MuiInput-input": {
        padding: "4px 4px 4px 0px"
      }
    },
    [`& .${inputClasses$1.root}.${inputBaseClasses$1.sizeSmall}`]: {
      [`& .${inputClasses$1.input}`]: {
        padding: "2px 4px 3px 0"
      }
    },
    [`& .${outlinedInputClasses$1.root}`]: {
      padding: 9,
      [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 26 + 4 + 9
      },
      [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 52 + 4 + 9
      },
      [`& .${autocompleteClasses$1.input}`]: {
        padding: "7.5px 4px 7.5px 6px"
      },
      [`& .${autocompleteClasses$1.endAdornment}`]: {
        right: 9
      }
    },
    [`& .${outlinedInputClasses$1.root}.${inputBaseClasses$1.sizeSmall}`]: {
      paddingTop: 6,
      paddingBottom: 6,
      paddingLeft: 6,
      [`& .${autocompleteClasses$1.input}`]: {
        padding: "2.5px 4px 2.5px 6px"
      }
    },
    [`& .${filledInputClasses$1.root}`]: {
      paddingTop: 19,
      paddingLeft: 8,
      [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 26 + 4 + 9
      },
      [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
        paddingRight: 52 + 4 + 9
      },
      [`& .${filledInputClasses$1.input}`]: {
        padding: "7px 4px"
      },
      [`& .${autocompleteClasses$1.endAdornment}`]: {
        right: 9
      }
    },
    [`& .${filledInputClasses$1.root}.${inputBaseClasses$1.sizeSmall}`]: {
      paddingBottom: 1,
      [`& .${filledInputClasses$1.input}`]: {
        padding: "2.5px 4px"
      }
    },
    [`& .${inputBaseClasses$1.hiddenLabel}`]: {
      paddingTop: 8
    },
    [`& .${autocompleteClasses$1.input}`]: _extends({
      flexGrow: 1,
      textOverflow: "ellipsis",
      opacity: 0
    }, ownerState.inputFocused && {
      opacity: 1
    })
  }));
  const AutocompleteEndAdornment = styled$1("div", {
    name: "MuiAutocomplete",
    slot: "EndAdornment",
    overridesResolver: (props, styles2) => styles2.endAdornment
  })({
    position: "absolute",
    right: 0,
    top: "calc(50% - 14px)"
  });
  const AutocompleteClearIndicator = styled$1(IconButton$1, {
    name: "MuiAutocomplete",
    slot: "ClearIndicator",
    overridesResolver: (props, styles2) => styles2.clearIndicator
  })({
    marginRight: -2,
    padding: 4,
    visibility: "hidden"
  });
  const AutocompletePopupIndicator = styled$1(IconButton$1, {
    name: "MuiAutocomplete",
    slot: "PopupIndicator",
    overridesResolver: ({
      ownerState
    }, styles2) => _extends({}, styles2.popupIndicator, ownerState.popupOpen && styles2.popupIndicatorOpen)
  })(({
    ownerState
  }) => _extends({
    padding: 2,
    marginRight: -2
  }, ownerState.popupOpen && {
    transform: "rotate(180deg)"
  }));
  const AutocompletePopper = styled$1(Popper$1, {
    name: "MuiAutocomplete",
    slot: "Popper",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [{
        [`& .${autocompleteClasses$1.option}`]: styles2.option
      }, styles2.popper, ownerState.disablePortal && styles2.popperDisablePortal];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    zIndex: (theme.vars || theme).zIndex.modal
  }, ownerState.disablePortal && {
    position: "absolute"
  }));
  const AutocompletePaper = styled$1(Paper$1, {
    name: "MuiAutocomplete",
    slot: "Paper",
    overridesResolver: (props, styles2) => styles2.paper
  })(({
    theme
  }) => _extends({}, theme.typography.body1, {
    overflow: "auto"
  }));
  const AutocompleteLoading = styled$1("div", {
    name: "MuiAutocomplete",
    slot: "Loading",
    overridesResolver: (props, styles2) => styles2.loading
  })(({
    theme
  }) => ({
    color: (theme.vars || theme).palette.text.secondary,
    padding: "14px 16px"
  }));
  const AutocompleteNoOptions = styled$1("div", {
    name: "MuiAutocomplete",
    slot: "NoOptions",
    overridesResolver: (props, styles2) => styles2.noOptions
  })(({
    theme
  }) => ({
    color: (theme.vars || theme).palette.text.secondary,
    padding: "14px 16px"
  }));
  const AutocompleteListbox = styled$1("div", {
    name: "MuiAutocomplete",
    slot: "Listbox",
    overridesResolver: (props, styles2) => styles2.listbox
  })(({
    theme
  }) => ({
    listStyle: "none",
    margin: 0,
    padding: "8px 0",
    maxHeight: "40vh",
    overflow: "auto",
    [`& .${autocompleteClasses$1.option}`]: {
      minHeight: 48,
      display: "flex",
      overflow: "hidden",
      justifyContent: "flex-start",
      alignItems: "center",
      cursor: "pointer",
      paddingTop: 6,
      boxSizing: "border-box",
      outline: "0",
      WebkitTapHighlightColor: "transparent",
      paddingBottom: 6,
      paddingLeft: 16,
      paddingRight: 16,
      [theme.breakpoints.up("sm")]: {
        minHeight: "auto"
      },
      [`&.${autocompleteClasses$1.focused}`]: {
        backgroundColor: (theme.vars || theme).palette.action.hover,
        "@media (hover: none)": {
          backgroundColor: "transparent"
        }
      },
      '&[aria-disabled="true"]': {
        opacity: (theme.vars || theme).palette.action.disabledOpacity,
        pointerEvents: "none"
      },
      [`&.${autocompleteClasses$1.focusVisible}`]: {
        backgroundColor: (theme.vars || theme).palette.action.focus
      },
      '&[aria-selected="true"]': {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
        [`&.${autocompleteClasses$1.focused}`]: {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
          "@media (hover: none)": {
            backgroundColor: (theme.vars || theme).palette.action.selected
          }
        },
        [`&.${autocompleteClasses$1.focusVisible}`]: {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
        }
      }
    }
  }));
  const AutocompleteGroupLabel = styled$1(ListSubheader$1, {
    name: "MuiAutocomplete",
    slot: "GroupLabel",
    overridesResolver: (props, styles2) => styles2.groupLabel
  })(({
    theme
  }) => ({
    backgroundColor: (theme.vars || theme).palette.background.paper,
    top: -8
  }));
  const AutocompleteGroupUl = styled$1("ul", {
    name: "MuiAutocomplete",
    slot: "GroupUl",
    overridesResolver: (props, styles2) => styles2.groupUl
  })({
    padding: 0,
    [`& .${autocompleteClasses$1.option}`]: {
      paddingLeft: 24
    }
  });
  const Autocomplete = /* @__PURE__ */ react.exports.forwardRef(function Autocomplete2(inProps, ref) {
    var _componentsProps$clea, _componentsProps$popu, _componentsProps$popp, _componentsProps$pape;
    const props = useThemeProps({
      props: inProps,
      name: "MuiAutocomplete"
    });
    const {
      autoComplete = false,
      autoHighlight = false,
      autoSelect = false,
      blurOnSelect = false,
      ChipProps,
      className,
      clearIcon = _ClearIcon || (_ClearIcon = /* @__PURE__ */ jsx(ClearIcon, {
        fontSize: "small"
      })),
      clearOnBlur = !props.freeSolo,
      clearOnEscape = false,
      clearText = "Clear",
      closeText = "Close",
      componentsProps = {},
      defaultValue = props.multiple ? [] : null,
      disableClearable = false,
      disableCloseOnSelect = false,
      disabled = false,
      disabledItemsFocusable = false,
      disableListWrap = false,
      disablePortal = false,
      filterSelectedOptions = false,
      forcePopupIcon = "auto",
      freeSolo = false,
      fullWidth = false,
      getLimitTagsText = (more) => `+${more}`,
      getOptionLabel = (option) => {
        var _option$label;
        return (_option$label = option.label) != null ? _option$label : option;
      },
      groupBy,
      handleHomeEndKeys = !props.freeSolo,
      includeInputInList = false,
      limitTags = -1,
      ListboxComponent = "ul",
      ListboxProps,
      loading = false,
      loadingText = "Loading\u2026",
      multiple = false,
      noOptionsText = "No options",
      openOnFocus = false,
      openText = "Open",
      PaperComponent = Paper$1,
      PopperComponent = Popper$1,
      popupIcon = _ArrowDropDownIcon || (_ArrowDropDownIcon = /* @__PURE__ */ jsx(ArrowDropDownIcon, {})),
      readOnly = false,
      renderGroup: renderGroupProp,
      renderInput,
      renderOption: renderOptionProp,
      renderTags,
      selectOnFocus = !props.freeSolo,
      size = "medium"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$r);
    const {
      getRootProps,
      getInputProps,
      getInputLabelProps,
      getPopupIndicatorProps,
      getClearProps,
      getTagProps,
      getListboxProps,
      getOptionProps,
      value,
      dirty,
      id: id2,
      popupOpen,
      focused,
      focusedTag,
      anchorEl,
      setAnchorEl,
      inputValue,
      groupedOptions
    } = useAutocomplete(_extends({}, props, {
      componentName: "Autocomplete"
    }));
    const hasClearIcon = !disableClearable && !disabled && dirty && !readOnly;
    const hasPopupIcon = (!freeSolo || forcePopupIcon === true) && forcePopupIcon !== false;
    const ownerState = _extends({}, props, {
      disablePortal,
      focused,
      fullWidth,
      hasClearIcon,
      hasPopupIcon,
      inputFocused: focusedTag === -1,
      popupOpen,
      size
    });
    const classes = useUtilityClasses$l(ownerState);
    let startAdornment;
    if (multiple && value.length > 0) {
      const getCustomizedTagProps = (params) => _extends({
        className: classes.tag,
        disabled
      }, getTagProps(params));
      if (renderTags) {
        startAdornment = renderTags(value, getCustomizedTagProps, ownerState);
      } else {
        startAdornment = value.map((option, index) => /* @__PURE__ */ jsx(Chip$1, _extends({
          label: getOptionLabel(option),
          size
        }, getCustomizedTagProps({
          index
        }), ChipProps)));
      }
    }
    if (limitTags > -1 && Array.isArray(startAdornment)) {
      const more = startAdornment.length - limitTags;
      if (!focused && more > 0) {
        startAdornment = startAdornment.splice(0, limitTags);
        startAdornment.push(/* @__PURE__ */ jsx("span", {
          className: classes.tag,
          children: getLimitTagsText(more)
        }, startAdornment.length));
      }
    }
    const defaultRenderGroup = (params) => /* @__PURE__ */ jsxs("li", {
      children: [/* @__PURE__ */ jsx(AutocompleteGroupLabel, {
        className: classes.groupLabel,
        ownerState,
        component: "div",
        children: params.group
      }), /* @__PURE__ */ jsx(AutocompleteGroupUl, {
        className: classes.groupUl,
        ownerState,
        children: params.children
      })]
    }, params.key);
    const renderGroup = renderGroupProp || defaultRenderGroup;
    const defaultRenderOption = (props2, option) => /* @__PURE__ */ jsx("li", _extends({}, props2, {
      children: getOptionLabel(option)
    }));
    const renderOption = renderOptionProp || defaultRenderOption;
    const renderListOption = (option, index) => {
      const optionProps = getOptionProps({
        option,
        index
      });
      return renderOption(_extends({}, optionProps, {
        className: classes.option
      }), option, {
        selected: optionProps["aria-selected"],
        inputValue
      });
    };
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx(AutocompleteRoot, _extends({
        ref,
        className: clsx(classes.root, className),
        ownerState
      }, getRootProps(other), {
        children: renderInput({
          id: id2,
          disabled,
          fullWidth: true,
          size: size === "small" ? "small" : void 0,
          InputLabelProps: getInputLabelProps(),
          InputProps: _extends({
            ref: setAnchorEl,
            className: classes.inputRoot,
            startAdornment
          }, (hasClearIcon || hasPopupIcon) && {
            endAdornment: /* @__PURE__ */ jsxs(AutocompleteEndAdornment, {
              className: classes.endAdornment,
              ownerState,
              children: [hasClearIcon ? /* @__PURE__ */ jsx(AutocompleteClearIndicator, _extends({}, getClearProps(), {
                "aria-label": clearText,
                title: clearText,
                ownerState
              }, componentsProps.clearIndicator, {
                className: clsx(classes.clearIndicator, (_componentsProps$clea = componentsProps.clearIndicator) == null ? void 0 : _componentsProps$clea.className),
                children: clearIcon
              })) : null, hasPopupIcon ? /* @__PURE__ */ jsx(AutocompletePopupIndicator, _extends({}, getPopupIndicatorProps(), {
                disabled,
                "aria-label": popupOpen ? closeText : openText,
                title: popupOpen ? closeText : openText,
                ownerState
              }, componentsProps.popupIndicator, {
                className: clsx(classes.popupIndicator, (_componentsProps$popu = componentsProps.popupIndicator) == null ? void 0 : _componentsProps$popu.className),
                children: popupIcon
              })) : null]
            })
          }),
          inputProps: _extends({
            className: classes.input,
            disabled,
            readOnly
          }, getInputProps())
        })
      })), anchorEl ? /* @__PURE__ */ jsx(AutocompletePopper, _extends({
        as: PopperComponent,
        disablePortal,
        style: {
          width: anchorEl ? anchorEl.clientWidth : null
        },
        ownerState,
        role: "presentation",
        anchorEl,
        open: popupOpen
      }, componentsProps.popper, {
        className: clsx(classes.popper, (_componentsProps$popp = componentsProps.popper) == null ? void 0 : _componentsProps$popp.className),
        children: /* @__PURE__ */ jsxs(AutocompletePaper, _extends({
          ownerState,
          as: PaperComponent
        }, componentsProps.paper, {
          className: clsx(classes.paper, (_componentsProps$pape = componentsProps.paper) == null ? void 0 : _componentsProps$pape.className),
          children: [loading && groupedOptions.length === 0 ? /* @__PURE__ */ jsx(AutocompleteLoading, {
            className: classes.loading,
            ownerState,
            children: loadingText
          }) : null, groupedOptions.length === 0 && !freeSolo && !loading ? /* @__PURE__ */ jsx(AutocompleteNoOptions, {
            className: classes.noOptions,
            ownerState,
            role: "presentation",
            onMouseDown: (event) => {
              event.preventDefault();
            },
            children: noOptionsText
          }) : null, groupedOptions.length > 0 ? /* @__PURE__ */ jsx(AutocompleteListbox, _extends({
            as: ListboxComponent,
            className: classes.listbox,
            ownerState
          }, getListboxProps(), ListboxProps, {
            children: groupedOptions.map((option, index) => {
              if (groupBy) {
                return renderGroup({
                  key: option.key,
                  group: option.group,
                  children: option.options.map((option2, index2) => renderListOption(option2, option.index + index2))
                });
              }
              return renderListOption(option, index);
            })
          })) : null]
        }))
      })) : null]
    });
  });
  const Autocomplete$1 = Autocomplete;
  const _excluded$q = ["addEndListener", "appear", "children", "easing", "in", "onEnter", "onEntered", "onEntering", "onExit", "onExited", "onExiting", "style", "timeout", "TransitionComponent"];
  const styles$2 = {
    entering: {
      opacity: 1
    },
    entered: {
      opacity: 1
    }
  };
  const Fade = /* @__PURE__ */ react.exports.forwardRef(function Fade2(props, ref) {
    const theme = useTheme();
    const defaultTimeout = {
      enter: theme.transitions.duration.enteringScreen,
      exit: theme.transitions.duration.leavingScreen
    };
    const {
      addEndListener,
      appear = true,
      children,
      easing: easing2,
      in: inProp,
      onEnter,
      onEntered,
      onEntering,
      onExit,
      onExited,
      onExiting,
      style: style2,
      timeout = defaultTimeout,
      TransitionComponent = Transition$1
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$q);
    const nodeRef = react.exports.useRef(null);
    const foreignRef = useForkRef(children.ref, ref);
    const handleRef = useForkRef(nodeRef, foreignRef);
    const normalizedTransitionCallback = (callback) => (maybeIsAppearing) => {
      if (callback) {
        const node2 = nodeRef.current;
        if (maybeIsAppearing === void 0) {
          callback(node2);
        } else {
          callback(node2, maybeIsAppearing);
        }
      }
    };
    const handleEntering = normalizedTransitionCallback(onEntering);
    const handleEnter = normalizedTransitionCallback((node2, isAppearing) => {
      reflow(node2);
      const transitionProps = getTransitionProps({
        style: style2,
        timeout,
        easing: easing2
      }, {
        mode: "enter"
      });
      node2.style.webkitTransition = theme.transitions.create("opacity", transitionProps);
      node2.style.transition = theme.transitions.create("opacity", transitionProps);
      if (onEnter) {
        onEnter(node2, isAppearing);
      }
    });
    const handleEntered = normalizedTransitionCallback(onEntered);
    const handleExiting = normalizedTransitionCallback(onExiting);
    const handleExit = normalizedTransitionCallback((node2) => {
      const transitionProps = getTransitionProps({
        style: style2,
        timeout,
        easing: easing2
      }, {
        mode: "exit"
      });
      node2.style.webkitTransition = theme.transitions.create("opacity", transitionProps);
      node2.style.transition = theme.transitions.create("opacity", transitionProps);
      if (onExit) {
        onExit(node2);
      }
    });
    const handleExited = normalizedTransitionCallback(onExited);
    const handleAddEndListener = (next2) => {
      if (addEndListener) {
        addEndListener(nodeRef.current, next2);
      }
    };
    return /* @__PURE__ */ jsx(TransitionComponent, _extends({
      appear,
      in: inProp,
      nodeRef,
      onEnter: handleEnter,
      onEntered: handleEntered,
      onEntering: handleEntering,
      onExit: handleExit,
      onExited: handleExited,
      onExiting: handleExiting,
      addEndListener: handleAddEndListener,
      timeout
    }, other, {
      children: (state, childProps) => {
        return /* @__PURE__ */ react.exports.cloneElement(children, _extends({
          style: _extends({
            opacity: 0,
            visibility: state === "exited" && !inProp ? "hidden" : void 0
          }, styles$2[state], style2, children.props.style),
          ref: handleRef
        }, childProps));
      }
    }));
  });
  const Fade$1 = Fade;
  function getBackdropUtilityClass(slot) {
    return generateUtilityClass("MuiBackdrop", slot);
  }
  generateUtilityClasses("MuiBackdrop", ["root", "invisible"]);
  const _excluded$p = ["children", "component", "components", "componentsProps", "className", "invisible", "open", "transitionDuration", "TransitionComponent"];
  const useUtilityClasses$k = (ownerState) => {
    const {
      classes,
      invisible
    } = ownerState;
    const slots = {
      root: ["root", invisible && "invisible"]
    };
    return composeClasses(slots, getBackdropUtilityClass, classes);
  };
  const BackdropRoot = styled$1("div", {
    name: "MuiBackdrop",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.invisible && styles2.invisible];
    }
  })(({
    ownerState
  }) => _extends({
    position: "fixed",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    right: 0,
    bottom: 0,
    top: 0,
    left: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    WebkitTapHighlightColor: "transparent"
  }, ownerState.invisible && {
    backgroundColor: "transparent"
  }));
  const Backdrop = /* @__PURE__ */ react.exports.forwardRef(function Backdrop2(inProps, ref) {
    var _components$Root, _componentsProps$root;
    const props = useThemeProps({
      props: inProps,
      name: "MuiBackdrop"
    });
    const {
      children,
      component = "div",
      components = {},
      componentsProps = {},
      className,
      invisible = false,
      open,
      transitionDuration,
      TransitionComponent = Fade$1
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$p);
    const ownerState = _extends({}, props, {
      component,
      invisible
    });
    const classes = useUtilityClasses$k(ownerState);
    return /* @__PURE__ */ jsx(TransitionComponent, _extends({
      in: open,
      timeout: transitionDuration
    }, other, {
      children: /* @__PURE__ */ jsx(BackdropRoot, {
        "aria-hidden": true,
        as: (_components$Root = components.Root) != null ? _components$Root : component,
        className: clsx(classes.root, className),
        ownerState: _extends({}, ownerState, (_componentsProps$root = componentsProps.root) == null ? void 0 : _componentsProps$root.ownerState),
        classes,
        ref,
        children
      })
    }));
  });
  const Backdrop$1 = Backdrop;
  const defaultTheme = createTheme();
  const Box = createBox({
    defaultTheme,
    defaultClassName: "MuiBox-root",
    generateClassName: ClassNameGenerator$1.generate
  });
  const Box$1 = Box;
  function getButtonUtilityClass(slot) {
    return generateUtilityClass("MuiButton", slot);
  }
  const buttonClasses = generateUtilityClasses("MuiButton", ["root", "text", "textInherit", "textPrimary", "textSecondary", "textSuccess", "textError", "textInfo", "textWarning", "outlined", "outlinedInherit", "outlinedPrimary", "outlinedSecondary", "outlinedSuccess", "outlinedError", "outlinedInfo", "outlinedWarning", "contained", "containedInherit", "containedPrimary", "containedSecondary", "containedSuccess", "containedError", "containedInfo", "containedWarning", "disableElevation", "focusVisible", "disabled", "colorInherit", "textSizeSmall", "textSizeMedium", "textSizeLarge", "outlinedSizeSmall", "outlinedSizeMedium", "outlinedSizeLarge", "containedSizeSmall", "containedSizeMedium", "containedSizeLarge", "sizeMedium", "sizeSmall", "sizeLarge", "fullWidth", "startIcon", "endIcon", "iconSizeSmall", "iconSizeMedium", "iconSizeLarge"]);
  const buttonClasses$1 = buttonClasses;
  const ButtonGroupContext = /* @__PURE__ */ react.exports.createContext({});
  const ButtonGroupContext$1 = ButtonGroupContext;
  const _excluded$o = ["children", "color", "component", "className", "disabled", "disableElevation", "disableFocusRipple", "endIcon", "focusVisibleClassName", "fullWidth", "size", "startIcon", "type", "variant"];
  const useUtilityClasses$j = (ownerState) => {
    const {
      color: color2,
      disableElevation,
      fullWidth,
      size,
      variant,
      classes
    } = ownerState;
    const slots = {
      root: ["root", variant, `${variant}${capitalize(color2)}`, `size${capitalize(size)}`, `${variant}Size${capitalize(size)}`, color2 === "inherit" && "colorInherit", disableElevation && "disableElevation", fullWidth && "fullWidth"],
      label: ["label"],
      startIcon: ["startIcon", `iconSize${capitalize(size)}`],
      endIcon: ["endIcon", `iconSize${capitalize(size)}`]
    };
    const composedClasses = composeClasses(slots, getButtonUtilityClass, classes);
    return _extends({}, classes, composedClasses);
  };
  const commonIconStyles = (ownerState) => _extends({}, ownerState.size === "small" && {
    "& > *:nth-of-type(1)": {
      fontSize: 18
    }
  }, ownerState.size === "medium" && {
    "& > *:nth-of-type(1)": {
      fontSize: 20
    }
  }, ownerState.size === "large" && {
    "& > *:nth-of-type(1)": {
      fontSize: 22
    }
  });
  const ButtonRoot = styled$1(ButtonBase$1, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiButton",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, styles2[ownerState.variant], styles2[`${ownerState.variant}${capitalize(ownerState.color)}`], styles2[`size${capitalize(ownerState.size)}`], styles2[`${ownerState.variant}Size${capitalize(ownerState.size)}`], ownerState.color === "inherit" && styles2.colorInherit, ownerState.disableElevation && styles2.disableElevation, ownerState.fullWidth && styles2.fullWidth];
    }
  })(({
    theme,
    ownerState
  }) => {
    var _theme$palette$getCon, _theme$palette;
    return _extends({}, theme.typography.button, {
      minWidth: 64,
      padding: "6px 16px",
      borderRadius: (theme.vars || theme).shape.borderRadius,
      transition: theme.transitions.create(["background-color", "box-shadow", "border-color", "color"], {
        duration: theme.transitions.duration.short
      }),
      "&:hover": _extends({
        textDecoration: "none",
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.text.primaryChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette.text.primary, theme.palette.action.hoverOpacity),
        "@media (hover: none)": {
          backgroundColor: "transparent"
        }
      }, ownerState.variant === "text" && ownerState.color !== "inherit" && {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity),
        "@media (hover: none)": {
          backgroundColor: "transparent"
        }
      }, ownerState.variant === "outlined" && ownerState.color !== "inherit" && {
        border: `1px solid ${(theme.vars || theme).palette[ownerState.color].main}`,
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity),
        "@media (hover: none)": {
          backgroundColor: "transparent"
        }
      }, ownerState.variant === "contained" && {
        backgroundColor: (theme.vars || theme).palette.grey.A100,
        boxShadow: (theme.vars || theme).shadows[4],
        "@media (hover: none)": {
          boxShadow: (theme.vars || theme).shadows[2],
          backgroundColor: (theme.vars || theme).palette.grey[300]
        }
      }, ownerState.variant === "contained" && ownerState.color !== "inherit" && {
        backgroundColor: (theme.vars || theme).palette[ownerState.color].dark,
        "@media (hover: none)": {
          backgroundColor: (theme.vars || theme).palette[ownerState.color].main
        }
      }),
      "&:active": _extends({}, ownerState.variant === "contained" && {
        boxShadow: (theme.vars || theme).shadows[8]
      }),
      [`&.${buttonClasses$1.focusVisible}`]: _extends({}, ownerState.variant === "contained" && {
        boxShadow: (theme.vars || theme).shadows[6]
      }),
      [`&.${buttonClasses$1.disabled}`]: _extends({
        color: (theme.vars || theme).palette.action.disabled
      }, ownerState.variant === "outlined" && {
        border: `1px solid ${(theme.vars || theme).palette.action.disabledBackground}`
      }, ownerState.variant === "outlined" && ownerState.color === "secondary" && {
        border: `1px solid ${(theme.vars || theme).palette.action.disabled}`
      }, ownerState.variant === "contained" && {
        color: (theme.vars || theme).palette.action.disabled,
        boxShadow: (theme.vars || theme).shadows[0],
        backgroundColor: (theme.vars || theme).palette.action.disabledBackground
      })
    }, ownerState.variant === "text" && {
      padding: "6px 8px"
    }, ownerState.variant === "text" && ownerState.color !== "inherit" && {
      color: (theme.vars || theme).palette[ownerState.color].main
    }, ownerState.variant === "outlined" && {
      padding: "5px 15px",
      border: "1px solid currentColor"
    }, ownerState.variant === "outlined" && ownerState.color !== "inherit" && {
      color: (theme.vars || theme).palette[ownerState.color].main,
      border: theme.vars ? `1px solid rgba(${theme.vars.palette[ownerState.color].mainChannel} / 0.5)` : `1px solid ${alpha(theme.palette[ownerState.color].main, 0.5)}`
    }, ownerState.variant === "contained" && {
      color: theme.vars ? theme.vars.palette.text.primary : (_theme$palette$getCon = (_theme$palette = theme.palette).getContrastText) == null ? void 0 : _theme$palette$getCon.call(_theme$palette, theme.palette.grey[300]),
      backgroundColor: (theme.vars || theme).palette.grey[300],
      boxShadow: (theme.vars || theme).shadows[2]
    }, ownerState.variant === "contained" && ownerState.color !== "inherit" && {
      color: (theme.vars || theme).palette[ownerState.color].contrastText,
      backgroundColor: (theme.vars || theme).palette[ownerState.color].main
    }, ownerState.color === "inherit" && {
      color: "inherit",
      borderColor: "currentColor"
    }, ownerState.size === "small" && ownerState.variant === "text" && {
      padding: "4px 5px",
      fontSize: theme.typography.pxToRem(13)
    }, ownerState.size === "large" && ownerState.variant === "text" && {
      padding: "8px 11px",
      fontSize: theme.typography.pxToRem(15)
    }, ownerState.size === "small" && ownerState.variant === "outlined" && {
      padding: "3px 9px",
      fontSize: theme.typography.pxToRem(13)
    }, ownerState.size === "large" && ownerState.variant === "outlined" && {
      padding: "7px 21px",
      fontSize: theme.typography.pxToRem(15)
    }, ownerState.size === "small" && ownerState.variant === "contained" && {
      padding: "4px 10px",
      fontSize: theme.typography.pxToRem(13)
    }, ownerState.size === "large" && ownerState.variant === "contained" && {
      padding: "8px 22px",
      fontSize: theme.typography.pxToRem(15)
    }, ownerState.fullWidth && {
      width: "100%"
    });
  }, ({
    ownerState
  }) => ownerState.disableElevation && {
    boxShadow: "none",
    "&:hover": {
      boxShadow: "none"
    },
    [`&.${buttonClasses$1.focusVisible}`]: {
      boxShadow: "none"
    },
    "&:active": {
      boxShadow: "none"
    },
    [`&.${buttonClasses$1.disabled}`]: {
      boxShadow: "none"
    }
  });
  const ButtonStartIcon = styled$1("span", {
    name: "MuiButton",
    slot: "StartIcon",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.startIcon, styles2[`iconSize${capitalize(ownerState.size)}`]];
    }
  })(({
    ownerState
  }) => _extends({
    display: "inherit",
    marginRight: 8,
    marginLeft: -4
  }, ownerState.size === "small" && {
    marginLeft: -2
  }, commonIconStyles(ownerState)));
  const ButtonEndIcon = styled$1("span", {
    name: "MuiButton",
    slot: "EndIcon",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.endIcon, styles2[`iconSize${capitalize(ownerState.size)}`]];
    }
  })(({
    ownerState
  }) => _extends({
    display: "inherit",
    marginRight: -4,
    marginLeft: 8
  }, ownerState.size === "small" && {
    marginRight: -2
  }, commonIconStyles(ownerState)));
  const Button = /* @__PURE__ */ react.exports.forwardRef(function Button2(inProps, ref) {
    const contextProps = react.exports.useContext(ButtonGroupContext$1);
    const resolvedProps = resolveProps(contextProps, inProps);
    const props = useThemeProps({
      props: resolvedProps,
      name: "MuiButton"
    });
    const {
      children,
      color: color2 = "primary",
      component = "button",
      className,
      disabled = false,
      disableElevation = false,
      disableFocusRipple = false,
      endIcon: endIconProp,
      focusVisibleClassName,
      fullWidth = false,
      size = "medium",
      startIcon: startIconProp,
      type,
      variant = "text"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$o);
    const ownerState = _extends({}, props, {
      color: color2,
      component,
      disabled,
      disableElevation,
      disableFocusRipple,
      fullWidth,
      size,
      type,
      variant
    });
    const classes = useUtilityClasses$j(ownerState);
    const startIcon = startIconProp && /* @__PURE__ */ jsx(ButtonStartIcon, {
      className: classes.startIcon,
      ownerState,
      children: startIconProp
    });
    const endIcon = endIconProp && /* @__PURE__ */ jsx(ButtonEndIcon, {
      className: classes.endIcon,
      ownerState,
      children: endIconProp
    });
    return /* @__PURE__ */ jsxs(ButtonRoot, _extends({
      ownerState,
      className: clsx(contextProps.className, classes.root, className),
      component,
      disabled,
      focusRipple: !disableFocusRipple,
      focusVisibleClassName: clsx(classes.focusVisible, focusVisibleClassName),
      ref,
      type
    }, other, {
      classes,
      children: [startIcon, children, endIcon]
    }));
  });
  const Button$1 = Button;
  function getCircularProgressUtilityClass(slot) {
    return generateUtilityClass("MuiCircularProgress", slot);
  }
  generateUtilityClasses("MuiCircularProgress", ["root", "determinate", "indeterminate", "colorPrimary", "colorSecondary", "svg", "circle", "circleDeterminate", "circleIndeterminate", "circleDisableShrink"]);
  const _excluded$n = ["className", "color", "disableShrink", "size", "style", "thickness", "value", "variant"];
  let _ = (t2) => t2, _t, _t2, _t3, _t4;
  const SIZE = 44;
  const circularRotateKeyframe = keyframes(_t || (_t = _`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`));
  const circularDashKeyframe = keyframes(_t2 || (_t2 = _`
  0% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: 0;
  }

  50% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -15px;
  }

  100% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -125px;
  }
`));
  const useUtilityClasses$i = (ownerState) => {
    const {
      classes,
      variant,
      color: color2,
      disableShrink
    } = ownerState;
    const slots = {
      root: ["root", variant, `color${capitalize(color2)}`],
      svg: ["svg"],
      circle: ["circle", `circle${capitalize(variant)}`, disableShrink && "circleDisableShrink"]
    };
    return composeClasses(slots, getCircularProgressUtilityClass, classes);
  };
  const CircularProgressRoot = styled$1("span", {
    name: "MuiCircularProgress",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, styles2[ownerState.variant], styles2[`color${capitalize(ownerState.color)}`]];
    }
  })(({
    ownerState,
    theme
  }) => _extends({
    display: "inline-block"
  }, ownerState.variant === "determinate" && {
    transition: theme.transitions.create("transform")
  }, ownerState.color !== "inherit" && {
    color: (theme.vars || theme).palette[ownerState.color].main
  }), ({
    ownerState
  }) => ownerState.variant === "indeterminate" && css(_t3 || (_t3 = _`
      animation: ${0} 1.4s linear infinite;
    `), circularRotateKeyframe));
  const CircularProgressSVG = styled$1("svg", {
    name: "MuiCircularProgress",
    slot: "Svg",
    overridesResolver: (props, styles2) => styles2.svg
  })({
    display: "block"
  });
  const CircularProgressCircle = styled$1("circle", {
    name: "MuiCircularProgress",
    slot: "Circle",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.circle, styles2[`circle${capitalize(ownerState.variant)}`], ownerState.disableShrink && styles2.circleDisableShrink];
    }
  })(({
    ownerState,
    theme
  }) => _extends({
    stroke: "currentColor"
  }, ownerState.variant === "determinate" && {
    transition: theme.transitions.create("stroke-dashoffset")
  }, ownerState.variant === "indeterminate" && {
    strokeDasharray: "80px, 200px",
    strokeDashoffset: 0
  }), ({
    ownerState
  }) => ownerState.variant === "indeterminate" && !ownerState.disableShrink && css(_t4 || (_t4 = _`
      animation: ${0} 1.4s ease-in-out infinite;
    `), circularDashKeyframe));
  const CircularProgress = /* @__PURE__ */ react.exports.forwardRef(function CircularProgress2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiCircularProgress"
    });
    const {
      className,
      color: color2 = "primary",
      disableShrink = false,
      size = 40,
      style: style2,
      thickness = 3.6,
      value = 0,
      variant = "indeterminate"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$n);
    const ownerState = _extends({}, props, {
      color: color2,
      disableShrink,
      size,
      thickness,
      value,
      variant
    });
    const classes = useUtilityClasses$i(ownerState);
    const circleStyle = {};
    const rootStyle = {};
    const rootProps = {};
    if (variant === "determinate") {
      const circumference = 2 * Math.PI * ((SIZE - thickness) / 2);
      circleStyle.strokeDasharray = circumference.toFixed(3);
      rootProps["aria-valuenow"] = Math.round(value);
      circleStyle.strokeDashoffset = `${((100 - value) / 100 * circumference).toFixed(3)}px`;
      rootStyle.transform = "rotate(-90deg)";
    }
    return /* @__PURE__ */ jsx(CircularProgressRoot, _extends({
      className: clsx(classes.root, className),
      style: _extends({
        width: size,
        height: size
      }, rootStyle, style2),
      ownerState,
      ref,
      role: "progressbar"
    }, rootProps, other, {
      children: /* @__PURE__ */ jsx(CircularProgressSVG, {
        className: classes.svg,
        ownerState,
        viewBox: `${SIZE / 2} ${SIZE / 2} ${SIZE} ${SIZE}`,
        children: /* @__PURE__ */ jsx(CircularProgressCircle, {
          className: classes.circle,
          style: circleStyle,
          ownerState,
          cx: SIZE,
          cy: SIZE,
          r: (SIZE - thickness) / 2,
          fill: "none",
          strokeWidth: thickness
        })
      })
    }));
  });
  const CircularProgress$1 = CircularProgress;
  const _excluded$m = ["BackdropComponent", "BackdropProps", "closeAfterTransition", "children", "component", "components", "componentsProps", "disableAutoFocus", "disableEnforceFocus", "disableEscapeKeyDown", "disablePortal", "disableRestoreFocus", "disableScrollLock", "hideBackdrop", "keepMounted", "theme"];
  const extendUtilityClasses = (ownerState) => {
    return ownerState.classes;
  };
  const ModalRoot = styled$1("div", {
    name: "MuiModal",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, !ownerState.open && ownerState.exited && styles2.hidden];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    position: "fixed",
    zIndex: (theme.vars || theme).zIndex.modal,
    right: 0,
    bottom: 0,
    top: 0,
    left: 0
  }, !ownerState.open && ownerState.exited && {
    visibility: "hidden"
  }));
  const ModalBackdrop = styled$1(Backdrop$1, {
    name: "MuiModal",
    slot: "Backdrop",
    overridesResolver: (props, styles2) => {
      return styles2.backdrop;
    }
  })({
    zIndex: -1
  });
  const Modal = /* @__PURE__ */ react.exports.forwardRef(function Modal2(inProps, ref) {
    var _ref, _components$Root;
    const props = useThemeProps({
      name: "MuiModal",
      props: inProps
    });
    const {
      BackdropComponent = ModalBackdrop,
      BackdropProps,
      closeAfterTransition = false,
      children,
      component,
      components = {},
      componentsProps = {},
      disableAutoFocus = false,
      disableEnforceFocus = false,
      disableEscapeKeyDown = false,
      disablePortal = false,
      disableRestoreFocus = false,
      disableScrollLock = false,
      hideBackdrop = false,
      keepMounted = false,
      theme
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$m);
    const [exited, setExited] = react.exports.useState(true);
    const commonProps = {
      closeAfterTransition,
      disableAutoFocus,
      disableEnforceFocus,
      disableEscapeKeyDown,
      disablePortal,
      disableRestoreFocus,
      disableScrollLock,
      hideBackdrop,
      keepMounted
    };
    const ownerState = _extends({}, props, commonProps, {
      exited
    });
    const classes = extendUtilityClasses(ownerState);
    const Root = (_ref = (_components$Root = components.Root) != null ? _components$Root : component) != null ? _ref : ModalRoot;
    return /* @__PURE__ */ jsx(ModalUnstyled$1, _extends({
      components: _extends({
        Root,
        Backdrop: BackdropComponent
      }, components),
      componentsProps: {
        root: () => _extends({}, resolveComponentProps(componentsProps.root, ownerState), !isHostComponent(Root) && {
          as: component,
          theme
        }),
        backdrop: () => _extends({}, BackdropProps, resolveComponentProps(componentsProps.backdrop, ownerState))
      },
      onTransitionEnter: () => setExited(false),
      onTransitionExited: () => setExited(true),
      ref
    }, other, {
      classes
    }, commonProps, {
      children
    }));
  });
  const Modal$1 = Modal;
  function getDialogUtilityClass(slot) {
    return generateUtilityClass("MuiDialog", slot);
  }
  const dialogClasses = generateUtilityClasses("MuiDialog", ["root", "scrollPaper", "scrollBody", "container", "paper", "paperScrollPaper", "paperScrollBody", "paperWidthFalse", "paperWidthXs", "paperWidthSm", "paperWidthMd", "paperWidthLg", "paperWidthXl", "paperFullWidth", "paperFullScreen"]);
  const dialogClasses$1 = dialogClasses;
  const DialogContext = /* @__PURE__ */ react.exports.createContext({});
  const DialogContext$1 = DialogContext;
  const _excluded$l = ["aria-describedby", "aria-labelledby", "BackdropComponent", "BackdropProps", "children", "className", "disableEscapeKeyDown", "fullScreen", "fullWidth", "maxWidth", "onBackdropClick", "onClose", "open", "PaperComponent", "PaperProps", "scroll", "TransitionComponent", "transitionDuration", "TransitionProps"];
  const DialogBackdrop = styled$1(Backdrop$1, {
    name: "MuiDialog",
    slot: "Backdrop",
    overrides: (props, styles2) => styles2.backdrop
  })({
    zIndex: -1
  });
  const useUtilityClasses$h = (ownerState) => {
    const {
      classes,
      scroll,
      maxWidth: maxWidth2,
      fullWidth,
      fullScreen
    } = ownerState;
    const slots = {
      root: ["root"],
      container: ["container", `scroll${capitalize(scroll)}`],
      paper: ["paper", `paperScroll${capitalize(scroll)}`, `paperWidth${capitalize(String(maxWidth2))}`, fullWidth && "paperFullWidth", fullScreen && "paperFullScreen"]
    };
    return composeClasses(slots, getDialogUtilityClass, classes);
  };
  const DialogRoot = styled$1(Modal$1, {
    name: "MuiDialog",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({
    "@media print": {
      position: "absolute !important"
    }
  });
  const DialogContainer = styled$1("div", {
    name: "MuiDialog",
    slot: "Container",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.container, styles2[`scroll${capitalize(ownerState.scroll)}`]];
    }
  })(({
    ownerState
  }) => _extends({
    height: "100%",
    "@media print": {
      height: "auto"
    },
    outline: 0
  }, ownerState.scroll === "paper" && {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  }, ownerState.scroll === "body" && {
    overflowY: "auto",
    overflowX: "hidden",
    textAlign: "center",
    "&:after": {
      content: '""',
      display: "inline-block",
      verticalAlign: "middle",
      height: "100%",
      width: "0"
    }
  }));
  const DialogPaper = styled$1(Paper$1, {
    name: "MuiDialog",
    slot: "Paper",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.paper, styles2[`scrollPaper${capitalize(ownerState.scroll)}`], styles2[`paperWidth${capitalize(String(ownerState.maxWidth))}`], ownerState.fullWidth && styles2.paperFullWidth, ownerState.fullScreen && styles2.paperFullScreen];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    margin: 32,
    position: "relative",
    overflowY: "auto",
    "@media print": {
      overflowY: "visible",
      boxShadow: "none"
    }
  }, ownerState.scroll === "paper" && {
    display: "flex",
    flexDirection: "column",
    maxHeight: "calc(100% - 64px)"
  }, ownerState.scroll === "body" && {
    display: "inline-block",
    verticalAlign: "middle",
    textAlign: "left"
  }, !ownerState.maxWidth && {
    maxWidth: "calc(100% - 64px)"
  }, ownerState.maxWidth === "xs" && {
    maxWidth: theme.breakpoints.unit === "px" ? Math.max(theme.breakpoints.values.xs, 444) : `${theme.breakpoints.values.xs}${theme.breakpoints.unit}`,
    [`&.${dialogClasses$1.paperScrollBody}`]: {
      [theme.breakpoints.down(Math.max(theme.breakpoints.values.xs, 444) + 32 * 2)]: {
        maxWidth: "calc(100% - 64px)"
      }
    }
  }, ownerState.maxWidth && ownerState.maxWidth !== "xs" && {
    maxWidth: `${theme.breakpoints.values[ownerState.maxWidth]}${theme.breakpoints.unit}`,
    [`&.${dialogClasses$1.paperScrollBody}`]: {
      [theme.breakpoints.down(theme.breakpoints.values[ownerState.maxWidth] + 32 * 2)]: {
        maxWidth: "calc(100% - 64px)"
      }
    }
  }, ownerState.fullWidth && {
    width: "calc(100% - 64px)"
  }, ownerState.fullScreen && {
    margin: 0,
    width: "100%",
    maxWidth: "100%",
    height: "100%",
    maxHeight: "none",
    borderRadius: 0,
    [`&.${dialogClasses$1.paperScrollBody}`]: {
      margin: 0,
      maxWidth: "100%"
    }
  }));
  const Dialog = /* @__PURE__ */ react.exports.forwardRef(function Dialog2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiDialog"
    });
    const theme = useTheme();
    const defaultTransitionDuration = {
      enter: theme.transitions.duration.enteringScreen,
      exit: theme.transitions.duration.leavingScreen
    };
    const {
      "aria-describedby": ariaDescribedby,
      "aria-labelledby": ariaLabelledbyProp,
      BackdropComponent,
      BackdropProps,
      children,
      className,
      disableEscapeKeyDown = false,
      fullScreen = false,
      fullWidth = false,
      maxWidth: maxWidth2 = "sm",
      onBackdropClick,
      onClose,
      open,
      PaperComponent = Paper$1,
      PaperProps = {},
      scroll = "paper",
      TransitionComponent = Fade$1,
      transitionDuration = defaultTransitionDuration,
      TransitionProps
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$l);
    const ownerState = _extends({}, props, {
      disableEscapeKeyDown,
      fullScreen,
      fullWidth,
      maxWidth: maxWidth2,
      scroll
    });
    const classes = useUtilityClasses$h(ownerState);
    const backdropClick = react.exports.useRef();
    const handleMouseDown = (event) => {
      backdropClick.current = event.target === event.currentTarget;
    };
    const handleBackdropClick = (event) => {
      if (!backdropClick.current) {
        return;
      }
      backdropClick.current = null;
      if (onBackdropClick) {
        onBackdropClick(event);
      }
      if (onClose) {
        onClose(event, "backdropClick");
      }
    };
    const ariaLabelledby = useId(ariaLabelledbyProp);
    const dialogContextValue = react.exports.useMemo(() => {
      return {
        titleId: ariaLabelledby
      };
    }, [ariaLabelledby]);
    return /* @__PURE__ */ jsx(DialogRoot, _extends({
      className: clsx(classes.root, className),
      closeAfterTransition: true,
      components: {
        Backdrop: DialogBackdrop
      },
      componentsProps: {
        backdrop: _extends({
          transitionDuration,
          as: BackdropComponent
        }, BackdropProps)
      },
      disableEscapeKeyDown,
      onClose,
      open,
      ref,
      onClick: handleBackdropClick,
      ownerState
    }, other, {
      children: /* @__PURE__ */ jsx(TransitionComponent, _extends({
        appear: true,
        in: open,
        timeout: transitionDuration,
        role: "presentation"
      }, TransitionProps, {
        children: /* @__PURE__ */ jsx(DialogContainer, {
          className: clsx(classes.container),
          onMouseDown: handleMouseDown,
          ownerState,
          children: /* @__PURE__ */ jsx(DialogPaper, _extends({
            as: PaperComponent,
            elevation: 24,
            role: "dialog",
            "aria-describedby": ariaDescribedby,
            "aria-labelledby": ariaLabelledby
          }, PaperProps, {
            className: clsx(classes.paper, PaperProps.className),
            ownerState,
            children: /* @__PURE__ */ jsx(DialogContext$1.Provider, {
              value: dialogContextValue,
              children
            })
          }))
        })
      }))
    }));
  });
  const Dialog$1 = Dialog;
  function getDialogContentUtilityClass(slot) {
    return generateUtilityClass("MuiDialogContent", slot);
  }
  generateUtilityClasses("MuiDialogContent", ["root", "dividers"]);
  const dialogTitleClasses = generateUtilityClasses("MuiDialogTitle", ["root"]);
  const dialogTitleClasses$1 = dialogTitleClasses;
  const _excluded$k = ["className", "dividers"];
  const useUtilityClasses$g = (ownerState) => {
    const {
      classes,
      dividers
    } = ownerState;
    const slots = {
      root: ["root", dividers && "dividers"]
    };
    return composeClasses(slots, getDialogContentUtilityClass, classes);
  };
  const DialogContentRoot = styled$1("div", {
    name: "MuiDialogContent",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.dividers && styles2.dividers];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    flex: "1 1 auto",
    WebkitOverflowScrolling: "touch",
    overflowY: "auto",
    padding: "20px 24px"
  }, ownerState.dividers ? {
    padding: "16px 24px",
    borderTop: `1px solid ${(theme.vars || theme).palette.divider}`,
    borderBottom: `1px solid ${(theme.vars || theme).palette.divider}`
  } : {
    [`.${dialogTitleClasses$1.root} + &`]: {
      paddingTop: 0
    }
  }));
  const DialogContent = /* @__PURE__ */ react.exports.forwardRef(function DialogContent2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiDialogContent"
    });
    const {
      className,
      dividers = false
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$k);
    const ownerState = _extends({}, props, {
      dividers
    });
    const classes = useUtilityClasses$g(ownerState);
    return /* @__PURE__ */ jsx(DialogContentRoot, _extends({
      className: clsx(classes.root, className),
      ownerState,
      ref
    }, other));
  });
  const DialogContent$1 = DialogContent;
  function getDividerUtilityClass(slot) {
    return generateUtilityClass("MuiDivider", slot);
  }
  generateUtilityClasses("MuiDivider", ["root", "absolute", "fullWidth", "inset", "middle", "flexItem", "light", "vertical", "withChildren", "withChildrenVertical", "textAlignRight", "textAlignLeft", "wrapper", "wrapperVertical"]);
  const _excluded$j = ["absolute", "children", "className", "component", "flexItem", "light", "orientation", "role", "textAlign", "variant"];
  const useUtilityClasses$f = (ownerState) => {
    const {
      absolute,
      children,
      classes,
      flexItem,
      light: light2,
      orientation,
      textAlign: textAlign2,
      variant
    } = ownerState;
    const slots = {
      root: ["root", absolute && "absolute", variant, light2 && "light", orientation === "vertical" && "vertical", flexItem && "flexItem", children && "withChildren", children && orientation === "vertical" && "withChildrenVertical", textAlign2 === "right" && orientation !== "vertical" && "textAlignRight", textAlign2 === "left" && orientation !== "vertical" && "textAlignLeft"],
      wrapper: ["wrapper", orientation === "vertical" && "wrapperVertical"]
    };
    return composeClasses(slots, getDividerUtilityClass, classes);
  };
  const DividerRoot = styled$1("div", {
    name: "MuiDivider",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.absolute && styles2.absolute, styles2[ownerState.variant], ownerState.light && styles2.light, ownerState.orientation === "vertical" && styles2.vertical, ownerState.flexItem && styles2.flexItem, ownerState.children && styles2.withChildren, ownerState.children && ownerState.orientation === "vertical" && styles2.withChildrenVertical, ownerState.textAlign === "right" && ownerState.orientation !== "vertical" && styles2.textAlignRight, ownerState.textAlign === "left" && ownerState.orientation !== "vertical" && styles2.textAlignLeft];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    margin: 0,
    flexShrink: 0,
    borderWidth: 0,
    borderStyle: "solid",
    borderColor: (theme.vars || theme).palette.divider,
    borderBottomWidth: "thin"
  }, ownerState.absolute && {
    position: "absolute",
    bottom: 0,
    left: 0,
    width: "100%"
  }, ownerState.light && {
    borderColor: theme.vars ? `rgba(${theme.vars.palette.dividerChannel} / 0.08)` : alpha(theme.palette.divider, 0.08)
  }, ownerState.variant === "inset" && {
    marginLeft: 72
  }, ownerState.variant === "middle" && ownerState.orientation === "horizontal" && {
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2)
  }, ownerState.variant === "middle" && ownerState.orientation === "vertical" && {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1)
  }, ownerState.orientation === "vertical" && {
    height: "100%",
    borderBottomWidth: 0,
    borderRightWidth: "thin"
  }, ownerState.flexItem && {
    alignSelf: "stretch",
    height: "auto"
  }), ({
    theme,
    ownerState
  }) => _extends({}, ownerState.children && {
    display: "flex",
    whiteSpace: "nowrap",
    textAlign: "center",
    border: 0,
    "&::before, &::after": {
      position: "relative",
      width: "100%",
      borderTop: `thin solid ${(theme.vars || theme).palette.divider}`,
      top: "50%",
      content: '""',
      transform: "translateY(50%)"
    }
  }), ({
    theme,
    ownerState
  }) => _extends({}, ownerState.children && ownerState.orientation === "vertical" && {
    flexDirection: "column",
    "&::before, &::after": {
      height: "100%",
      top: "0%",
      left: "50%",
      borderTop: 0,
      borderLeft: `thin solid ${(theme.vars || theme).palette.divider}`,
      transform: "translateX(0%)"
    }
  }), ({
    ownerState
  }) => _extends({}, ownerState.textAlign === "right" && ownerState.orientation !== "vertical" && {
    "&::before": {
      width: "90%"
    },
    "&::after": {
      width: "10%"
    }
  }, ownerState.textAlign === "left" && ownerState.orientation !== "vertical" && {
    "&::before": {
      width: "10%"
    },
    "&::after": {
      width: "90%"
    }
  }));
  const DividerWrapper = styled$1("span", {
    name: "MuiDivider",
    slot: "Wrapper",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.wrapper, ownerState.orientation === "vertical" && styles2.wrapperVertical];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    display: "inline-block",
    paddingLeft: `calc(${theme.spacing(1)} * 1.2)`,
    paddingRight: `calc(${theme.spacing(1)} * 1.2)`
  }, ownerState.orientation === "vertical" && {
    paddingTop: `calc(${theme.spacing(1)} * 1.2)`,
    paddingBottom: `calc(${theme.spacing(1)} * 1.2)`
  }));
  const Divider = /* @__PURE__ */ react.exports.forwardRef(function Divider2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiDivider"
    });
    const {
      absolute = false,
      children,
      className,
      component = children ? "div" : "hr",
      flexItem = false,
      light: light2 = false,
      orientation = "horizontal",
      role = component !== "hr" ? "separator" : void 0,
      textAlign: textAlign2 = "center",
      variant = "fullWidth"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$j);
    const ownerState = _extends({}, props, {
      absolute,
      component,
      flexItem,
      light: light2,
      orientation,
      role,
      textAlign: textAlign2,
      variant
    });
    const classes = useUtilityClasses$f(ownerState);
    return /* @__PURE__ */ jsx(DividerRoot, _extends({
      as: component,
      className: clsx(classes.root, className),
      role,
      ref,
      ownerState
    }, other, {
      children: children ? /* @__PURE__ */ jsx(DividerWrapper, {
        className: classes.wrapper,
        ownerState,
        children
      }) : null
    }));
  });
  const Divider$1 = Divider;
  const _excluded$i = ["disableUnderline", "components", "componentsProps", "fullWidth", "hiddenLabel", "inputComponent", "multiline", "type"];
  const useUtilityClasses$e = (ownerState) => {
    const {
      classes,
      disableUnderline
    } = ownerState;
    const slots = {
      root: ["root", !disableUnderline && "underline"],
      input: ["input"]
    };
    const composedClasses = composeClasses(slots, getFilledInputUtilityClass, classes);
    return _extends({}, classes, composedClasses);
  };
  const FilledInputRoot = styled$1(InputBaseRoot, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiFilledInput",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [...rootOverridesResolver(props, styles2), !ownerState.disableUnderline && styles2.underline];
    }
  })(({
    theme,
    ownerState
  }) => {
    var _palette;
    const light2 = theme.palette.mode === "light";
    const bottomLineColor = light2 ? "rgba(0, 0, 0, 0.42)" : "rgba(255, 255, 255, 0.7)";
    const backgroundColor2 = light2 ? "rgba(0, 0, 0, 0.06)" : "rgba(255, 255, 255, 0.09)";
    const hoverBackground = light2 ? "rgba(0, 0, 0, 0.09)" : "rgba(255, 255, 255, 0.13)";
    const disabledBackground = light2 ? "rgba(0, 0, 0, 0.12)" : "rgba(255, 255, 255, 0.12)";
    return _extends({
      position: "relative",
      backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor2,
      borderTopLeftRadius: (theme.vars || theme).shape.borderRadius,
      borderTopRightRadius: (theme.vars || theme).shape.borderRadius,
      transition: theme.transitions.create("background-color", {
        duration: theme.transitions.duration.shorter,
        easing: theme.transitions.easing.easeOut
      }),
      "&:hover": {
        backgroundColor: theme.vars ? theme.vars.palette.FilledInput.hoverBg : hoverBackground,
        "@media (hover: none)": {
          backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor2
        }
      },
      [`&.${filledInputClasses$1.focused}`]: {
        backgroundColor: theme.vars ? theme.vars.palette.FilledInput.bg : backgroundColor2
      },
      [`&.${filledInputClasses$1.disabled}`]: {
        backgroundColor: theme.vars ? theme.vars.palette.FilledInput.disabledBg : disabledBackground
      }
    }, !ownerState.disableUnderline && {
      "&:after": {
        borderBottom: `2px solid ${(_palette = (theme.vars || theme).palette[ownerState.color || "primary"]) == null ? void 0 : _palette.main}`,
        left: 0,
        bottom: 0,
        content: '""',
        position: "absolute",
        right: 0,
        transform: "scaleX(0)",
        transition: theme.transitions.create("transform", {
          duration: theme.transitions.duration.shorter,
          easing: theme.transitions.easing.easeOut
        }),
        pointerEvents: "none"
      },
      [`&.${filledInputClasses$1.focused}:after`]: {
        transform: "scaleX(1) translateX(0)"
      },
      [`&.${filledInputClasses$1.error}:after`]: {
        borderBottomColor: (theme.vars || theme).palette.error.main,
        transform: "scaleX(1)"
      },
      "&:before": {
        borderBottom: `1px solid ${theme.vars ? `rgba(${theme.vars.palette.common.onBackgroundChannel} / ${theme.vars.opacity.inputUnderline})` : bottomLineColor}`,
        left: 0,
        bottom: 0,
        content: '"\\00a0"',
        position: "absolute",
        right: 0,
        transition: theme.transitions.create("border-bottom-color", {
          duration: theme.transitions.duration.shorter
        }),
        pointerEvents: "none"
      },
      [`&:hover:not(.${filledInputClasses$1.disabled}):before`]: {
        borderBottom: `1px solid ${(theme.vars || theme).palette.text.primary}`
      },
      [`&.${filledInputClasses$1.disabled}:before`]: {
        borderBottomStyle: "dotted"
      }
    }, ownerState.startAdornment && {
      paddingLeft: 12
    }, ownerState.endAdornment && {
      paddingRight: 12
    }, ownerState.multiline && _extends({
      padding: "25px 12px 8px"
    }, ownerState.size === "small" && {
      paddingTop: 21,
      paddingBottom: 4
    }, ownerState.hiddenLabel && {
      paddingTop: 16,
      paddingBottom: 17
    }));
  });
  const FilledInputInput = styled$1(InputBaseComponent, {
    name: "MuiFilledInput",
    slot: "Input",
    overridesResolver: inputOverridesResolver
  })(({
    theme,
    ownerState
  }) => _extends({
    paddingTop: 25,
    paddingRight: 12,
    paddingBottom: 8,
    paddingLeft: 12
  }, !theme.vars && {
    "&:-webkit-autofill": {
      WebkitBoxShadow: theme.palette.mode === "light" ? null : "0 0 0 100px #266798 inset",
      WebkitTextFillColor: theme.palette.mode === "light" ? null : "#fff",
      caretColor: theme.palette.mode === "light" ? null : "#fff",
      borderTopLeftRadius: "inherit",
      borderTopRightRadius: "inherit"
    }
  }, theme.vars && {
    "&:-webkit-autofill": {
      borderTopLeftRadius: "inherit",
      borderTopRightRadius: "inherit"
    },
    [theme.getColorSchemeSelector("dark")]: {
      "&:-webkit-autofill": {
        WebkitBoxShadow: "0 0 0 100px #266798 inset",
        WebkitTextFillColor: "#fff",
        caretColor: "#fff"
      }
    }
  }, ownerState.size === "small" && {
    paddingTop: 21,
    paddingBottom: 4
  }, ownerState.hiddenLabel && {
    paddingTop: 16,
    paddingBottom: 17
  }, ownerState.multiline && {
    paddingTop: 0,
    paddingBottom: 0,
    paddingLeft: 0,
    paddingRight: 0
  }, ownerState.startAdornment && {
    paddingLeft: 0
  }, ownerState.endAdornment && {
    paddingRight: 0
  }, ownerState.hiddenLabel && ownerState.size === "small" && {
    paddingTop: 8,
    paddingBottom: 9
  }));
  const FilledInput = /* @__PURE__ */ react.exports.forwardRef(function FilledInput2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiFilledInput"
    });
    const {
      components = {},
      componentsProps: componentsPropsProp,
      fullWidth = false,
      inputComponent = "input",
      multiline = false,
      type = "text"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$i);
    const ownerState = _extends({}, props, {
      fullWidth,
      inputComponent,
      multiline,
      type
    });
    const classes = useUtilityClasses$e(props);
    const filledInputComponentsProps = {
      root: {
        ownerState
      },
      input: {
        ownerState
      }
    };
    const componentsProps = componentsPropsProp ? deepmerge(componentsPropsProp, filledInputComponentsProps) : filledInputComponentsProps;
    return /* @__PURE__ */ jsx(InputBase$1, _extends({
      components: _extends({
        Root: FilledInputRoot,
        Input: FilledInputInput
      }, components),
      componentsProps,
      fullWidth,
      inputComponent,
      multiline,
      ref,
      type
    }, other, {
      classes
    }));
  });
  FilledInput.muiName = "Input";
  const FilledInput$1 = FilledInput;
  function getFormControlUtilityClasses(slot) {
    return generateUtilityClass("MuiFormControl", slot);
  }
  generateUtilityClasses("MuiFormControl", ["root", "marginNone", "marginNormal", "marginDense", "fullWidth", "disabled"]);
  const _excluded$h = ["children", "className", "color", "component", "disabled", "error", "focused", "fullWidth", "hiddenLabel", "margin", "required", "size", "variant"];
  const useUtilityClasses$d = (ownerState) => {
    const {
      classes,
      margin,
      fullWidth
    } = ownerState;
    const slots = {
      root: ["root", margin !== "none" && `margin${capitalize(margin)}`, fullWidth && "fullWidth"]
    };
    return composeClasses(slots, getFormControlUtilityClasses, classes);
  };
  const FormControlRoot = styled$1("div", {
    name: "MuiFormControl",
    slot: "Root",
    overridesResolver: ({
      ownerState
    }, styles2) => {
      return _extends({}, styles2.root, styles2[`margin${capitalize(ownerState.margin)}`], ownerState.fullWidth && styles2.fullWidth);
    }
  })(({
    ownerState
  }) => _extends({
    display: "inline-flex",
    flexDirection: "column",
    position: "relative",
    minWidth: 0,
    padding: 0,
    margin: 0,
    border: 0,
    verticalAlign: "top"
  }, ownerState.margin === "normal" && {
    marginTop: 16,
    marginBottom: 8
  }, ownerState.margin === "dense" && {
    marginTop: 8,
    marginBottom: 4
  }, ownerState.fullWidth && {
    width: "100%"
  }));
  const FormControl = /* @__PURE__ */ react.exports.forwardRef(function FormControl2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiFormControl"
    });
    const {
      children,
      className,
      color: color2 = "primary",
      component = "div",
      disabled = false,
      error = false,
      focused: visuallyFocused,
      fullWidth = false,
      hiddenLabel = false,
      margin = "none",
      required = false,
      size = "medium",
      variant = "outlined"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$h);
    const ownerState = _extends({}, props, {
      color: color2,
      component,
      disabled,
      error,
      fullWidth,
      hiddenLabel,
      margin,
      required,
      size,
      variant
    });
    const classes = useUtilityClasses$d(ownerState);
    const [adornedStart, setAdornedStart] = react.exports.useState(() => {
      let initialAdornedStart = false;
      if (children) {
        react.exports.Children.forEach(children, (child) => {
          if (!isMuiElement(child, ["Input", "Select"])) {
            return;
          }
          const input = isMuiElement(child, ["Select"]) ? child.props.input : child;
          if (input && isAdornedStart(input.props)) {
            initialAdornedStart = true;
          }
        });
      }
      return initialAdornedStart;
    });
    const [filled, setFilled] = react.exports.useState(() => {
      let initialFilled = false;
      if (children) {
        react.exports.Children.forEach(children, (child) => {
          if (!isMuiElement(child, ["Input", "Select"])) {
            return;
          }
          if (isFilled(child.props, true)) {
            initialFilled = true;
          }
        });
      }
      return initialFilled;
    });
    const [focusedState, setFocused] = react.exports.useState(false);
    if (disabled && focusedState) {
      setFocused(false);
    }
    const focused = visuallyFocused !== void 0 && !disabled ? visuallyFocused : focusedState;
    let registerEffect;
    const onFilled = react.exports.useCallback(() => {
      setFilled(true);
    }, []);
    const onEmpty = react.exports.useCallback(() => {
      setFilled(false);
    }, []);
    const childContext = {
      adornedStart,
      setAdornedStart,
      color: color2,
      disabled,
      error,
      filled,
      focused,
      fullWidth,
      hiddenLabel,
      size,
      onBlur: () => {
        setFocused(false);
      },
      onEmpty,
      onFilled,
      onFocus: () => {
        setFocused(true);
      },
      registerEffect,
      required,
      variant
    };
    return /* @__PURE__ */ jsx(FormControlContext$1.Provider, {
      value: childContext,
      children: /* @__PURE__ */ jsx(FormControlRoot, _extends({
        as: component,
        ownerState,
        className: clsx(classes.root, className),
        ref
      }, other, {
        children
      }))
    });
  });
  const FormControl$1 = FormControl;
  function getFormHelperTextUtilityClasses(slot) {
    return generateUtilityClass("MuiFormHelperText", slot);
  }
  const formHelperTextClasses = generateUtilityClasses("MuiFormHelperText", ["root", "error", "disabled", "sizeSmall", "sizeMedium", "contained", "focused", "filled", "required"]);
  const formHelperTextClasses$1 = formHelperTextClasses;
  var _span$3;
  const _excluded$g = ["children", "className", "component", "disabled", "error", "filled", "focused", "margin", "required", "variant"];
  const useUtilityClasses$c = (ownerState) => {
    const {
      classes,
      contained,
      size,
      disabled,
      error,
      filled,
      focused,
      required
    } = ownerState;
    const slots = {
      root: ["root", disabled && "disabled", error && "error", size && `size${capitalize(size)}`, contained && "contained", focused && "focused", filled && "filled", required && "required"]
    };
    return composeClasses(slots, getFormHelperTextUtilityClasses, classes);
  };
  const FormHelperTextRoot = styled$1("p", {
    name: "MuiFormHelperText",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, ownerState.size && styles2[`size${capitalize(ownerState.size)}`], ownerState.contained && styles2.contained, ownerState.filled && styles2.filled];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    color: (theme.vars || theme).palette.text.secondary
  }, theme.typography.caption, {
    textAlign: "left",
    marginTop: 3,
    marginRight: 0,
    marginBottom: 0,
    marginLeft: 0,
    [`&.${formHelperTextClasses$1.disabled}`]: {
      color: (theme.vars || theme).palette.text.disabled
    },
    [`&.${formHelperTextClasses$1.error}`]: {
      color: (theme.vars || theme).palette.error.main
    }
  }, ownerState.size === "small" && {
    marginTop: 4
  }, ownerState.contained && {
    marginLeft: 14,
    marginRight: 14
  }));
  const FormHelperText = /* @__PURE__ */ react.exports.forwardRef(function FormHelperText2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiFormHelperText"
    });
    const {
      children,
      className,
      component = "p"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$g);
    const muiFormControl = useFormControl();
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["variant", "size", "disabled", "error", "filled", "focused", "required"]
    });
    const ownerState = _extends({}, props, {
      component,
      contained: fcs.variant === "filled" || fcs.variant === "outlined",
      variant: fcs.variant,
      size: fcs.size,
      disabled: fcs.disabled,
      error: fcs.error,
      filled: fcs.filled,
      focused: fcs.focused,
      required: fcs.required
    });
    const classes = useUtilityClasses$c(ownerState);
    return /* @__PURE__ */ jsx(FormHelperTextRoot, _extends({
      as: component,
      ownerState,
      className: clsx(classes.root, className),
      ref
    }, other, {
      children: children === " " ? _span$3 || (_span$3 = /* @__PURE__ */ jsx("span", {
        className: "notranslate",
        children: "\u200B"
      })) : children
    }));
  });
  const FormHelperText$1 = FormHelperText;
  function getFormLabelUtilityClasses(slot) {
    return generateUtilityClass("MuiFormLabel", slot);
  }
  const formLabelClasses = generateUtilityClasses("MuiFormLabel", ["root", "colorSecondary", "focused", "disabled", "error", "filled", "required", "asterisk"]);
  const formLabelClasses$1 = formLabelClasses;
  const _excluded$f = ["children", "className", "color", "component", "disabled", "error", "filled", "focused", "required"];
  const useUtilityClasses$b = (ownerState) => {
    const {
      classes,
      color: color2,
      focused,
      disabled,
      error,
      filled,
      required
    } = ownerState;
    const slots = {
      root: ["root", `color${capitalize(color2)}`, disabled && "disabled", error && "error", filled && "filled", focused && "focused", required && "required"],
      asterisk: ["asterisk", error && "error"]
    };
    return composeClasses(slots, getFormLabelUtilityClasses, classes);
  };
  const FormLabelRoot = styled$1("label", {
    name: "MuiFormLabel",
    slot: "Root",
    overridesResolver: ({
      ownerState
    }, styles2) => {
      return _extends({}, styles2.root, ownerState.color === "secondary" && styles2.colorSecondary, ownerState.filled && styles2.filled);
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    color: (theme.vars || theme).palette.text.secondary
  }, theme.typography.body1, {
    lineHeight: "1.4375em",
    padding: 0,
    position: "relative",
    [`&.${formLabelClasses$1.focused}`]: {
      color: (theme.vars || theme).palette[ownerState.color].main
    },
    [`&.${formLabelClasses$1.disabled}`]: {
      color: (theme.vars || theme).palette.text.disabled
    },
    [`&.${formLabelClasses$1.error}`]: {
      color: (theme.vars || theme).palette.error.main
    }
  }));
  const AsteriskComponent = styled$1("span", {
    name: "MuiFormLabel",
    slot: "Asterisk",
    overridesResolver: (props, styles2) => styles2.asterisk
  })(({
    theme
  }) => ({
    [`&.${formLabelClasses$1.error}`]: {
      color: (theme.vars || theme).palette.error.main
    }
  }));
  const FormLabel = /* @__PURE__ */ react.exports.forwardRef(function FormLabel2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiFormLabel"
    });
    const {
      children,
      className,
      component = "label"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$f);
    const muiFormControl = useFormControl();
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["color", "required", "focused", "disabled", "error", "filled"]
    });
    const ownerState = _extends({}, props, {
      color: fcs.color || "primary",
      component,
      disabled: fcs.disabled,
      error: fcs.error,
      filled: fcs.filled,
      focused: fcs.focused,
      required: fcs.required
    });
    const classes = useUtilityClasses$b(ownerState);
    return /* @__PURE__ */ jsxs(FormLabelRoot, _extends({
      as: component,
      ownerState,
      className: clsx(classes.root, className),
      ref
    }, other, {
      children: [children, fcs.required && /* @__PURE__ */ jsxs(AsteriskComponent, {
        ownerState,
        "aria-hidden": true,
        className: classes.asterisk,
        children: ["\u2009", "*"]
      })]
    }));
  });
  const FormLabel$1 = FormLabel;
  const _excluded$e = ["addEndListener", "appear", "children", "easing", "in", "onEnter", "onEntered", "onEntering", "onExit", "onExited", "onExiting", "style", "timeout", "TransitionComponent"];
  function getScale(value) {
    return `scale(${value}, ${value ** 2})`;
  }
  const styles$1 = {
    entering: {
      opacity: 1,
      transform: getScale(1)
    },
    entered: {
      opacity: 1,
      transform: "none"
    }
  };
  const isWebKit154 = typeof navigator !== "undefined" && /^((?!chrome|android).)*(safari|mobile)/i.test(navigator.userAgent) && /(os |version\/)15(.|_)4/i.test(navigator.userAgent);
  const Grow = /* @__PURE__ */ react.exports.forwardRef(function Grow2(props, ref) {
    const {
      addEndListener,
      appear = true,
      children,
      easing: easing2,
      in: inProp,
      onEnter,
      onEntered,
      onEntering,
      onExit,
      onExited,
      onExiting,
      style: style2,
      timeout = "auto",
      TransitionComponent = Transition$1
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$e);
    const timer = react.exports.useRef();
    const autoTimeout = react.exports.useRef();
    const theme = useTheme();
    const nodeRef = react.exports.useRef(null);
    const foreignRef = useForkRef(children.ref, ref);
    const handleRef = useForkRef(nodeRef, foreignRef);
    const normalizedTransitionCallback = (callback) => (maybeIsAppearing) => {
      if (callback) {
        const node2 = nodeRef.current;
        if (maybeIsAppearing === void 0) {
          callback(node2);
        } else {
          callback(node2, maybeIsAppearing);
        }
      }
    };
    const handleEntering = normalizedTransitionCallback(onEntering);
    const handleEnter = normalizedTransitionCallback((node2, isAppearing) => {
      reflow(node2);
      const {
        duration: transitionDuration,
        delay,
        easing: transitionTimingFunction
      } = getTransitionProps({
        style: style2,
        timeout,
        easing: easing2
      }, {
        mode: "enter"
      });
      let duration2;
      if (timeout === "auto") {
        duration2 = theme.transitions.getAutoHeightDuration(node2.clientHeight);
        autoTimeout.current = duration2;
      } else {
        duration2 = transitionDuration;
      }
      node2.style.transition = [theme.transitions.create("opacity", {
        duration: duration2,
        delay
      }), theme.transitions.create("transform", {
        duration: isWebKit154 ? duration2 : duration2 * 0.666,
        delay,
        easing: transitionTimingFunction
      })].join(",");
      if (onEnter) {
        onEnter(node2, isAppearing);
      }
    });
    const handleEntered = normalizedTransitionCallback(onEntered);
    const handleExiting = normalizedTransitionCallback(onExiting);
    const handleExit = normalizedTransitionCallback((node2) => {
      const {
        duration: transitionDuration,
        delay,
        easing: transitionTimingFunction
      } = getTransitionProps({
        style: style2,
        timeout,
        easing: easing2
      }, {
        mode: "exit"
      });
      let duration2;
      if (timeout === "auto") {
        duration2 = theme.transitions.getAutoHeightDuration(node2.clientHeight);
        autoTimeout.current = duration2;
      } else {
        duration2 = transitionDuration;
      }
      node2.style.transition = [theme.transitions.create("opacity", {
        duration: duration2,
        delay
      }), theme.transitions.create("transform", {
        duration: isWebKit154 ? duration2 : duration2 * 0.666,
        delay: isWebKit154 ? delay : delay || duration2 * 0.333,
        easing: transitionTimingFunction
      })].join(",");
      node2.style.opacity = 0;
      node2.style.transform = getScale(0.75);
      if (onExit) {
        onExit(node2);
      }
    });
    const handleExited = normalizedTransitionCallback(onExited);
    const handleAddEndListener = (next2) => {
      if (timeout === "auto") {
        timer.current = setTimeout(next2, autoTimeout.current || 0);
      }
      if (addEndListener) {
        addEndListener(nodeRef.current, next2);
      }
    };
    react.exports.useEffect(() => {
      return () => {
        clearTimeout(timer.current);
      };
    }, []);
    return /* @__PURE__ */ jsx(TransitionComponent, _extends({
      appear,
      in: inProp,
      nodeRef,
      onEnter: handleEnter,
      onEntered: handleEntered,
      onEntering: handleEntering,
      onExit: handleExit,
      onExited: handleExited,
      onExiting: handleExiting,
      addEndListener: handleAddEndListener,
      timeout: timeout === "auto" ? null : timeout
    }, other, {
      children: (state, childProps) => {
        return /* @__PURE__ */ react.exports.cloneElement(children, _extends({
          style: _extends({
            opacity: 0,
            transform: getScale(0.75),
            visibility: state === "exited" && !inProp ? "hidden" : void 0
          }, styles$1[state], style2, children.props.style),
          ref: handleRef
        }, childProps));
      }
    }));
  });
  Grow.muiSupportAuto = true;
  const Grow$1 = Grow;
  const _excluded$d = ["disableUnderline", "components", "componentsProps", "fullWidth", "inputComponent", "multiline", "type"];
  const useUtilityClasses$a = (ownerState) => {
    const {
      classes,
      disableUnderline
    } = ownerState;
    const slots = {
      root: ["root", !disableUnderline && "underline"],
      input: ["input"]
    };
    const composedClasses = composeClasses(slots, getInputUtilityClass, classes);
    return _extends({}, classes, composedClasses);
  };
  const InputRoot = styled$1(InputBaseRoot, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiInput",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [...rootOverridesResolver(props, styles2), !ownerState.disableUnderline && styles2.underline];
    }
  })(({
    theme,
    ownerState
  }) => {
    const light2 = theme.palette.mode === "light";
    let bottomLineColor = light2 ? "rgba(0, 0, 0, 0.42)" : "rgba(255, 255, 255, 0.7)";
    if (theme.vars) {
      bottomLineColor = `rgba(${theme.vars.palette.common.onBackgroundChannel} / ${theme.vars.opacity.inputUnderline})`;
    }
    return _extends({
      position: "relative"
    }, ownerState.formControl && {
      "label + &": {
        marginTop: 16
      }
    }, !ownerState.disableUnderline && {
      "&:after": {
        borderBottom: `2px solid ${(theme.vars || theme).palette[ownerState.color].main}`,
        left: 0,
        bottom: 0,
        content: '""',
        position: "absolute",
        right: 0,
        transform: "scaleX(0)",
        transition: theme.transitions.create("transform", {
          duration: theme.transitions.duration.shorter,
          easing: theme.transitions.easing.easeOut
        }),
        pointerEvents: "none"
      },
      [`&.${inputClasses$1.focused}:after`]: {
        transform: "scaleX(1) translateX(0)"
      },
      [`&.${inputClasses$1.error}:after`]: {
        borderBottomColor: (theme.vars || theme).palette.error.main,
        transform: "scaleX(1)"
      },
      "&:before": {
        borderBottom: `1px solid ${bottomLineColor}`,
        left: 0,
        bottom: 0,
        content: '"\\00a0"',
        position: "absolute",
        right: 0,
        transition: theme.transitions.create("border-bottom-color", {
          duration: theme.transitions.duration.shorter
        }),
        pointerEvents: "none"
      },
      [`&:hover:not(.${inputClasses$1.disabled}):before`]: {
        borderBottom: `2px solid ${(theme.vars || theme).palette.text.primary}`,
        "@media (hover: none)": {
          borderBottom: `1px solid ${bottomLineColor}`
        }
      },
      [`&.${inputClasses$1.disabled}:before`]: {
        borderBottomStyle: "dotted"
      }
    });
  });
  const InputInput = styled$1(InputBaseComponent, {
    name: "MuiInput",
    slot: "Input",
    overridesResolver: inputOverridesResolver
  })({});
  const Input = /* @__PURE__ */ react.exports.forwardRef(function Input2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiInput"
    });
    const {
      disableUnderline,
      components = {},
      componentsProps: componentsPropsProp,
      fullWidth = false,
      inputComponent = "input",
      multiline = false,
      type = "text"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$d);
    const classes = useUtilityClasses$a(props);
    const ownerState = {
      disableUnderline
    };
    const inputComponentsProps = {
      root: {
        ownerState
      }
    };
    const componentsProps = componentsPropsProp ? deepmerge(componentsPropsProp, inputComponentsProps) : inputComponentsProps;
    return /* @__PURE__ */ jsx(InputBase$1, _extends({
      components: _extends({
        Root: InputRoot,
        Input: InputInput
      }, components),
      componentsProps,
      fullWidth,
      inputComponent,
      multiline,
      ref,
      type
    }, other, {
      classes
    }));
  });
  Input.muiName = "Input";
  const Input$1 = Input;
  function getInputAdornmentUtilityClass(slot) {
    return generateUtilityClass("MuiInputAdornment", slot);
  }
  const inputAdornmentClasses = generateUtilityClasses("MuiInputAdornment", ["root", "filled", "standard", "outlined", "positionStart", "positionEnd", "disablePointerEvents", "hiddenLabel", "sizeSmall"]);
  const inputAdornmentClasses$1 = inputAdornmentClasses;
  var _span$2;
  const _excluded$c = ["children", "className", "component", "disablePointerEvents", "disableTypography", "position", "variant"];
  const overridesResolver = (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, styles2[`position${capitalize(ownerState.position)}`], ownerState.disablePointerEvents === true && styles2.disablePointerEvents, styles2[ownerState.variant]];
  };
  const useUtilityClasses$9 = (ownerState) => {
    const {
      classes,
      disablePointerEvents,
      hiddenLabel,
      position: position2,
      size,
      variant
    } = ownerState;
    const slots = {
      root: ["root", disablePointerEvents && "disablePointerEvents", position2 && `position${capitalize(position2)}`, variant, hiddenLabel && "hiddenLabel", size && `size${capitalize(size)}`]
    };
    return composeClasses(slots, getInputAdornmentUtilityClass, classes);
  };
  const InputAdornmentRoot = styled$1("div", {
    name: "MuiInputAdornment",
    slot: "Root",
    overridesResolver
  })(({
    theme,
    ownerState
  }) => _extends({
    display: "flex",
    height: "0.01em",
    maxHeight: "2em",
    alignItems: "center",
    whiteSpace: "nowrap",
    color: (theme.vars || theme).palette.action.active
  }, ownerState.variant === "filled" && {
    [`&.${inputAdornmentClasses$1.positionStart}&:not(.${inputAdornmentClasses$1.hiddenLabel})`]: {
      marginTop: 16
    }
  }, ownerState.position === "start" && {
    marginRight: 8
  }, ownerState.position === "end" && {
    marginLeft: 8
  }, ownerState.disablePointerEvents === true && {
    pointerEvents: "none"
  }));
  const InputAdornment = /* @__PURE__ */ react.exports.forwardRef(function InputAdornment2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiInputAdornment"
    });
    const {
      children,
      className,
      component = "div",
      disablePointerEvents = false,
      disableTypography = false,
      position: position2,
      variant: variantProp
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$c);
    const muiFormControl = useFormControl() || {};
    let variant = variantProp;
    if (variantProp && muiFormControl.variant)
      ;
    if (muiFormControl && !variant) {
      variant = muiFormControl.variant;
    }
    const ownerState = _extends({}, props, {
      hiddenLabel: muiFormControl.hiddenLabel,
      size: muiFormControl.size,
      disablePointerEvents,
      position: position2,
      variant
    });
    const classes = useUtilityClasses$9(ownerState);
    return /* @__PURE__ */ jsx(FormControlContext$1.Provider, {
      value: null,
      children: /* @__PURE__ */ jsx(InputAdornmentRoot, _extends({
        as: component,
        ownerState,
        className: clsx(classes.root, className),
        ref
      }, other, {
        children: typeof children === "string" && !disableTypography ? /* @__PURE__ */ jsx(Typography$1, {
          color: "text.secondary",
          children
        }) : /* @__PURE__ */ jsxs(react.exports.Fragment, {
          children: [position2 === "start" ? _span$2 || (_span$2 = /* @__PURE__ */ jsx("span", {
            className: "notranslate",
            children: "\u200B"
          })) : null, children]
        })
      }))
    });
  });
  const InputAdornment$1 = InputAdornment;
  function getInputLabelUtilityClasses(slot) {
    return generateUtilityClass("MuiInputLabel", slot);
  }
  generateUtilityClasses("MuiInputLabel", ["root", "focused", "disabled", "error", "required", "asterisk", "formControl", "sizeSmall", "shrink", "animated", "standard", "filled", "outlined"]);
  const _excluded$b = ["disableAnimation", "margin", "shrink", "variant", "className"];
  const useUtilityClasses$8 = (ownerState) => {
    const {
      classes,
      formControl,
      size,
      shrink,
      disableAnimation,
      variant,
      required
    } = ownerState;
    const slots = {
      root: ["root", formControl && "formControl", !disableAnimation && "animated", shrink && "shrink", size === "small" && "sizeSmall", variant],
      asterisk: [required && "asterisk"]
    };
    const composedClasses = composeClasses(slots, getInputLabelUtilityClasses, classes);
    return _extends({}, classes, composedClasses);
  };
  const InputLabelRoot = styled$1(FormLabel$1, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiInputLabel",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [{
        [`& .${formLabelClasses$1.asterisk}`]: styles2.asterisk
      }, styles2.root, ownerState.formControl && styles2.formControl, ownerState.size === "small" && styles2.sizeSmall, ownerState.shrink && styles2.shrink, !ownerState.disableAnimation && styles2.animated, styles2[ownerState.variant]];
    }
  })(({
    theme,
    ownerState
  }) => _extends({
    display: "block",
    transformOrigin: "top left",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    maxWidth: "100%"
  }, ownerState.formControl && {
    position: "absolute",
    left: 0,
    top: 0,
    transform: "translate(0, 20px) scale(1)"
  }, ownerState.size === "small" && {
    transform: "translate(0, 17px) scale(1)"
  }, ownerState.shrink && {
    transform: "translate(0, -1.5px) scale(0.75)",
    transformOrigin: "top left",
    maxWidth: "133%"
  }, !ownerState.disableAnimation && {
    transition: theme.transitions.create(["color", "transform", "max-width"], {
      duration: theme.transitions.duration.shorter,
      easing: theme.transitions.easing.easeOut
    })
  }, ownerState.variant === "filled" && _extends({
    zIndex: 1,
    pointerEvents: "none",
    transform: "translate(12px, 16px) scale(1)",
    maxWidth: "calc(100% - 24px)"
  }, ownerState.size === "small" && {
    transform: "translate(12px, 13px) scale(1)"
  }, ownerState.shrink && _extends({
    userSelect: "none",
    pointerEvents: "auto",
    transform: "translate(12px, 7px) scale(0.75)",
    maxWidth: "calc(133% - 24px)"
  }, ownerState.size === "small" && {
    transform: "translate(12px, 4px) scale(0.75)"
  })), ownerState.variant === "outlined" && _extends({
    zIndex: 1,
    pointerEvents: "none",
    transform: "translate(14px, 16px) scale(1)",
    maxWidth: "calc(100% - 24px)"
  }, ownerState.size === "small" && {
    transform: "translate(14px, 9px) scale(1)"
  }, ownerState.shrink && {
    userSelect: "none",
    pointerEvents: "auto",
    maxWidth: "calc(133% - 24px)",
    transform: "translate(14px, -9px) scale(0.75)"
  })));
  const InputLabel = /* @__PURE__ */ react.exports.forwardRef(function InputLabel2(inProps, ref) {
    const props = useThemeProps({
      name: "MuiInputLabel",
      props: inProps
    });
    const {
      disableAnimation = false,
      shrink: shrinkProp,
      className
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$b);
    const muiFormControl = useFormControl();
    let shrink = shrinkProp;
    if (typeof shrink === "undefined" && muiFormControl) {
      shrink = muiFormControl.filled || muiFormControl.focused || muiFormControl.adornedStart;
    }
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["size", "variant", "required"]
    });
    const ownerState = _extends({}, props, {
      disableAnimation,
      formControl: muiFormControl,
      shrink,
      size: fcs.size,
      variant: fcs.variant,
      required: fcs.required
    });
    const classes = useUtilityClasses$8(ownerState);
    return /* @__PURE__ */ jsx(InputLabelRoot, _extends({
      "data-shrink": shrink,
      ownerState,
      ref,
      className: clsx(classes.root, className)
    }, other, {
      classes
    }));
  });
  const InputLabel$1 = InputLabel;
  const ListContext = /* @__PURE__ */ react.exports.createContext({});
  const ListContext$1 = ListContext;
  function getListUtilityClass(slot) {
    return generateUtilityClass("MuiList", slot);
  }
  generateUtilityClasses("MuiList", ["root", "padding", "dense", "subheader"]);
  const _excluded$a = ["children", "className", "component", "dense", "disablePadding", "subheader"];
  const useUtilityClasses$7 = (ownerState) => {
    const {
      classes,
      disablePadding,
      dense,
      subheader
    } = ownerState;
    const slots = {
      root: ["root", !disablePadding && "padding", dense && "dense", subheader && "subheader"]
    };
    return composeClasses(slots, getListUtilityClass, classes);
  };
  const ListRoot = styled$1("ul", {
    name: "MuiList",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.root, !ownerState.disablePadding && styles2.padding, ownerState.dense && styles2.dense, ownerState.subheader && styles2.subheader];
    }
  })(({
    ownerState
  }) => _extends({
    listStyle: "none",
    margin: 0,
    padding: 0,
    position: "relative"
  }, !ownerState.disablePadding && {
    paddingTop: 8,
    paddingBottom: 8
  }, ownerState.subheader && {
    paddingTop: 0
  }));
  const List = /* @__PURE__ */ react.exports.forwardRef(function List2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiList"
    });
    const {
      children,
      className,
      component = "ul",
      dense = false,
      disablePadding = false,
      subheader
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$a);
    const context = react.exports.useMemo(() => ({
      dense
    }), [dense]);
    const ownerState = _extends({}, props, {
      component,
      dense,
      disablePadding
    });
    const classes = useUtilityClasses$7(ownerState);
    return /* @__PURE__ */ jsx(ListContext$1.Provider, {
      value: context,
      children: /* @__PURE__ */ jsxs(ListRoot, _extends({
        as: component,
        className: clsx(classes.root, className),
        ref,
        ownerState
      }, other, {
        children: [subheader, children]
      }))
    });
  });
  const List$1 = List;
  const _excluded$9 = ["actions", "autoFocus", "autoFocusItem", "children", "className", "disabledItemsFocusable", "disableListWrap", "onKeyDown", "variant"];
  function nextItem(list, item, disableListWrap) {
    if (list === item) {
      return list.firstChild;
    }
    if (item && item.nextElementSibling) {
      return item.nextElementSibling;
    }
    return disableListWrap ? null : list.firstChild;
  }
  function previousItem(list, item, disableListWrap) {
    if (list === item) {
      return disableListWrap ? list.firstChild : list.lastChild;
    }
    if (item && item.previousElementSibling) {
      return item.previousElementSibling;
    }
    return disableListWrap ? null : list.lastChild;
  }
  function textCriteriaMatches(nextFocus, textCriteria) {
    if (textCriteria === void 0) {
      return true;
    }
    let text = nextFocus.innerText;
    if (text === void 0) {
      text = nextFocus.textContent;
    }
    text = text.trim().toLowerCase();
    if (text.length === 0) {
      return false;
    }
    if (textCriteria.repeating) {
      return text[0] === textCriteria.keys[0];
    }
    return text.indexOf(textCriteria.keys.join("")) === 0;
  }
  function moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, traversalFunction, textCriteria) {
    let wrappedOnce = false;
    let nextFocus = traversalFunction(list, currentFocus, currentFocus ? disableListWrap : false);
    while (nextFocus) {
      if (nextFocus === list.firstChild) {
        if (wrappedOnce) {
          return false;
        }
        wrappedOnce = true;
      }
      const nextFocusDisabled = disabledItemsFocusable ? false : nextFocus.disabled || nextFocus.getAttribute("aria-disabled") === "true";
      if (!nextFocus.hasAttribute("tabindex") || !textCriteriaMatches(nextFocus, textCriteria) || nextFocusDisabled) {
        nextFocus = traversalFunction(list, nextFocus, disableListWrap);
      } else {
        nextFocus.focus();
        return true;
      }
    }
    return false;
  }
  const MenuList = /* @__PURE__ */ react.exports.forwardRef(function MenuList2(props, ref) {
    const {
      actions,
      autoFocus = false,
      autoFocusItem = false,
      children,
      className,
      disabledItemsFocusable = false,
      disableListWrap = false,
      onKeyDown,
      variant = "selectedMenu"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$9);
    const listRef = react.exports.useRef(null);
    const textCriteriaRef = react.exports.useRef({
      keys: [],
      repeating: true,
      previousKeyMatched: true,
      lastTime: null
    });
    useEnhancedEffect$1(() => {
      if (autoFocus) {
        listRef.current.focus();
      }
    }, [autoFocus]);
    react.exports.useImperativeHandle(actions, () => ({
      adjustStyleForScrollbar: (containerElement, theme) => {
        const noExplicitWidth = !listRef.current.style.width;
        if (containerElement.clientHeight < listRef.current.clientHeight && noExplicitWidth) {
          const scrollbarSize = `${getScrollbarSize(ownerDocument(containerElement))}px`;
          listRef.current.style[theme.direction === "rtl" ? "paddingLeft" : "paddingRight"] = scrollbarSize;
          listRef.current.style.width = `calc(100% + ${scrollbarSize})`;
        }
        return listRef.current;
      }
    }), []);
    const handleKeyDown2 = (event) => {
      const list = listRef.current;
      const key = event.key;
      const currentFocus = ownerDocument(list).activeElement;
      if (key === "ArrowDown") {
        event.preventDefault();
        moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, nextItem);
      } else if (key === "ArrowUp") {
        event.preventDefault();
        moveFocus(list, currentFocus, disableListWrap, disabledItemsFocusable, previousItem);
      } else if (key === "Home") {
        event.preventDefault();
        moveFocus(list, null, disableListWrap, disabledItemsFocusable, nextItem);
      } else if (key === "End") {
        event.preventDefault();
        moveFocus(list, null, disableListWrap, disabledItemsFocusable, previousItem);
      } else if (key.length === 1) {
        const criteria = textCriteriaRef.current;
        const lowerKey = key.toLowerCase();
        const currTime = performance.now();
        if (criteria.keys.length > 0) {
          if (currTime - criteria.lastTime > 500) {
            criteria.keys = [];
            criteria.repeating = true;
            criteria.previousKeyMatched = true;
          } else if (criteria.repeating && lowerKey !== criteria.keys[0]) {
            criteria.repeating = false;
          }
        }
        criteria.lastTime = currTime;
        criteria.keys.push(lowerKey);
        const keepFocusOnCurrent = currentFocus && !criteria.repeating && textCriteriaMatches(currentFocus, criteria);
        if (criteria.previousKeyMatched && (keepFocusOnCurrent || moveFocus(list, currentFocus, false, disabledItemsFocusable, nextItem, criteria))) {
          event.preventDefault();
        } else {
          criteria.previousKeyMatched = false;
        }
      }
      if (onKeyDown) {
        onKeyDown(event);
      }
    };
    const handleRef = useForkRef(listRef, ref);
    let activeItemIndex = -1;
    react.exports.Children.forEach(children, (child, index) => {
      if (!/* @__PURE__ */ react.exports.isValidElement(child)) {
        return;
      }
      if (!child.props.disabled) {
        if (variant === "selectedMenu" && child.props.selected) {
          activeItemIndex = index;
        } else if (activeItemIndex === -1) {
          activeItemIndex = index;
        }
      }
    });
    const items = react.exports.Children.map(children, (child, index) => {
      if (index === activeItemIndex) {
        const newChildProps = {};
        if (autoFocusItem) {
          newChildProps.autoFocus = true;
        }
        if (child.props.tabIndex === void 0 && variant === "selectedMenu") {
          newChildProps.tabIndex = 0;
        }
        return /* @__PURE__ */ react.exports.cloneElement(child, newChildProps);
      }
      return child;
    });
    return /* @__PURE__ */ jsx(List$1, _extends({
      role: "menu",
      ref: handleRef,
      className,
      onKeyDown: handleKeyDown2,
      tabIndex: autoFocus ? 0 : -1
    }, other, {
      children: items
    }));
  });
  const MenuList$1 = MenuList;
  function getPopoverUtilityClass(slot) {
    return generateUtilityClass("MuiPopover", slot);
  }
  generateUtilityClasses("MuiPopover", ["root", "paper"]);
  const _excluded$8 = ["onEntering"], _excluded2$1 = ["action", "anchorEl", "anchorOrigin", "anchorPosition", "anchorReference", "children", "className", "container", "elevation", "marginThreshold", "open", "PaperProps", "transformOrigin", "TransitionComponent", "transitionDuration", "TransitionProps"];
  function getOffsetTop(rect, vertical) {
    let offset2 = 0;
    if (typeof vertical === "number") {
      offset2 = vertical;
    } else if (vertical === "center") {
      offset2 = rect.height / 2;
    } else if (vertical === "bottom") {
      offset2 = rect.height;
    }
    return offset2;
  }
  function getOffsetLeft(rect, horizontal) {
    let offset2 = 0;
    if (typeof horizontal === "number") {
      offset2 = horizontal;
    } else if (horizontal === "center") {
      offset2 = rect.width / 2;
    } else if (horizontal === "right") {
      offset2 = rect.width;
    }
    return offset2;
  }
  function getTransformOriginValue(transformOrigin) {
    return [transformOrigin.horizontal, transformOrigin.vertical].map((n2) => typeof n2 === "number" ? `${n2}px` : n2).join(" ");
  }
  function resolveAnchorEl(anchorEl) {
    return typeof anchorEl === "function" ? anchorEl() : anchorEl;
  }
  const useUtilityClasses$6 = (ownerState) => {
    const {
      classes
    } = ownerState;
    const slots = {
      root: ["root"],
      paper: ["paper"]
    };
    return composeClasses(slots, getPopoverUtilityClass, classes);
  };
  const PopoverRoot = styled$1(Modal$1, {
    name: "MuiPopover",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({});
  const PopoverPaper = styled$1(Paper$1, {
    name: "MuiPopover",
    slot: "Paper",
    overridesResolver: (props, styles2) => styles2.paper
  })({
    position: "absolute",
    overflowY: "auto",
    overflowX: "hidden",
    minWidth: 16,
    minHeight: 16,
    maxWidth: "calc(100% - 32px)",
    maxHeight: "calc(100% - 32px)",
    outline: 0
  });
  const Popover = /* @__PURE__ */ react.exports.forwardRef(function Popover2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiPopover"
    });
    const {
      action,
      anchorEl,
      anchorOrigin = {
        vertical: "top",
        horizontal: "left"
      },
      anchorPosition,
      anchorReference = "anchorEl",
      children,
      className,
      container: containerProp,
      elevation = 8,
      marginThreshold = 16,
      open,
      PaperProps = {},
      transformOrigin = {
        vertical: "top",
        horizontal: "left"
      },
      TransitionComponent = Grow$1,
      transitionDuration: transitionDurationProp = "auto",
      TransitionProps: {
        onEntering
      } = {}
    } = props, TransitionProps = _objectWithoutPropertiesLoose(props.TransitionProps, _excluded$8), other = _objectWithoutPropertiesLoose(props, _excluded2$1);
    const paperRef = react.exports.useRef();
    const handlePaperRef = useForkRef(paperRef, PaperProps.ref);
    const ownerState = _extends({}, props, {
      anchorOrigin,
      anchorReference,
      elevation,
      marginThreshold,
      PaperProps,
      transformOrigin,
      TransitionComponent,
      transitionDuration: transitionDurationProp,
      TransitionProps
    });
    const classes = useUtilityClasses$6(ownerState);
    const getAnchorOffset = react.exports.useCallback(() => {
      if (anchorReference === "anchorPosition") {
        return anchorPosition;
      }
      const resolvedAnchorEl = resolveAnchorEl(anchorEl);
      const anchorElement = resolvedAnchorEl && resolvedAnchorEl.nodeType === 1 ? resolvedAnchorEl : ownerDocument(paperRef.current).body;
      const anchorRect = anchorElement.getBoundingClientRect();
      return {
        top: anchorRect.top + getOffsetTop(anchorRect, anchorOrigin.vertical),
        left: anchorRect.left + getOffsetLeft(anchorRect, anchorOrigin.horizontal)
      };
    }, [anchorEl, anchorOrigin.horizontal, anchorOrigin.vertical, anchorPosition, anchorReference]);
    const getTransformOrigin = react.exports.useCallback((elemRect) => {
      return {
        vertical: getOffsetTop(elemRect, transformOrigin.vertical),
        horizontal: getOffsetLeft(elemRect, transformOrigin.horizontal)
      };
    }, [transformOrigin.horizontal, transformOrigin.vertical]);
    const getPositioningStyle = react.exports.useCallback((element) => {
      const elemRect = {
        width: element.offsetWidth,
        height: element.offsetHeight
      };
      const elemTransformOrigin = getTransformOrigin(elemRect);
      if (anchorReference === "none") {
        return {
          top: null,
          left: null,
          transformOrigin: getTransformOriginValue(elemTransformOrigin)
        };
      }
      const anchorOffset = getAnchorOffset();
      let top2 = anchorOffset.top - elemTransformOrigin.vertical;
      let left2 = anchorOffset.left - elemTransformOrigin.horizontal;
      const bottom2 = top2 + elemRect.height;
      const right2 = left2 + elemRect.width;
      const containerWindow = ownerWindow(resolveAnchorEl(anchorEl));
      const heightThreshold = containerWindow.innerHeight - marginThreshold;
      const widthThreshold = containerWindow.innerWidth - marginThreshold;
      if (top2 < marginThreshold) {
        const diff = top2 - marginThreshold;
        top2 -= diff;
        elemTransformOrigin.vertical += diff;
      } else if (bottom2 > heightThreshold) {
        const diff = bottom2 - heightThreshold;
        top2 -= diff;
        elemTransformOrigin.vertical += diff;
      }
      if (left2 < marginThreshold) {
        const diff = left2 - marginThreshold;
        left2 -= diff;
        elemTransformOrigin.horizontal += diff;
      } else if (right2 > widthThreshold) {
        const diff = right2 - widthThreshold;
        left2 -= diff;
        elemTransformOrigin.horizontal += diff;
      }
      return {
        top: `${Math.round(top2)}px`,
        left: `${Math.round(left2)}px`,
        transformOrigin: getTransformOriginValue(elemTransformOrigin)
      };
    }, [anchorEl, anchorReference, getAnchorOffset, getTransformOrigin, marginThreshold]);
    const setPositioningStyles = react.exports.useCallback(() => {
      const element = paperRef.current;
      if (!element) {
        return;
      }
      const positioning = getPositioningStyle(element);
      if (positioning.top !== null) {
        element.style.top = positioning.top;
      }
      if (positioning.left !== null) {
        element.style.left = positioning.left;
      }
      element.style.transformOrigin = positioning.transformOrigin;
    }, [getPositioningStyle]);
    const handleEntering = (element, isAppearing) => {
      if (onEntering) {
        onEntering(element, isAppearing);
      }
      setPositioningStyles();
    };
    react.exports.useEffect(() => {
      if (open) {
        setPositioningStyles();
      }
    });
    react.exports.useImperativeHandle(action, () => open ? {
      updatePosition: () => {
        setPositioningStyles();
      }
    } : null, [open, setPositioningStyles]);
    react.exports.useEffect(() => {
      if (!open) {
        return void 0;
      }
      const handleResize = debounce$1(() => {
        setPositioningStyles();
      });
      const containerWindow = ownerWindow(anchorEl);
      containerWindow.addEventListener("resize", handleResize);
      return () => {
        handleResize.clear();
        containerWindow.removeEventListener("resize", handleResize);
      };
    }, [anchorEl, open, setPositioningStyles]);
    let transitionDuration = transitionDurationProp;
    if (transitionDurationProp === "auto" && !TransitionComponent.muiSupportAuto) {
      transitionDuration = void 0;
    }
    const container = containerProp || (anchorEl ? ownerDocument(resolveAnchorEl(anchorEl)).body : void 0);
    return /* @__PURE__ */ jsx(PopoverRoot, _extends({
      BackdropProps: {
        invisible: true
      },
      className: clsx(classes.root, className),
      container,
      open,
      ref,
      ownerState
    }, other, {
      children: /* @__PURE__ */ jsx(TransitionComponent, _extends({
        appear: true,
        in: open,
        onEntering: handleEntering,
        timeout: transitionDuration
      }, TransitionProps, {
        children: /* @__PURE__ */ jsx(PopoverPaper, _extends({
          elevation
        }, PaperProps, {
          ref: handlePaperRef,
          className: clsx(classes.paper, PaperProps.className),
          ownerState,
          children
        }))
      }))
    }));
  });
  const Popover$1 = Popover;
  function getMenuUtilityClass(slot) {
    return generateUtilityClass("MuiMenu", slot);
  }
  generateUtilityClasses("MuiMenu", ["root", "paper", "list"]);
  const _excluded$7 = ["onEntering"], _excluded2 = ["autoFocus", "children", "disableAutoFocusItem", "MenuListProps", "onClose", "open", "PaperProps", "PopoverClasses", "transitionDuration", "TransitionProps", "variant"];
  const RTL_ORIGIN = {
    vertical: "top",
    horizontal: "right"
  };
  const LTR_ORIGIN = {
    vertical: "top",
    horizontal: "left"
  };
  const useUtilityClasses$5 = (ownerState) => {
    const {
      classes
    } = ownerState;
    const slots = {
      root: ["root"],
      paper: ["paper"],
      list: ["list"]
    };
    return composeClasses(slots, getMenuUtilityClass, classes);
  };
  const MenuRoot = styled$1(Popover$1, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiMenu",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({});
  const MenuPaper = styled$1(Paper$1, {
    name: "MuiMenu",
    slot: "Paper",
    overridesResolver: (props, styles2) => styles2.paper
  })({
    maxHeight: "calc(100% - 96px)",
    WebkitOverflowScrolling: "touch"
  });
  const MenuMenuList = styled$1(MenuList$1, {
    name: "MuiMenu",
    slot: "List",
    overridesResolver: (props, styles2) => styles2.list
  })({
    outline: 0
  });
  const Menu = /* @__PURE__ */ react.exports.forwardRef(function Menu2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiMenu"
    });
    const {
      autoFocus = true,
      children,
      disableAutoFocusItem = false,
      MenuListProps = {},
      onClose,
      open,
      PaperProps = {},
      PopoverClasses,
      transitionDuration = "auto",
      TransitionProps: {
        onEntering
      } = {},
      variant = "selectedMenu"
    } = props, TransitionProps = _objectWithoutPropertiesLoose(props.TransitionProps, _excluded$7), other = _objectWithoutPropertiesLoose(props, _excluded2);
    const theme = useTheme();
    const isRtl = theme.direction === "rtl";
    const ownerState = _extends({}, props, {
      autoFocus,
      disableAutoFocusItem,
      MenuListProps,
      onEntering,
      PaperProps,
      transitionDuration,
      TransitionProps,
      variant
    });
    const classes = useUtilityClasses$5(ownerState);
    const autoFocusItem = autoFocus && !disableAutoFocusItem && open;
    const menuListActionsRef = react.exports.useRef(null);
    const handleEntering = (element, isAppearing) => {
      if (menuListActionsRef.current) {
        menuListActionsRef.current.adjustStyleForScrollbar(element, theme);
      }
      if (onEntering) {
        onEntering(element, isAppearing);
      }
    };
    const handleListKeyDown = (event) => {
      if (event.key === "Tab") {
        event.preventDefault();
        if (onClose) {
          onClose(event, "tabKeyDown");
        }
      }
    };
    let activeItemIndex = -1;
    react.exports.Children.map(children, (child, index) => {
      if (!/* @__PURE__ */ react.exports.isValidElement(child)) {
        return;
      }
      if (!child.props.disabled) {
        if (variant === "selectedMenu" && child.props.selected) {
          activeItemIndex = index;
        } else if (activeItemIndex === -1) {
          activeItemIndex = index;
        }
      }
    });
    return /* @__PURE__ */ jsx(MenuRoot, _extends({
      classes: PopoverClasses,
      onClose,
      anchorOrigin: {
        vertical: "bottom",
        horizontal: isRtl ? "right" : "left"
      },
      transformOrigin: isRtl ? RTL_ORIGIN : LTR_ORIGIN,
      PaperProps: _extends({
        component: MenuPaper
      }, PaperProps, {
        classes: _extends({}, PaperProps.classes, {
          root: classes.paper
        })
      }),
      className: classes.root,
      open,
      ref,
      transitionDuration,
      TransitionProps: _extends({
        onEntering: handleEntering
      }, TransitionProps),
      ownerState
    }, other, {
      children: /* @__PURE__ */ jsx(MenuMenuList, _extends({
        onKeyDown: handleListKeyDown,
        actions: menuListActionsRef,
        autoFocus: autoFocus && (activeItemIndex === -1 || disableAutoFocusItem),
        autoFocusItem,
        variant
      }, MenuListProps, {
        className: clsx(classes.list, MenuListProps.className),
        children
      }))
    }));
  });
  const Menu$1 = Menu;
  function getNativeSelectUtilityClasses(slot) {
    return generateUtilityClass("MuiNativeSelect", slot);
  }
  const nativeSelectClasses = generateUtilityClasses("MuiNativeSelect", ["root", "select", "multiple", "filled", "outlined", "standard", "disabled", "icon", "iconOpen", "iconFilled", "iconOutlined", "iconStandard", "nativeInput"]);
  const nativeSelectClasses$1 = nativeSelectClasses;
  const _excluded$6 = ["className", "disabled", "IconComponent", "inputRef", "variant"];
  const useUtilityClasses$4 = (ownerState) => {
    const {
      classes,
      variant,
      disabled,
      multiple,
      open
    } = ownerState;
    const slots = {
      select: ["select", variant, disabled && "disabled", multiple && "multiple"],
      icon: ["icon", `icon${capitalize(variant)}`, open && "iconOpen", disabled && "disabled"]
    };
    return composeClasses(slots, getNativeSelectUtilityClasses, classes);
  };
  const nativeSelectSelectStyles = ({
    ownerState,
    theme
  }) => _extends({
    MozAppearance: "none",
    WebkitAppearance: "none",
    userSelect: "none",
    borderRadius: 0,
    cursor: "pointer",
    "&:focus": {
      backgroundColor: theme.palette.mode === "light" ? "rgba(0, 0, 0, 0.05)" : "rgba(255, 255, 255, 0.05)",
      borderRadius: 0
    },
    "&::-ms-expand": {
      display: "none"
    },
    [`&.${nativeSelectClasses$1.disabled}`]: {
      cursor: "default"
    },
    "&[multiple]": {
      height: "auto"
    },
    "&:not([multiple]) option, &:not([multiple]) optgroup": {
      backgroundColor: theme.palette.background.paper
    },
    "&&&": {
      paddingRight: 24,
      minWidth: 16
    }
  }, ownerState.variant === "filled" && {
    "&&&": {
      paddingRight: 32
    }
  }, ownerState.variant === "outlined" && {
    borderRadius: theme.shape.borderRadius,
    "&:focus": {
      borderRadius: theme.shape.borderRadius
    },
    "&&&": {
      paddingRight: 32
    }
  });
  const NativeSelectSelect = styled$1("select", {
    name: "MuiNativeSelect",
    slot: "Select",
    shouldForwardProp: rootShouldForwardProp,
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.select, styles2[ownerState.variant], {
        [`&.${nativeSelectClasses$1.multiple}`]: styles2.multiple
      }];
    }
  })(nativeSelectSelectStyles);
  const nativeSelectIconStyles = ({
    ownerState,
    theme
  }) => _extends({
    position: "absolute",
    right: 0,
    top: "calc(50% - .5em)",
    pointerEvents: "none",
    color: theme.palette.action.active,
    [`&.${nativeSelectClasses$1.disabled}`]: {
      color: theme.palette.action.disabled
    }
  }, ownerState.open && {
    transform: "rotate(180deg)"
  }, ownerState.variant === "filled" && {
    right: 7
  }, ownerState.variant === "outlined" && {
    right: 7
  });
  const NativeSelectIcon = styled$1("svg", {
    name: "MuiNativeSelect",
    slot: "Icon",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.icon, ownerState.variant && styles2[`icon${capitalize(ownerState.variant)}`], ownerState.open && styles2.iconOpen];
    }
  })(nativeSelectIconStyles);
  const NativeSelectInput = /* @__PURE__ */ react.exports.forwardRef(function NativeSelectInput2(props, ref) {
    const {
      className,
      disabled,
      IconComponent,
      inputRef,
      variant = "standard"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$6);
    const ownerState = _extends({}, props, {
      disabled,
      variant
    });
    const classes = useUtilityClasses$4(ownerState);
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx(NativeSelectSelect, _extends({
        ownerState,
        className: clsx(classes.select, className),
        disabled,
        ref: inputRef || ref
      }, other)), props.multiple ? null : /* @__PURE__ */ jsx(NativeSelectIcon, {
        as: IconComponent,
        ownerState,
        className: classes.icon
      })]
    });
  });
  const NativeSelectInput$1 = NativeSelectInput;
  var _span$1;
  const _excluded$5 = ["children", "classes", "className", "label", "notched"];
  const NotchedOutlineRoot$1 = styled$1("fieldset")({
    textAlign: "left",
    position: "absolute",
    bottom: 0,
    right: 0,
    top: -5,
    left: 0,
    margin: 0,
    padding: "0 8px",
    pointerEvents: "none",
    borderRadius: "inherit",
    borderStyle: "solid",
    borderWidth: 1,
    overflow: "hidden",
    minWidth: "0%"
  });
  const NotchedOutlineLegend = styled$1("legend")(({
    ownerState,
    theme
  }) => _extends({
    float: "unset",
    width: "auto",
    overflow: "hidden"
  }, !ownerState.withLabel && {
    padding: 0,
    lineHeight: "11px",
    transition: theme.transitions.create("width", {
      duration: 150,
      easing: theme.transitions.easing.easeOut
    })
  }, ownerState.withLabel && _extends({
    display: "block",
    padding: 0,
    height: 11,
    fontSize: "0.75em",
    visibility: "hidden",
    maxWidth: 0.01,
    transition: theme.transitions.create("max-width", {
      duration: 50,
      easing: theme.transitions.easing.easeOut
    }),
    whiteSpace: "nowrap",
    "& > span": {
      paddingLeft: 5,
      paddingRight: 5,
      display: "inline-block",
      opacity: 0,
      visibility: "visible"
    }
  }, ownerState.notched && {
    maxWidth: "100%",
    transition: theme.transitions.create("max-width", {
      duration: 100,
      easing: theme.transitions.easing.easeOut,
      delay: 50
    })
  })));
  function NotchedOutline(props) {
    const {
      className,
      label,
      notched
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$5);
    const withLabel = label != null && label !== "";
    const ownerState = _extends({}, props, {
      notched,
      withLabel
    });
    return /* @__PURE__ */ jsx(NotchedOutlineRoot$1, _extends({
      "aria-hidden": true,
      className,
      ownerState
    }, other, {
      children: /* @__PURE__ */ jsx(NotchedOutlineLegend, {
        ownerState,
        children: withLabel ? /* @__PURE__ */ jsx("span", {
          children: label
        }) : _span$1 || (_span$1 = /* @__PURE__ */ jsx("span", {
          className: "notranslate",
          children: "\u200B"
        }))
      })
    }));
  }
  const _excluded$4 = ["components", "fullWidth", "inputComponent", "label", "multiline", "notched", "type"];
  const useUtilityClasses$3 = (ownerState) => {
    const {
      classes
    } = ownerState;
    const slots = {
      root: ["root"],
      notchedOutline: ["notchedOutline"],
      input: ["input"]
    };
    const composedClasses = composeClasses(slots, getOutlinedInputUtilityClass, classes);
    return _extends({}, classes, composedClasses);
  };
  const OutlinedInputRoot = styled$1(InputBaseRoot, {
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
    name: "MuiOutlinedInput",
    slot: "Root",
    overridesResolver: rootOverridesResolver
  })(({
    theme,
    ownerState
  }) => {
    const borderColor2 = theme.palette.mode === "light" ? "rgba(0, 0, 0, 0.23)" : "rgba(255, 255, 255, 0.23)";
    return _extends({
      position: "relative",
      borderRadius: (theme.vars || theme).shape.borderRadius,
      [`&:hover .${outlinedInputClasses$1.notchedOutline}`]: {
        borderColor: (theme.vars || theme).palette.text.primary
      },
      "@media (hover: none)": {
        [`&:hover .${outlinedInputClasses$1.notchedOutline}`]: {
          borderColor: theme.vars ? `rgba(${theme.vars.palette.common.onBackgroundChannel} / 0.23)` : borderColor2
        }
      },
      [`&.${outlinedInputClasses$1.focused} .${outlinedInputClasses$1.notchedOutline}`]: {
        borderColor: (theme.vars || theme).palette[ownerState.color].main,
        borderWidth: 2
      },
      [`&.${outlinedInputClasses$1.error} .${outlinedInputClasses$1.notchedOutline}`]: {
        borderColor: (theme.vars || theme).palette.error.main
      },
      [`&.${outlinedInputClasses$1.disabled} .${outlinedInputClasses$1.notchedOutline}`]: {
        borderColor: (theme.vars || theme).palette.action.disabled
      }
    }, ownerState.startAdornment && {
      paddingLeft: 14
    }, ownerState.endAdornment && {
      paddingRight: 14
    }, ownerState.multiline && _extends({
      padding: "16.5px 14px"
    }, ownerState.size === "small" && {
      padding: "8.5px 14px"
    }));
  });
  const NotchedOutlineRoot = styled$1(NotchedOutline, {
    name: "MuiOutlinedInput",
    slot: "NotchedOutline",
    overridesResolver: (props, styles2) => styles2.notchedOutline
  })(({
    theme
  }) => {
    const borderColor2 = theme.palette.mode === "light" ? "rgba(0, 0, 0, 0.23)" : "rgba(255, 255, 255, 0.23)";
    return {
      borderColor: theme.vars ? `rgba(${theme.vars.palette.common.onBackgroundChannel} / 0.23)` : borderColor2
    };
  });
  const OutlinedInputInput = styled$1(InputBaseComponent, {
    name: "MuiOutlinedInput",
    slot: "Input",
    overridesResolver: inputOverridesResolver
  })(({
    theme,
    ownerState
  }) => _extends({
    padding: "16.5px 14px"
  }, !theme.vars && {
    "&:-webkit-autofill": {
      WebkitBoxShadow: theme.palette.mode === "light" ? null : "0 0 0 100px #266798 inset",
      WebkitTextFillColor: theme.palette.mode === "light" ? null : "#fff",
      caretColor: theme.palette.mode === "light" ? null : "#fff",
      borderRadius: "inherit"
    }
  }, theme.vars && {
    "&:-webkit-autofill": {
      borderRadius: "inherit"
    },
    [theme.getColorSchemeSelector("dark")]: {
      "&:-webkit-autofill": {
        WebkitBoxShadow: "0 0 0 100px #266798 inset",
        WebkitTextFillColor: "#fff",
        caretColor: "#fff"
      }
    }
  }, ownerState.size === "small" && {
    padding: "8.5px 14px"
  }, ownerState.multiline && {
    padding: 0
  }, ownerState.startAdornment && {
    paddingLeft: 0
  }, ownerState.endAdornment && {
    paddingRight: 0
  }));
  const OutlinedInput = /* @__PURE__ */ react.exports.forwardRef(function OutlinedInput2(inProps, ref) {
    var _React$Fragment;
    const props = useThemeProps({
      props: inProps,
      name: "MuiOutlinedInput"
    });
    const {
      components = {},
      fullWidth = false,
      inputComponent = "input",
      label,
      multiline = false,
      notched,
      type = "text"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$4);
    const classes = useUtilityClasses$3(props);
    const muiFormControl = useFormControl();
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["required"]
    });
    const ownerState = _extends({}, props, {
      color: fcs.color || "primary",
      disabled: fcs.disabled,
      error: fcs.error,
      focused: fcs.focused,
      formControl: muiFormControl,
      fullWidth,
      hiddenLabel: fcs.hiddenLabel,
      multiline,
      size: fcs.size,
      type
    });
    return /* @__PURE__ */ jsx(InputBase$1, _extends({
      components: _extends({
        Root: OutlinedInputRoot,
        Input: OutlinedInputInput
      }, components),
      renderSuffix: (state) => /* @__PURE__ */ jsx(NotchedOutlineRoot, {
        ownerState,
        className: classes.notchedOutline,
        label: label != null && label !== "" && fcs.required ? _React$Fragment || (_React$Fragment = /* @__PURE__ */ jsxs(react.exports.Fragment, {
          children: [label, "\xA0", "*"]
        })) : label,
        notched: typeof notched !== "undefined" ? notched : Boolean(state.startAdornment || state.filled || state.focused)
      }),
      fullWidth,
      inputComponent,
      multiline,
      ref,
      type
    }, other, {
      classes: _extends({}, classes, {
        notchedOutline: null
      })
    }));
  });
  OutlinedInput.muiName = "Input";
  const OutlinedInput$1 = OutlinedInput;
  function getSelectUtilityClasses(slot) {
    return generateUtilityClass("MuiSelect", slot);
  }
  const selectClasses = generateUtilityClasses("MuiSelect", ["select", "multiple", "filled", "outlined", "standard", "disabled", "focused", "icon", "iconOpen", "iconFilled", "iconOutlined", "iconStandard", "nativeInput"]);
  const selectClasses$1 = selectClasses;
  var _span;
  const _excluded$3 = ["aria-describedby", "aria-label", "autoFocus", "autoWidth", "children", "className", "defaultOpen", "defaultValue", "disabled", "displayEmpty", "IconComponent", "inputRef", "labelId", "MenuProps", "multiple", "name", "onBlur", "onChange", "onClose", "onFocus", "onOpen", "open", "readOnly", "renderValue", "SelectDisplayProps", "tabIndex", "type", "value", "variant"];
  const SelectSelect = styled$1("div", {
    name: "MuiSelect",
    slot: "Select",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [
        {
          [`&.${selectClasses$1.select}`]: styles2.select
        },
        {
          [`&.${selectClasses$1.select}`]: styles2[ownerState.variant]
        },
        {
          [`&.${selectClasses$1.multiple}`]: styles2.multiple
        }
      ];
    }
  })(nativeSelectSelectStyles, {
    [`&.${selectClasses$1.select}`]: {
      height: "auto",
      minHeight: "1.4375em",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      overflow: "hidden"
    }
  });
  const SelectIcon = styled$1("svg", {
    name: "MuiSelect",
    slot: "Icon",
    overridesResolver: (props, styles2) => {
      const {
        ownerState
      } = props;
      return [styles2.icon, ownerState.variant && styles2[`icon${capitalize(ownerState.variant)}`], ownerState.open && styles2.iconOpen];
    }
  })(nativeSelectIconStyles);
  const SelectNativeInput = styled$1("input", {
    shouldForwardProp: (prop) => slotShouldForwardProp(prop) && prop !== "classes",
    name: "MuiSelect",
    slot: "NativeInput",
    overridesResolver: (props, styles2) => styles2.nativeInput
  })({
    bottom: 0,
    left: 0,
    position: "absolute",
    opacity: 0,
    pointerEvents: "none",
    width: "100%",
    boxSizing: "border-box"
  });
  function areEqualValues(a, b2) {
    if (typeof b2 === "object" && b2 !== null) {
      return a === b2;
    }
    return String(a) === String(b2);
  }
  function isEmpty(display2) {
    return display2 == null || typeof display2 === "string" && !display2.trim();
  }
  const useUtilityClasses$2 = (ownerState) => {
    const {
      classes,
      variant,
      disabled,
      multiple,
      open
    } = ownerState;
    const slots = {
      select: ["select", variant, disabled && "disabled", multiple && "multiple"],
      icon: ["icon", `icon${capitalize(variant)}`, open && "iconOpen", disabled && "disabled"],
      nativeInput: ["nativeInput"]
    };
    return composeClasses(slots, getSelectUtilityClasses, classes);
  };
  const SelectInput = /* @__PURE__ */ react.exports.forwardRef(function SelectInput2(props, ref) {
    const {
      "aria-describedby": ariaDescribedby,
      "aria-label": ariaLabel,
      autoFocus,
      autoWidth,
      children,
      className,
      defaultOpen,
      defaultValue,
      disabled,
      displayEmpty,
      IconComponent,
      inputRef: inputRefProp,
      labelId,
      MenuProps = {},
      multiple,
      name,
      onBlur,
      onChange,
      onClose,
      onFocus,
      onOpen,
      open: openProp,
      readOnly,
      renderValue,
      SelectDisplayProps = {},
      tabIndex: tabIndexProp,
      value: valueProp,
      variant = "standard"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$3);
    const [value, setValueState] = useControlled({
      controlled: valueProp,
      default: defaultValue,
      name: "Select"
    });
    const [openState, setOpenState] = useControlled({
      controlled: openProp,
      default: defaultOpen,
      name: "Select"
    });
    const inputRef = react.exports.useRef(null);
    const displayRef = react.exports.useRef(null);
    const [displayNode, setDisplayNode] = react.exports.useState(null);
    const {
      current: isOpenControlled
    } = react.exports.useRef(openProp != null);
    const [menuMinWidthState, setMenuMinWidthState] = react.exports.useState();
    const handleRef = useForkRef(ref, inputRefProp);
    const handleDisplayRef = react.exports.useCallback((node2) => {
      displayRef.current = node2;
      if (node2) {
        setDisplayNode(node2);
      }
    }, []);
    react.exports.useImperativeHandle(handleRef, () => ({
      focus: () => {
        displayRef.current.focus();
      },
      node: inputRef.current,
      value
    }), [value]);
    react.exports.useEffect(() => {
      if (defaultOpen && openState && displayNode && !isOpenControlled) {
        setMenuMinWidthState(autoWidth ? null : displayNode.clientWidth);
        displayRef.current.focus();
      }
    }, [displayNode, autoWidth]);
    react.exports.useEffect(() => {
      if (autoFocus) {
        displayRef.current.focus();
      }
    }, [autoFocus]);
    react.exports.useEffect(() => {
      if (!labelId) {
        return void 0;
      }
      const label = ownerDocument(displayRef.current).getElementById(labelId);
      if (label) {
        const handler = () => {
          if (getSelection().isCollapsed) {
            displayRef.current.focus();
          }
        };
        label.addEventListener("click", handler);
        return () => {
          label.removeEventListener("click", handler);
        };
      }
      return void 0;
    }, [labelId]);
    const update = (open2, event) => {
      if (open2) {
        if (onOpen) {
          onOpen(event);
        }
      } else if (onClose) {
        onClose(event);
      }
      if (!isOpenControlled) {
        setMenuMinWidthState(autoWidth ? null : displayNode.clientWidth);
        setOpenState(open2);
      }
    };
    const handleMouseDown = (event) => {
      if (event.button !== 0) {
        return;
      }
      event.preventDefault();
      displayRef.current.focus();
      update(true, event);
    };
    const handleClose = (event) => {
      update(false, event);
    };
    const childrenArray = react.exports.Children.toArray(children);
    const handleChange = (event) => {
      const index = childrenArray.map((child2) => child2.props.value).indexOf(event.target.value);
      if (index === -1) {
        return;
      }
      const child = childrenArray[index];
      setValueState(child.props.value);
      if (onChange) {
        onChange(event, child);
      }
    };
    const handleItemClick = (child) => (event) => {
      let newValue;
      if (!event.currentTarget.hasAttribute("tabindex")) {
        return;
      }
      if (multiple) {
        newValue = Array.isArray(value) ? value.slice() : [];
        const itemIndex = value.indexOf(child.props.value);
        if (itemIndex === -1) {
          newValue.push(child.props.value);
        } else {
          newValue.splice(itemIndex, 1);
        }
      } else {
        newValue = child.props.value;
      }
      if (child.props.onClick) {
        child.props.onClick(event);
      }
      if (value !== newValue) {
        setValueState(newValue);
        if (onChange) {
          const nativeEvent = event.nativeEvent || event;
          const clonedEvent = new nativeEvent.constructor(nativeEvent.type, nativeEvent);
          Object.defineProperty(clonedEvent, "target", {
            writable: true,
            value: {
              value: newValue,
              name
            }
          });
          onChange(clonedEvent, child);
        }
      }
      if (!multiple) {
        update(false, event);
      }
    };
    const handleKeyDown2 = (event) => {
      if (!readOnly) {
        const validKeys = [
          " ",
          "ArrowUp",
          "ArrowDown",
          "Enter"
        ];
        if (validKeys.indexOf(event.key) !== -1) {
          event.preventDefault();
          update(true, event);
        }
      }
    };
    const open = displayNode !== null && openState;
    const handleBlur = (event) => {
      if (!open && onBlur) {
        Object.defineProperty(event, "target", {
          writable: true,
          value: {
            value,
            name
          }
        });
        onBlur(event);
      }
    };
    delete other["aria-invalid"];
    let display2;
    let displaySingle;
    const displayMultiple = [];
    let computeDisplay = false;
    if (isFilled({
      value
    }) || displayEmpty) {
      if (renderValue) {
        display2 = renderValue(value);
      } else {
        computeDisplay = true;
      }
    }
    const items = childrenArray.map((child, index, arr) => {
      if (!/* @__PURE__ */ react.exports.isValidElement(child)) {
        return null;
      }
      let selected;
      if (multiple) {
        if (!Array.isArray(value)) {
          throw new Error(formatMuiErrorMessage(2));
        }
        selected = value.some((v2) => areEqualValues(v2, child.props.value));
        if (selected && computeDisplay) {
          displayMultiple.push(child.props.children);
        }
      } else {
        selected = areEqualValues(value, child.props.value);
        if (selected && computeDisplay) {
          displaySingle = child.props.children;
        }
      }
      if (child.props.value === void 0) {
        return /* @__PURE__ */ react.exports.cloneElement(child, {
          "aria-readonly": true,
          role: "option"
        });
      }
      const isFirstSelectableElement = () => {
        if (value) {
          return selected;
        }
        const firstSelectableElement = arr.find((item) => item.props.value !== void 0 && item.props.disabled !== true);
        if (child === firstSelectableElement) {
          return true;
        }
        return selected;
      };
      return /* @__PURE__ */ react.exports.cloneElement(child, {
        "aria-selected": selected ? "true" : "false",
        onClick: handleItemClick(child),
        onKeyUp: (event) => {
          if (event.key === " ") {
            event.preventDefault();
          }
          if (child.props.onKeyUp) {
            child.props.onKeyUp(event);
          }
        },
        role: "option",
        selected: arr[0].props.value === void 0 || arr[0].props.disabled === true ? isFirstSelectableElement() : selected,
        value: void 0,
        "data-value": child.props.value
      });
    });
    if (computeDisplay) {
      if (multiple) {
        if (displayMultiple.length === 0) {
          display2 = null;
        } else {
          display2 = displayMultiple.reduce((output, child, index) => {
            output.push(child);
            if (index < displayMultiple.length - 1) {
              output.push(", ");
            }
            return output;
          }, []);
        }
      } else {
        display2 = displaySingle;
      }
    }
    let menuMinWidth = menuMinWidthState;
    if (!autoWidth && isOpenControlled && displayNode) {
      menuMinWidth = displayNode.clientWidth;
    }
    let tabIndex;
    if (typeof tabIndexProp !== "undefined") {
      tabIndex = tabIndexProp;
    } else {
      tabIndex = disabled ? null : 0;
    }
    const buttonId = SelectDisplayProps.id || (name ? `mui-component-select-${name}` : void 0);
    const ownerState = _extends({}, props, {
      variant,
      value,
      open
    });
    const classes = useUtilityClasses$2(ownerState);
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx(SelectSelect, _extends({
        ref: handleDisplayRef,
        tabIndex,
        role: "button",
        "aria-disabled": disabled ? "true" : void 0,
        "aria-expanded": open ? "true" : "false",
        "aria-haspopup": "listbox",
        "aria-label": ariaLabel,
        "aria-labelledby": [labelId, buttonId].filter(Boolean).join(" ") || void 0,
        "aria-describedby": ariaDescribedby,
        onKeyDown: handleKeyDown2,
        onMouseDown: disabled || readOnly ? null : handleMouseDown,
        onBlur: handleBlur,
        onFocus
      }, SelectDisplayProps, {
        ownerState,
        className: clsx(SelectDisplayProps.className, classes.select, className),
        id: buttonId,
        children: isEmpty(display2) ? _span || (_span = /* @__PURE__ */ jsx("span", {
          className: "notranslate",
          children: "\u200B"
        })) : display2
      })), /* @__PURE__ */ jsx(SelectNativeInput, _extends({
        value: Array.isArray(value) ? value.join(",") : value,
        name,
        ref: inputRef,
        "aria-hidden": true,
        onChange: handleChange,
        tabIndex: -1,
        disabled,
        className: classes.nativeInput,
        autoFocus,
        ownerState
      }, other)), /* @__PURE__ */ jsx(SelectIcon, {
        as: IconComponent,
        className: classes.icon,
        ownerState
      }), /* @__PURE__ */ jsx(Menu$1, _extends({
        id: `menu-${name || ""}`,
        anchorEl: displayNode,
        open,
        onClose: handleClose,
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "center"
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "center"
        }
      }, MenuProps, {
        MenuListProps: _extends({
          "aria-labelledby": labelId,
          role: "listbox",
          disableListWrap: true
        }, MenuProps.MenuListProps),
        PaperProps: _extends({}, MenuProps.PaperProps, {
          style: _extends({
            minWidth: menuMinWidth
          }, MenuProps.PaperProps != null ? MenuProps.PaperProps.style : null)
        }),
        children: items
      }))]
    });
  });
  const SelectInput$1 = SelectInput;
  var _StyledInput, _StyledFilledInput;
  const _excluded$2 = ["autoWidth", "children", "classes", "className", "defaultOpen", "displayEmpty", "IconComponent", "id", "input", "inputProps", "label", "labelId", "MenuProps", "multiple", "native", "onClose", "onOpen", "open", "renderValue", "SelectDisplayProps", "variant"];
  const useUtilityClasses$1 = (ownerState) => {
    const {
      classes
    } = ownerState;
    return classes;
  };
  const styledRootConfig = {
    name: "MuiSelect",
    overridesResolver: (props, styles2) => styles2.root,
    shouldForwardProp: (prop) => rootShouldForwardProp(prop) && prop !== "variant",
    slot: "Root"
  };
  const StyledInput = styled$1(Input$1, styledRootConfig)("");
  const StyledOutlinedInput = styled$1(OutlinedInput$1, styledRootConfig)("");
  const StyledFilledInput = styled$1(FilledInput$1, styledRootConfig)("");
  const Select = /* @__PURE__ */ react.exports.forwardRef(function Select2(inProps, ref) {
    const props = useThemeProps({
      name: "MuiSelect",
      props: inProps
    });
    const {
      autoWidth = false,
      children,
      classes: classesProp = {},
      className,
      defaultOpen = false,
      displayEmpty = false,
      IconComponent = ArrowDropDownIcon,
      id: id2,
      input,
      inputProps,
      label,
      labelId,
      MenuProps,
      multiple = false,
      native = false,
      onClose,
      onOpen,
      open,
      renderValue,
      SelectDisplayProps,
      variant: variantProp = "outlined"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$2);
    const inputComponent = native ? NativeSelectInput$1 : SelectInput$1;
    const muiFormControl = useFormControl();
    const fcs = formControlState({
      props,
      muiFormControl,
      states: ["variant"]
    });
    const variant = fcs.variant || variantProp;
    const InputComponent = input || {
      standard: _StyledInput || (_StyledInput = /* @__PURE__ */ jsx(StyledInput, {})),
      outlined: /* @__PURE__ */ jsx(StyledOutlinedInput, {
        label
      }),
      filled: _StyledFilledInput || (_StyledFilledInput = /* @__PURE__ */ jsx(StyledFilledInput, {}))
    }[variant];
    const ownerState = _extends({}, props, {
      variant,
      classes: classesProp
    });
    const classes = useUtilityClasses$1(ownerState);
    const inputComponentRef = useForkRef(ref, InputComponent.ref);
    return /* @__PURE__ */ jsx(react.exports.Fragment, {
      children: /* @__PURE__ */ react.exports.cloneElement(InputComponent, _extends({
        inputComponent,
        inputProps: _extends({
          children,
          IconComponent,
          variant,
          type: void 0,
          multiple
        }, native ? {
          id: id2
        } : {
          autoWidth,
          defaultOpen,
          displayEmpty,
          labelId,
          MenuProps,
          onClose,
          onOpen,
          open,
          renderValue,
          SelectDisplayProps: _extends({
            id: id2
          }, SelectDisplayProps)
        }, inputProps, {
          classes: inputProps ? deepmerge(classes, inputProps.classes) : classes
        }, input ? input.props.inputProps : {})
      }, multiple && native && variant === "outlined" ? {
        notched: true
      } : {}, {
        ref: inputComponentRef,
        className: clsx(InputComponent.props.className, className)
      }, !input && {
        variant
      }, other))
    });
  });
  Select.muiName = "Select";
  const Select$1 = Select;
  const _excluded$1 = ["component", "direction", "spacing", "divider", "children"];
  function joinChildren(children, separator) {
    const childrenArray = react.exports.Children.toArray(children).filter(Boolean);
    return childrenArray.reduce((output, child, index) => {
      output.push(child);
      if (index < childrenArray.length - 1) {
        output.push(/* @__PURE__ */ react.exports.cloneElement(separator, {
          key: `separator-${index}`
        }));
      }
      return output;
    }, []);
  }
  const getSideFromDirection = (direction) => {
    return {
      row: "Left",
      "row-reverse": "Right",
      column: "Top",
      "column-reverse": "Bottom"
    }[direction];
  };
  const style = ({
    ownerState,
    theme
  }) => {
    let styles2 = _extends({
      display: "flex",
      flexDirection: "column"
    }, handleBreakpoints({
      theme
    }, resolveBreakpointValues({
      values: ownerState.direction,
      breakpoints: theme.breakpoints.values
    }), (propValue) => ({
      flexDirection: propValue
    })));
    if (ownerState.spacing) {
      const transformer = createUnarySpacing(theme);
      const base = Object.keys(theme.breakpoints.values).reduce((acc, breakpoint) => {
        if (typeof ownerState.spacing === "object" && ownerState.spacing[breakpoint] != null || typeof ownerState.direction === "object" && ownerState.direction[breakpoint] != null) {
          acc[breakpoint] = true;
        }
        return acc;
      }, {});
      const directionValues = resolveBreakpointValues({
        values: ownerState.direction,
        base
      });
      const spacingValues = resolveBreakpointValues({
        values: ownerState.spacing,
        base
      });
      if (typeof directionValues === "object") {
        Object.keys(directionValues).forEach((breakpoint, index, breakpoints) => {
          const directionValue = directionValues[breakpoint];
          if (!directionValue) {
            const previousDirectionValue = index > 0 ? directionValues[breakpoints[index - 1]] : "column";
            directionValues[breakpoint] = previousDirectionValue;
          }
        });
      }
      const styleFromPropValue = (propValue, breakpoint) => {
        return {
          "& > :not(style) + :not(style)": {
            margin: 0,
            [`margin${getSideFromDirection(breakpoint ? directionValues[breakpoint] : ownerState.direction)}`]: getValue(transformer, propValue)
          }
        };
      };
      styles2 = deepmerge(styles2, handleBreakpoints({
        theme
      }, spacingValues, styleFromPropValue));
    }
    styles2 = mergeBreakpointsInOrder(theme.breakpoints, styles2);
    return styles2;
  };
  const StackRoot = styled$1("div", {
    name: "MuiStack",
    slot: "Root",
    overridesResolver: (props, styles2) => {
      return [styles2.root];
    }
  })(style);
  const Stack = /* @__PURE__ */ react.exports.forwardRef(function Stack2(inProps, ref) {
    const themeProps = useThemeProps({
      props: inProps,
      name: "MuiStack"
    });
    const props = extendSxProp(themeProps);
    const {
      component = "div",
      direction = "column",
      spacing: spacing2 = 0,
      divider,
      children
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded$1);
    const ownerState = {
      direction,
      spacing: spacing2
    };
    return /* @__PURE__ */ jsx(StackRoot, _extends({
      as: component,
      ownerState,
      ref
    }, other, {
      children: divider ? joinChildren(children, divider) : children
    }));
  });
  const Stack$1 = Stack;
  function getTextFieldUtilityClass(slot) {
    return generateUtilityClass("MuiTextField", slot);
  }
  generateUtilityClasses("MuiTextField", ["root"]);
  const _excluded = ["autoComplete", "autoFocus", "children", "className", "color", "defaultValue", "disabled", "error", "FormHelperTextProps", "fullWidth", "helperText", "id", "InputLabelProps", "inputProps", "InputProps", "inputRef", "label", "maxRows", "minRows", "multiline", "name", "onBlur", "onChange", "onFocus", "placeholder", "required", "rows", "select", "SelectProps", "type", "value", "variant"];
  const variantComponent = {
    standard: Input$1,
    filled: FilledInput$1,
    outlined: OutlinedInput$1
  };
  const useUtilityClasses = (ownerState) => {
    const {
      classes
    } = ownerState;
    const slots = {
      root: ["root"]
    };
    return composeClasses(slots, getTextFieldUtilityClass, classes);
  };
  const TextFieldRoot = styled$1(FormControl$1, {
    name: "MuiTextField",
    slot: "Root",
    overridesResolver: (props, styles2) => styles2.root
  })({});
  const TextField = /* @__PURE__ */ react.exports.forwardRef(function TextField2(inProps, ref) {
    const props = useThemeProps({
      props: inProps,
      name: "MuiTextField"
    });
    const {
      autoComplete,
      autoFocus = false,
      children,
      className,
      color: color2 = "primary",
      defaultValue,
      disabled = false,
      error = false,
      FormHelperTextProps,
      fullWidth = false,
      helperText,
      id: idOverride,
      InputLabelProps,
      inputProps,
      InputProps,
      inputRef,
      label,
      maxRows,
      minRows,
      multiline = false,
      name,
      onBlur,
      onChange,
      onFocus,
      placeholder,
      required = false,
      rows,
      select = false,
      SelectProps,
      type,
      value,
      variant = "outlined"
    } = props, other = _objectWithoutPropertiesLoose(props, _excluded);
    const ownerState = _extends({}, props, {
      autoFocus,
      color: color2,
      disabled,
      error,
      fullWidth,
      multiline,
      required,
      select,
      variant
    });
    const classes = useUtilityClasses(ownerState);
    const InputMore = {};
    if (variant === "outlined") {
      if (InputLabelProps && typeof InputLabelProps.shrink !== "undefined") {
        InputMore.notched = InputLabelProps.shrink;
      }
      InputMore.label = label;
    }
    if (select) {
      if (!SelectProps || !SelectProps.native) {
        InputMore.id = void 0;
      }
      InputMore["aria-describedby"] = void 0;
    }
    const id2 = useId(idOverride);
    const helperTextId = helperText && id2 ? `${id2}-helper-text` : void 0;
    const inputLabelId = label && id2 ? `${id2}-label` : void 0;
    const InputComponent = variantComponent[variant];
    const InputElement = /* @__PURE__ */ jsx(InputComponent, _extends({
      "aria-describedby": helperTextId,
      autoComplete,
      autoFocus,
      defaultValue,
      fullWidth,
      multiline,
      name,
      rows,
      maxRows,
      minRows,
      type,
      value,
      id: id2,
      inputRef,
      onBlur,
      onChange,
      onFocus,
      placeholder,
      inputProps
    }, InputMore, InputProps));
    return /* @__PURE__ */ jsxs(TextFieldRoot, _extends({
      className: clsx(classes.root, className),
      disabled,
      error,
      fullWidth,
      ref,
      required,
      color: color2,
      variant,
      ownerState
    }, other, {
      children: [label != null && label !== "" && /* @__PURE__ */ jsx(InputLabel$1, _extends({
        htmlFor: id2,
        id: inputLabelId
      }, InputLabelProps, {
        children: label
      })), select ? /* @__PURE__ */ jsx(Select$1, _extends({
        "aria-describedby": helperTextId,
        id: id2,
        labelId: inputLabelId,
        value,
        input: InputElement
      }, SelectProps, {
        children
      })) : InputElement, helperText && /* @__PURE__ */ jsx(FormHelperText$1, _extends({
        id: helperTextId
      }, FormHelperTextProps, {
        children: helperText
      }))]
    }));
  });
  const TextField$1 = TextField;
  const GlobalStyle = () => {
    return /* @__PURE__ */ jsx(GlobalStyles, {
      styles: {
        ".au-hidden": {
          display: "none !important"
        },
        ".timeline___timeline--timeline_unreadJumpButtonWrap": {
          zIndex: 101
        }
      }
    });
  };
  const SLCT = {
    SUPPORT: "#launcher",
    MEMBER_SEARCHED_ELE_1: 'div > script[src="https://tag.web.onesdata.com/od.js"]',
    MEMBER_SEARCHED_ELE_2: 'div > script[src="https://b90.yahoo.co.jp/conv.js"]',
    MEMBER_SEARCHED_ELE_3: 'div > script[src="https://s.yimg.jp/images/listing/tool/cv/ytag.js"]'
  };
  class UIs {
  }
  __publicField(UIs, "create", (tag) => {
    return new UIBuilder(tag);
  });
  __publicField(UIs, "find", (key) => {
    return document.querySelector(SLCT[key]);
  });
  __publicField(UIs, "finds", (key) => {
    return document.querySelectorAll(SLCT[key]);
  });
  __publicField(UIs, "class", (ele, mode, ...cls) => {
    const list = ele.classList;
    for (const c2 of cls.map((cc2) => CLS[cc2])) {
      mode === "+" ? list.add(c2) : list.remove(c2);
    }
    return ele;
  });
  class UIBuilder {
    constructor(tag) {
      __publicField(this, "e");
      __publicField(this, "skip");
      __publicField(this, "if", (test) => {
        this.skip = typeof test === "boolean" ? !test : !test();
        return this;
      });
      __publicField(this, "fi", () => {
        this.skip = false;
        return this;
      });
      __publicField(this, "classes", (...classes) => {
        if (this.skip)
          return this;
        this.e.classList.add(...classes);
        return this;
      });
      __publicField(this, "appendTo", (parent) => {
        if (this.skip)
          return this;
        parent.append(this.e);
        return this;
      });
      __publicField(this, "done", () => {
        return this.e;
      });
      this.e = document.createElement(tag);
      this.skip = false;
    }
  }
  const Footer = react.exports.memo(({
    children
  }) => {
    return /* @__PURE__ */ jsx(_Box_, {
      children: /* @__PURE__ */ jsx(_Stack_, {
        direction: "row",
        justifyContent: "flex-end",
        spacing: "5px",
        children
      })
    });
  });
  Footer.displayName = "Footer";
  const _Box_ = newStyled(Box$1)({
    position: "fixed",
    bottom: 0,
    height: "30px",
    paddingTop: "3px",
    paddingBottom: "3px",
    width: "100%",
    backgroundColor: "#FFF",
    borderTop: "1px solid #E9EAEA",
    zIndex: "100"
  });
  const _Stack_ = newStyled(Stack$1)({
    height: "100%",
    paddingRight: "10px"
  });
  const FooterButton = react.exports.memo(({
    text,
    icon,
    ...others
  }) => /* @__PURE__ */ jsx(Button$1, {
    variant: "outlined",
    startIcon: icon,
    ...others,
    disableFocusRipple: true,
    children: text
  }));
  FooterButton.displayName = "FooterButton";
  const IntInput = react.exports.memo(({
    value,
    onChange,
    ...props
  }) => {
    const handler = react.exports.useCallback((e2) => {
      if (!onChange)
        return;
      const v2 = e2.target.value;
      if (!v2) {
        onChange(void 0);
      } else {
        const n2 = parseInt(v2);
        if (!Number.isNaN(n2))
          onChange(n2);
      }
    }, [onChange]);
    return /* @__PURE__ */ jsx(TextField$1, {
      value: value === void 0 ? "" : value,
      onChange: handler,
      type: "number",
      ...props
    });
  });
  IntInput.displayName = "IntInput";
  const MemberSearch = react.exports.memo(({
    value,
    onChange,
    label,
    ...props
  }) => {
    const [options, setOptions] = react.exports.useState([]);
    const [input, setInput] = react.exports.useState("");
    const [timer, setTimer] = react.exports.useState();
    const handleInputChange = react.exports.useCallback((_2, value2) => {
      setInput(value2);
      if (timer)
        clearTimeout(timer);
      if (value2.length === 0) {
        setOptions([]);
        setTimer(void 0);
        return;
      }
      setTimer(setTimeout(() => {
        UniposAPI.getMembersByNameWithFuzzySearch(value2).then((res) => setOptions(res.result)).then(() => setTimer(void 0));
      }, 1e3));
    }, [timer]);
    const handleValueChange = react.exports.useCallback((_2, value2) => {
      if (onChange)
        onChange(value2 || void 0);
    }, [onChange]);
    const handleOpen = react.exports.useCallback(() => {
      if (value) {
        setInput(value.display_name);
        handleInputChange(null, value.display_name);
      }
    }, [handleInputChange, value]);
    const handleBlur = react.exports.useCallback(() => {
      var _a, _b, _c;
      for (const e2 of UIs.finds("MEMBER_SEARCHED_ELE_1"))
        (_a = e2.parentElement) == null ? void 0 : _a.remove();
      for (const e2 of UIs.finds("MEMBER_SEARCHED_ELE_2"))
        (_b = e2.parentElement) == null ? void 0 : _b.remove();
      for (const e2 of UIs.finds("MEMBER_SEARCHED_ELE_3"))
        (_c = e2.parentElement) == null ? void 0 : _c.remove();
    }, []);
    const filterOptions = react.exports.useCallback((opt) => opt, []);
    const isOptionEqualToValue = react.exports.useCallback((a, b2) => a.id === b2.id, []);
    const getOptionLabel = react.exports.useCallback((opt) => `${opt.display_name} (${opt.uname})`, []);
    return /* @__PURE__ */ jsx(Autocomplete$1, {
      fullWidth: true,
      blurOnSelect: true,
      size: "small",
      options,
      renderInput: ({
        InputLabelProps,
        ...params
      }) => /* @__PURE__ */ jsx(TextField$1, {
        ...params,
        label,
        InputLabelProps: {
          ...InputLabelProps,
          shrink: true
        }
      }),
      loading: !!timer,
      value: value || null,
      inputValue: input,
      onInputChange: handleInputChange,
      onChange: handleValueChange,
      onFocus: handleOpen,
      onBlur: handleBlur,
      filterOptions,
      isOptionEqualToValue,
      getOptionLabel,
      ...props
    });
  });
  MemberSearch.displayName = "MemberSearch";
  const MemoizedInput = react.exports.memo(({
    onChange,
    ...props
  }) => {
    const handler = react.exports.useCallback((e2) => {
      if (onChange)
        onChange(e2.target.value);
    }, [onChange]);
    return /* @__PURE__ */ jsx(TextField$1, {
      onChange: handler,
      ...props
    });
  });
  MemoizedInput.displayName = "MemoizedInput";
  var SyncAlt = {};
  var interopRequireDefault = { exports: {} };
  (function(module) {
    function _interopRequireDefault2(obj) {
      return obj && obj.__esModule ? obj : {
        "default": obj
      };
    }
    module.exports = _interopRequireDefault2, module.exports.__esModule = true, module.exports["default"] = module.exports;
  })(interopRequireDefault);
  var createSvgIcon = {};
  const require$$0 = /* @__PURE__ */ getAugmentedNamespace(utils);
  var hasRequiredCreateSvgIcon;
  function requireCreateSvgIcon() {
    if (hasRequiredCreateSvgIcon)
      return createSvgIcon;
    hasRequiredCreateSvgIcon = 1;
    (function(exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      Object.defineProperty(exports, "default", {
        enumerable: true,
        get: function() {
          return _utils.createSvgIcon;
        }
      });
      var _utils = require$$0;
    })(createSvgIcon);
    return createSvgIcon;
  }
  const require$$2 = /* @__PURE__ */ getAugmentedNamespace(jsxRuntime);
  var _interopRequireDefault$9 = interopRequireDefault.exports;
  Object.defineProperty(SyncAlt, "__esModule", {
    value: true
  });
  var default_1$8 = SyncAlt.default = void 0;
  var _createSvgIcon$8 = _interopRequireDefault$9(requireCreateSvgIcon());
  var _jsxRuntime$8 = require$$2;
  var _default$9 = (0, _createSvgIcon$8.default)(/* @__PURE__ */ (0, _jsxRuntime$8.jsx)("path", {
    d: "m18 12 4-4-4-4v3H3v2h15zM6 12l-4 4 4 4v-3h15v-2H6z"
  }), "SyncAlt");
  default_1$8 = SyncAlt.default = _default$9;
  const SyncIntInput = react.exports.memo(({
    ...props
  }) => {
    const commons = react.exports.useMemo(() => {
      return {
        fullWidth: true,
        required: true,
        size: "small",
        InputLabelProps: {
          shrink: true
        }
      };
    }, []);
    return /* @__PURE__ */ jsxs(Stack$1, {
      spacing: "3px",
      direction: "row",
      alignItems: "center",
      children: [/* @__PURE__ */ jsx(IntInput, {
        value: props.v1,
        onChange: props.onChangeV1,
        onBlur: props.onBlurV1,
        label: props.labelV1,
        title: props.titleV1,
        inputProps: props.inputPropsV1,
        InputProps: props.InputPropsV1,
        ...commons
      }), /* @__PURE__ */ jsx(default_1$8, {}), /* @__PURE__ */ jsx(IntInput, {
        value: props.v2,
        onChange: props.onChangeV2,
        onBlur: props.onBlurV2,
        label: props.labelV2,
        title: props.titleV2,
        inputProps: props.inputPropsV2,
        InputProps: props.InputPropsV2,
        ...commons
      })]
    });
  });
  SyncIntInput.displayName = "SyncIntInput";
  var SignLanguage = {};
  var _interopRequireDefault$8 = interopRequireDefault.exports;
  Object.defineProperty(SignLanguage, "__esModule", {
    value: true
  });
  var default_1$7 = SignLanguage.default = void 0;
  var _createSvgIcon$7 = _interopRequireDefault$8(requireCreateSvgIcon());
  var _jsxRuntime$7 = require$$2;
  var _default$8 = (0, _createSvgIcon$7.default)(/* @__PURE__ */ (0, _jsxRuntime$7.jsx)("path", {
    d: "m12.49 13-.93-1.86c-.37-.74-.07-1.64.67-2.01l.26-.13 5.73 5.46c.5.47.78 1.13.78 1.81v5.23c0 1.38-1.12 2.5-2.5 2.5h-11c-.55 0-1-.45-1-1s.45-1 1-1H10v-1H4c-.55 0-1-.45-1-1s.45-1 1-1h6v-1H3c-.55 0-1-.45-1-1s.45-1 1-1h7v-1H4.5c-.55 0-1-.45-1-1s.45-1 1-1h7.99zm-.71-5.88c-.84.4-1.17.62-1.63 1.19l-2.7-2.85c-.38-.4-.36-1.03.04-1.41.4-.38 1.03-.36 1.41.04l2.88 3.03zM9.64 9.21c-.23.55-.29 1.24-.2 1.79h-.86L6.31 8.61c-.38-.4-.37-1.03.04-1.41.4-.38 1.03-.36 1.41.04l1.88 1.97zm10.69 4.7.88-.83c.5-.47.79-1.13.79-1.82V3.35l-.27-.1c-.78-.28-1.64.12-1.92.9l-.71 1.96-5.5-5.8c-.38-.4-1.01-.42-1.41-.04-.4.38-.42 1.01-.04 1.41l3.79 3.99-.73.69-4.82-5.08c-.38-.4-1.01-.42-1.41-.04-.4.38-.42 1.01-.04 1.41l3.78 3.98L15.38 9l3.61 3.43.61.58c.29.27.53.57.73.9z"
  }), "SignLanguage");
  default_1$7 = SignLanguage.default = _default$8;
  const ConsumerContext = react.exports.createContext(void 0);
  const init = () => ({
    me: void 0,
    t_point: 0,
    t_clap: 0,
    e_point: 0,
    e_clap: 0,
    offset: "",
    breaks: "",
    already: UniposAPI.MAX_PRAISE_COUNT - 1,
    from: void 0,
    to: void 0,
    open: false,
    mode: "window",
    pos: void 0,
    size: {
      width: 500,
      height: "auto"
    }
  });
  const ConsumerDispatchContext = react.exports.createContext(void 0);
  const consumerReducer = (state, action) => {
    switch (action.type) {
      case "RESET": {
        const {
          open,
          mode,
          pos,
          size
        } = state;
        return {
          ...init(),
          open,
          mode,
          pos,
          size
        };
      }
      case "SET_ME": {
        return {
          ...state,
          me: action.me
        };
      }
      case "SET_TOTAL_POINT": {
        const t_point = action.point;
        const next2 = {
          ...state,
          t_point
        };
        if (t_point !== void 0 && t_point >= 0) {
          next2.t_clap = Math.floor(t_point / 2);
        }
        return next2;
      }
      case "SET_TOTAL_CLAP": {
        const t_clap = action.clap;
        const next2 = {
          ...state,
          t_clap
        };
        if (t_clap !== void 0 && t_clap >= 0) {
          next2.t_point = t_clap * 2;
        }
        return next2;
      }
      case "ADJUST_TOTALS": {
        const next2 = {
          ...state
        };
        if ((next2.t_point === void 0 || next2.t_point < 0) && next2.t_clap !== void 0) {
          next2.t_point = next2.t_clap * 2;
        }
        if ((next2.t_clap === void 0 || next2.t_clap < 0) && next2.t_point !== void 0) {
          next2.t_clap = Math.floor(next2.t_point / 2);
        }
        return next2;
      }
      case "SET_EACH_POINT": {
        const e_point = action.point;
        const next2 = {
          ...state,
          e_point
        };
        if (e_point !== void 0 && e_point >= 0) {
          next2.e_clap = Math.floor(e_point / 2);
        }
        return next2;
      }
      case "SET_EACH_CLAP": {
        const e_clap = action.clap;
        const next2 = {
          ...state,
          e_clap
        };
        if (e_clap !== void 0 && e_clap >= 0) {
          next2.e_point = e_clap * 2;
        }
        return next2;
      }
      case "ADJUST_EACHS": {
        const next2 = {
          ...state
        };
        if ((next2.e_point === void 0 || next2.e_point < 0) && next2.e_clap !== void 0) {
          next2.e_point = next2.e_clap * 2;
        }
        if ((next2.e_clap === void 0 || next2.e_clap < 0) && next2.e_point !== void 0) {
          next2.e_clap = Math.floor(next2.e_point / 2);
        }
        return next2;
      }
      case "SET_OFFSET": {
        return {
          ...state,
          offset: action.offset
        };
      }
      case "SET_BREAKS": {
        return {
          ...state,
          breaks: action.breaks
        };
      }
      case "SET_ALREADY": {
        return {
          ...state,
          already: action.already
        };
      }
      case "ADJUST_ALREADY": {
        const MAX = UniposAPI.MAX_PRAISE_COUNT - 1;
        if (state.already === void 0 || state.already < 0) {
          return {
            ...state,
            already: 0
          };
        } else if (state.already > MAX) {
          return {
            ...state,
            already: MAX
          };
        } else {
          return state;
        }
      }
      case "SET_FROM": {
        return {
          ...state,
          from: action.from
        };
      }
      case "SET_TO": {
        return {
          ...state,
          to: action.to
        };
      }
      case "CHANGE_OPEN": {
        const open = action.force || !state.open;
        return {
          ...state,
          open
        };
      }
      case "CHANGE_MODE": {
        const mode = action.force || (state.mode === "dialog" ? "window" : "dialog");
        return {
          ...state,
          mode
        };
      }
      case "SET_POS": {
        return {
          ...state,
          pos: action.pos
        };
      }
      case "SET_SIZE": {
        return {
          ...state,
          size: action.size
        };
      }
    }
  };
  const ConsumerContextProvider = ({
    children
  }) => {
    const [state, dispatch] = react.exports.useReducer(consumerReducer, init());
    return /* @__PURE__ */ jsx(ConsumerDispatchContext.Provider, {
      value: dispatch,
      children: /* @__PURE__ */ jsx(ConsumerContext.Provider, {
        value: state,
        children
      })
    });
  };
  const useConsumerState = () => {
    const state = react.exports.useContext(ConsumerContext);
    if (!state)
      throw new Error("ConsumerContext not found");
    return state;
  };
  const useConsumerDispatch = () => {
    const dispatch = react.exports.useContext(ConsumerDispatchContext);
    if (!dispatch)
      throw new Error("ConsumerDispatchContext not found");
    return dispatch;
  };
  var Paid = {};
  var _interopRequireDefault$7 = interopRequireDefault.exports;
  Object.defineProperty(Paid, "__esModule", {
    value: true
  });
  var default_1$6 = Paid.default = void 0;
  var _createSvgIcon$6 = _interopRequireDefault$7(requireCreateSvgIcon());
  var _jsxRuntime$6 = require$$2;
  var _default$7 = (0, _createSvgIcon$6.default)(/* @__PURE__ */ (0, _jsxRuntime$6.jsx)("path", {
    d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm.88 15.76V19h-1.75v-1.29c-.74-.18-2.39-.77-3.02-2.96l1.65-.67c.06.22.58 2.09 2.4 2.09.93 0 1.98-.48 1.98-1.61 0-.96-.7-1.46-2.28-2.03-1.1-.39-3.35-1.03-3.35-3.31 0-.1.01-2.4 2.62-2.96V5h1.75v1.24c1.84.32 2.51 1.79 2.66 2.23l-1.58.67c-.11-.35-.59-1.34-1.9-1.34-.7 0-1.81.37-1.81 1.39 0 .95.86 1.31 2.64 1.9 2.4.83 3.01 2.05 3.01 3.45 0 2.63-2.5 3.13-3.02 3.22z"
  }), "Paid");
  default_1$6 = Paid.default = _default$7;
  var Savings = {};
  var _interopRequireDefault$6 = interopRequireDefault.exports;
  Object.defineProperty(Savings, "__esModule", {
    value: true
  });
  var default_1$5 = Savings.default = void 0;
  var _createSvgIcon$5 = _interopRequireDefault$6(requireCreateSvgIcon());
  var _jsxRuntime$5 = require$$2;
  var _default$6 = (0, _createSvgIcon$5.default)(/* @__PURE__ */ (0, _jsxRuntime$5.jsx)("path", {
    d: "m19.83 7.5-2.27-2.27c.07-.42.18-.81.32-1.15.08-.18.12-.37.12-.58 0-.83-.67-1.5-1.5-1.5-1.64 0-3.09.79-4 2h-5C4.46 4 2 6.46 2 9.5S4.5 21 4.5 21H10v-2h2v2h5.5l1.68-5.59 2.82-.94V7.5h-2.17zM13 9H8V7h5v2zm3 2c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"
  }), "Savings");
  default_1$5 = Savings.default = _default$6;
  const MAX_PRAISE_COUNT = UniposAPI.MAX_PRAISE_COUNT;
  const MAX_ALREADY_COUNT = MAX_PRAISE_COUNT - 1;
  const ConsumerContent = react.exports.memo(({
    close
  }) => {
    const {
      me: me2,
      t_point,
      t_clap,
      e_point,
      e_clap,
      offset: offset2,
      breaks,
      already,
      from: from2,
      to
    } = useConsumerState();
    const dispatch = useConsumerDispatch();
    const handleTPointChange = react.exports.useCallback((point) => dispatch({
      type: "SET_TOTAL_POINT",
      point
    }), [dispatch]);
    const handleTClapChange = react.exports.useCallback((clap) => dispatch({
      type: "SET_TOTAL_CLAP",
      clap
    }), [dispatch]);
    const handleTotalsBlur = react.exports.useCallback(() => dispatch({
      type: "ADJUST_TOTALS"
    }), [dispatch]);
    const allIn = react.exports.useCallback(() => dispatch({
      type: "SET_TOTAL_POINT",
      point: me2 == null ? void 0 : me2.pocket.available_point
    }), [dispatch, me2]);
    const handleEPointChange = react.exports.useCallback((point) => dispatch({
      type: "SET_EACH_POINT",
      point
    }), [dispatch]);
    const handleEClapChange = react.exports.useCallback((clap) => dispatch({
      type: "SET_EACH_CLAP",
      clap
    }), [dispatch]);
    const handleEachsBlur = react.exports.useCallback(() => dispatch({
      type: "ADJUST_EACHS"
    }), [dispatch]);
    const lastOffsetPasted = react.exports.useRef("");
    const lastOffsetPastedTime = react.exports.useRef(0);
    const handleOffsetChange = react.exports.useCallback((offset22) => {
      if (Date.now() - lastOffsetPastedTime.current < 500 && offset22 === lastOffsetPasted.current) {
        offset22 = UniposAPI.extractCardIdFromCardLink(offset22) || offset22;
      }
      dispatch({
        type: "SET_OFFSET",
        offset: offset22
      });
    }, [dispatch]);
    const handleOffsetPaste = react.exports.useCallback((e2) => {
      lastOffsetPasted.current = e2.clipboardData.getData("text");
      lastOffsetPastedTime.current = Date.now();
    }, []);
    const lastBreaksPasted = react.exports.useRef("");
    const lastBreaksPastedTime = react.exports.useRef(0);
    const handleBreaksChange = react.exports.useCallback((breaks2) => {
      if (Date.now() - lastBreaksPastedTime.current < 500 && breaks2 === lastBreaksPasted.current) {
        breaks2 = UniposAPI.extractCardIdFromCardLink(breaks2) || breaks2;
      }
      dispatch({
        type: "SET_BREAKS",
        breaks: breaks2
      });
    }, [dispatch]);
    const handleBreaksPaste = react.exports.useCallback((e2) => {
      lastBreaksPasted.current = e2.clipboardData.getData("text");
      lastBreaksPastedTime.current = Date.now();
    }, []);
    const handleAlreadyChange = react.exports.useCallback((already2) => dispatch({
      type: "SET_ALREADY",
      already: already2
    }), [dispatch]);
    const handleAlreadyBlur = react.exports.useCallback(() => dispatch({
      type: "ADJUST_ALREADY"
    }), [dispatch]);
    const handleFromChange = react.exports.useCallback((from22) => dispatch({
      type: "SET_FROM",
      from: from22
    }), [dispatch]);
    const handleToChange = react.exports.useCallback((to2) => dispatch({
      type: "SET_TO",
      to: to2
    }), [dispatch]);
    const notReadyMessage = react.exports.useMemo(() => {
      if (me2 === void 0 || t_point === void 0 || t_clap === void 0 || e_clap === void 0) {
        return "\u5FC5\u9808\u30D1\u30E9\u30E1\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3002";
      }
      if (me2.pocket.available_point < t_point) {
        return "\u300C\u7DCF\u4F7F\u7528\u30DD\u30A4\u30F3\u30C8\u6570\u300D\u304C\u6240\u6301\u30DD\u30A4\u30F3\u30C8\u6570\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002";
      }
      if (t_clap < 1) {
        return "\u300C\u7DCF\u62CD\u624B\u6570\u300D\u304C1\u672A\u6E80\u3067\u3059\u3002";
      }
      if (e_clap < 1 || MAX_PRAISE_COUNT < e_clap) {
        return `\u300C\u5404\u6295\u7A3F\u306B\u9001\u308B\u62CD\u624B\u6570\u300D\u304C 1\uFF5E${MAX_PRAISE_COUNT} \u306E\u7BC4\u56F2\u5916\u3067\u3059\u3002`;
      }
      if (t_clap < e_clap) {
        return "\u300C\u5404\u6295\u7A3F\u306B\u9001\u308B\u62CD\u624B\u6570\u300D\u304C\u300C\u7DCF\u62CD\u624B\u6570\u300D\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002";
      }
      return;
    }, [e_clap, me2, t_clap, t_point]);
    const run = react.exports.useCallback(async () => {
      if (me2 === void 0 || t_point === void 0 || t_clap === void 0 || e_clap === void 0)
        return;
      close();
      const id2 = Date.now();
      Logger.info(`Start of praise: id="${id2}"`);
      const possible = (card) => {
        if (card.from_member.id === me2.id)
          return false;
        for (const to_member of card.to_members) {
          if (to_member.id === me2.id)
            return false;
        }
        if ((already !== void 0 ? already : MAX_ALREADY_COUNT) < card.self_praise_count)
          return false;
        return true;
      };
      let remain = t_clap;
      let _offset = offset2;
      loop:
        for (; ; ) {
          const options = {
            from_member_id: from2 == null ? void 0 : from2.id,
            to_member_id: to == null ? void 0 : to.id
          };
          const cards = (await UniposAPI.getCards(20, _offset, options)).result;
          for (const card of cards) {
            _offset = card.id;
            if (!possible(card))
              continue;
            await new Promise((ok2) => setTimeout(ok2, 500));
            const max2 = MAX_PRAISE_COUNT - card.self_praise_count;
            const pay = Math.min(e_clap, max2);
            UniposAPI.praise(card.id, pay);
            Logger.info(`https://unipos.me/cards/${card.id} : ${pay}`);
            remain -= pay;
            if (remain < e_clap || card.id == breaks)
              break loop;
          }
        }
    }, [already, breaks, close, e_clap, from2, me2, offset2, t_clap, t_point, to]);
    return !me2 ? /* @__PURE__ */ jsx(Stack$1, {
      justifyContent: "center",
      alignItems: "center",
      children: /* @__PURE__ */ jsx(CircularProgress$1, {})
    }) : /* @__PURE__ */ jsxs(Stack$1, {
      spacing: "12px",
      children: [/* @__PURE__ */ jsx(SyncIntInput, {
        v1: t_point,
        onChangeV1: handleTPointChange,
        onBlurV1: handleTotalsBlur,
        labelV1: "\u7DCF\u4F7F\u7528\u30DD\u30A4\u30F3\u30C8\u6570",
        titleV1: "\u4ECA\u56DE\u4F7F\u7528\u3059\u308B\u7DCF\u30DD\u30A4\u30F3\u30C8\u6570\u3067\u3059\u3002[\u5165\u529B\u5024]\xF72\u304C\u7DCF\u62CD\u624B\u6570\u3068\u306A\u308A\u307E\u3059\u3002",
        inputPropsV1: {
          min: "0",
          step: "2",
          max: `${me2.pocket.available_point}`
        },
        InputPropsV1: {
          startAdornment: /* @__PURE__ */ jsx(InputAdornment$1, {
            position: "start",
            children: /* @__PURE__ */ jsx(default_1$6, {
              fontSize: "small"
            })
          }),
          endAdornment: /* @__PURE__ */ jsx(InputAdornment$1, {
            position: "end",
            children: /* @__PURE__ */ jsx(IconButton$1, {
              title: "\u6240\u6301\u30DD\u30A4\u30F3\u30C8\u3092\u5168\u3066\u4F7F\u7528\u3059\u308B",
              disabled: me2.pocket.available_point === t_point,
              onClick: allIn,
              size: "small",
              edge: "end",
              children: /* @__PURE__ */ jsx(default_1$5, {})
            })
          })
        },
        v2: t_clap,
        onChangeV2: handleTClapChange,
        onBlurV2: handleTotalsBlur,
        labelV2: "\u7DCF\u62CD\u624B\u6570",
        titleV2: "\u4ECA\u56DE\u9001\u308B\u7DCF\u62CD\u624B\u6570\u3067\u3059\u3002[\u5165\u529B\u5024]x2\u304C\u7DCF\u4F7F\u7528\u30DD\u30A4\u30F3\u30C8\u6570\u3068\u306A\u308A\u307E\u3059\u3002",
        inputPropsV2: {
          min: "0",
          step: "1",
          max: `${Math.floor(me2.pocket.available_point / 2)}`
        },
        InputPropsV2: {
          startAdornment: /* @__PURE__ */ jsx(InputAdornment$1, {
            position: "start",
            children: /* @__PURE__ */ jsx(default_1$7, {
              fontSize: "small"
            })
          })
        }
      }), /* @__PURE__ */ jsx(SyncIntInput, {
        v1: e_point,
        onChangeV1: handleEPointChange,
        onBlurV1: handleEachsBlur,
        labelV1: "\u5404\u6295\u7A3F\u306B\u9001\u308B\u30DD\u30A4\u30F3\u30C8\u6570",
        titleV1: "\u5404\u6295\u7A3F\u306B\u9001\u308B\u30DD\u30A4\u30F3\u30C8\u6570\u3067\u3059\u3002[\u5165\u529B\u5024]\xF72\u304C\u5404\u6295\u7A3F\u306B\u9001\u308B\u62CD\u624B\u6570\u3068\u306A\u308A\u307E\u3059\u3002",
        inputPropsV1: {
          min: "0",
          step: "2",
          max: "120"
        },
        InputPropsV1: {
          startAdornment: /* @__PURE__ */ jsx(InputAdornment$1, {
            position: "start",
            children: /* @__PURE__ */ jsx(default_1$6, {
              fontSize: "small"
            })
          })
        },
        v2: e_clap,
        onChangeV2: handleEClapChange,
        onBlurV2: handleEachsBlur,
        labelV2: "\u5404\u6295\u7A3F\u306B\u9001\u308B\u62CD\u624B\u6570",
        titleV2: "\u5404\u6295\u7A3F\u306B\u9001\u308B\u62CD\u624B\u6570\u3067\u3059\u3002[\u5165\u529B\u5024]x2\u304C\u5404\u6295\u7A3F\u306B\u9001\u308B\u30DD\u30A4\u30F3\u30C8\u6570\u3068\u306A\u308A\u307E\u3059\u3002",
        inputPropsV2: {
          min: "0",
          step: "1",
          max: `${MAX_PRAISE_COUNT}`
        },
        InputPropsV2: {
          startAdornment: /* @__PURE__ */ jsx(InputAdornment$1, {
            position: "start",
            children: /* @__PURE__ */ jsx(default_1$7, {
              fontSize: "small"
            })
          })
        }
      }), /* @__PURE__ */ jsx(Divider$1, {
        textAlign: "center",
        children: /* @__PURE__ */ jsx(Chip$1, {
          label: "\u5BFE\u8C61\u3068\u3059\u308B\u6295\u7A3F\u306E\u6761\u4EF6\uFF08\u30AA\u30D7\u30B7\u30E7\u30F3\uFF09"
        })
      }), /* @__PURE__ */ jsx(MemoizedInput, {
        fullWidth: true,
        size: "small",
        value: offset2,
        onChange: handleOffsetChange,
        onPaste: handleOffsetPaste,
        label: "\u30AA\u30D5\u30BB\u30C3\u30C8(\u6295\u7A3FID)",
        title: "\u6307\u5B9A\u3057\u305F\u6295\u7A3F\u3088\u308A\u3001\u904E\u53BB\u306E\u6295\u7A3F\u306E\u307F\u3092\u5BFE\u8C61\u306B\u3057\u307E\u3059\u3002\u6307\u5B9A\u3055\u308C\u305F\u6295\u7A3F\u306F\u62CD\u624B\u306E\u5BFE\u8C61\u3068\u306A\u308A\u307E\u305B\u3093\u3002\r\n\u5404\u6295\u7A3F\u306E\u300C\u30EA\u30F3\u30AF\u3092\u30B3\u30D4\u30FC\u3059\u308B\u300D\u3067\u53D6\u5F97\u3057\u305FURL\u3092\u8CBC\u308A\u4ED8\u3051\u308B\u3068\u3001\u81EA\u52D5\u3067ID\u306B\u5909\u63DB\u3055\u308C\u307E\u3059\u3002",
        InputLabelProps: {
          shrink: true
        }
      }), /* @__PURE__ */ jsx(MemoizedInput, {
        fullWidth: true,
        size: "small",
        value: breaks,
        onChange: handleBreaksChange,
        onPaste: handleBreaksPaste,
        label: "\u62CD\u624B\u3092\u7D42\u3048\u308B\u6295\u7A3F(\u6295\u7A3FID)",
        title: "\u6307\u5B9A\u3057\u305F\u6295\u7A3F\u306B\u62CD\u624B\u3092\u3057\u3066\u3001\u4E00\u62EC\u62CD\u624B\u306E\u51E6\u7406\u3092\u7D42\u4E86\u3057\u307E\u3059\u3002\r\n\u5404\u6295\u7A3F\u306E\u300C\u30EA\u30F3\u30AF\u3092\u30B3\u30D4\u30FC\u3059\u308B\u300D\u3067\u53D6\u5F97\u3057\u305FURL\u3092\u8CBC\u308A\u4ED8\u3051\u308B\u3068\u3001\u81EA\u52D5\u3067ID\u306B\u5909\u63DB\u3055\u308C\u307E\u3059\u3002",
        InputLabelProps: {
          shrink: true
        }
      }), /* @__PURE__ */ jsx(IntInput, {
        fullWidth: true,
        size: "small",
        value: already,
        onChange: handleAlreadyChange,
        onBlur: handleAlreadyBlur,
        label: "\u81EA\u5206\u306E\u62CD\u624B\u6570\u306E\u4E0A\u9650",
        title: `\u81EA\u5206\u306E\u62CD\u624B\u6570\u304C\u5165\u529B\u5024\u4EE5\u4E0B\u306E\u6295\u7A3F\u306E\u307F\u62CD\u624B\u3092\u3057\u307E\u3059\u30020\u306A\u3089\u62CD\u624B\u3092\u3057\u305F\u3053\u3068\u304C\u306A\u3044\u6295\u7A3F\u306E\u307F\u3001${MAX_ALREADY_COUNT}\u3092\u6307\u5B9A\u3059\u308C\u3070\u5168\u3066\u306E\u6295\u7A3F\u304C\u5BFE\u8C61\u3068\u306A\u308A\u307E\u3059\u3002`,
        inputProps: {
          min: "0",
          step: "1",
          max: `${MAX_ALREADY_COUNT}`
        },
        InputLabelProps: {
          shrink: true
        }
      }), /* @__PURE__ */ jsx(MemberSearch, {
        value: from2,
        onChange: handleFromChange,
        label: "\u6295\u7A3F\u3092\u304A\u304F\u3063\u305F\u4EBA",
        title: !to ? "\u6295\u7A3F\u306E\u5DEE\u51FA\u4EBA\u3092\u6307\u5B9A\u3057\u307E\u3059\u3002" : "\u300C\u6295\u7A3F\u3092\u3082\u3089\u3063\u305F\u4EBA\u300D\u3068\u540C\u6642\u306B\u6307\u5B9A\u3059\u308B\u3053\u3068\u306F\u51FA\u6765\u307E\u305B\u3093\u3002",
        disabled: !!to
      }), /* @__PURE__ */ jsx(MemberSearch, {
        value: to,
        onChange: handleToChange,
        label: "\u6295\u7A3F\u3092\u3082\u3089\u3063\u305F\u4EBA",
        title: !from2 ? "\u6295\u7A3F\u306E\u5B9B\u5148\u3092\u6307\u5B9A\u3057\u307E\u3059\u3002" : "\u300C\u6295\u7A3F\u3092\u304A\u304F\u3063\u305F\u4EBA\u300D\u3068\u540C\u6642\u306B\u6307\u5B9A\u3059\u308B\u3053\u3068\u306F\u51FA\u6765\u307E\u305B\u3093\u3002",
        disabled: !!from2
      }), /* @__PURE__ */ jsx(Stack$1, {
        direction: "row",
        justifyContent: "center",
        children: /* @__PURE__ */ jsx(Box$1, {
          title: notReadyMessage,
          children: /* @__PURE__ */ jsx(Button$1, {
            onClick: run,
            variant: "contained",
            disabled: !!notReadyMessage,
            children: "\u9001\u308B"
          })
        })
      })]
    });
  });
  ConsumerContent.displayName = "ConsumerContent";
  var Close = {};
  var _interopRequireDefault$5 = interopRequireDefault.exports;
  Object.defineProperty(Close, "__esModule", {
    value: true
  });
  var default_1$4 = Close.default = void 0;
  var _createSvgIcon$4 = _interopRequireDefault$5(requireCreateSvgIcon());
  var _jsxRuntime$4 = require$$2;
  var _default$5 = (0, _createSvgIcon$4.default)(/* @__PURE__ */ (0, _jsxRuntime$4.jsx)("path", {
    d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
  }), "Close");
  default_1$4 = Close.default = _default$5;
  var FullscreenExit = {};
  var _interopRequireDefault$4 = interopRequireDefault.exports;
  Object.defineProperty(FullscreenExit, "__esModule", {
    value: true
  });
  var default_1$3 = FullscreenExit.default = void 0;
  var _createSvgIcon$3 = _interopRequireDefault$4(requireCreateSvgIcon());
  var _jsxRuntime$3 = require$$2;
  var _default$4 = (0, _createSvgIcon$3.default)(/* @__PURE__ */ (0, _jsxRuntime$3.jsx)("path", {
    d: "M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"
  }), "FullscreenExit");
  default_1$3 = FullscreenExit.default = _default$4;
  const ConsumerDialog = react.exports.memo(({
    open,
    onClose,
    changeMode,
    children
  }) => {
    return /* @__PURE__ */ jsxs(Dialog$1, {
      open,
      fullWidth: true,
      maxWidth: "md",
      onClose,
      children: [/* @__PURE__ */ jsxs(_Header_$1, {
        children: [/* @__PURE__ */ jsx(_IconButton_$1, {
          title: "\u30A6\u30A3\u30F3\u30C9\u30A6\u5316\u3059\u308B",
          onClick: changeMode,
          children: /* @__PURE__ */ jsx(default_1$3, {})
        }), /* @__PURE__ */ jsx(_IconButton_$1, {
          title: "\u9589\u3058\u308B",
          onClick: onClose,
          children: /* @__PURE__ */ jsx(default_1$4, {})
        })]
      }), /* @__PURE__ */ jsx(DialogContent$1, {
        children
      })]
    });
  });
  ConsumerDialog.displayName = "ConsumerDialog";
  const _Header_$1 = styled$1(Box$1)(({
    theme
  }) => ({
    display: "flex",
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "center",
    padding: "0 5px",
    backgroundColor: theme.palette.divider
  }));
  const _IconButton_$1 = styled$1(IconButton$1)({
    width: "24px",
    height: "24px"
  });
  var DragHandle = {};
  var _interopRequireDefault$3 = interopRequireDefault.exports;
  Object.defineProperty(DragHandle, "__esModule", {
    value: true
  });
  var default_1$2 = DragHandle.default = void 0;
  var _createSvgIcon$2 = _interopRequireDefault$3(requireCreateSvgIcon());
  var _jsxRuntime$2 = require$$2;
  var _default$3 = (0, _createSvgIcon$2.default)(/* @__PURE__ */ (0, _jsxRuntime$2.jsx)("path", {
    d: "M20 9H4v2h16V9zM4 15h16v-2H4v2z"
  }), "DragHandle");
  default_1$2 = DragHandle.default = _default$3;
  var Fullscreen = {};
  var _interopRequireDefault$2 = interopRequireDefault.exports;
  Object.defineProperty(Fullscreen, "__esModule", {
    value: true
  });
  var default_1$1 = Fullscreen.default = void 0;
  var _createSvgIcon$1 = _interopRequireDefault$2(requireCreateSvgIcon());
  var _jsxRuntime$1 = require$$2;
  var _default$2 = (0, _createSvgIcon$1.default)(/* @__PURE__ */ (0, _jsxRuntime$1.jsx)("path", {
    d: "M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"
  }), "Fullscreen");
  default_1$1 = Fullscreen.default = _default$2;
  var cjs = { exports: {} };
  var Draggable$2 = {};
  const require$$3 = /* @__PURE__ */ getAugmentedNamespace(clsx_m);
  var domFns = {};
  var shims = {};
  Object.defineProperty(shims, "__esModule", {
    value: true
  });
  shims.findInArray = findInArray;
  shims.isFunction = isFunction;
  shims.isNum = isNum;
  shims.int = int;
  shims.dontSetMe = dontSetMe;
  function findInArray(array, callback) {
    for (var i = 0, length2 = array.length; i < length2; i++) {
      if (callback.apply(callback, [array[i], i, array]))
        return array[i];
    }
  }
  function isFunction(func) {
    return typeof func === "function" || Object.prototype.toString.call(func) === "[object Function]";
  }
  function isNum(num) {
    return typeof num === "number" && !isNaN(num);
  }
  function int(a) {
    return parseInt(a, 10);
  }
  function dontSetMe(props, propName, componentName) {
    if (props[propName]) {
      return new Error("Invalid prop ".concat(propName, " passed to ").concat(componentName, " - do not set this, set it on the child."));
    }
  }
  var getPrefix$1 = {};
  Object.defineProperty(getPrefix$1, "__esModule", {
    value: true
  });
  getPrefix$1.getPrefix = getPrefix;
  getPrefix$1.browserPrefixToKey = browserPrefixToKey;
  getPrefix$1.browserPrefixToStyle = browserPrefixToStyle;
  getPrefix$1.default = void 0;
  var prefixes = ["Moz", "Webkit", "O", "ms"];
  function getPrefix() {
    var _window$document, _window$document$docu;
    var prop = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "transform";
    if (typeof window === "undefined")
      return "";
    var style2 = (_window$document = window.document) === null || _window$document === void 0 ? void 0 : (_window$document$docu = _window$document.documentElement) === null || _window$document$docu === void 0 ? void 0 : _window$document$docu.style;
    if (!style2)
      return "";
    if (prop in style2)
      return "";
    for (var i = 0; i < prefixes.length; i++) {
      if (browserPrefixToKey(prop, prefixes[i]) in style2)
        return prefixes[i];
    }
    return "";
  }
  function browserPrefixToKey(prop, prefix2) {
    return prefix2 ? "".concat(prefix2).concat(kebabToTitleCase(prop)) : prop;
  }
  function browserPrefixToStyle(prop, prefix2) {
    return prefix2 ? "-".concat(prefix2.toLowerCase(), "-").concat(prop) : prop;
  }
  function kebabToTitleCase(str) {
    var out = "";
    var shouldCapitalize = true;
    for (var i = 0; i < str.length; i++) {
      if (shouldCapitalize) {
        out += str[i].toUpperCase();
        shouldCapitalize = false;
      } else if (str[i] === "-") {
        shouldCapitalize = true;
      } else {
        out += str[i];
      }
    }
    return out;
  }
  var _default$1 = getPrefix();
  getPrefix$1.default = _default$1;
  function _typeof$1(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof$1 = function _typeof2(obj2) {
        return typeof obj2;
      };
    } else {
      _typeof$1 = function _typeof2(obj2) {
        return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
      };
    }
    return _typeof$1(obj);
  }
  Object.defineProperty(domFns, "__esModule", {
    value: true
  });
  domFns.matchesSelector = matchesSelector;
  domFns.matchesSelectorAndParentsTo = matchesSelectorAndParentsTo;
  domFns.addEvent = addEvent;
  domFns.removeEvent = removeEvent;
  domFns.outerHeight = outerHeight;
  domFns.outerWidth = outerWidth;
  domFns.innerHeight = innerHeight;
  domFns.innerWidth = innerWidth;
  domFns.offsetXYFromParent = offsetXYFromParent;
  domFns.createCSSTransform = createCSSTransform;
  domFns.createSVGTransform = createSVGTransform;
  domFns.getTranslation = getTranslation;
  domFns.getTouch = getTouch;
  domFns.getTouchIdentifier = getTouchIdentifier;
  domFns.addUserSelectStyles = addUserSelectStyles;
  domFns.removeUserSelectStyles = removeUserSelectStyles;
  domFns.addClassName = addClassName;
  domFns.removeClassName = removeClassName;
  var _shims$2 = shims;
  var _getPrefix = _interopRequireWildcard$1(getPrefix$1);
  function _getRequireWildcardCache$1(nodeInterop) {
    if (typeof WeakMap !== "function")
      return null;
    var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
    var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
    return (_getRequireWildcardCache$1 = function _getRequireWildcardCache2(nodeInterop2) {
      return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
  }
  function _interopRequireWildcard$1(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
      return obj;
    }
    if (obj === null || _typeof$1(obj) !== "object" && typeof obj !== "function") {
      return { default: obj };
    }
    var cache = _getRequireWildcardCache$1(nodeInterop);
    if (cache && cache.has(obj)) {
      return cache.get(obj);
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var key in obj) {
      if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
        var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
        if (desc && (desc.get || desc.set)) {
          Object.defineProperty(newObj, key, desc);
        } else {
          newObj[key] = obj[key];
        }
      }
    }
    newObj.default = obj;
    if (cache) {
      cache.set(obj, newObj);
    }
    return newObj;
  }
  function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
      var symbols = Object.getOwnPropertySymbols(object);
      if (enumerableOnly) {
        symbols = symbols.filter(function(sym) {
          return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        });
      }
      keys.push.apply(keys, symbols);
    }
    return keys;
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i] != null ? arguments[i] : {};
      if (i % 2) {
        ownKeys(Object(source), true).forEach(function(key) {
          _defineProperty$1(target, key, source[key]);
        });
      } else if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
      } else {
        ownKeys(Object(source)).forEach(function(key) {
          Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
      }
    }
    return target;
  }
  function _defineProperty$1(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  var matchesSelectorFunc = "";
  function matchesSelector(el2, selector) {
    if (!matchesSelectorFunc) {
      matchesSelectorFunc = (0, _shims$2.findInArray)(["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"], function(method) {
        return (0, _shims$2.isFunction)(el2[method]);
      });
    }
    if (!(0, _shims$2.isFunction)(el2[matchesSelectorFunc]))
      return false;
    return el2[matchesSelectorFunc](selector);
  }
  function matchesSelectorAndParentsTo(el2, selector, baseNode) {
    var node2 = el2;
    do {
      if (matchesSelector(node2, selector))
        return true;
      if (node2 === baseNode)
        return false;
      node2 = node2.parentNode;
    } while (node2);
    return false;
  }
  function addEvent(el2, event, handler, inputOptions) {
    if (!el2)
      return;
    var options = _objectSpread({
      capture: true
    }, inputOptions);
    if (el2.addEventListener) {
      el2.addEventListener(event, handler, options);
    } else if (el2.attachEvent) {
      el2.attachEvent("on" + event, handler);
    } else {
      el2["on" + event] = handler;
    }
  }
  function removeEvent(el2, event, handler, inputOptions) {
    if (!el2)
      return;
    var options = _objectSpread({
      capture: true
    }, inputOptions);
    if (el2.removeEventListener) {
      el2.removeEventListener(event, handler, options);
    } else if (el2.detachEvent) {
      el2.detachEvent("on" + event, handler);
    } else {
      el2["on" + event] = null;
    }
  }
  function outerHeight(node2) {
    var height2 = node2.clientHeight;
    var computedStyle = node2.ownerDocument.defaultView.getComputedStyle(node2);
    height2 += (0, _shims$2.int)(computedStyle.borderTopWidth);
    height2 += (0, _shims$2.int)(computedStyle.borderBottomWidth);
    return height2;
  }
  function outerWidth(node2) {
    var width2 = node2.clientWidth;
    var computedStyle = node2.ownerDocument.defaultView.getComputedStyle(node2);
    width2 += (0, _shims$2.int)(computedStyle.borderLeftWidth);
    width2 += (0, _shims$2.int)(computedStyle.borderRightWidth);
    return width2;
  }
  function innerHeight(node2) {
    var height2 = node2.clientHeight;
    var computedStyle = node2.ownerDocument.defaultView.getComputedStyle(node2);
    height2 -= (0, _shims$2.int)(computedStyle.paddingTop);
    height2 -= (0, _shims$2.int)(computedStyle.paddingBottom);
    return height2;
  }
  function innerWidth(node2) {
    var width2 = node2.clientWidth;
    var computedStyle = node2.ownerDocument.defaultView.getComputedStyle(node2);
    width2 -= (0, _shims$2.int)(computedStyle.paddingLeft);
    width2 -= (0, _shims$2.int)(computedStyle.paddingRight);
    return width2;
  }
  function offsetXYFromParent(evt, offsetParent, scale) {
    var isBody = offsetParent === offsetParent.ownerDocument.body;
    var offsetParentRect = isBody ? {
      left: 0,
      top: 0
    } : offsetParent.getBoundingClientRect();
    var x2 = (evt.clientX + offsetParent.scrollLeft - offsetParentRect.left) / scale;
    var y2 = (evt.clientY + offsetParent.scrollTop - offsetParentRect.top) / scale;
    return {
      x: x2,
      y: y2
    };
  }
  function createCSSTransform(controlPos, positionOffset) {
    var translation = getTranslation(controlPos, positionOffset, "px");
    return _defineProperty$1({}, (0, _getPrefix.browserPrefixToKey)("transform", _getPrefix.default), translation);
  }
  function createSVGTransform(controlPos, positionOffset) {
    var translation = getTranslation(controlPos, positionOffset, "");
    return translation;
  }
  function getTranslation(_ref2, positionOffset, unitSuffix) {
    var x2 = _ref2.x, y2 = _ref2.y;
    var translation = "translate(".concat(x2).concat(unitSuffix, ",").concat(y2).concat(unitSuffix, ")");
    if (positionOffset) {
      var defaultX = "".concat(typeof positionOffset.x === "string" ? positionOffset.x : positionOffset.x + unitSuffix);
      var defaultY = "".concat(typeof positionOffset.y === "string" ? positionOffset.y : positionOffset.y + unitSuffix);
      translation = "translate(".concat(defaultX, ", ").concat(defaultY, ")") + translation;
    }
    return translation;
  }
  function getTouch(e2, identifier2) {
    return e2.targetTouches && (0, _shims$2.findInArray)(e2.targetTouches, function(t2) {
      return identifier2 === t2.identifier;
    }) || e2.changedTouches && (0, _shims$2.findInArray)(e2.changedTouches, function(t2) {
      return identifier2 === t2.identifier;
    });
  }
  function getTouchIdentifier(e2) {
    if (e2.targetTouches && e2.targetTouches[0])
      return e2.targetTouches[0].identifier;
    if (e2.changedTouches && e2.changedTouches[0])
      return e2.changedTouches[0].identifier;
  }
  function addUserSelectStyles(doc) {
    if (!doc)
      return;
    var styleEl = doc.getElementById("react-draggable-style-el");
    if (!styleEl) {
      styleEl = doc.createElement("style");
      styleEl.type = "text/css";
      styleEl.id = "react-draggable-style-el";
      styleEl.innerHTML = ".react-draggable-transparent-selection *::-moz-selection {all: inherit;}\n";
      styleEl.innerHTML += ".react-draggable-transparent-selection *::selection {all: inherit;}\n";
      doc.getElementsByTagName("head")[0].appendChild(styleEl);
    }
    if (doc.body)
      addClassName(doc.body, "react-draggable-transparent-selection");
  }
  function removeUserSelectStyles(doc) {
    if (!doc)
      return;
    try {
      if (doc.body)
        removeClassName(doc.body, "react-draggable-transparent-selection");
      if (doc.selection) {
        doc.selection.empty();
      } else {
        var selection = (doc.defaultView || window).getSelection();
        if (selection && selection.type !== "Caret") {
          selection.removeAllRanges();
        }
      }
    } catch (e2) {
    }
  }
  function addClassName(el2, className) {
    if (el2.classList) {
      el2.classList.add(className);
    } else {
      if (!el2.className.match(new RegExp("(?:^|\\s)".concat(className, "(?!\\S)")))) {
        el2.className += " ".concat(className);
      }
    }
  }
  function removeClassName(el2, className) {
    if (el2.classList) {
      el2.classList.remove(className);
    } else {
      el2.className = el2.className.replace(new RegExp("(?:^|\\s)".concat(className, "(?!\\S)"), "g"), "");
    }
  }
  var positionFns = {};
  Object.defineProperty(positionFns, "__esModule", {
    value: true
  });
  positionFns.getBoundPosition = getBoundPosition;
  positionFns.snapToGrid = snapToGrid;
  positionFns.canDragX = canDragX;
  positionFns.canDragY = canDragY;
  positionFns.getControlPosition = getControlPosition;
  positionFns.createCoreData = createCoreData;
  positionFns.createDraggableData = createDraggableData;
  var _shims$1 = shims;
  var _domFns$1 = domFns;
  function getBoundPosition(draggable, x2, y2) {
    if (!draggable.props.bounds)
      return [x2, y2];
    var bounds = draggable.props.bounds;
    bounds = typeof bounds === "string" ? bounds : cloneBounds(bounds);
    var node2 = findDOMNode(draggable);
    if (typeof bounds === "string") {
      var ownerDocument2 = node2.ownerDocument;
      var ownerWindow2 = ownerDocument2.defaultView;
      var boundNode;
      if (bounds === "parent") {
        boundNode = node2.parentNode;
      } else {
        boundNode = ownerDocument2.querySelector(bounds);
      }
      if (!(boundNode instanceof ownerWindow2.HTMLElement)) {
        throw new Error('Bounds selector "' + bounds + '" could not find an element.');
      }
      var boundNodeEl = boundNode;
      var nodeStyle = ownerWindow2.getComputedStyle(node2);
      var boundNodeStyle = ownerWindow2.getComputedStyle(boundNodeEl);
      bounds = {
        left: -node2.offsetLeft + (0, _shims$1.int)(boundNodeStyle.paddingLeft) + (0, _shims$1.int)(nodeStyle.marginLeft),
        top: -node2.offsetTop + (0, _shims$1.int)(boundNodeStyle.paddingTop) + (0, _shims$1.int)(nodeStyle.marginTop),
        right: (0, _domFns$1.innerWidth)(boundNodeEl) - (0, _domFns$1.outerWidth)(node2) - node2.offsetLeft + (0, _shims$1.int)(boundNodeStyle.paddingRight) - (0, _shims$1.int)(nodeStyle.marginRight),
        bottom: (0, _domFns$1.innerHeight)(boundNodeEl) - (0, _domFns$1.outerHeight)(node2) - node2.offsetTop + (0, _shims$1.int)(boundNodeStyle.paddingBottom) - (0, _shims$1.int)(nodeStyle.marginBottom)
      };
    }
    if ((0, _shims$1.isNum)(bounds.right))
      x2 = Math.min(x2, bounds.right);
    if ((0, _shims$1.isNum)(bounds.bottom))
      y2 = Math.min(y2, bounds.bottom);
    if ((0, _shims$1.isNum)(bounds.left))
      x2 = Math.max(x2, bounds.left);
    if ((0, _shims$1.isNum)(bounds.top))
      y2 = Math.max(y2, bounds.top);
    return [x2, y2];
  }
  function snapToGrid(grid2, pendingX, pendingY) {
    var x2 = Math.round(pendingX / grid2[0]) * grid2[0];
    var y2 = Math.round(pendingY / grid2[1]) * grid2[1];
    return [x2, y2];
  }
  function canDragX(draggable) {
    return draggable.props.axis === "both" || draggable.props.axis === "x";
  }
  function canDragY(draggable) {
    return draggable.props.axis === "both" || draggable.props.axis === "y";
  }
  function getControlPosition(e2, touchIdentifier, draggableCore) {
    var touchObj = typeof touchIdentifier === "number" ? (0, _domFns$1.getTouch)(e2, touchIdentifier) : null;
    if (typeof touchIdentifier === "number" && !touchObj)
      return null;
    var node2 = findDOMNode(draggableCore);
    var offsetParent = draggableCore.props.offsetParent || node2.offsetParent || node2.ownerDocument.body;
    return (0, _domFns$1.offsetXYFromParent)(touchObj || e2, offsetParent, draggableCore.props.scale);
  }
  function createCoreData(draggable, x2, y2) {
    var state = draggable.state;
    var isStart = !(0, _shims$1.isNum)(state.lastX);
    var node2 = findDOMNode(draggable);
    if (isStart) {
      return {
        node: node2,
        deltaX: 0,
        deltaY: 0,
        lastX: x2,
        lastY: y2,
        x: x2,
        y: y2
      };
    } else {
      return {
        node: node2,
        deltaX: x2 - state.lastX,
        deltaY: y2 - state.lastY,
        lastX: state.lastX,
        lastY: state.lastY,
        x: x2,
        y: y2
      };
    }
  }
  function createDraggableData(draggable, coreData) {
    var scale = draggable.props.scale;
    return {
      node: coreData.node,
      x: draggable.state.x + coreData.deltaX / scale,
      y: draggable.state.y + coreData.deltaY / scale,
      deltaX: coreData.deltaX / scale,
      deltaY: coreData.deltaY / scale,
      lastX: draggable.state.x,
      lastY: draggable.state.y
    };
  }
  function cloneBounds(bounds) {
    return {
      left: bounds.left,
      top: bounds.top,
      right: bounds.right,
      bottom: bounds.bottom
    };
  }
  function findDOMNode(draggable) {
    var node2 = draggable.findDOMNode();
    if (!node2) {
      throw new Error("<DraggableCore>: Unmounted during event!");
    }
    return node2;
  }
  var DraggableCore$2 = {};
  var log$1 = {};
  Object.defineProperty(log$1, "__esModule", {
    value: true
  });
  log$1.default = log;
  function log() {
  }
  function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function _typeof2(obj2) {
        return typeof obj2;
      };
    } else {
      _typeof = function _typeof2(obj2) {
        return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
      };
    }
    return _typeof(obj);
  }
  Object.defineProperty(DraggableCore$2, "__esModule", {
    value: true
  });
  DraggableCore$2.default = void 0;
  var React = _interopRequireWildcard(react.exports);
  var _propTypes = _interopRequireDefault$1(propTypes.exports);
  var _reactDom = _interopRequireDefault$1(reactDom.exports);
  var _domFns = domFns;
  var _positionFns = positionFns;
  var _shims = shims;
  var _log = _interopRequireDefault$1(log$1);
  function _interopRequireDefault$1(obj) {
    return obj && obj.__esModule ? obj : { default: obj };
  }
  function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function")
      return null;
    var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
    var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
    return (_getRequireWildcardCache = function _getRequireWildcardCache2(nodeInterop2) {
      return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
  }
  function _interopRequireWildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
      return obj;
    }
    if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
      return { default: obj };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
      return cache.get(obj);
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var key in obj) {
      if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
        var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
        if (desc && (desc.get || desc.set)) {
          Object.defineProperty(newObj, key, desc);
        } else {
          newObj[key] = obj[key];
        }
      }
    }
    newObj.default = obj;
    if (cache) {
      cache.set(obj, newObj);
    }
    return newObj;
  }
  function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o)
      return;
    if (typeof o === "string")
      return _arrayLikeToArray(o, minLen);
    var n2 = Object.prototype.toString.call(o).slice(8, -1);
    if (n2 === "Object" && o.constructor)
      n2 = o.constructor.name;
    if (n2 === "Map" || n2 === "Set")
      return Array.from(o);
    if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
      return _arrayLikeToArray(o, minLen);
  }
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length)
      len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) {
      arr2[i] = arr[i];
    }
    return arr2;
  }
  function _iterableToArrayLimit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null)
      return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
      for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);
        if (i && _arr.length === i)
          break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"] != null)
          _i["return"]();
      } finally {
        if (_d)
          throw _e;
      }
    }
    return _arr;
  }
  function _arrayWithHoles(arr) {
    if (Array.isArray(arr))
      return arr;
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps)
      _defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } });
    if (superClass)
      _setPrototypeOf(subClass, superClass);
  }
  function _setPrototypeOf(o, p2) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o2, p3) {
      o2.__proto__ = p3;
      return o2;
    };
    return _setPrototypeOf(o, p2);
  }
  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();
    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived), result;
      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;
        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }
      return _possibleConstructorReturn(this, result);
    };
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (_typeof(call) === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct)
      return false;
    if (Reflect.construct.sham)
      return false;
    if (typeof Proxy === "function")
      return true;
    try {
      Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
      }));
      return true;
    } catch (e2) {
      return false;
    }
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf2(o2) {
      return o2.__proto__ || Object.getPrototypeOf(o2);
    };
    return _getPrototypeOf(o);
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  var eventsFor = {
    touch: {
      start: "touchstart",
      move: "touchmove",
      stop: "touchend"
    },
    mouse: {
      start: "mousedown",
      move: "mousemove",
      stop: "mouseup"
    }
  };
  var dragEventFor = eventsFor.mouse;
  var DraggableCore$1 = /* @__PURE__ */ function(_React$Component) {
    _inherits(DraggableCore2, _React$Component);
    var _super = _createSuper(DraggableCore2);
    function DraggableCore2() {
      var _this;
      _classCallCheck(this, DraggableCore2);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _super.call.apply(_super, [this].concat(args));
      _defineProperty(_assertThisInitialized(_this), "state", {
        dragging: false,
        lastX: NaN,
        lastY: NaN,
        touchIdentifier: null
      });
      _defineProperty(_assertThisInitialized(_this), "mounted", false);
      _defineProperty(_assertThisInitialized(_this), "handleDragStart", function(e2) {
        _this.props.onMouseDown(e2);
        if (!_this.props.allowAnyClick && typeof e2.button === "number" && e2.button !== 0)
          return false;
        var thisNode = _this.findDOMNode();
        if (!thisNode || !thisNode.ownerDocument || !thisNode.ownerDocument.body) {
          throw new Error("<DraggableCore> not mounted on DragStart!");
        }
        var ownerDocument2 = thisNode.ownerDocument;
        if (_this.props.disabled || !(e2.target instanceof ownerDocument2.defaultView.Node) || _this.props.handle && !(0, _domFns.matchesSelectorAndParentsTo)(e2.target, _this.props.handle, thisNode) || _this.props.cancel && (0, _domFns.matchesSelectorAndParentsTo)(e2.target, _this.props.cancel, thisNode)) {
          return;
        }
        if (e2.type === "touchstart")
          e2.preventDefault();
        var touchIdentifier = (0, _domFns.getTouchIdentifier)(e2);
        _this.setState({
          touchIdentifier
        });
        var position2 = (0, _positionFns.getControlPosition)(e2, touchIdentifier, _assertThisInitialized(_this));
        if (position2 == null)
          return;
        var x2 = position2.x, y2 = position2.y;
        var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x2, y2);
        (0, _log.default)("DraggableCore: handleDragStart: %j", coreEvent);
        (0, _log.default)("calling", _this.props.onStart);
        var shouldUpdate = _this.props.onStart(e2, coreEvent);
        if (shouldUpdate === false || _this.mounted === false)
          return;
        if (_this.props.enableUserSelectHack)
          (0, _domFns.addUserSelectStyles)(ownerDocument2);
        _this.setState({
          dragging: true,
          lastX: x2,
          lastY: y2
        });
        (0, _domFns.addEvent)(ownerDocument2, dragEventFor.move, _this.handleDrag);
        (0, _domFns.addEvent)(ownerDocument2, dragEventFor.stop, _this.handleDragStop);
      });
      _defineProperty(_assertThisInitialized(_this), "handleDrag", function(e2) {
        var position2 = (0, _positionFns.getControlPosition)(e2, _this.state.touchIdentifier, _assertThisInitialized(_this));
        if (position2 == null)
          return;
        var x2 = position2.x, y2 = position2.y;
        if (Array.isArray(_this.props.grid)) {
          var deltaX = x2 - _this.state.lastX, deltaY = y2 - _this.state.lastY;
          var _snapToGrid = (0, _positionFns.snapToGrid)(_this.props.grid, deltaX, deltaY);
          var _snapToGrid2 = _slicedToArray(_snapToGrid, 2);
          deltaX = _snapToGrid2[0];
          deltaY = _snapToGrid2[1];
          if (!deltaX && !deltaY)
            return;
          x2 = _this.state.lastX + deltaX, y2 = _this.state.lastY + deltaY;
        }
        var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x2, y2);
        (0, _log.default)("DraggableCore: handleDrag: %j", coreEvent);
        var shouldUpdate = _this.props.onDrag(e2, coreEvent);
        if (shouldUpdate === false || _this.mounted === false) {
          try {
            _this.handleDragStop(new MouseEvent("mouseup"));
          } catch (err) {
            var event = document.createEvent("MouseEvents");
            event.initMouseEvent("mouseup", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            _this.handleDragStop(event);
          }
          return;
        }
        _this.setState({
          lastX: x2,
          lastY: y2
        });
      });
      _defineProperty(_assertThisInitialized(_this), "handleDragStop", function(e2) {
        if (!_this.state.dragging)
          return;
        var position2 = (0, _positionFns.getControlPosition)(e2, _this.state.touchIdentifier, _assertThisInitialized(_this));
        if (position2 == null)
          return;
        var x2 = position2.x, y2 = position2.y;
        var coreEvent = (0, _positionFns.createCoreData)(_assertThisInitialized(_this), x2, y2);
        var shouldContinue = _this.props.onStop(e2, coreEvent);
        if (shouldContinue === false || _this.mounted === false)
          return false;
        var thisNode = _this.findDOMNode();
        if (thisNode) {
          if (_this.props.enableUserSelectHack)
            (0, _domFns.removeUserSelectStyles)(thisNode.ownerDocument);
        }
        (0, _log.default)("DraggableCore: handleDragStop: %j", coreEvent);
        _this.setState({
          dragging: false,
          lastX: NaN,
          lastY: NaN
        });
        if (thisNode) {
          (0, _log.default)("DraggableCore: Removing handlers");
          (0, _domFns.removeEvent)(thisNode.ownerDocument, dragEventFor.move, _this.handleDrag);
          (0, _domFns.removeEvent)(thisNode.ownerDocument, dragEventFor.stop, _this.handleDragStop);
        }
      });
      _defineProperty(_assertThisInitialized(_this), "onMouseDown", function(e2) {
        dragEventFor = eventsFor.mouse;
        return _this.handleDragStart(e2);
      });
      _defineProperty(_assertThisInitialized(_this), "onMouseUp", function(e2) {
        dragEventFor = eventsFor.mouse;
        return _this.handleDragStop(e2);
      });
      _defineProperty(_assertThisInitialized(_this), "onTouchStart", function(e2) {
        dragEventFor = eventsFor.touch;
        return _this.handleDragStart(e2);
      });
      _defineProperty(_assertThisInitialized(_this), "onTouchEnd", function(e2) {
        dragEventFor = eventsFor.touch;
        return _this.handleDragStop(e2);
      });
      return _this;
    }
    _createClass(DraggableCore2, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        this.mounted = true;
        var thisNode = this.findDOMNode();
        if (thisNode) {
          (0, _domFns.addEvent)(thisNode, eventsFor.touch.start, this.onTouchStart, {
            passive: false
          });
        }
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        this.mounted = false;
        var thisNode = this.findDOMNode();
        if (thisNode) {
          var ownerDocument2 = thisNode.ownerDocument;
          (0, _domFns.removeEvent)(ownerDocument2, eventsFor.mouse.move, this.handleDrag);
          (0, _domFns.removeEvent)(ownerDocument2, eventsFor.touch.move, this.handleDrag);
          (0, _domFns.removeEvent)(ownerDocument2, eventsFor.mouse.stop, this.handleDragStop);
          (0, _domFns.removeEvent)(ownerDocument2, eventsFor.touch.stop, this.handleDragStop);
          (0, _domFns.removeEvent)(thisNode, eventsFor.touch.start, this.onTouchStart, {
            passive: false
          });
          if (this.props.enableUserSelectHack)
            (0, _domFns.removeUserSelectStyles)(ownerDocument2);
        }
      }
    }, {
      key: "findDOMNode",
      value: function findDOMNode2() {
        var _this$props$nodeRef$c, _this$props, _this$props$nodeRef;
        return (_this$props$nodeRef$c = (_this$props = this.props) === null || _this$props === void 0 ? void 0 : (_this$props$nodeRef = _this$props.nodeRef) === null || _this$props$nodeRef === void 0 ? void 0 : _this$props$nodeRef.current) !== null && _this$props$nodeRef$c !== void 0 ? _this$props$nodeRef$c : _reactDom.default.findDOMNode(this);
      }
    }, {
      key: "render",
      value: function render() {
        return /* @__PURE__ */ React.cloneElement(React.Children.only(this.props.children), {
          onMouseDown: this.onMouseDown,
          onMouseUp: this.onMouseUp,
          onTouchEnd: this.onTouchEnd
        });
      }
    }]);
    return DraggableCore2;
  }(React.Component);
  DraggableCore$2.default = DraggableCore$1;
  _defineProperty(DraggableCore$1, "displayName", "DraggableCore");
  _defineProperty(DraggableCore$1, "propTypes", {
    allowAnyClick: _propTypes.default.bool,
    disabled: _propTypes.default.bool,
    enableUserSelectHack: _propTypes.default.bool,
    offsetParent: function offsetParent(props, propName) {
      if (props[propName] && props[propName].nodeType !== 1) {
        throw new Error("Draggable's offsetParent must be a DOM Node.");
      }
    },
    grid: _propTypes.default.arrayOf(_propTypes.default.number),
    handle: _propTypes.default.string,
    cancel: _propTypes.default.string,
    nodeRef: _propTypes.default.object,
    onStart: _propTypes.default.func,
    onDrag: _propTypes.default.func,
    onStop: _propTypes.default.func,
    onMouseDown: _propTypes.default.func,
    scale: _propTypes.default.number,
    className: _shims.dontSetMe,
    style: _shims.dontSetMe,
    transform: _shims.dontSetMe
  });
  _defineProperty(DraggableCore$1, "defaultProps", {
    allowAnyClick: false,
    disabled: false,
    enableUserSelectHack: true,
    onStart: function onStart() {
    },
    onDrag: function onDrag() {
    },
    onStop: function onStop() {
    },
    onMouseDown: function onMouseDown() {
    },
    scale: 1
  });
  (function(exports) {
    function _typeof2(obj) {
      "@babel/helpers - typeof";
      if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof2 = function _typeof3(obj2) {
          return typeof obj2;
        };
      } else {
        _typeof2 = function _typeof3(obj2) {
          return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        };
      }
      return _typeof2(obj);
    }
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    Object.defineProperty(exports, "DraggableCore", {
      enumerable: true,
      get: function get() {
        return _DraggableCore.default;
      }
    });
    exports.default = void 0;
    var React2 = _interopRequireWildcard2(react.exports);
    var _propTypes2 = _interopRequireDefault2(propTypes.exports);
    var _reactDom2 = _interopRequireDefault2(reactDom.exports);
    var _clsx2 = _interopRequireDefault2(require$$3);
    var _domFns2 = domFns;
    var _positionFns2 = positionFns;
    var _shims2 = shims;
    var _DraggableCore = _interopRequireDefault2(DraggableCore$2);
    var _log2 = _interopRequireDefault2(log$1);
    var _excluded4 = ["axis", "bounds", "children", "defaultPosition", "defaultClassName", "defaultClassNameDragging", "defaultClassNameDragged", "position", "positionOffset", "scale"];
    function _interopRequireDefault2(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _getRequireWildcardCache2(nodeInterop) {
      if (typeof WeakMap !== "function")
        return null;
      var cacheBabelInterop = /* @__PURE__ */ new WeakMap();
      var cacheNodeInterop = /* @__PURE__ */ new WeakMap();
      return (_getRequireWildcardCache2 = function _getRequireWildcardCache3(nodeInterop2) {
        return nodeInterop2 ? cacheNodeInterop : cacheBabelInterop;
      })(nodeInterop);
    }
    function _interopRequireWildcard2(obj, nodeInterop) {
      if (!nodeInterop && obj && obj.__esModule) {
        return obj;
      }
      if (obj === null || _typeof2(obj) !== "object" && typeof obj !== "function") {
        return { default: obj };
      }
      var cache = _getRequireWildcardCache2(nodeInterop);
      if (cache && cache.has(obj)) {
        return cache.get(obj);
      }
      var newObj = {};
      var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
      for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
          var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
          if (desc && (desc.get || desc.set)) {
            Object.defineProperty(newObj, key, desc);
          } else {
            newObj[key] = obj[key];
          }
        }
      }
      newObj.default = obj;
      if (cache) {
        cache.set(obj, newObj);
      }
      return newObj;
    }
    function _extends2() {
      _extends2 = Object.assign || function(target) {
        for (var i = 1; i < arguments.length; i++) {
          var source = arguments[i];
          for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
        return target;
      };
      return _extends2.apply(this, arguments);
    }
    function _objectWithoutProperties(source, excluded) {
      if (source == null)
        return {};
      var target = _objectWithoutPropertiesLoose2(source, excluded);
      var key, i;
      if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for (i = 0; i < sourceSymbolKeys.length; i++) {
          key = sourceSymbolKeys[i];
          if (excluded.indexOf(key) >= 0)
            continue;
          if (!Object.prototype.propertyIsEnumerable.call(source, key))
            continue;
          target[key] = source[key];
        }
      }
      return target;
    }
    function _objectWithoutPropertiesLoose2(source, excluded) {
      if (source == null)
        return {};
      var target = {};
      var sourceKeys = Object.keys(source);
      var key, i;
      for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0)
          continue;
        target[key] = source[key];
      }
      return target;
    }
    function ownKeys2(object, enumerableOnly) {
      var keys = Object.keys(object);
      if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly) {
          symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
          });
        }
        keys.push.apply(keys, symbols);
      }
      return keys;
    }
    function _objectSpread2(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
          ownKeys2(Object(source), true).forEach(function(key) {
            _defineProperty2(target, key, source[key]);
          });
        } else if (Object.getOwnPropertyDescriptors) {
          Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
          ownKeys2(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
          });
        }
      }
      return target;
    }
    function _slicedToArray2(arr, i) {
      return _arrayWithHoles2(arr) || _iterableToArrayLimit2(arr, i) || _unsupportedIterableToArray2(arr, i) || _nonIterableRest2();
    }
    function _nonIterableRest2() {
      throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function _unsupportedIterableToArray2(o, minLen) {
      if (!o)
        return;
      if (typeof o === "string")
        return _arrayLikeToArray2(o, minLen);
      var n2 = Object.prototype.toString.call(o).slice(8, -1);
      if (n2 === "Object" && o.constructor)
        n2 = o.constructor.name;
      if (n2 === "Map" || n2 === "Set")
        return Array.from(o);
      if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
        return _arrayLikeToArray2(o, minLen);
    }
    function _arrayLikeToArray2(arr, len) {
      if (len == null || len > arr.length)
        len = arr.length;
      for (var i = 0, arr2 = new Array(len); i < len; i++) {
        arr2[i] = arr[i];
      }
      return arr2;
    }
    function _iterableToArrayLimit2(arr, i) {
      var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
      if (_i == null)
        return;
      var _arr = [];
      var _n = true;
      var _d = false;
      var _s, _e;
      try {
        for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);
          if (i && _arr.length === i)
            break;
        }
      } catch (err) {
        _d = true;
        _e = err;
      } finally {
        try {
          if (!_n && _i["return"] != null)
            _i["return"]();
        } finally {
          if (_d)
            throw _e;
        }
      }
      return _arr;
    }
    function _arrayWithHoles2(arr) {
      if (Array.isArray(arr))
        return arr;
    }
    function _classCallCheck2(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _defineProperties2(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor)
          descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    function _createClass2(Constructor, protoProps, staticProps) {
      if (protoProps)
        _defineProperties2(Constructor.prototype, protoProps);
      if (staticProps)
        _defineProperties2(Constructor, staticProps);
      return Constructor;
    }
    function _inherits2(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } });
      if (superClass)
        _setPrototypeOf2(subClass, superClass);
    }
    function _setPrototypeOf2(o, p2) {
      _setPrototypeOf2 = Object.setPrototypeOf || function _setPrototypeOf3(o2, p3) {
        o2.__proto__ = p3;
        return o2;
      };
      return _setPrototypeOf2(o, p2);
    }
    function _createSuper2(Derived) {
      var hasNativeReflectConstruct = _isNativeReflectConstruct2();
      return function _createSuperInternal() {
        var Super = _getPrototypeOf2(Derived), result;
        if (hasNativeReflectConstruct) {
          var NewTarget = _getPrototypeOf2(this).constructor;
          result = Reflect.construct(Super, arguments, NewTarget);
        } else {
          result = Super.apply(this, arguments);
        }
        return _possibleConstructorReturn2(this, result);
      };
    }
    function _possibleConstructorReturn2(self, call) {
      if (call && (_typeof2(call) === "object" || typeof call === "function")) {
        return call;
      } else if (call !== void 0) {
        throw new TypeError("Derived constructors may only return object or undefined");
      }
      return _assertThisInitialized2(self);
    }
    function _assertThisInitialized2(self) {
      if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return self;
    }
    function _isNativeReflectConstruct2() {
      if (typeof Reflect === "undefined" || !Reflect.construct)
        return false;
      if (Reflect.construct.sham)
        return false;
      if (typeof Proxy === "function")
        return true;
      try {
        Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
        }));
        return true;
      } catch (e2) {
        return false;
      }
    }
    function _getPrototypeOf2(o) {
      _getPrototypeOf2 = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf3(o2) {
        return o2.__proto__ || Object.getPrototypeOf(o2);
      };
      return _getPrototypeOf2(o);
    }
    function _defineProperty2(obj, key, value) {
      if (key in obj) {
        Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
      } else {
        obj[key] = value;
      }
      return obj;
    }
    var Draggable2 = /* @__PURE__ */ function(_React$Component) {
      _inherits2(Draggable3, _React$Component);
      var _super = _createSuper2(Draggable3);
      function Draggable3(props) {
        var _this;
        _classCallCheck2(this, Draggable3);
        _this = _super.call(this, props);
        _defineProperty2(_assertThisInitialized2(_this), "onDragStart", function(e2, coreData) {
          (0, _log2.default)("Draggable: onDragStart: %j", coreData);
          var shouldStart = _this.props.onStart(e2, (0, _positionFns2.createDraggableData)(_assertThisInitialized2(_this), coreData));
          if (shouldStart === false)
            return false;
          _this.setState({
            dragging: true,
            dragged: true
          });
        });
        _defineProperty2(_assertThisInitialized2(_this), "onDrag", function(e2, coreData) {
          if (!_this.state.dragging)
            return false;
          (0, _log2.default)("Draggable: onDrag: %j", coreData);
          var uiData = (0, _positionFns2.createDraggableData)(_assertThisInitialized2(_this), coreData);
          var newState = {
            x: uiData.x,
            y: uiData.y
          };
          if (_this.props.bounds) {
            var x2 = newState.x, y2 = newState.y;
            newState.x += _this.state.slackX;
            newState.y += _this.state.slackY;
            var _getBoundPosition = (0, _positionFns2.getBoundPosition)(_assertThisInitialized2(_this), newState.x, newState.y), _getBoundPosition2 = _slicedToArray2(_getBoundPosition, 2), newStateX = _getBoundPosition2[0], newStateY = _getBoundPosition2[1];
            newState.x = newStateX;
            newState.y = newStateY;
            newState.slackX = _this.state.slackX + (x2 - newState.x);
            newState.slackY = _this.state.slackY + (y2 - newState.y);
            uiData.x = newState.x;
            uiData.y = newState.y;
            uiData.deltaX = newState.x - _this.state.x;
            uiData.deltaY = newState.y - _this.state.y;
          }
          var shouldUpdate = _this.props.onDrag(e2, uiData);
          if (shouldUpdate === false)
            return false;
          _this.setState(newState);
        });
        _defineProperty2(_assertThisInitialized2(_this), "onDragStop", function(e2, coreData) {
          if (!_this.state.dragging)
            return false;
          var shouldContinue = _this.props.onStop(e2, (0, _positionFns2.createDraggableData)(_assertThisInitialized2(_this), coreData));
          if (shouldContinue === false)
            return false;
          (0, _log2.default)("Draggable: onDragStop: %j", coreData);
          var newState = {
            dragging: false,
            slackX: 0,
            slackY: 0
          };
          var controlled = Boolean(_this.props.position);
          if (controlled) {
            var _this$props$position = _this.props.position, x2 = _this$props$position.x, y2 = _this$props$position.y;
            newState.x = x2;
            newState.y = y2;
          }
          _this.setState(newState);
        });
        _this.state = {
          dragging: false,
          dragged: false,
          x: props.position ? props.position.x : props.defaultPosition.x,
          y: props.position ? props.position.y : props.defaultPosition.y,
          prevPropsPosition: _objectSpread2({}, props.position),
          slackX: 0,
          slackY: 0,
          isElementSVG: false
        };
        if (props.position && !(props.onDrag || props.onStop)) {
          console.warn("A `position` was applied to this <Draggable>, without drag handlers. This will make this component effectively undraggable. Please attach `onDrag` or `onStop` handlers so you can adjust the `position` of this element.");
        }
        return _this;
      }
      _createClass2(Draggable3, [{
        key: "componentDidMount",
        value: function componentDidMount() {
          if (typeof window.SVGElement !== "undefined" && this.findDOMNode() instanceof window.SVGElement) {
            this.setState({
              isElementSVG: true
            });
          }
        }
      }, {
        key: "componentWillUnmount",
        value: function componentWillUnmount() {
          this.setState({
            dragging: false
          });
        }
      }, {
        key: "findDOMNode",
        value: function findDOMNode2() {
          var _this$props$nodeRef$c, _this$props, _this$props$nodeRef;
          return (_this$props$nodeRef$c = (_this$props = this.props) === null || _this$props === void 0 ? void 0 : (_this$props$nodeRef = _this$props.nodeRef) === null || _this$props$nodeRef === void 0 ? void 0 : _this$props$nodeRef.current) !== null && _this$props$nodeRef$c !== void 0 ? _this$props$nodeRef$c : _reactDom2.default.findDOMNode(this);
        }
      }, {
        key: "render",
        value: function render() {
          var _clsx;
          var _this$props2 = this.props;
          _this$props2.axis;
          _this$props2.bounds;
          var children = _this$props2.children, defaultPosition = _this$props2.defaultPosition, defaultClassName = _this$props2.defaultClassName, defaultClassNameDragging = _this$props2.defaultClassNameDragging, defaultClassNameDragged = _this$props2.defaultClassNameDragged, position2 = _this$props2.position, positionOffset = _this$props2.positionOffset;
          _this$props2.scale;
          var draggableCoreProps = _objectWithoutProperties(_this$props2, _excluded4);
          var style2 = {};
          var svgTransform = null;
          var controlled = Boolean(position2);
          var draggable = !controlled || this.state.dragging;
          var validPosition = position2 || defaultPosition;
          var transformOpts = {
            x: (0, _positionFns2.canDragX)(this) && draggable ? this.state.x : validPosition.x,
            y: (0, _positionFns2.canDragY)(this) && draggable ? this.state.y : validPosition.y
          };
          if (this.state.isElementSVG) {
            svgTransform = (0, _domFns2.createSVGTransform)(transformOpts, positionOffset);
          } else {
            style2 = (0, _domFns2.createCSSTransform)(transformOpts, positionOffset);
          }
          var className = (0, _clsx2.default)(children.props.className || "", defaultClassName, (_clsx = {}, _defineProperty2(_clsx, defaultClassNameDragging, this.state.dragging), _defineProperty2(_clsx, defaultClassNameDragged, this.state.dragged), _clsx));
          return /* @__PURE__ */ React2.createElement(_DraggableCore.default, _extends2({}, draggableCoreProps, {
            onStart: this.onDragStart,
            onDrag: this.onDrag,
            onStop: this.onDragStop
          }), /* @__PURE__ */ React2.cloneElement(React2.Children.only(children), {
            className,
            style: _objectSpread2(_objectSpread2({}, children.props.style), style2),
            transform: svgTransform
          }));
        }
      }], [{
        key: "getDerivedStateFromProps",
        value: function getDerivedStateFromProps(_ref, _ref2) {
          var position2 = _ref.position;
          var prevPropsPosition = _ref2.prevPropsPosition;
          if (position2 && (!prevPropsPosition || position2.x !== prevPropsPosition.x || position2.y !== prevPropsPosition.y)) {
            (0, _log2.default)("Draggable: getDerivedStateFromProps %j", {
              position: position2,
              prevPropsPosition
            });
            return {
              x: position2.x,
              y: position2.y,
              prevPropsPosition: _objectSpread2({}, position2)
            };
          }
          return null;
        }
      }]);
      return Draggable3;
    }(React2.Component);
    exports.default = Draggable2;
    _defineProperty2(Draggable2, "displayName", "Draggable");
    _defineProperty2(Draggable2, "propTypes", _objectSpread2(_objectSpread2({}, _DraggableCore.default.propTypes), {}, {
      axis: _propTypes2.default.oneOf(["both", "x", "y", "none"]),
      bounds: _propTypes2.default.oneOfType([_propTypes2.default.shape({
        left: _propTypes2.default.number,
        right: _propTypes2.default.number,
        top: _propTypes2.default.number,
        bottom: _propTypes2.default.number
      }), _propTypes2.default.string, _propTypes2.default.oneOf([false])]),
      defaultClassName: _propTypes2.default.string,
      defaultClassNameDragging: _propTypes2.default.string,
      defaultClassNameDragged: _propTypes2.default.string,
      defaultPosition: _propTypes2.default.shape({
        x: _propTypes2.default.number,
        y: _propTypes2.default.number
      }),
      positionOffset: _propTypes2.default.shape({
        x: _propTypes2.default.oneOfType([_propTypes2.default.number, _propTypes2.default.string]),
        y: _propTypes2.default.oneOfType([_propTypes2.default.number, _propTypes2.default.string])
      }),
      position: _propTypes2.default.shape({
        x: _propTypes2.default.number,
        y: _propTypes2.default.number
      }),
      className: _shims2.dontSetMe,
      style: _shims2.dontSetMe,
      transform: _shims2.dontSetMe
    }));
    _defineProperty2(Draggable2, "defaultProps", _objectSpread2(_objectSpread2({}, _DraggableCore.default.defaultProps), {}, {
      axis: "both",
      bounds: false,
      defaultClassName: "react-draggable",
      defaultClassNameDragging: "react-draggable-dragging",
      defaultClassNameDragged: "react-draggable-dragged",
      defaultPosition: {
        x: 0,
        y: 0
      },
      scale: 1
    }));
  })(Draggable$2);
  var _require = Draggable$2, Draggable$1 = _require.default, DraggableCore = _require.DraggableCore;
  cjs.exports = Draggable$1;
  cjs.exports.default = Draggable$1;
  cjs.exports.DraggableCore = DraggableCore;
  var __extends$2 = globalThis && globalThis.__extends || function() {
    var extendStatics2 = function(d2, b2) {
      extendStatics2 = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3)
          if (Object.prototype.hasOwnProperty.call(b3, p2))
            d3[p2] = b3[p2];
      };
      return extendStatics2(d2, b2);
    };
    return function(d2, b2) {
      extendStatics2(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __assign$2 = globalThis && globalThis.__assign || function() {
    __assign$2 = Object.assign || function(t2) {
      for (var s, i = 1, n2 = arguments.length; i < n2; i++) {
        s = arguments[i];
        for (var p2 in s)
          if (Object.prototype.hasOwnProperty.call(s, p2))
            t2[p2] = s[p2];
      }
      return t2;
    };
    return __assign$2.apply(this, arguments);
  };
  var styles = {
    top: {
      width: "100%",
      height: "10px",
      top: "-5px",
      left: "0px",
      cursor: "row-resize"
    },
    right: {
      width: "10px",
      height: "100%",
      top: "0px",
      right: "-5px",
      cursor: "col-resize"
    },
    bottom: {
      width: "100%",
      height: "10px",
      bottom: "-5px",
      left: "0px",
      cursor: "row-resize"
    },
    left: {
      width: "10px",
      height: "100%",
      top: "0px",
      left: "-5px",
      cursor: "col-resize"
    },
    topRight: {
      width: "20px",
      height: "20px",
      position: "absolute",
      right: "-10px",
      top: "-10px",
      cursor: "ne-resize"
    },
    bottomRight: {
      width: "20px",
      height: "20px",
      position: "absolute",
      right: "-10px",
      bottom: "-10px",
      cursor: "se-resize"
    },
    bottomLeft: {
      width: "20px",
      height: "20px",
      position: "absolute",
      left: "-10px",
      bottom: "-10px",
      cursor: "sw-resize"
    },
    topLeft: {
      width: "20px",
      height: "20px",
      position: "absolute",
      left: "-10px",
      top: "-10px",
      cursor: "nw-resize"
    }
  };
  var Resizer = function(_super) {
    __extends$2(Resizer2, _super);
    function Resizer2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.onMouseDown = function(e2) {
        _this.props.onResizeStart(e2, _this.props.direction);
      };
      _this.onTouchStart = function(e2) {
        _this.props.onResizeStart(e2, _this.props.direction);
      };
      return _this;
    }
    Resizer2.prototype.render = function() {
      return /* @__PURE__ */ jsx("div", {
        className: this.props.className || "",
        style: __assign$2(__assign$2({
          position: "absolute",
          userSelect: "none"
        }, styles[this.props.direction]), this.props.replaceStyles || {}),
        onMouseDown: this.onMouseDown,
        onTouchStart: this.onTouchStart,
        children: this.props.children
      });
    };
    return Resizer2;
  }(react.exports.PureComponent);
  var src = { exports: {} };
  function memoize(fn, options) {
    var cache = options && options.cache ? options.cache : cacheDefault;
    var serializer = options && options.serializer ? options.serializer : serializerDefault;
    var strategy = options && options.strategy ? options.strategy : strategyDefault;
    return strategy(fn, {
      cache,
      serializer
    });
  }
  function isPrimitive(value) {
    return value == null || typeof value === "number" || typeof value === "boolean";
  }
  function monadic(fn, cache, serializer, arg) {
    var cacheKey = isPrimitive(arg) ? arg : serializer(arg);
    var computedValue = cache.get(cacheKey);
    if (typeof computedValue === "undefined") {
      computedValue = fn.call(this, arg);
      cache.set(cacheKey, computedValue);
    }
    return computedValue;
  }
  function variadic(fn, cache, serializer) {
    var args = Array.prototype.slice.call(arguments, 3);
    var cacheKey = serializer(args);
    var computedValue = cache.get(cacheKey);
    if (typeof computedValue === "undefined") {
      computedValue = fn.apply(this, args);
      cache.set(cacheKey, computedValue);
    }
    return computedValue;
  }
  function assemble(fn, context, strategy, cache, serialize2) {
    return strategy.bind(
      context,
      fn,
      cache,
      serialize2
    );
  }
  function strategyDefault(fn, options) {
    var strategy = fn.length === 1 ? monadic : variadic;
    return assemble(
      fn,
      this,
      strategy,
      options.cache.create(),
      options.serializer
    );
  }
  function strategyVariadic(fn, options) {
    var strategy = variadic;
    return assemble(
      fn,
      this,
      strategy,
      options.cache.create(),
      options.serializer
    );
  }
  function strategyMonadic(fn, options) {
    var strategy = monadic;
    return assemble(
      fn,
      this,
      strategy,
      options.cache.create(),
      options.serializer
    );
  }
  function serializerDefault() {
    return JSON.stringify(arguments);
  }
  function ObjectWithoutPrototypeCache() {
    this.cache = /* @__PURE__ */ Object.create(null);
  }
  ObjectWithoutPrototypeCache.prototype.has = function(key) {
    return key in this.cache;
  };
  ObjectWithoutPrototypeCache.prototype.get = function(key) {
    return this.cache[key];
  };
  ObjectWithoutPrototypeCache.prototype.set = function(key, value) {
    this.cache[key] = value;
  };
  var cacheDefault = {
    create: function create() {
      return new ObjectWithoutPrototypeCache();
    }
  };
  src.exports = memoize;
  src.exports.strategies = {
    variadic: strategyVariadic,
    monadic: strategyMonadic
  };
  var __extends$1 = globalThis && globalThis.__extends || function() {
    var extendStatics2 = function(d2, b2) {
      extendStatics2 = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function(d3, b3) {
        d3.__proto__ = b3;
      } || function(d3, b3) {
        for (var p2 in b3)
          if (Object.prototype.hasOwnProperty.call(b3, p2))
            d3[p2] = b3[p2];
      };
      return extendStatics2(d2, b2);
    };
    return function(d2, b2) {
      extendStatics2(d2, b2);
      function __() {
        this.constructor = d2;
      }
      d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
    };
  }();
  var __assign$1 = globalThis && globalThis.__assign || function() {
    __assign$1 = Object.assign || function(t2) {
      for (var s, i = 1, n2 = arguments.length; i < n2; i++) {
        s = arguments[i];
        for (var p2 in s)
          if (Object.prototype.hasOwnProperty.call(s, p2))
            t2[p2] = s[p2];
      }
      return t2;
    };
    return __assign$1.apply(this, arguments);
  };
  var DEFAULT_SIZE = {
    width: "auto",
    height: "auto"
  };
  var clamp = src.exports(function(n2, min2, max2) {
    return Math.max(Math.min(n2, max2), min2);
  });
  var snap = src.exports(function(n2, size) {
    return Math.round(n2 / size) * size;
  });
  var hasDirection = src.exports(function(dir, target) {
    return new RegExp(dir, "i").test(target);
  });
  var isTouchEvent = function(event) {
    return Boolean(event.touches && event.touches.length);
  };
  var isMouseEvent = function(event) {
    return Boolean((event.clientX || event.clientX === 0) && (event.clientY || event.clientY === 0));
  };
  var findClosestSnap = src.exports(function(n2, snapArray, snapGap) {
    if (snapGap === void 0) {
      snapGap = 0;
    }
    var closestGapIndex = snapArray.reduce(function(prev2, curr, index) {
      return Math.abs(curr - n2) < Math.abs(snapArray[prev2] - n2) ? index : prev2;
    }, 0);
    var gap2 = Math.abs(snapArray[closestGapIndex] - n2);
    return snapGap === 0 || gap2 < snapGap ? snapArray[closestGapIndex] : n2;
  });
  var endsWith = src.exports(function(str, searchStr) {
    return str.substr(str.length - searchStr.length, searchStr.length) === searchStr;
  });
  var getStringSize = src.exports(function(n2) {
    n2 = n2.toString();
    if (n2 === "auto") {
      return n2;
    }
    if (endsWith(n2, "px")) {
      return n2;
    }
    if (endsWith(n2, "%")) {
      return n2;
    }
    if (endsWith(n2, "vh")) {
      return n2;
    }
    if (endsWith(n2, "vw")) {
      return n2;
    }
    if (endsWith(n2, "vmax")) {
      return n2;
    }
    if (endsWith(n2, "vmin")) {
      return n2;
    }
    return n2 + "px";
  });
  var getPixelSize = function(size, parentSize, innerWidth2, innerHeight2) {
    if (size && typeof size === "string") {
      if (endsWith(size, "px")) {
        return Number(size.replace("px", ""));
      }
      if (endsWith(size, "%")) {
        var ratio = Number(size.replace("%", "")) / 100;
        return parentSize * ratio;
      }
      if (endsWith(size, "vw")) {
        var ratio = Number(size.replace("vw", "")) / 100;
        return innerWidth2 * ratio;
      }
      if (endsWith(size, "vh")) {
        var ratio = Number(size.replace("vh", "")) / 100;
        return innerHeight2 * ratio;
      }
    }
    return size;
  };
  var calculateNewMax = src.exports(function(parentSize, innerWidth2, innerHeight2, maxWidth2, maxHeight2, minWidth2, minHeight2) {
    maxWidth2 = getPixelSize(maxWidth2, parentSize.width, innerWidth2, innerHeight2);
    maxHeight2 = getPixelSize(maxHeight2, parentSize.height, innerWidth2, innerHeight2);
    minWidth2 = getPixelSize(minWidth2, parentSize.width, innerWidth2, innerHeight2);
    minHeight2 = getPixelSize(minHeight2, parentSize.height, innerWidth2, innerHeight2);
    return {
      maxWidth: typeof maxWidth2 === "undefined" ? void 0 : Number(maxWidth2),
      maxHeight: typeof maxHeight2 === "undefined" ? void 0 : Number(maxHeight2),
      minWidth: typeof minWidth2 === "undefined" ? void 0 : Number(minWidth2),
      minHeight: typeof minHeight2 === "undefined" ? void 0 : Number(minHeight2)
    };
  });
  var definedProps = ["as", "style", "className", "grid", "snap", "bounds", "boundsByDirection", "size", "defaultSize", "minWidth", "minHeight", "maxWidth", "maxHeight", "lockAspectRatio", "lockAspectRatioExtraWidth", "lockAspectRatioExtraHeight", "enable", "handleStyles", "handleClasses", "handleWrapperStyle", "handleWrapperClass", "children", "onResizeStart", "onResize", "onResizeStop", "handleComponent", "scale", "resizeRatio", "snapGap"];
  var baseClassName = "__resizable_base__";
  var Resizable = function(_super) {
    __extends$1(Resizable2, _super);
    function Resizable2(props) {
      var _this = _super.call(this, props) || this;
      _this.ratio = 1;
      _this.resizable = null;
      _this.parentLeft = 0;
      _this.parentTop = 0;
      _this.resizableLeft = 0;
      _this.resizableRight = 0;
      _this.resizableTop = 0;
      _this.resizableBottom = 0;
      _this.targetLeft = 0;
      _this.targetTop = 0;
      _this.appendBase = function() {
        if (!_this.resizable || !_this.window) {
          return null;
        }
        var parent = _this.parentNode;
        if (!parent) {
          return null;
        }
        var element = _this.window.document.createElement("div");
        element.style.width = "100%";
        element.style.height = "100%";
        element.style.position = "absolute";
        element.style.transform = "scale(0, 0)";
        element.style.left = "0";
        element.style.flex = "0 0 100%";
        if (element.classList) {
          element.classList.add(baseClassName);
        } else {
          element.className += baseClassName;
        }
        parent.appendChild(element);
        return element;
      };
      _this.removeBase = function(base) {
        var parent = _this.parentNode;
        if (!parent) {
          return;
        }
        parent.removeChild(base);
      };
      _this.ref = function(c2) {
        if (c2) {
          _this.resizable = c2;
        }
      };
      _this.state = {
        isResizing: false,
        width: typeof (_this.propsSize && _this.propsSize.width) === "undefined" ? "auto" : _this.propsSize && _this.propsSize.width,
        height: typeof (_this.propsSize && _this.propsSize.height) === "undefined" ? "auto" : _this.propsSize && _this.propsSize.height,
        direction: "right",
        original: {
          x: 0,
          y: 0,
          width: 0,
          height: 0
        },
        backgroundStyle: {
          height: "100%",
          width: "100%",
          backgroundColor: "rgba(0,0,0,0)",
          cursor: "auto",
          opacity: 0,
          position: "fixed",
          zIndex: 9999,
          top: "0",
          left: "0",
          bottom: "0",
          right: "0"
        },
        flexBasis: void 0
      };
      _this.onResizeStart = _this.onResizeStart.bind(_this);
      _this.onMouseMove = _this.onMouseMove.bind(_this);
      _this.onMouseUp = _this.onMouseUp.bind(_this);
      return _this;
    }
    Object.defineProperty(Resizable2.prototype, "parentNode", {
      get: function() {
        if (!this.resizable) {
          return null;
        }
        return this.resizable.parentNode;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Resizable2.prototype, "window", {
      get: function() {
        if (!this.resizable) {
          return null;
        }
        if (!this.resizable.ownerDocument) {
          return null;
        }
        return this.resizable.ownerDocument.defaultView;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Resizable2.prototype, "propsSize", {
      get: function() {
        return this.props.size || this.props.defaultSize || DEFAULT_SIZE;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Resizable2.prototype, "size", {
      get: function() {
        var width2 = 0;
        var height2 = 0;
        if (this.resizable && this.window) {
          var orgWidth = this.resizable.offsetWidth;
          var orgHeight = this.resizable.offsetHeight;
          var orgPosition = this.resizable.style.position;
          if (orgPosition !== "relative") {
            this.resizable.style.position = "relative";
          }
          width2 = this.resizable.style.width !== "auto" ? this.resizable.offsetWidth : orgWidth;
          height2 = this.resizable.style.height !== "auto" ? this.resizable.offsetHeight : orgHeight;
          this.resizable.style.position = orgPosition;
        }
        return {
          width: width2,
          height: height2
        };
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Resizable2.prototype, "sizeStyle", {
      get: function() {
        var _this = this;
        var size = this.props.size;
        var getSize = function(key) {
          if (typeof _this.state[key] === "undefined" || _this.state[key] === "auto") {
            return "auto";
          }
          if (_this.propsSize && _this.propsSize[key] && endsWith(_this.propsSize[key].toString(), "%")) {
            if (endsWith(_this.state[key].toString(), "%")) {
              return _this.state[key].toString();
            }
            var parentSize = _this.getParentSize();
            var value = Number(_this.state[key].toString().replace("px", ""));
            var percent = value / parentSize[key] * 100;
            return percent + "%";
          }
          return getStringSize(_this.state[key]);
        };
        var width2 = size && typeof size.width !== "undefined" && !this.state.isResizing ? getStringSize(size.width) : getSize("width");
        var height2 = size && typeof size.height !== "undefined" && !this.state.isResizing ? getStringSize(size.height) : getSize("height");
        return {
          width: width2,
          height: height2
        };
      },
      enumerable: false,
      configurable: true
    });
    Resizable2.prototype.getParentSize = function() {
      if (!this.parentNode) {
        if (!this.window) {
          return {
            width: 0,
            height: 0
          };
        }
        return {
          width: this.window.innerWidth,
          height: this.window.innerHeight
        };
      }
      var base = this.appendBase();
      if (!base) {
        return {
          width: 0,
          height: 0
        };
      }
      var wrapChanged = false;
      var wrap = this.parentNode.style.flexWrap;
      if (wrap !== "wrap") {
        wrapChanged = true;
        this.parentNode.style.flexWrap = "wrap";
      }
      base.style.position = "relative";
      base.style.minWidth = "100%";
      base.style.minHeight = "100%";
      var size = {
        width: base.offsetWidth,
        height: base.offsetHeight
      };
      if (wrapChanged) {
        this.parentNode.style.flexWrap = wrap;
      }
      this.removeBase(base);
      return size;
    };
    Resizable2.prototype.bindEvents = function() {
      if (this.window) {
        this.window.addEventListener("mouseup", this.onMouseUp);
        this.window.addEventListener("mousemove", this.onMouseMove);
        this.window.addEventListener("mouseleave", this.onMouseUp);
        this.window.addEventListener("touchmove", this.onMouseMove, {
          capture: true,
          passive: false
        });
        this.window.addEventListener("touchend", this.onMouseUp);
      }
    };
    Resizable2.prototype.unbindEvents = function() {
      if (this.window) {
        this.window.removeEventListener("mouseup", this.onMouseUp);
        this.window.removeEventListener("mousemove", this.onMouseMove);
        this.window.removeEventListener("mouseleave", this.onMouseUp);
        this.window.removeEventListener("touchmove", this.onMouseMove, true);
        this.window.removeEventListener("touchend", this.onMouseUp);
      }
    };
    Resizable2.prototype.componentDidMount = function() {
      if (!this.resizable || !this.window) {
        return;
      }
      var computedStyle = this.window.getComputedStyle(this.resizable);
      this.setState({
        width: this.state.width || this.size.width,
        height: this.state.height || this.size.height,
        flexBasis: computedStyle.flexBasis !== "auto" ? computedStyle.flexBasis : void 0
      });
    };
    Resizable2.prototype.componentWillUnmount = function() {
      if (this.window) {
        this.unbindEvents();
      }
    };
    Resizable2.prototype.createSizeForCssProperty = function(newSize, kind) {
      var propsSize = this.propsSize && this.propsSize[kind];
      return this.state[kind] === "auto" && this.state.original[kind] === newSize && (typeof propsSize === "undefined" || propsSize === "auto") ? "auto" : newSize;
    };
    Resizable2.prototype.calculateNewMaxFromBoundary = function(maxWidth2, maxHeight2) {
      var boundsByDirection = this.props.boundsByDirection;
      var direction = this.state.direction;
      var widthByDirection = boundsByDirection && hasDirection("left", direction);
      var heightByDirection = boundsByDirection && hasDirection("top", direction);
      var boundWidth;
      var boundHeight;
      if (this.props.bounds === "parent") {
        var parent_1 = this.parentNode;
        if (parent_1) {
          boundWidth = widthByDirection ? this.resizableRight - this.parentLeft : parent_1.offsetWidth + (this.parentLeft - this.resizableLeft);
          boundHeight = heightByDirection ? this.resizableBottom - this.parentTop : parent_1.offsetHeight + (this.parentTop - this.resizableTop);
        }
      } else if (this.props.bounds === "window") {
        if (this.window) {
          boundWidth = widthByDirection ? this.resizableRight : this.window.innerWidth - this.resizableLeft;
          boundHeight = heightByDirection ? this.resizableBottom : this.window.innerHeight - this.resizableTop;
        }
      } else if (this.props.bounds) {
        boundWidth = widthByDirection ? this.resizableRight - this.targetLeft : this.props.bounds.offsetWidth + (this.targetLeft - this.resizableLeft);
        boundHeight = heightByDirection ? this.resizableBottom - this.targetTop : this.props.bounds.offsetHeight + (this.targetTop - this.resizableTop);
      }
      if (boundWidth && Number.isFinite(boundWidth)) {
        maxWidth2 = maxWidth2 && maxWidth2 < boundWidth ? maxWidth2 : boundWidth;
      }
      if (boundHeight && Number.isFinite(boundHeight)) {
        maxHeight2 = maxHeight2 && maxHeight2 < boundHeight ? maxHeight2 : boundHeight;
      }
      return {
        maxWidth: maxWidth2,
        maxHeight: maxHeight2
      };
    };
    Resizable2.prototype.calculateNewSizeFromDirection = function(clientX, clientY) {
      var scale = this.props.scale || 1;
      var resizeRatio = this.props.resizeRatio || 1;
      var _a = this.state, direction = _a.direction, original = _a.original;
      var _b = this.props, lockAspectRatio = _b.lockAspectRatio, lockAspectRatioExtraHeight = _b.lockAspectRatioExtraHeight, lockAspectRatioExtraWidth = _b.lockAspectRatioExtraWidth;
      var newWidth = original.width;
      var newHeight = original.height;
      var extraHeight = lockAspectRatioExtraHeight || 0;
      var extraWidth = lockAspectRatioExtraWidth || 0;
      if (hasDirection("right", direction)) {
        newWidth = original.width + (clientX - original.x) * resizeRatio / scale;
        if (lockAspectRatio) {
          newHeight = (newWidth - extraWidth) / this.ratio + extraHeight;
        }
      }
      if (hasDirection("left", direction)) {
        newWidth = original.width - (clientX - original.x) * resizeRatio / scale;
        if (lockAspectRatio) {
          newHeight = (newWidth - extraWidth) / this.ratio + extraHeight;
        }
      }
      if (hasDirection("bottom", direction)) {
        newHeight = original.height + (clientY - original.y) * resizeRatio / scale;
        if (lockAspectRatio) {
          newWidth = (newHeight - extraHeight) * this.ratio + extraWidth;
        }
      }
      if (hasDirection("top", direction)) {
        newHeight = original.height - (clientY - original.y) * resizeRatio / scale;
        if (lockAspectRatio) {
          newWidth = (newHeight - extraHeight) * this.ratio + extraWidth;
        }
      }
      return {
        newWidth,
        newHeight
      };
    };
    Resizable2.prototype.calculateNewSizeFromAspectRatio = function(newWidth, newHeight, max2, min2) {
      var _a = this.props, lockAspectRatio = _a.lockAspectRatio, lockAspectRatioExtraHeight = _a.lockAspectRatioExtraHeight, lockAspectRatioExtraWidth = _a.lockAspectRatioExtraWidth;
      var computedMinWidth = typeof min2.width === "undefined" ? 10 : min2.width;
      var computedMaxWidth = typeof max2.width === "undefined" || max2.width < 0 ? newWidth : max2.width;
      var computedMinHeight = typeof min2.height === "undefined" ? 10 : min2.height;
      var computedMaxHeight = typeof max2.height === "undefined" || max2.height < 0 ? newHeight : max2.height;
      var extraHeight = lockAspectRatioExtraHeight || 0;
      var extraWidth = lockAspectRatioExtraWidth || 0;
      if (lockAspectRatio) {
        var extraMinWidth = (computedMinHeight - extraHeight) * this.ratio + extraWidth;
        var extraMaxWidth = (computedMaxHeight - extraHeight) * this.ratio + extraWidth;
        var extraMinHeight = (computedMinWidth - extraWidth) / this.ratio + extraHeight;
        var extraMaxHeight = (computedMaxWidth - extraWidth) / this.ratio + extraHeight;
        var lockedMinWidth = Math.max(computedMinWidth, extraMinWidth);
        var lockedMaxWidth = Math.min(computedMaxWidth, extraMaxWidth);
        var lockedMinHeight = Math.max(computedMinHeight, extraMinHeight);
        var lockedMaxHeight = Math.min(computedMaxHeight, extraMaxHeight);
        newWidth = clamp(newWidth, lockedMinWidth, lockedMaxWidth);
        newHeight = clamp(newHeight, lockedMinHeight, lockedMaxHeight);
      } else {
        newWidth = clamp(newWidth, computedMinWidth, computedMaxWidth);
        newHeight = clamp(newHeight, computedMinHeight, computedMaxHeight);
      }
      return {
        newWidth,
        newHeight
      };
    };
    Resizable2.prototype.setBoundingClientRect = function() {
      if (this.props.bounds === "parent") {
        var parent_2 = this.parentNode;
        if (parent_2) {
          var parentRect = parent_2.getBoundingClientRect();
          this.parentLeft = parentRect.left;
          this.parentTop = parentRect.top;
        }
      }
      if (this.props.bounds && typeof this.props.bounds !== "string") {
        var targetRect = this.props.bounds.getBoundingClientRect();
        this.targetLeft = targetRect.left;
        this.targetTop = targetRect.top;
      }
      if (this.resizable) {
        var _a = this.resizable.getBoundingClientRect(), left2 = _a.left, top_1 = _a.top, right2 = _a.right, bottom2 = _a.bottom;
        this.resizableLeft = left2;
        this.resizableRight = right2;
        this.resizableTop = top_1;
        this.resizableBottom = bottom2;
      }
    };
    Resizable2.prototype.onResizeStart = function(event, direction) {
      if (!this.resizable || !this.window) {
        return;
      }
      var clientX = 0;
      var clientY = 0;
      if (event.nativeEvent && isMouseEvent(event.nativeEvent)) {
        clientX = event.nativeEvent.clientX;
        clientY = event.nativeEvent.clientY;
      } else if (event.nativeEvent && isTouchEvent(event.nativeEvent)) {
        clientX = event.nativeEvent.touches[0].clientX;
        clientY = event.nativeEvent.touches[0].clientY;
      }
      if (this.props.onResizeStart) {
        if (this.resizable) {
          var startResize = this.props.onResizeStart(event, direction, this.resizable);
          if (startResize === false) {
            return;
          }
        }
      }
      if (this.props.size) {
        if (typeof this.props.size.height !== "undefined" && this.props.size.height !== this.state.height) {
          this.setState({
            height: this.props.size.height
          });
        }
        if (typeof this.props.size.width !== "undefined" && this.props.size.width !== this.state.width) {
          this.setState({
            width: this.props.size.width
          });
        }
      }
      this.ratio = typeof this.props.lockAspectRatio === "number" ? this.props.lockAspectRatio : this.size.width / this.size.height;
      var flexBasis2;
      var computedStyle = this.window.getComputedStyle(this.resizable);
      if (computedStyle.flexBasis !== "auto") {
        var parent_3 = this.parentNode;
        if (parent_3) {
          var dir = this.window.getComputedStyle(parent_3).flexDirection;
          this.flexDir = dir.startsWith("row") ? "row" : "column";
          flexBasis2 = computedStyle.flexBasis;
        }
      }
      this.setBoundingClientRect();
      this.bindEvents();
      var state = {
        original: {
          x: clientX,
          y: clientY,
          width: this.size.width,
          height: this.size.height
        },
        isResizing: true,
        backgroundStyle: __assign$1(__assign$1({}, this.state.backgroundStyle), {
          cursor: this.window.getComputedStyle(event.target).cursor || "auto"
        }),
        direction,
        flexBasis: flexBasis2
      };
      this.setState(state);
    };
    Resizable2.prototype.onMouseMove = function(event) {
      if (!this.state.isResizing || !this.resizable || !this.window) {
        return;
      }
      if (this.window.TouchEvent && isTouchEvent(event)) {
        try {
          event.preventDefault();
          event.stopPropagation();
        } catch (e2) {
        }
      }
      var _a = this.props, maxWidth2 = _a.maxWidth, maxHeight2 = _a.maxHeight, minWidth2 = _a.minWidth, minHeight2 = _a.minHeight;
      var clientX = isTouchEvent(event) ? event.touches[0].clientX : event.clientX;
      var clientY = isTouchEvent(event) ? event.touches[0].clientY : event.clientY;
      var _b = this.state, direction = _b.direction, original = _b.original, width2 = _b.width, height2 = _b.height;
      var parentSize = this.getParentSize();
      var max2 = calculateNewMax(parentSize, this.window.innerWidth, this.window.innerHeight, maxWidth2, maxHeight2, minWidth2, minHeight2);
      maxWidth2 = max2.maxWidth;
      maxHeight2 = max2.maxHeight;
      minWidth2 = max2.minWidth;
      minHeight2 = max2.minHeight;
      var _c = this.calculateNewSizeFromDirection(clientX, clientY), newHeight = _c.newHeight, newWidth = _c.newWidth;
      var boundaryMax = this.calculateNewMaxFromBoundary(maxWidth2, maxHeight2);
      if (this.props.snap && this.props.snap.x) {
        newWidth = findClosestSnap(newWidth, this.props.snap.x, this.props.snapGap);
      }
      if (this.props.snap && this.props.snap.y) {
        newHeight = findClosestSnap(newHeight, this.props.snap.y, this.props.snapGap);
      }
      var newSize = this.calculateNewSizeFromAspectRatio(newWidth, newHeight, {
        width: boundaryMax.maxWidth,
        height: boundaryMax.maxHeight
      }, {
        width: minWidth2,
        height: minHeight2
      });
      newWidth = newSize.newWidth;
      newHeight = newSize.newHeight;
      if (this.props.grid) {
        var newGridWidth = snap(newWidth, this.props.grid[0]);
        var newGridHeight = snap(newHeight, this.props.grid[1]);
        var gap2 = this.props.snapGap || 0;
        newWidth = gap2 === 0 || Math.abs(newGridWidth - newWidth) <= gap2 ? newGridWidth : newWidth;
        newHeight = gap2 === 0 || Math.abs(newGridHeight - newHeight) <= gap2 ? newGridHeight : newHeight;
      }
      var delta = {
        width: newWidth - original.width,
        height: newHeight - original.height
      };
      if (width2 && typeof width2 === "string") {
        if (endsWith(width2, "%")) {
          var percent = newWidth / parentSize.width * 100;
          newWidth = percent + "%";
        } else if (endsWith(width2, "vw")) {
          var vw = newWidth / this.window.innerWidth * 100;
          newWidth = vw + "vw";
        } else if (endsWith(width2, "vh")) {
          var vh2 = newWidth / this.window.innerHeight * 100;
          newWidth = vh2 + "vh";
        }
      }
      if (height2 && typeof height2 === "string") {
        if (endsWith(height2, "%")) {
          var percent = newHeight / parentSize.height * 100;
          newHeight = percent + "%";
        } else if (endsWith(height2, "vw")) {
          var vw = newHeight / this.window.innerWidth * 100;
          newHeight = vw + "vw";
        } else if (endsWith(height2, "vh")) {
          var vh2 = newHeight / this.window.innerHeight * 100;
          newHeight = vh2 + "vh";
        }
      }
      var newState = {
        width: this.createSizeForCssProperty(newWidth, "width"),
        height: this.createSizeForCssProperty(newHeight, "height")
      };
      if (this.flexDir === "row") {
        newState.flexBasis = newState.width;
      } else if (this.flexDir === "column") {
        newState.flexBasis = newState.height;
      }
      this.setState(newState);
      if (this.props.onResize) {
        this.props.onResize(event, direction, this.resizable, delta);
      }
    };
    Resizable2.prototype.onMouseUp = function(event) {
      var _a = this.state, isResizing = _a.isResizing, direction = _a.direction, original = _a.original;
      if (!isResizing || !this.resizable) {
        return;
      }
      var delta = {
        width: this.size.width - original.width,
        height: this.size.height - original.height
      };
      if (this.props.onResizeStop) {
        this.props.onResizeStop(event, direction, this.resizable, delta);
      }
      if (this.props.size) {
        this.setState(this.props.size);
      }
      this.unbindEvents();
      this.setState({
        isResizing: false,
        backgroundStyle: __assign$1(__assign$1({}, this.state.backgroundStyle), {
          cursor: "auto"
        })
      });
    };
    Resizable2.prototype.updateSize = function(size) {
      this.setState({
        width: size.width,
        height: size.height
      });
    };
    Resizable2.prototype.renderResizer = function() {
      var _this = this;
      var _a = this.props, enable = _a.enable, handleStyles = _a.handleStyles, handleClasses = _a.handleClasses, handleWrapperStyle = _a.handleWrapperStyle, handleWrapperClass = _a.handleWrapperClass, handleComponent = _a.handleComponent;
      if (!enable) {
        return null;
      }
      var resizers = Object.keys(enable).map(function(dir) {
        if (enable[dir] !== false) {
          return /* @__PURE__ */ jsx(Resizer, {
            direction: dir,
            onResizeStart: _this.onResizeStart,
            replaceStyles: handleStyles && handleStyles[dir],
            className: handleClasses && handleClasses[dir],
            children: handleComponent && handleComponent[dir] ? handleComponent[dir] : null
          }, dir);
        }
        return null;
      });
      return /* @__PURE__ */ jsx("div", {
        className: handleWrapperClass,
        style: handleWrapperStyle,
        children: resizers
      });
    };
    Resizable2.prototype.render = function() {
      var _this = this;
      var extendsProps = Object.keys(this.props).reduce(function(acc, key) {
        if (definedProps.indexOf(key) !== -1) {
          return acc;
        }
        acc[key] = _this.props[key];
        return acc;
      }, {});
      var style2 = __assign$1(__assign$1(__assign$1({
        position: "relative",
        userSelect: this.state.isResizing ? "none" : "auto"
      }, this.props.style), this.sizeStyle), {
        maxWidth: this.props.maxWidth,
        maxHeight: this.props.maxHeight,
        minWidth: this.props.minWidth,
        minHeight: this.props.minHeight,
        boxSizing: "border-box",
        flexShrink: 0
      });
      if (this.state.flexBasis) {
        style2.flexBasis = this.state.flexBasis;
      }
      var Wrapper = this.props.as || "div";
      return /* @__PURE__ */ jsxs(Wrapper, {
        ...__assign$1({
          ref: this.ref,
          style: style2,
          className: this.props.className
        }, extendsProps),
        children: [this.state.isResizing && /* @__PURE__ */ jsx("div", {
          style: this.state.backgroundStyle
        }), this.props.children, this.renderResizer()]
      });
    };
    Resizable2.defaultProps = {
      as: "div",
      onResizeStart: function() {
      },
      onResize: function() {
      },
      onResizeStop: function() {
      },
      enable: {
        top: true,
        right: true,
        bottom: true,
        left: true,
        topRight: true,
        bottomRight: true,
        bottomLeft: true,
        topLeft: true
      },
      style: {},
      grid: [1, 1],
      lockAspectRatio: false,
      lockAspectRatioExtraWidth: 0,
      lockAspectRatioExtraHeight: 0,
      scale: 1,
      resizeRatio: 1,
      snapGap: 0
    };
    return Resizable2;
  }(react.exports.PureComponent);
  /*! *****************************************************************************
  	Copyright (c) Microsoft Corporation. All rights reserved.
  	Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  	this file except in compliance with the License. You may obtain a copy of the
  	License at http://www.apache.org/licenses/LICENSE-2.0
  
  	THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  	KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  	WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  	MERCHANTABLITY OR NON-INFRINGEMENT.
  
  	See the Apache Version 2.0 License for specific language governing permissions
  	and limitations under the License.
  	***************************************************************************** */
  var extendStatics = function(d2, b2) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b3) {
      d3.__proto__ = b3;
    } || function(d3, b3) {
      for (var p2 in b3)
        if (b3.hasOwnProperty(p2))
          d3[p2] = b3[p2];
    };
    return extendStatics(d2, b2);
  };
  function __extends(d2, b2) {
    extendStatics(d2, b2);
    function __() {
      this.constructor = d2;
    }
    d2.prototype = b2 === null ? Object.create(b2) : (__.prototype = b2.prototype, new __());
  }
  var __assign = function() {
    __assign = Object.assign || function __assign2(t2) {
      for (var s, i = 1, n2 = arguments.length; i < n2; i++) {
        s = arguments[i];
        for (var p2 in s)
          if (Object.prototype.hasOwnProperty.call(s, p2))
            t2[p2] = s[p2];
      }
      return t2;
    };
    return __assign.apply(this, arguments);
  };
  function __rest(s, e2) {
    var t2 = {};
    for (var p2 in s)
      if (Object.prototype.hasOwnProperty.call(s, p2) && e2.indexOf(p2) < 0)
        t2[p2] = s[p2];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
      for (var i = 0, p2 = Object.getOwnPropertySymbols(s); i < p2.length; i++) {
        if (e2.indexOf(p2[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p2[i]))
          t2[p2[i]] = s[p2[i]];
      }
    return t2;
  }
  var Draggable = cjs.exports;
  var resizableStyle = {
    width: "auto",
    height: "auto",
    display: "inline-block",
    position: "absolute",
    top: 0,
    left: 0
  };
  var getEnableResizingByFlag = function(flag) {
    return {
      bottom: flag,
      bottomLeft: flag,
      bottomRight: flag,
      left: flag,
      right: flag,
      top: flag,
      topLeft: flag,
      topRight: flag
    };
  };
  var Rnd = function(_super) {
    __extends(Rnd2, _super);
    function Rnd2(props) {
      var _this = _super.call(this, props) || this;
      _this.resizingPosition = { x: 0, y: 0 };
      _this.offsetFromParent = { left: 0, top: 0 };
      _this.resizableElement = { current: null };
      _this.originalPosition = { x: 0, y: 0 };
      _this.refDraggable = function(c2) {
        if (!c2)
          return;
        _this.draggable = c2;
      };
      _this.refResizable = function(c2) {
        if (!c2)
          return;
        _this.resizable = c2;
        _this.resizableElement.current = c2.resizable;
      };
      _this.state = {
        resizing: false,
        bounds: {
          top: 0,
          right: 0,
          bottom: 0,
          left: 0
        },
        maxWidth: props.maxWidth,
        maxHeight: props.maxHeight
      };
      _this.onResizeStart = _this.onResizeStart.bind(_this);
      _this.onResize = _this.onResize.bind(_this);
      _this.onResizeStop = _this.onResizeStop.bind(_this);
      _this.onDragStart = _this.onDragStart.bind(_this);
      _this.onDrag = _this.onDrag.bind(_this);
      _this.onDragStop = _this.onDragStop.bind(_this);
      _this.getMaxSizesFromProps = _this.getMaxSizesFromProps.bind(_this);
      return _this;
    }
    Rnd2.prototype.componentDidMount = function() {
      this.updateOffsetFromParent();
      var _a = this.offsetFromParent, left2 = _a.left, top2 = _a.top;
      var _b = this.getDraggablePosition(), x2 = _b.x, y2 = _b.y;
      this.draggable.setState({
        x: x2 - left2,
        y: y2 - top2
      });
      this.forceUpdate();
    };
    Rnd2.prototype.getDraggablePosition = function() {
      var _a = this.draggable.state, x2 = _a.x, y2 = _a.y;
      return { x: x2, y: y2 };
    };
    Rnd2.prototype.getParent = function() {
      return this.resizable && this.resizable.parentNode;
    };
    Rnd2.prototype.getParentSize = function() {
      return this.resizable.getParentSize();
    };
    Rnd2.prototype.getMaxSizesFromProps = function() {
      var maxWidth2 = typeof this.props.maxWidth === "undefined" ? Number.MAX_SAFE_INTEGER : this.props.maxWidth;
      var maxHeight2 = typeof this.props.maxHeight === "undefined" ? Number.MAX_SAFE_INTEGER : this.props.maxHeight;
      return { maxWidth: maxWidth2, maxHeight: maxHeight2 };
    };
    Rnd2.prototype.getSelfElement = function() {
      return this.resizable && this.resizable.resizable;
    };
    Rnd2.prototype.getOffsetHeight = function(boundary) {
      var scale = this.props.scale;
      switch (this.props.bounds) {
        case "window":
          return window.innerHeight / scale;
        case "body":
          return document.body.offsetHeight / scale;
        default:
          return boundary.offsetHeight;
      }
    };
    Rnd2.prototype.getOffsetWidth = function(boundary) {
      var scale = this.props.scale;
      switch (this.props.bounds) {
        case "window":
          return window.innerWidth / scale;
        case "body":
          return document.body.offsetWidth / scale;
        default:
          return boundary.offsetWidth;
      }
    };
    Rnd2.prototype.onDragStart = function(e2, data) {
      if (this.props.onDragStart) {
        this.props.onDragStart(e2, data);
      }
      var pos = this.getDraggablePosition();
      this.originalPosition = pos;
      if (!this.props.bounds)
        return;
      var parent = this.getParent();
      var scale = this.props.scale;
      var boundary;
      if (this.props.bounds === "parent") {
        boundary = parent;
      } else if (this.props.bounds === "body") {
        var parentRect_1 = parent.getBoundingClientRect();
        var parentLeft_1 = parentRect_1.left;
        var parentTop_1 = parentRect_1.top;
        var bodyRect = document.body.getBoundingClientRect();
        var left_1 = -(parentLeft_1 - parent.offsetLeft * scale - bodyRect.left) / scale;
        var top_1 = -(parentTop_1 - parent.offsetTop * scale - bodyRect.top) / scale;
        var right2 = (document.body.offsetWidth - this.resizable.size.width * scale) / scale + left_1;
        var bottom2 = (document.body.offsetHeight - this.resizable.size.height * scale) / scale + top_1;
        return this.setState({ bounds: { top: top_1, right: right2, bottom: bottom2, left: left_1 } });
      } else if (this.props.bounds === "window") {
        if (!this.resizable)
          return;
        var parentRect_2 = parent.getBoundingClientRect();
        var parentLeft_2 = parentRect_2.left;
        var parentTop_2 = parentRect_2.top;
        var left_2 = -(parentLeft_2 - parent.offsetLeft * scale) / scale;
        var top_2 = -(parentTop_2 - parent.offsetTop * scale) / scale;
        var right2 = (window.innerWidth - this.resizable.size.width * scale) / scale + left_2;
        var bottom2 = (window.innerHeight - this.resizable.size.height * scale) / scale + top_2;
        return this.setState({ bounds: { top: top_2, right: right2, bottom: bottom2, left: left_2 } });
      } else {
        boundary = document.querySelector(this.props.bounds);
      }
      if (!(boundary instanceof HTMLElement) || !(parent instanceof HTMLElement)) {
        return;
      }
      var boundaryRect = boundary.getBoundingClientRect();
      var boundaryLeft = boundaryRect.left;
      var boundaryTop = boundaryRect.top;
      var parentRect = parent.getBoundingClientRect();
      var parentLeft = parentRect.left;
      var parentTop = parentRect.top;
      var left2 = (boundaryLeft - parentLeft) / scale;
      var top2 = boundaryTop - parentTop;
      if (!this.resizable)
        return;
      this.updateOffsetFromParent();
      var offset2 = this.offsetFromParent;
      this.setState({
        bounds: {
          top: top2 - offset2.top,
          right: left2 + (boundary.offsetWidth - this.resizable.size.width) - offset2.left / scale,
          bottom: top2 + (boundary.offsetHeight - this.resizable.size.height) - offset2.top,
          left: left2 - offset2.left / scale
        }
      });
    };
    Rnd2.prototype.onDrag = function(e2, data) {
      if (!this.props.onDrag)
        return;
      var _a = this.offsetFromParent, left2 = _a.left, top2 = _a.top;
      if (!this.props.dragAxis || this.props.dragAxis === "both") {
        return this.props.onDrag(e2, __assign(__assign({}, data), { x: data.x - left2, y: data.y - top2 }));
      } else if (this.props.dragAxis === "x") {
        return this.props.onDrag(e2, __assign(__assign({}, data), { x: data.x + left2, y: this.originalPosition.y + top2, deltaY: 0 }));
      } else if (this.props.dragAxis === "y") {
        return this.props.onDrag(e2, __assign(__assign({}, data), { x: this.originalPosition.x + left2, y: data.y + top2, deltaX: 0 }));
      }
    };
    Rnd2.prototype.onDragStop = function(e2, data) {
      if (!this.props.onDragStop)
        return;
      var _a = this.offsetFromParent, left2 = _a.left, top2 = _a.top;
      if (!this.props.dragAxis || this.props.dragAxis === "both") {
        return this.props.onDragStop(e2, __assign(__assign({}, data), { x: data.x + left2, y: data.y + top2 }));
      } else if (this.props.dragAxis === "x") {
        return this.props.onDragStop(e2, __assign(__assign({}, data), { x: data.x + left2, y: this.originalPosition.y + top2, deltaY: 0 }));
      } else if (this.props.dragAxis === "y") {
        return this.props.onDragStop(e2, __assign(__assign({}, data), { x: this.originalPosition.x + left2, y: data.y + top2, deltaX: 0 }));
      }
    };
    Rnd2.prototype.onResizeStart = function(e2, dir, elementRef) {
      e2.stopPropagation();
      this.setState({
        resizing: true
      });
      var scale = this.props.scale;
      var offset2 = this.offsetFromParent;
      var pos = this.getDraggablePosition();
      this.resizingPosition = { x: pos.x + offset2.left, y: pos.y + offset2.top };
      this.originalPosition = pos;
      if (this.props.bounds) {
        var parent_1 = this.getParent();
        var boundary = void 0;
        if (this.props.bounds === "parent") {
          boundary = parent_1;
        } else if (this.props.bounds === "body") {
          boundary = document.body;
        } else if (this.props.bounds === "window") {
          boundary = window;
        } else {
          boundary = document.querySelector(this.props.bounds);
        }
        var self_1 = this.getSelfElement();
        if (self_1 instanceof Element && (boundary instanceof HTMLElement || boundary === window) && parent_1 instanceof HTMLElement) {
          var _a = this.getMaxSizesFromProps(), maxWidth2 = _a.maxWidth, maxHeight2 = _a.maxHeight;
          var parentSize = this.getParentSize();
          if (maxWidth2 && typeof maxWidth2 === "string") {
            if (maxWidth2.endsWith("%")) {
              var ratio = Number(maxWidth2.replace("%", "")) / 100;
              maxWidth2 = parentSize.width * ratio;
            } else if (maxWidth2.endsWith("px")) {
              maxWidth2 = Number(maxWidth2.replace("px", ""));
            }
          }
          if (maxHeight2 && typeof maxHeight2 === "string") {
            if (maxHeight2.endsWith("%")) {
              var ratio = Number(maxHeight2.replace("%", "")) / 100;
              maxHeight2 = parentSize.width * ratio;
            } else if (maxHeight2.endsWith("px")) {
              maxHeight2 = Number(maxHeight2.replace("px", ""));
            }
          }
          var selfRect = self_1.getBoundingClientRect();
          var selfLeft = selfRect.left;
          var selfTop = selfRect.top;
          var boundaryRect = this.props.bounds === "window" ? { left: 0, top: 0 } : boundary.getBoundingClientRect();
          var boundaryLeft = boundaryRect.left;
          var boundaryTop = boundaryRect.top;
          var offsetWidth = this.getOffsetWidth(boundary);
          var offsetHeight = this.getOffsetHeight(boundary);
          var hasLeft = dir.toLowerCase().endsWith("left");
          var hasRight = dir.toLowerCase().endsWith("right");
          var hasTop = dir.startsWith("top");
          var hasBottom = dir.startsWith("bottom");
          if ((hasLeft || hasTop) && this.resizable) {
            var max2 = (selfLeft - boundaryLeft) / scale + this.resizable.size.width;
            this.setState({ maxWidth: max2 > Number(maxWidth2) ? maxWidth2 : max2 });
          }
          if (hasRight || this.props.lockAspectRatio && !hasLeft && !hasTop) {
            var max2 = offsetWidth + (boundaryLeft - selfLeft) / scale;
            this.setState({ maxWidth: max2 > Number(maxWidth2) ? maxWidth2 : max2 });
          }
          if ((hasTop || hasLeft) && this.resizable) {
            var max2 = (selfTop - boundaryTop) / scale + this.resizable.size.height;
            this.setState({
              maxHeight: max2 > Number(maxHeight2) ? maxHeight2 : max2
            });
          }
          if (hasBottom || this.props.lockAspectRatio && !hasTop && !hasLeft) {
            var max2 = offsetHeight + (boundaryTop - selfTop) / scale;
            this.setState({
              maxHeight: max2 > Number(maxHeight2) ? maxHeight2 : max2
            });
          }
        }
      } else {
        this.setState({
          maxWidth: this.props.maxWidth,
          maxHeight: this.props.maxHeight
        });
      }
      if (this.props.onResizeStart) {
        this.props.onResizeStart(e2, dir, elementRef);
      }
    };
    Rnd2.prototype.onResize = function(e2, direction, elementRef, delta) {
      var newPos = { x: this.originalPosition.x, y: this.originalPosition.y };
      var left2 = -delta.width;
      var top2 = -delta.height;
      var directions2 = ["top", "left", "topLeft", "bottomLeft", "topRight"];
      if (directions2.indexOf(direction) !== -1) {
        if (direction === "bottomLeft") {
          newPos.x += left2;
        } else if (direction === "topRight") {
          newPos.y += top2;
        } else {
          newPos.x += left2;
          newPos.y += top2;
        }
      }
      if (newPos.x !== this.draggable.state.x || newPos.y !== this.draggable.state.y) {
        this.draggable.setState(newPos);
      }
      this.updateOffsetFromParent();
      var offset2 = this.offsetFromParent;
      var x2 = this.getDraggablePosition().x + offset2.left;
      var y2 = this.getDraggablePosition().y + offset2.top;
      this.resizingPosition = { x: x2, y: y2 };
      if (!this.props.onResize)
        return;
      this.props.onResize(e2, direction, elementRef, delta, {
        x: x2,
        y: y2
      });
    };
    Rnd2.prototype.onResizeStop = function(e2, direction, elementRef, delta) {
      this.setState({
        resizing: false
      });
      var _a = this.getMaxSizesFromProps(), maxWidth2 = _a.maxWidth, maxHeight2 = _a.maxHeight;
      this.setState({ maxWidth: maxWidth2, maxHeight: maxHeight2 });
      if (this.props.onResizeStop) {
        this.props.onResizeStop(e2, direction, elementRef, delta, this.resizingPosition);
      }
    };
    Rnd2.prototype.updateSize = function(size) {
      if (!this.resizable)
        return;
      this.resizable.updateSize({ width: size.width, height: size.height });
    };
    Rnd2.prototype.updatePosition = function(position2) {
      this.draggable.setState(position2);
    };
    Rnd2.prototype.updateOffsetFromParent = function() {
      var scale = this.props.scale;
      var parent = this.getParent();
      var self = this.getSelfElement();
      if (!parent || self === null) {
        return {
          top: 0,
          left: 0
        };
      }
      var parentRect = parent.getBoundingClientRect();
      var parentLeft = parentRect.left;
      var parentTop = parentRect.top;
      var selfRect = self.getBoundingClientRect();
      var position2 = this.getDraggablePosition();
      var scrollLeft = parent.scrollLeft;
      var scrollTop = parent.scrollTop;
      this.offsetFromParent = {
        left: selfRect.left - parentLeft + scrollLeft - position2.x * scale,
        top: selfRect.top - parentTop + scrollTop - position2.y * scale
      };
    };
    Rnd2.prototype.render = function() {
      var _a = this.props, disableDragging = _a.disableDragging, style2 = _a.style, dragHandleClassName = _a.dragHandleClassName, position2 = _a.position, onMouseDown = _a.onMouseDown, onMouseUp = _a.onMouseUp, dragAxis = _a.dragAxis, dragGrid = _a.dragGrid, bounds = _a.bounds, enableUserSelectHack = _a.enableUserSelectHack, cancel = _a.cancel, children = _a.children;
      _a.onResizeStart;
      _a.onResize;
      _a.onResizeStop;
      _a.onDragStart;
      _a.onDrag;
      _a.onDragStop;
      var resizeHandleStyles = _a.resizeHandleStyles, resizeHandleClasses = _a.resizeHandleClasses, resizeHandleComponent = _a.resizeHandleComponent, enableResizing = _a.enableResizing, resizeGrid = _a.resizeGrid, resizeHandleWrapperClass = _a.resizeHandleWrapperClass, resizeHandleWrapperStyle = _a.resizeHandleWrapperStyle, scale = _a.scale, allowAnyClick = _a.allowAnyClick, resizableProps = __rest(_a, ["disableDragging", "style", "dragHandleClassName", "position", "onMouseDown", "onMouseUp", "dragAxis", "dragGrid", "bounds", "enableUserSelectHack", "cancel", "children", "onResizeStart", "onResize", "onResizeStop", "onDragStart", "onDrag", "onDragStop", "resizeHandleStyles", "resizeHandleClasses", "resizeHandleComponent", "enableResizing", "resizeGrid", "resizeHandleWrapperClass", "resizeHandleWrapperStyle", "scale", "allowAnyClick"]);
      var defaultValue = this.props.default ? __assign({}, this.props.default) : void 0;
      delete resizableProps.default;
      var cursorStyle = disableDragging || dragHandleClassName ? { cursor: "auto" } : { cursor: "move" };
      var innerStyle = __assign(__assign(__assign({}, resizableStyle), cursorStyle), style2);
      var _b = this.offsetFromParent, left2 = _b.left, top2 = _b.top;
      var draggablePosition;
      if (position2) {
        draggablePosition = {
          x: position2.x - left2,
          y: position2.y - top2
        };
      }
      var pos = this.state.resizing ? void 0 : draggablePosition;
      var dragAxisOrUndefined = this.state.resizing ? "both" : dragAxis;
      return react.exports.createElement(
        Draggable,
        { ref: this.refDraggable, handle: dragHandleClassName ? ".".concat(dragHandleClassName) : void 0, defaultPosition: defaultValue, onMouseDown, onMouseUp, onStart: this.onDragStart, onDrag: this.onDrag, onStop: this.onDragStop, axis: dragAxisOrUndefined, disabled: disableDragging, grid: dragGrid, bounds: bounds ? this.state.bounds : void 0, position: pos, enableUserSelectHack, cancel, scale, allowAnyClick, nodeRef: this.resizableElement },
        react.exports.createElement(Resizable, __assign({}, resizableProps, { ref: this.refResizable, defaultSize: defaultValue, size: this.props.size, enable: typeof enableResizing === "boolean" ? getEnableResizingByFlag(enableResizing) : enableResizing, onResizeStart: this.onResizeStart, onResize: this.onResize, onResizeStop: this.onResizeStop, style: innerStyle, minWidth: this.props.minWidth, minHeight: this.props.minHeight, maxWidth: this.state.resizing ? this.state.maxWidth : this.props.maxWidth, maxHeight: this.state.resizing ? this.state.maxHeight : this.props.maxHeight, grid: resizeGrid, handleWrapperClass: resizeHandleWrapperClass, handleWrapperStyle: resizeHandleWrapperStyle, lockAspectRatio: this.props.lockAspectRatio, lockAspectRatioExtraWidth: this.props.lockAspectRatioExtraWidth, lockAspectRatioExtraHeight: this.props.lockAspectRatioExtraHeight, handleStyles: resizeHandleStyles, handleClasses: resizeHandleClasses, handleComponent: resizeHandleComponent, scale: this.props.scale }), children)
      );
    };
    Rnd2.defaultProps = {
      maxWidth: Number.MAX_SAFE_INTEGER,
      maxHeight: Number.MAX_SAFE_INTEGER,
      scale: 1,
      onResizeStart: function() {
      },
      onResize: function() {
      },
      onResizeStop: function() {
      },
      onDragStart: function() {
      },
      onDrag: function() {
      },
      onDragStop: function() {
      }
    };
    return Rnd2;
  }(react.exports.PureComponent);
  const DRAG_PARENT = "au-rnd-root";
  const DRAG_HANDLE = "au-rnd-handle";
  const ConsumerWindow = react.exports.memo(({
    open,
    onClose,
    changeMode,
    children
  }) => {
    const {
      pos,
      size
    } = useConsumerState();
    const width2 = react.exports.useMemo(() => {
      return typeof size.width === "number" ? size.width : parseInt(size.width);
    }, [size.width]);
    const dispatch = useConsumerDispatch();
    const handleDragged = react.exports.useCallback((_2, data) => dispatch({
      type: "SET_POS",
      pos: {
        x: data.x,
        y: data.y
      }
    }), [dispatch]);
    const handleReized = react.exports.useCallback((_ev, _dir, ref, _del, pos2) => {
      dispatch({
        type: "SET_SIZE",
        size: {
          width: ref.clientWidth,
          height: ref.clientHeight
        }
      });
      dispatch({
        type: "SET_POS",
        pos: pos2
      });
    }, [dispatch]);
    return !open ? null : reactDom.exports.createPortal(/* @__PURE__ */ jsx(_Root_, {
      id: DRAG_PARENT,
      children: /* @__PURE__ */ jsx(Rnd, {
        bounds: `#${DRAG_PARENT}`,
        position: pos || {
          x: document.body.clientWidth - width2 - 14,
          y: 0
        },
        size,
        minWidth: 300,
        dragHandleClassName: DRAG_HANDLE,
        enableResizing: {
          left: true,
          right: true
        },
        onDragStop: handleDragged,
        onResizeStop: handleReized,
        style: {
          zIndex: 298,
          pointerEvents: "all"
        },
        children: /* @__PURE__ */ jsxs(_Paper_, {
          square: true,
          elevation: 3,
          children: [/* @__PURE__ */ jsxs(Box$1, {
            children: [/* @__PURE__ */ jsx(_Header_, {
              className: DRAG_HANDLE,
              children: /* @__PURE__ */ jsx(default_1$2, {})
            }), /* @__PURE__ */ jsxs(_Buttons_, {
              direction: "row",
              children: [/* @__PURE__ */ jsx(_IconButton_, {
                title: "\u30C0\u30A4\u30A2\u30ED\u30B0\u5316\u3059\u308B",
                onClick: changeMode,
                children: /* @__PURE__ */ jsx(default_1$1, {})
              }), /* @__PURE__ */ jsx(_IconButton_, {
                title: "\u9589\u3058\u308B",
                onClick: onClose,
                children: /* @__PURE__ */ jsx(default_1$4, {})
              })]
            })]
          }), /* @__PURE__ */ jsx(Box$1, {
            padding: "20px 10px 10px",
            children
          })]
        })
      })
    }), document.body);
  });
  ConsumerWindow.displayName = "MovableWindow";
  const _Root_ = styled$1(Box$1)({
    position: "fixed",
    inset: "7px",
    zIndex: 500,
    pointerEvents: "none"
  });
  const _Paper_ = styled$1(Paper$1)(({
    theme
  }) => ({
    border: `1px solid ${theme.palette.grey[300]}`
  }));
  const _Header_ = styled$1(Box$1)(({
    theme
  }) => ({
    backgroundColor: theme.palette.divider,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "move"
  }));
  const _Buttons_ = styled$1(Stack$1)({
    position: "absolute",
    top: 0,
    right: 5
  });
  const _IconButton_ = styled$1(IconButton$1)({
    width: "24px",
    height: "24px"
  });
  const ConsumerView = react.exports.memo(({
    open,
    doClose,
    mode,
    changeMode
  }) => {
    const dispatch = useConsumerDispatch();
    react.exports.useEffect(() => {
      dispatch({
        type: "RESET"
      });
      if (open)
        UniposAPI.getProfile().then((res) => dispatch({
          type: "SET_ME",
          me: res.result.member
        }));
    }, [open, dispatch]);
    return mode === "dialog" ? /* @__PURE__ */ jsx(ConsumerDialog, {
      open,
      onClose: doClose,
      changeMode,
      children: /* @__PURE__ */ jsx(ConsumerContent, {
        close: doClose
      })
    }) : /* @__PURE__ */ jsx(ConsumerWindow, {
      open,
      onClose: doClose,
      changeMode,
      children: /* @__PURE__ */ jsx(ConsumerContent, {
        close: doClose
      })
    });
  });
  ConsumerView.displayName = "ConsumerView";
  const Consumer = react.exports.memo(() => {
    return /* @__PURE__ */ jsx(ConsumerContextProvider, {
      children: /* @__PURE__ */ jsx(ConsumerImpl, {})
    });
  });
  Consumer.displayName = "Consumer";
  const ConsumerImpl = react.exports.memo(() => {
    const {
      open,
      mode
    } = useConsumerState();
    const dispatch = useConsumerDispatch();
    const clickTimer = react.exports.useRef(null);
    const handleClick = react.exports.useCallback((e2) => {
      if (!open) {
        dispatch({
          type: "CHANGE_OPEN"
        });
      } else {
        if (e2.detail === 1) {
          if (clickTimer.current != null)
            clearTimeout(clickTimer.current);
          clickTimer.current = setTimeout(() => {
            dispatch({
              type: "CHANGE_OPEN"
            });
            clickTimer.current = null;
          }, 150);
        } else if (e2.detail === 2) {
          if (clickTimer.current != null) {
            clearTimeout(clickTimer.current);
            clickTimer.current = null;
          }
          dispatch({
            type: "SET_POS",
            pos: void 0
          });
        }
      }
    }, [dispatch, open]);
    const close = react.exports.useCallback(() => dispatch({
      type: "CHANGE_OPEN",
      force: false
    }), [dispatch]);
    const changeMode = react.exports.useCallback(() => dispatch({
      type: "CHANGE_MODE"
    }), [dispatch]);
    react.exports.useEffect(
      () => () => {
        if (clickTimer.current != null) {
          clearTimeout(clickTimer.current);
          clickTimer.current = null;
        }
      },
      []
    );
    return /* @__PURE__ */ jsxs(react.exports.Fragment, {
      children: [/* @__PURE__ */ jsx(FooterButton, {
        text: "\u4E00\u62EC\u62CD\u624B",
        icon: /* @__PURE__ */ jsx(default_1$7, {}),
        onClick: handleClick
      }), /* @__PURE__ */ jsx(ConsumerView, {
        open,
        doClose: close,
        mode,
        changeMode
      })]
    });
  });
  ConsumerImpl.displayName = "ConsumerImpl";
  var HelpOutline = {};
  var _interopRequireDefault = interopRequireDefault.exports;
  Object.defineProperty(HelpOutline, "__esModule", {
    value: true
  });
  var default_1 = HelpOutline.default = void 0;
  var _createSvgIcon = _interopRequireDefault(requireCreateSvgIcon());
  var _jsxRuntime = require$$2;
  var _default = (0, _createSvgIcon.default)(/* @__PURE__ */ (0, _jsxRuntime.jsx)("path", {
    d: "M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"
  }), "HelpOutline");
  default_1 = HelpOutline.default = _default;
  const Support = react.exports.memo(() => {
    const [button, setButton] = react.exports.useState();
    const [disabled, setDisabled] = react.exports.useState(false);
    const handleClick = react.exports.useCallback(() => {
      button == null ? void 0 : button.click();
    }, [button]);
    react.exports.useEffect(() => {
      const ms = Preferences.try_interval;
      const i = setInterval(() => {
        var _a;
        const iframe = UIs.find("SUPPORT");
        const button2 = (_a = iframe == null ? void 0 : iframe.contentDocument) == null ? void 0 : _a.querySelector("button");
        const parent = iframe == null ? void 0 : iframe.parentElement;
        if (iframe && parent && button2) {
          clearInterval(i);
          UIs.class(iframe, "+", "HIDDEN");
          setButton(button2);
          const obs = new MutationObserver(() => {
            if (parent.childElementCount === 1)
              setDisabled(false);
            else
              setDisabled(true);
          });
          obs.observe(parent, {
            childList: true
          });
          return () => {
            obs.disconnect();
            UIs.class(iframe, "-", "HIDDEN");
          };
        }
      }, ms);
    }, []);
    return /* @__PURE__ */ jsx(
      FooterButton,
      {
        text: "\u30B5\u30DD\u30FC\u30C8",
        icon: /* @__PURE__ */ jsx(default_1, {}),
        onClick: handleClick,
        disabled
      }
    );
  });
  Support.displayName = "Support";
  const _View = class extends react.exports.Component {
    static get root() {
      if (__privateGet(this, _root))
        return __privateGet(this, _root);
      const container = UIs.create("div").appendTo(document.body).done();
      return __privateSet(this, _root, createRoot(container));
    }
    constructor(props) {
      super(props);
    }
    render() {
      return /* @__PURE__ */ jsxs(react.exports.Fragment, {
        children: [/* @__PURE__ */ jsx(GlobalStyle, {}), /* @__PURE__ */ jsxs(Footer, {
          children: [/* @__PURE__ */ jsx(Consumer, {}), /* @__PURE__ */ jsx(Support, {})]
        })]
      });
    }
  };
  let View = _View;
  _root = new WeakMap();
  _on = new WeakMap();
  __privateAdd(View, _root, void 0);
  __privateAdd(View, _on, false);
  __publicField(View, "on", () => {
    if (__privateGet(_View, _on))
      return;
    _View.root.render(/* @__PURE__ */ jsx(_View, {}));
    __privateSet(_View, _on, true);
  });
  __publicField(View, "off", () => {
    if (!__privateGet(_View, _on))
      return;
    _View.root.unmount();
    __privateSet(_View, _on, false);
  });
  (async function main2() {
    await Preferences.init();
    Logger.info(`WebExtension "${"Advanced Unipos"}" has been loaded`);
    Logger.debug(`This extension was built in ${"production"} mode.`);
    Logger.debug(`Preferences: ${Preferences.str()}`);
    if (!UniposAPI.ready) {
      Logger.warn("Extensions are not available on this page.");
      return;
    }
    setTimeout(View.on, 500);
  })();
})();
