import { M as MessageListener, A as AlarmListener, N as NotificationListener } from "./message-listener.73afd8b2.js";
(function main() {
  const listeners = [
    new MessageListener(),
    new AlarmListener(),
    new NotificationListener()
  ];
  for (const l of listeners) {
    l.setup();
  }
})();
