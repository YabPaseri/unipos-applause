(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.ts.3a35470b.js")
    );
  })().catch(console.error);

})();
