import './assets/service-worker.ts.b2721ba2.js';
