(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.ts.2b333de8.js")
    );
  })().catch(console.error);

})();
