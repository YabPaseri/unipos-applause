import { P as Preferences, L as Logger, u as parse } from "./logger.2400d0e2.js";
(async function main() {
  await Preferences.init();
  chrome.runtime.onMessage.addListener(async (message, _, sendResponse) => {
    Logger.debug("background received message:", JSON.stringify(message));
    switch (message.summary) {
      case "update-alarm": {
        sendResponse(JSON.stringify({ from: "service", summary: "update-alarm", result: await updateAlarm() }));
        break;
      }
    }
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "Advanced Unipos") {
      chrome.notifications.create("Advanced Unipos", {
        title: "Unipos\u306E\u62CD\u624B\u306F\u304A\u5FD8\u308C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u304B?",
        message: "\u30BB\u30C3\u30C8\u3057\u305F\u65E5\u6642\u306B\u306A\u308A\u307E\u3057\u305F\u3002\nUnipos\u3092\u8997\u3044\u3066\u307F\u307E\u3057\u3087\u3046",
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon128.png"),
        eventTime: Date.now(),
        priority: 2,
        silent: false
      });
    }
  });
  chrome.notifications.onClicked.addListener(async (id) => {
    if (id === "Advanced Unipos") {
      chrome.tabs.create({ active: true, url: "https://unipos.me/all" });
    }
  });
})();
async function updateAlarm() {
  Logger.debug("#update Alarm...");
  await Preferences.reload();
  await chrome.alarms.clearAll();
  if (Preferences.alarm_active) {
    const d = parse(Preferences.alarm_time, "HHmm", new Date());
    d.setSeconds(0, 0);
    const w = Preferences.alarm_wday;
    for (; d.getDay() !== w || d.getTime() < Date.now(); d.setDate(d.getDate() + 1)) {
    }
    chrome.alarms.create("Advanced Unipos", {
      when: d.getTime(),
      periodInMinutes: 10080
    });
    Logger.info(`update alarm. first is ${JSON.stringify(d)}`);
    return d;
  }
  Logger.debug(`removed alarm`);
  return null;
}
